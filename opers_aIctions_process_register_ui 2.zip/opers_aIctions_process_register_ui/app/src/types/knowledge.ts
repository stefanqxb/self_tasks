export interface SystemMeta {
  id: string;
  name: string;
  domain: string;
  owner: string;
  description: string;
  techStack: string[];
  environment: string;
  lifecycle: string;
  onboardingMethod: string;
  mcpServerUrl?: string;
}

export interface IntegrationConfig {
  authType: string;
  baseUrl: string;
  timeout: number;
  rateLimit: string;
  retryPolicy: string;
}

export interface ActivityItem {
  id: string;
  action: string;
  timestamp: string;
}

export interface CapabilityUseCase {
  trigger: string;
  flow: string;
}

export interface Capability {
  id: string;
  name: string;
  description: string;
  exposedVia: 'MCP Tool' | 'REST API' | 'Event' | 'File';
  input: string;
  output: string;
  tags: string[];
  constraints: string[];
  dependencies: string[];
  useCases: CapabilityUseCase[];
}

export interface ApiParam {
  name: string;
  type: string;
  required: boolean;
  description: string;
}

export interface ApiEndpoint {
  id: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  path: string;
  name: string;
  description: string;
  params: {
    path: ApiParam[];
    query: ApiParam[];
    body: ApiParam[];
  };
  requestExample: string;
  responseExample: string;
  curlExample: string;
  capabilityId: string;
}

export interface EntityField {
  name: string;
  type: string;
  format: string;
  example: string;
  mapsTo: string;
}

export interface ValidationRule {
  id: string;
  name: string;
  condition: string;
  action: 'ALLOW' | 'REJECT' | 'WARN';
  message: string;
}

export interface SystemDocument {
  id: string;
  name: string;
  type: 'business' | 'technical' | 'operational' | 'api-spec';
  size: string;
  source?: 'manual' | 'local' | 'confluence';
  url?: string;
}

export interface SemanticTag {
  keyword: string;
  synonyms: string[];
  relatedConcepts: string[];
}

export interface SystemKnowledge {
  meta: SystemMeta;
  integration: IntegrationConfig;
  activities: ActivityItem[];
  capabilities: Capability[];
  endpoints: ApiEndpoint[];
  rules: ValidationRule[];
  documents: SystemDocument[];
  semanticTags: SemanticTag[];
}
