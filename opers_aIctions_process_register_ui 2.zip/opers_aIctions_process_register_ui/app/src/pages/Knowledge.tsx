import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Info,
  Layers,
  Code,
  ShieldAlert,
  FileText,
  Plus,
  Search,
  ChevronDown,
  Copy,
  Check,
  ArrowRight,
  Link2,
  AlertTriangle,
  Zap,
  Clock,
  Pencil,
  X,
  Trash2,
  Upload,
  Link,
} from 'lucide-react';
import Layout from '@/components/Layout';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import type {
  SystemKnowledge,
  Capability,
  ApiEndpoint,
  ApiParam,
  ValidationRule,
  SystemDocument,
  ActivityItem,
} from '@/types/knowledge';
import OnboardingWizard from '@/components/OnboardingWizard';

// ─── easing ─────────────────────────────────────────────────────────────────
const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number];

// ─── Tab definition ─────────────────────────────────────────────────────────
const TABS = [
  { id: 'overview', label: 'Overview', icon: Info },
  { id: 'capabilities', label: 'Capabilities', icon: Layers },
  { id: 'endpoints', label: 'Endpoints', icon: Code },

  { id: 'rules', label: 'Rules', icon: ShieldAlert },
  { id: 'documents', label: 'Documents', icon: FileText },

];

// ─── Color helpers ──────────────────────────────────────────────────────────
const SYSTEM_COLORS: Record<string, string> = {
  qtrack: '#6366F1',
  transformer: '#10B981',
  swb: '#8B5CF6',
  sire: '#EF4444',
  opas: '#06B6D4',
  goldeneye: '#F97316',
};

const METHOD_COLORS: Record<string, string> = {
  GET: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  POST: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  PUT: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  DELETE: 'bg-red-500/20 text-red-400 border-red-500/30',
  PATCH: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
};

const ACTION_COLORS: Record<string, string> = {
  ALLOW: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  REJECT: 'bg-red-500/20 text-red-400 border-red-500/30',
  WARN: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
};

const EXPOSED_VIA_COLORS: Record<string, string> = {
  'MCP Tool': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  'REST API': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  'Event': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  'File': 'bg-gray-500/20 text-gray-400 border-gray-500/30',
};

const DOCUMENT_COLORS: Record<string, string> = {
  business: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  technical: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  operational: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  'api-spec': 'bg-orange-500/20 text-orange-400 border-orange-500/30',
};

// ─── Mock Data ──────────────────────────────────────────────────────────────

const INITIAL_SYSTEMS: SystemKnowledge[] = [
  {
    meta: {
      id: 'qtrack',
      name: 'QTrack',
      domain: 'email-management',
      owner: 'Platform Team',
      description:
        'Intelligent email management system that handles the full lifecycle of email communication. Receives, prioritizes, and processes emails with AI-powered classification.',
      techStack: ['Node.js', 'Express', 'PostgreSQL', 'Redis'],
      environment: 'Production',
      lifecycle: 'Active',
      onboardingMethod: 'manual',
    },
    integration: {
      authType: 'api-key',
      baseUrl: 'https://api.qtrack.internal',
      timeout: 30000,
      rateLimit: '1000/min',
      retryPolicy: '3 retries, exponential backoff',
    },
    activities: [
      { id: 'a1', action: 'Capability "Send/Reply Email" updated', timestamp: '2 hours ago' },
      { id: 'a2', action: 'Document "API Guide" uploaded', timestamp: '1 day ago' },
      { id: 'a3', action: 'Endpoint POST /v1/emails added', timestamp: '2 days ago' },
    ],
    capabilities: [
      {
        id: 'c1',
        name: 'Receive Email',
        description: 'Receives incoming emails from various sources and stores them for processing.',
        exposedVia: 'REST API',
        input: 'Email content (MIME, headers)',
        output: 'Stored email record with ID',
        tags: ['email', 'receive', 'ingestion'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'Incoming email arrives', flow: 'Parse MIME → Extract headers → Store → Return ID' },
        ],
      },
      {
        id: 'c2',
        name: 'Prioritize Email',
        description: 'Uses AI to analyze and assign priority scores to emails based on urgency and content.',
        exposedVia: 'REST API',
        input: 'Email record ID',
        output: 'Priority score (1-5) + category',
        tags: ['email', 'ai', 'priority'],
        constraints: ['Requires valid email record'],
        dependencies: ['QTrack Receive Email'],
        useCases: [
          { trigger: 'Email received', flow: 'Fetch email → AI analysis → Score → Update record' },
        ],
      },
      {
        id: 'c3',
        name: 'Send/Reply Email',
        description: 'Composes and sends outbound emails or replies to existing threads.',
        exposedVia: 'REST API',
        input: 'Recipient, subject, body, thread ID (optional)',
        output: 'Sent email confirmation + message ID',
        tags: ['email', 'send', 'reply', 'outbound'],
        constraints: ['Valid SMTP configuration required'],
        dependencies: [],
        useCases: [
          { trigger: 'User requests reply', flow: 'Compose → Validate → Send SMTP → Confirm' },
          { trigger: 'Automated notification', flow: 'Template render → Send → Log' },
        ],
      },
    ],
    endpoints: [
      {
        id: 'e1',
        method: 'POST',
        path: '/v1/emails/receive',
        name: 'Receive Email',
        description: 'Receive and store an incoming email',
        params: {
          path: [],
          query: [],
          body: [
            { name: 'from', type: 'string', required: true, description: 'Sender address' },
            { name: 'to', type: 'string[]', required: true, description: 'Recipients' },
            { name: 'subject', type: 'string', required: true, description: 'Subject line' },
            { name: 'body', type: 'string', required: true, description: 'Email body' },
          ],
        },
        requestExample: '{\n  "from": "sender@example.com",\n  "to": ["team@company.com"],\n  "subject": "Invoice #12345",\n  "body": "Please find attached invoice..."\n}',
        responseExample: '{\n  "id": "eml_abc123",\n  "status": "received",\n  "receivedAt": "2025-01-15T10:30:00Z"\n}',
        curlExample: 'curl -X POST https://api.qtrack.internal/v1/emails/receive \\\n  -H "X-API-Key: YOUR_KEY" \\\n  -d \'{ "from": "a@b.com", "to": ["c@d.com"], "subject": "Hi", "body": "Hello" }\'',
        capabilityId: 'c1',
      },
      {
        id: 'e2',
        method: 'POST',
        path: '/v1/emails/prioritize',
        name: 'Prioritize Email',
        description: 'Analyze and assign priority to an email',
        params: {
          path: [],
          query: [],
          body: [
            { name: 'emailId', type: 'string', required: true, description: 'Email record ID' },
          ],
        },
        requestExample: '{\n  "emailId": "eml_abc123"\n}',
        responseExample: '{\n  "emailId": "eml_abc123",\n  "priority": 4,\n  "category": "urgent",\n  "confidence": 0.92\n}',
        curlExample: 'curl -X POST https://api.qtrack.internal/v1/emails/prioritize \\\n  -H "X-API-Key: YOUR_KEY" \\\n  -d \'{ "emailId": "eml_abc123" }\'',
        capabilityId: 'c2',
      },
      {
        id: 'e3',
        method: 'POST',
        path: '/v1/emails/send',
        name: 'Send Email',
        description: 'Send an outbound email',
        params: {
          path: [],
          query: [],
          body: [
            { name: 'to', type: 'string[]', required: true, description: 'Recipients' },
            { name: 'subject', type: 'string', required: true, description: 'Subject' },
            { name: 'body', type: 'string', required: true, description: 'Body content' },
          ],
        },
        requestExample: '{\n  "to": ["user@example.com"],\n  "subject": "Status Update",\n  "body": "Your request has been processed."\n}',
        responseExample: '{\n  "messageId": "msg_xyz789",\n  "status": "sent",\n  "sentAt": "2025-01-15T10:35:00Z"\n}',
        curlExample: 'curl -X POST https://api.qtrack.internal/v1/emails/send \\\n  -H "X-API-Key: YOUR_KEY" \\\n  -d \'{ "to": ["user@example.com"], "subject": "Hi", "body": "Hello" }\'',
        capabilityId: 'c3',
      },
    ],
    rules: [],
    documents: [
      { id: 'd1', name: 'API Guide', type: 'business', size: '2.4 MB' },
      { id: 'd2', name: 'Architecture Overview', type: 'technical', size: '1.8 MB' },
      { id: 'd3', name: 'Operations Manual', type: 'operational', size: '845 KB' },
    ],
    semanticTags: [
      {
        keyword: 'email',
        synonyms: ['mail', 'message', 'inbox', 'correspondence'],
        relatedConcepts: ['communication', 'notification', 'alert'],
      },
      {
        keyword: 'prioritize',
        synonyms: ['rank', 'sort', 'triage'],
        relatedConcepts: ['urgency', 'importance'],
      },
    ],
  },
  {
    meta: {
      id: 'transformer',
      name: 'Transformer',
      domain: 'data-transformation',
      owner: 'Data Team',
      description: 'Handles data transformation across multiple formats including Excel, PDF, and batch processing pipelines.',
      techStack: ['Python', 'FastAPI', 'Pandas', 'Apache Spark'],
      environment: 'Production',
      lifecycle: 'Active',
      onboardingMethod: 'openapi',
    },
    integration: {
      authType: 'bearer',
      baseUrl: 'https://api.transformer.internal',
      timeout: 60000,
      rateLimit: '500/min',
      retryPolicy: '3 retries, linear backoff',
    },
    activities: [
      { id: 'a1', action: 'OpenAPI spec updated to v2.3', timestamp: '1 day ago' },
      { id: 'a2', action: 'Batch Processing capability expanded', timestamp: '3 days ago' },
    ],
    capabilities: [
      {
        id: 'c1',
        name: 'Transform Excel',
        description: 'Converts Excel files (.xlsx, .xls) to structured JSON or CSV formats.',
        exposedVia: 'REST API',
        input: 'Excel file binary',
        output: 'Structured JSON with sheet data',
        tags: ['excel', 'transform', 'spreadsheet'],
        constraints: ['Max file size: 50MB', 'Max 100 sheets'],
        dependencies: [],
        useCases: [
          { trigger: 'Excel upload', flow: 'Upload → Parse sheets → Extract data → Return JSON' },
        ],
      },
      {
        id: 'c2',
        name: 'Transform PDF',
        description: 'Extracts text, tables, and structured data from PDF documents.',
        exposedVia: 'REST API',
        input: 'PDF file binary',
        output: 'Extracted text + tables + metadata',
        tags: ['pdf', 'transform', 'extraction'],
        constraints: ['Max file size: 100MB', 'Scanned PDFs require OCR'],
        dependencies: [],
        useCases: [
          { trigger: 'PDF upload', flow: 'Upload → Parse → Extract text/tables → Return structured' },
        ],
      },
      {
        id: 'c3',
        name: 'Batch Processing',
        description: 'Processes multiple files in a single batch job with progress tracking.',
        exposedVia: 'REST API',
        input: 'Array of file references + config',
        output: 'Batch job ID + progress tracker',
        tags: ['batch', 'pipeline', 'async'],
        constraints: ['Max 1000 files per batch'],
        dependencies: ['Transformer Excel', 'Transformer PDF'],
        useCases: [
          { trigger: 'Bulk upload request', flow: 'Queue files → Process parallel → Aggregate → Notify' },
        ],
      },
    ],
    endpoints: [
      {
        id: 'e1',
        method: 'POST',
        path: '/v1/transform/excel',
        name: 'Transform Excel',
        description: 'Convert Excel to structured data',
        params: { path: [], query: [], body: [{ name: 'file', type: 'file', required: true, description: 'Excel file' }] },
        requestExample: '{\n  "file": "<binary>"\n}',
        responseExample: '{\n  "sheets": [{"name": "Sheet1", "rows": 150, "data": [...]}]\n}',
        curlExample: 'curl -X POST https://api.transformer.internal/v1/transform/excel \\\n  -H "Authorization: Bearer TOKEN" \\\n  -F "file=@data.xlsx"',
        capabilityId: 'c1',
      },
      {
        id: 'e2',
        method: 'POST',
        path: '/v1/transform/pdf',
        name: 'Transform PDF',
        description: 'Extract structured data from PDF',
        params: { path: [], query: [], body: [{ name: 'file', type: 'file', required: true, description: 'PDF file' }] },
        requestExample: '{\n  "file": "<binary>"\n}',
        responseExample: '{\n  "text": "...",\n  "tables": [...],\n  "metadata": {...}\n}',
        curlExample: 'curl -X POST https://api.transformer.internal/v1/transform/pdf \\\n  -H "Authorization: Bearer TOKEN" \\\n  -F "file=@doc.pdf"',
        capabilityId: 'c2',
      },
    ],
    rules: [],
    documents: [
      { id: 'd1', name: 'OpenAPI Spec', type: 'api-spec', size: '156 KB' },
      { id: 'd2', name: 'Batch Processing Guide', type: 'technical', size: '3.2 MB' },
    ],
    semanticTags: [
      { keyword: 'transform', synonyms: ['convert', 'transcode'], relatedConcepts: ['ETL', 'pipeline'] },
      { keyword: 'excel', synonyms: ['spreadsheet', 'xlsx'], relatedConcepts: ['data', 'sheet'] },
    ],
  },
  {
    meta: {
      id: 'swb',
      name: 'SWB',
      domain: 'information-extraction',
      owner: 'AI Team',
      description: 'Smart Workbench for intelligent information extraction from documents. Uses MCP for AI-native tool integration.',
      techStack: ['Python', 'LangChain', 'OpenAI', 'PostgreSQL'],
      environment: 'Production',
      lifecycle: 'Active',
      onboardingMethod: 'mcp',
      mcpServerUrl: 'http://swb.internal:8080/mcp',
    },
    integration: {
      authType: 'api-key',
      baseUrl: 'http://swb.internal:8080',
      timeout: 120000,
      rateLimit: '200/min',
      retryPolicy: '2 retries',
    },
    activities: [
      { id: 'a1', action: 'MCP server config updated', timestamp: '5 hours ago' },
      { id: 'a2', action: 'Extract PDF capability improved', timestamp: '2 days ago' },
    ],
    capabilities: [
      {
        id: 'c1',
        name: 'Extract PDF',
        description: 'Extracts structured information from PDF documents using AI models.',
        exposedVia: 'MCP Tool',
        input: 'PDF file URL or binary',
        output: 'Structured extracted data',
        tags: ['pdf', 'extraction', 'ai', 'mcp'],
        constraints: ['Max 500 pages per PDF'],
        dependencies: [],
        useCases: [
          { trigger: 'PDF document received', flow: 'Load → AI parse → Extract fields → Return JSON' },
        ],
      },
      {
        id: 'c2',
        name: 'Extract Email',
        description: 'Extracts entities and structured data from email content.',
        exposedVia: 'MCP Tool',
        input: 'Email content (text + headers)',
        output: 'Extracted entities (people, dates, amounts)',
        tags: ['email', 'extraction', 'entities', 'mcp'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'Email needs parsing', flow: 'Parse content → AI NER → Extract entities → Return' },
        ],
      },
      {
        id: 'c3',
        name: 'Batch Extract',
        description: 'Batch processes multiple documents for information extraction.',
        exposedVia: 'MCP Tool',
        input: 'Array of document references',
        output: 'Array of extraction results',
        tags: ['batch', 'extraction', 'mcp'],
        constraints: ['Max 500 documents per batch'],
        dependencies: ['SWB Extract PDF', 'SWB Extract Email'],
        useCases: [
          { trigger: 'Bulk extraction request', flow: 'Queue docs → Parallel extract → Aggregate → Return' },
        ],
      },
    ],
    endpoints: [],
    rules: [],
    documents: [
      { id: 'd1', name: 'MCP Integration Guide', type: 'technical', size: '1.2 MB' },
      { id: 'd2', name: 'Extraction Models', type: 'technical', size: '890 KB' },
    ],
    semanticTags: [
      { keyword: 'extract', synonyms: ['parse', 'mine', 'retrieve'], relatedConcepts: ['NLP', 'NER', 'AI'] },
      { keyword: 'MCP', synonyms: ['Model Context Protocol'], relatedConcepts: ['AI tools', 'integration'] },
    ],
  },
  {
    meta: {
      id: 'sire',
      name: 'SIRE',
      domain: 'reconciliation-engine',
      owner: 'Operations Team',
      description: 'Trade and settlement reconciliation engine. Compares data from multiple sources to identify breaks and discrepancies.',
      techStack: ['Java', 'Spring Boot', 'Oracle', 'Kafka'],
      environment: 'Production',
      lifecycle: 'Active',
      onboardingMethod: 'manual',
    },
    integration: {
      authType: 'oauth2',
      baseUrl: 'https://api.sire.internal',
      timeout: 45000,
      rateLimit: '300/min',
      retryPolicy: '3 retries, exponential backoff',
    },
    activities: [
      { id: 'a1', action: 'Validation rule R3 updated', timestamp: '1 hour ago' },
      { id: 'a2', action: 'Break Management capability added', timestamp: '1 day ago' },
    ],
    capabilities: [
      {
        id: 'c1',
        name: 'Trade Reconcile',
        description: 'Compares trade data between two sources and identifies discrepancies.',
        exposedVia: 'REST API',
        input: 'Two trade data sources',
        output: 'Reconciliation report with breaks',
        tags: ['trade', 'reconcile', 'compare'],
        constraints: ['Requires exactly 2 input sources', 'Output is reconciliation report only, not for downstream processing'],
        dependencies: ['GoldenEye'],
        useCases: [
          { trigger: 'End-of-day reconciliation', flow: 'Fetch source A → Fetch source B → Compare → Generate report' },
        ],
      },
      {
        id: 'c2',
        name: 'Settlement Reconcile',
        description: 'Reconciles settlement instructions against actual settlement data.',
        exposedVia: 'REST API',
        input: 'Settlement instructions + actuals',
        output: 'Settlement reconciliation report',
        tags: ['settlement', 'reconcile', 'instructions'],
        constraints: ['Requires exactly 2 input sources', 'Output is reconciliation report only, not for downstream processing'],
        dependencies: ['OPAS'],
        useCases: [
          { trigger: 'Settlement date reached', flow: 'Fetch instructions → Fetch actuals → Match → Report breaks' },
        ],
      },
      {
        id: 'c3',
        name: 'Break Management',
        description: 'Manages identified breaks including assignment, tracking, and resolution.',
        exposedVia: 'REST API',
        input: 'Break record IDs + actions',
        output: 'Updated break status',
        tags: ['break', 'management', 'workflow'],
        constraints: [],
        dependencies: ['SIRE Trade Reconcile', 'SIRE Settlement Reconcile'],
        useCases: [
          { trigger: 'Break identified', flow: 'Create break → Assign → Track → Resolve → Close' },
        ],
      },
    ],
    endpoints: [
      {
        id: 'e1',
        method: 'POST',
        path: '/v1/reconcile/trades',
        name: 'Trade Reconcile',
        description: 'Run trade reconciliation between two sources',
        params: {
          path: [],
          query: [],
          body: [
            { name: 'sourceA', type: 'string', required: true, description: 'First source identifier' },
            { name: 'sourceB', type: 'string', required: true, description: 'Second source identifier' },
            { name: 'tradeDate', type: 'string', required: true, description: 'Trade date (YYYY-MM-DD)' },
          ],
        },
        requestExample: '{\n  "sourceA": "goldeneye",\n  "sourceB": "external",\n  "tradeDate": "2025-01-15"\n}',
        responseExample: '{\n  "reportId": "rep_001",\n  "matches": 145,\n  "breaks": 3,\n  "breakDetails": [...]\n}',
        curlExample: 'curl -X POST https://api.sire.internal/v1/reconcile/trades \\\n  -H "Authorization: Bearer TOKEN" \\\n  -d \'{ "sourceA": "goldeneye", "sourceB": "external", "tradeDate": "2025-01-15" }\'',
        capabilityId: 'c1',
      },
    ],
    rules: [
      { id: 'R1', name: 'Min 2 Inputs', condition: 'inputs.count < 2', action: 'REJECT', message: 'SIRE requires exactly 2 input sources' },
      { id: 'R2', name: 'Max 2 Inputs', condition: 'inputs.count > 2', action: 'REJECT', message: 'SIRE requires exactly 2 input sources' },
      { id: 'R3', name: 'No Downstream', condition: 'output.connected == true', action: 'WARN', message: 'SIRE output is a report, should not connect to downstream systems' },
    ],
    documents: [
      { id: 'd1', name: 'Reconciliation Process', type: 'business', size: '3.5 MB' },
      { id: 'd2', name: 'Break Management Flow', type: 'technical', size: '2.1 MB' },
    ],
    semanticTags: [
      { keyword: 'reconcile', synonyms: ['match', 'compare', 'validate'], relatedConcepts: ['break', 'discrepancy', ' matching'] },
      { keyword: 'break', synonyms: ['discrepancy', 'mismatch', 'exception'], relatedConcepts: ['resolution', 'workflow'] },
    ],
  },
  {
    meta: {
      id: 'opas',
      name: 'OPAS',
      domain: 'payment-storage',
      owner: 'Finance Team',
      description: 'Payment and settlement data storage system. Manages settlement records and payment instructions.',
      techStack: ['Java', 'Spring Boot', 'PostgreSQL', 'Redis'],
      environment: 'Production',
      lifecycle: 'Active',
      onboardingMethod: 'manual',
    },
    integration: {
      authType: 'api-key',
      baseUrl: 'https://api.opas.internal',
      timeout: 30000,
      rateLimit: '500/min',
      retryPolicy: '3 retries',
    },
    activities: [
      { id: 'a1', action: 'Settlement entity updated', timestamp: '3 hours ago' },
      { id: 'a2', action: 'Standalone Allowed rule added', timestamp: '1 day ago' },
    ],
    capabilities: [
      {
        id: 'c1',
        name: 'List Settlement',
        description: 'Lists all settlement records with optional filtering.',
        exposedVia: 'REST API',
        input: 'Filter criteria (date, status, counterparty)',
        output: 'Paginated settlement list',
        tags: ['settlement', 'list', 'query'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'User requests settlement list', flow: 'Apply filters → Query DB → Return paginated results' },
        ],
      },
      {
        id: 'c2',
        name: 'Get Settlement',
        description: 'Retrieves a single settlement record by ID.',
        exposedVia: 'REST API',
        input: 'Settlement ID',
        output: 'Settlement record details',
        tags: ['settlement', 'get', 'read'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'User views settlement details', flow: 'Fetch by ID → Enrich → Return' },
        ],
      },
      {
        id: 'c3',
        name: 'Set Settlement',
        description: 'Creates or updates a settlement record.',
        exposedVia: 'REST API',
        input: 'Settlement data (amount, currency, date, counterparty)',
        output: 'Created/updated settlement record',
        tags: ['settlement', 'create', 'update'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'New settlement booked', flow: 'Validate → Save → Confirm' },
        ],
      },
      {
        id: 'c4',
        name: 'List Payment',
        description: 'Lists all payment records with optional filtering.',
        exposedVia: 'REST API',
        input: 'Filter criteria (date, status, type)',
        output: 'Paginated payment list',
        tags: ['payment', 'list', 'query'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'User requests payment list', flow: 'Apply filters → Query DB → Return' },
        ],
      },
      {
        id: 'c5',
        name: 'Set Payment',
        description: 'Creates or updates a payment instruction.',
        exposedVia: 'REST API',
        input: 'Payment data (amount, currency, beneficiary, account)',
        output: 'Created/updated payment record',
        tags: ['payment', 'create', 'update'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'Payment instruction received', flow: 'Validate → Enrich → Save → Confirm' },
        ],
      },
    ],
    endpoints: [
      {
        id: 'e1',
        method: 'GET',
        path: '/v1/settlements',
        name: 'List Settlements',
        description: 'List settlement records',
        params: {
          path: [],
          query: [
            { name: 'tradeDate', type: 'string', required: false, description: 'Filter by trade date' },
            { name: 'status', type: 'string', required: false, description: 'Filter by status' },
          ],
          body: [],
        },
        requestExample: 'GET /v1/settlements?tradeDate=2025-01-15&status=pending',
        responseExample: '{\n  "items": [...],\n  "total": 45,\n  "page": 1\n}',
        curlExample: 'curl "https://api.opas.internal/v1/settlements?tradeDate=2025-01-15" \\\n  -H "X-API-Key: YOUR_KEY"',
        capabilityId: 'c1',
      },
    ],
    rules: [
      { id: 'R4', name: 'Standalone Allowed', condition: 'inputs.count == 0', action: 'ALLOW', message: 'OPAS can operate as a standalone data source' },
    ],
    documents: [
      { id: 'd1', name: 'Settlement API Guide', type: 'api-spec', size: '1.8 MB' },
      { id: 'd2', name: 'Payment Flow', type: 'business', size: '2.4 MB' },
    ],
    semanticTags: [
      { keyword: 'settlement', synonyms: ['settle', 'clearing'], relatedConcepts: ['trade', 'payment', 'T+2'] },
      { keyword: 'payment', synonyms: ['transfer', 'remittance', 'disbursement'], relatedConcepts: ['instructions', 'beneficiary'] },
    ],
  },
  {
    meta: {
      id: 'goldeneye',
      name: 'GoldenEye',
      domain: 'trade-storage',
      owner: 'Trading Team',
      description: 'Trade data storage and management system. Stores trade records, tracks lifecycle, and provides trade history and analytics.',
      techStack: ['Java', 'Spring Boot', 'MongoDB', 'Kafka'],
      environment: 'Production',
      lifecycle: 'Active',
      onboardingMethod: 'openapi',
    },
    integration: {
      authType: 'bearer',
      baseUrl: 'https://api.goldeneye.internal',
      timeout: 30000,
      rateLimit: '1000/min',
      retryPolicy: '3 retries, exponential backoff',
    },
    activities: [
      { id: 'a1', action: 'OpenAPI spec v3.1 published', timestamp: '6 hours ago' },
      { id: 'a2', action: 'Trade entity fields expanded', timestamp: '2 days ago' },
    ],
    capabilities: [
      {
        id: 'c1',
        name: 'List Trade',
        description: 'Lists all trade records with filtering and pagination.',
        exposedVia: 'REST API',
        input: 'Filter criteria (instrument, date, book)',
        output: 'Paginated trade list',
        tags: ['trade', 'list', 'query'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'User requests trade list', flow: 'Apply filters → Query → Return results' },
        ],
      },
      {
        id: 'c2',
        name: 'Get Trade',
        description: 'Retrieves a single trade record by ID.',
        exposedVia: 'REST API',
        input: 'Trade ID',
        output: 'Trade record details with history',
        tags: ['trade', 'get', 'read'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'User views trade details', flow: 'Fetch by ID → Enrich history → Return' },
        ],
      },
      {
        id: 'c3',
        name: 'Set Trade',
        description: 'Creates or updates a trade record.',
        exposedVia: 'REST API',
        input: 'Trade data (instrument, quantity, price, counterparty)',
        output: 'Created/updated trade record',
        tags: ['trade', 'create', 'update'],
        constraints: [],
        dependencies: [],
        useCases: [
          { trigger: 'New trade executed', flow: 'Validate → Enrich → Save → Confirm' },
          { trigger: 'Trade amendment', flow: 'Validate delta → Apply → Audit → Confirm' },
        ],
      },
    ],
    endpoints: [
      {
        id: 'e1',
        method: 'GET',
        path: '/v1/trades',
        name: 'List Trades',
        description: 'List trade records',
        params: {
          path: [],
          query: [
            { name: 'instrument', type: 'string', required: false, description: 'Filter by instrument' },
            { name: 'book', type: 'string', required: false, description: 'Filter by trading book' },
            { name: 'tradeDate', type: 'string', required: false, description: 'Filter by date' },
          ],
          body: [],
        },
        requestExample: 'GET /v1/trades?instrument=AAPL&book=EQUITY',
        responseExample: '{\n  "items": [...],\n  "total": 234,\n  "page": 1\n}',
        curlExample: 'curl "https://api.goldeneye.internal/v1/trades?instrument=AAPL" \\\n  -H "Authorization: Bearer TOKEN"',
        capabilityId: 'c1',
      },
      {
        id: 'e2',
        method: 'POST',
        path: '/v1/trades',
        name: 'Create Trade',
        description: 'Create a new trade record',
        params: {
          path: [],
          query: [],
          body: [
            { name: 'instrument', type: 'string', required: true, description: 'Instrument symbol' },
            { name: 'quantity', type: 'number', required: true, description: 'Trade quantity' },
            { name: 'price', type: 'number', required: true, description: 'Trade price' },
            { name: 'counterparty', type: 'string', required: true, description: 'Counterparty code' },
          ],
        },
        requestExample: '{\n  "instrument": "AAPL",\n  "quantity": 1000,\n  "price": 182.50,\n  "counterparty": "CPTY001"\n}',
        responseExample: '{\n  "id": "trd_001",\n  "status": "executed",\n  "executedAt": "2025-01-15T14:30:00Z"\n}',
        curlExample: 'curl -X POST https://api.goldeneye.internal/v1/trades \\\n  -H "Authorization: Bearer TOKEN" \\\n  -d \'{ "instrument": "AAPL", "quantity": 1000, "price": 182.50, "counterparty": "CPTY001" }\'',
        capabilityId: 'c3',
      },
    ],
    rules: [],
    documents: [
      { id: 'd1', name: 'OpenAPI Spec', type: 'api-spec', size: '234 KB' },
      { id: 'd2', name: 'Trade Data Model', type: 'technical', size: '3.1 MB' },
    ],
    semanticTags: [
      { keyword: 'trade', synonyms: ['transaction', 'deal', 'execution'], relatedConcepts: ['instrument', 'position', 'P&L'] },
      { keyword: 'instrument', synonyms: ['security', 'ticker', 'symbol'], relatedConcepts: ['asset', 'market'] },
    ],
  },
];

// ─── Tab 1: Overview ────────────────────────────────────────────────────────
function OverviewTab({ system }: { system: SystemKnowledge }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* Left: System Meta */}
      <div className="space-y-4">
        <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] p-5">
          <h3 className="text-sm font-semibold text-[#F8FAFC] mb-4 flex items-center gap-2">
            <Info className="w-4 h-4 text-[#6366F1]" />
            System Metadata
          </h3>
          <div className="space-y-3">
            {([
              ['Name', system.meta.name],
              ['Domain', system.meta.domain],
              ['Owner', system.meta.owner],
              ['Description', system.meta.description],
              ['Environment', system.meta.environment],
            ] as [string, string][]).map(([label, value]) => (
              <div key={label} className="flex flex-col gap-0.5">
                <span className="text-[11px] font-medium text-[#64748B] uppercase tracking-wider">{label}</span>
                <span className="text-[13px] text-[#E2E8F0]">{value}</span>
              </div>
            ))}
            <div className="flex flex-col gap-2 pt-1">
              <div className="flex items-center gap-2">
                <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                  {system.meta.lifecycle}
                </Badge>
                <Badge variant="outline" className="text-[#94A3B8] border-[#334155]">
                  {system.meta.onboardingMethod}
                </Badge>
                {system.meta.mcpServerUrl && (
                  <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                    MCP
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right: Activity + Semantic Tags */}
      <div className="space-y-4">
        <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] p-5">
          <h3 className="text-sm font-semibold text-[#F8FAFC] mb-4 flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#6366F1]" />
            Activity Feed
          </h3>
          <div className="space-y-3">
            {system.activities.map((activity: ActivityItem, i: number) => (
              <div key={activity.id} className="flex items-start gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-[#6366F1] mt-1.5 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-[13px] text-[#E2E8F0] leading-relaxed">{activity.action}</p>
                  <span className="text-[11px] text-[#64748B]">{activity.timestamp}</span>
                </div>
                {i === 0 && (
                  <span className="shrink-0 text-[10px] bg-[#6366F1]/20 text-[#818CF8] px-1.5 py-0.5 rounded">latest</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Semantic Tags */}
        <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] p-5">
          <h3 className="text-sm font-semibold text-[#F8FAFC] mb-4 flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#6366F1]" />
            Semantic Tags
          </h3>
          <div className="space-y-3">
            {system.semanticTags.map((tag, i) => (
              <div key={`${tag.keyword}-${i}`} className="rounded-lg bg-[#1E293B] p-3">
                <p className="text-[13px] font-semibold text-[#F8FAFC]">{tag.keyword}</p>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {tag.synonyms.map((s) => (
                    <Badge key={s} variant="outline" className="text-[10px] text-[#94A3B8] border-[#334155] px-1.5 py-0">
                      {s}
                    </Badge>
                  ))}
                </div>
                <p className="text-[11px] text-[#64748B] mt-1.5">
                  Related: {tag.relatedConcepts.join(', ')}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Tab 2: Capabilities ────────────────────────────────────────────────────
function ExposedViaBadge({ via }: { via: string }) {
  const cls = EXPOSED_VIA_COLORS[via] || 'bg-gray-500/20 text-gray-400 border-gray-500/30';
  return <Badge className={cls}>{via}</Badge>;
}

function CapabilityCard({ capability }: { capability: Capability }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-4 text-left hover:bg-[#1E293B]/50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <Zap className="w-4 h-4 text-[#6366F1]" />
          <span className="text-[14px] font-semibold text-[#F8FAFC]">{capability.name}</span>
          <ExposedViaBadge via={capability.exposedVia} />
        </div>
        <motion.div
          animate={{ rotate: open ? 180 : 0 }}
          transition={{ duration: 0.2, ease: EASE }}
        >
          <ChevronDown className="w-4 h-4 text-[#64748B]" />
        </motion.div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: EASE }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-4 border-t border-[#1E293B] pt-4">
              <p className="text-[13px] text-[#94A3B8] leading-relaxed">{capability.description}</p>

              {/* Input → Output */}
              <div className="flex items-center gap-3 rounded-lg bg-[#1E293B] p-3">
                <div className="flex-1">
                  <span className="text-[10px] font-medium text-[#64748B] uppercase tracking-wider">Input</span>
                  <p className="text-[13px] text-emerald-400 font-medium">{capability.input}</p>
                </div>
                <ArrowRight className="w-4 h-4 text-[#64748B] shrink-0" />
                <div className="flex-1">
                  <span className="text-[10px] font-medium text-[#64748B] uppercase tracking-wider">Output</span>
                  <p className="text-[13px] text-blue-400 font-medium">{capability.output}</p>
                </div>
              </div>

              {/* Tags */}
              {capability.tags.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {capability.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="text-[#94A3B8] border-[#334155]">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Constraints */}
              {capability.constraints.length > 0 && (
                <div className="space-y-2">
                  {capability.constraints.map((c, i) => (
                    <div key={i} className="flex items-center gap-2 text-yellow-400 text-[13px]">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      {c}
                    </div>
                  ))}
                </div>
              )}

              {/* Dependencies */}
              {capability.dependencies.length > 0 && (
                <div className="flex items-center gap-2 flex-wrap">
                  <Link2 className="w-4 h-4 text-[#64748B]" />
                  <span className="text-[11px] text-[#64748B]">Depends on:</span>
                  {capability.dependencies.map((dep) => (
                    <Badge key={dep} className="bg-[#1E293B] text-[#A5B4FC] border-[#334155]">
                      {dep}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Use Cases */}
              {capability.useCases.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[11px] font-medium text-[#64748B] uppercase tracking-wider">Use Cases</span>
                  {capability.useCases.map((uc, i) => (
                    <div key={i} className="flex items-center gap-2 text-[13px]">
                      <span className="text-[#F8FAFC] font-medium">{uc.trigger}</span>
                      <ArrowRight className="w-3 h-3 text-[#64748B]" />
                      <span className="text-[#94A3B8]">{uc.flow}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function CapabilitiesTab({ system }: { system: SystemKnowledge }) {
  return (
    <div className="space-y-3">
      {system.capabilities.map((cap) => (
        <CapabilityCard key={cap.id} capability={cap} />
      ))}
    </div>
  );
}

// ─── Tab 3: Endpoints ───────────────────────────────────────────────────────
function EndpointCard({ endpoint }: { endpoint: ApiEndpoint }) {
  const [open, setOpen] = useState(false);
  const [copiedReq, setCopiedReq] = useState(false);
  const [copiedRes, setCopiedRes] = useState(false);
  const [copiedCurl, setCopiedCurl] = useState(false);

  const handleCopy = async (text: string, setter: (v: boolean) => void) => {
    await navigator.clipboard.writeText(text);
    setter(true);
    setTimeout(() => setter(false), 1500);
  };

  return (
    <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-4 text-left hover:bg-[#1E293B]/50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <Badge className={METHOD_COLORS[endpoint.method] || ''}>{endpoint.method}</Badge>
          <span className="text-[13px] font-mono text-[#E2E8F0]">{endpoint.path}</span>
          <span className="text-[13px] text-[#94A3B8]">{endpoint.name}</span>
        </div>
        <motion.div
          animate={{ rotate: open ? 180 : 0 }}
          transition={{ duration: 0.2, ease: EASE }}
        >
          <ChevronDown className="w-4 h-4 text-[#64748B]" />
        </motion.div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: EASE }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-4 border-t border-[#1E293B] pt-4">
              <p className="text-[13px] text-[#94A3B8]">{endpoint.description}</p>

              {/* Params */}
              {Object.entries(endpoint.params).some(([, v]) => (v as ApiParam[]).length > 0) && (
                <div>
                  <span className="text-[11px] font-medium text-[#64748B] uppercase tracking-wider block mb-2">
                    Parameters
                  </span>
                  <div className="rounded-lg border border-[#1E293B] overflow-hidden">
                    <table className="w-full text-[12px]">
                      <thead className="bg-[#1E293B]">
                        <tr>
                          <th className="text-left p-2 text-[#94A3B8] font-medium">Location</th>
                          <th className="text-left p-2 text-[#94A3B8] font-medium">Name</th>
                          <th className="text-left p-2 text-[#94A3B8] font-medium">Type</th>
                          <th className="text-left p-2 text-[#94A3B8] font-medium">Required</th>
                          <th className="text-left p-2 text-[#94A3B8] font-medium">Description</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(['path', 'query', 'body'] as const).map((loc) =>
                          endpoint.params[loc].map((param: ApiParam) => (
                            <tr key={`${loc}-${param.name}`} className="border-t border-[#1E293B]">
                              <td className="p-2 text-[#64748B]">{loc}</td>
                              <td className="p-2 text-[#F8FAFC] font-mono">{param.name}</td>
                              <td className="p-2 text-[#94A3B8]">{param.type}</td>
                              <td className="p-2">
                                {param.required ? (
                                  <span className="text-red-400">Required</span>
                                ) : (
                                  <span className="text-[#64748B]">Optional</span>
                                )}
                              </td>
                              <td className="p-2 text-[#94A3B8]">{param.description}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Request */}
              {endpoint.requestExample && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-medium text-[#64748B] uppercase tracking-wider">Request</span>
                    <button
                      onClick={() => handleCopy(endpoint.requestExample, setCopiedReq)}
                      className="flex items-center gap-1 text-[11px] text-[#64748B] hover:text-[#F8FAFC] transition-colors"
                    >
                      {copiedReq ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      {copiedReq ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <pre className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3 font-mono text-[13px] text-[#A5D6FF] overflow-x-auto">
                    {endpoint.requestExample}
                  </pre>
                </div>
              )}

              {/* Response */}
              {endpoint.responseExample && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-medium text-[#64748B] uppercase tracking-wider">Response</span>
                    <button
                      onClick={() => handleCopy(endpoint.responseExample, setCopiedRes)}
                      className="flex items-center gap-1 text-[11px] text-[#64748B] hover:text-[#F8FAFC] transition-colors"
                    >
                      {copiedRes ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      {copiedRes ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <pre className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3 font-mono text-[13px] text-[#A5D6FF] overflow-x-auto">
                    {endpoint.responseExample}
                  </pre>
                </div>
              )}

              {/* cURL */}
              {endpoint.curlExample && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-medium text-[#64748B] uppercase tracking-wider">cURL</span>
                    <button
                      onClick={() => handleCopy(endpoint.curlExample, setCopiedCurl)}
                      className="flex items-center gap-1 text-[11px] text-[#64748B] hover:text-[#F8FAFC] transition-colors"
                    >
                      {copiedCurl ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      {copiedCurl ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <pre className="bg-[#0D1117] border border-[#30363D] rounded-lg p-3 font-mono text-[12px] text-[#7EE787] overflow-x-auto">
                    {endpoint.curlExample}
                  </pre>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function EndpointsTab({ system }: { system: SystemKnowledge }) {
  if (system.endpoints.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-[#64748B] text-sm">
        No endpoints defined for this system.
      </div>
    );
  }

  // Group by capability
  const grouped = system.endpoints.reduce<Record<string, ApiEndpoint[]>>((acc, ep) => {
    const cap = system.capabilities.find((c) => c.id === ep.capabilityId);
    const groupName = cap ? cap.name : 'Other';
    if (!acc[groupName]) acc[groupName] = [];
    acc[groupName].push(ep);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      {Object.entries(grouped).map(([groupName, endpoints]) => (
        <div key={groupName}>
          <h4 className="text-[13px] font-semibold text-[#94A3B8] mb-3 flex items-center gap-2">
            <Code className="w-4 h-4" />
            {groupName}
          </h4>
          <div className="space-y-3">
            {endpoints.map((ep) => (
              <EndpointCard key={ep.id} endpoint={ep} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Tab 4: Rules ───────────────────────────────────────────────────────────
function RulesTab({ system }: { system: SystemKnowledge }) {
  if (system.rules.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-[#64748B] text-sm">
        No validation rules defined for this system.
      </div>
    );
  }

  const isSire = system.meta.id === 'sire';

  return (
    <div className={`rounded-xl border border-[#1E293B] overflow-hidden ${isSire ? 'ring-1 ring-yellow-500/20' : ''}`}>
      {isSire && (
        <div className="bg-yellow-500/10 px-4 py-2 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-yellow-400" />
          <span className="text-[12px] text-yellow-400 font-medium">
            SIRE has strict validation rules — reconciliation requires exactly 2 input sources
          </span>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="w-full text-[13px]">
          <thead className="bg-[#1E293B]">
            <tr>
              <th className="text-left p-3 text-[#94A3B8] font-medium">Name</th>
              <th className="text-left p-3 text-[#94A3B8] font-medium">Condition</th>
              <th className="text-left p-3 text-[#94A3B8] font-medium">Action</th>
              <th className="text-left p-3 text-[#94A3B8] font-medium">Message</th>
            </tr>
          </thead>
          <tbody>
            {system.rules.map((rule: ValidationRule) => (
              <tr key={rule.id} className={`border-t border-[#1E293B] ${isSire ? 'bg-yellow-500/5' : ''}`}>
                <td className="p-3 text-[#F8FAFC] font-medium">{rule.name}</td>
                <td className="p-3 text-[#A5D6FF] font-mono text-[12px]">{rule.condition}</td>
                <td className="p-3">
                  <Badge className={ACTION_COLORS[rule.action]}>{rule.action}</Badge>
                </td>
                <td className="p-3 text-[#94A3B8]">{rule.message}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── Edit System Dialog ─────────────────────────────────────────────────────
const EDIT_TABS = [
  { id: 'overview', label: 'Overview', icon: Info },
  { id: 'capabilities', label: 'Capabilities', icon: Layers },
  { id: 'documents', label: 'Documents', icon: FileText },
  { id: 'rules', label: 'Rules', icon: ShieldAlert },
];

interface EditSystemDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  system: SystemKnowledge;
  onSave: (updated: SystemKnowledge) => void;
}

function EditSystemDialog({ open, onOpenChange, system, onSave }: EditSystemDialogProps) {
  const [activeTab, setActiveTab] = useState('overview');

  // ── Metadata state ──
  const [metaName, setMetaName] = useState(system.meta.name);
  const [metaDomain, setMetaDomain] = useState(system.meta.domain);
  const [metaOwner, setMetaOwner] = useState(system.meta.owner);
  const [metaDesc, setMetaDesc] = useState(system.meta.description);
  const [metaEnv, setMetaEnv] = useState(system.meta.environment);
  const [metaLifecycle, setMetaLifecycle] = useState(system.meta.lifecycle);
  const [metaTechStack, setMetaTechStack] = useState(system.meta.techStack.join(', '));
  const [metaMcpUrl, setMetaMcpUrl] = useState(system.meta.mcpServerUrl || '');

  // ── Tab arrays state ──
  const [capabilities, setCapabilities] = useState<Capability[]>(system.capabilities);
  const [documents, setDocuments] = useState<SystemDocument[]>(system.documents);
  const [rules, setRules] = useState<ValidationRule[]>(system.rules);

  // ── New document form state ──
  const [newDocName, setNewDocName] = useState('');
  const [newDocType, setNewDocType] = useState<'business' | 'technical' | 'operational' | 'api-spec'>('business');
  const [newDocSize, setNewDocSize] = useState('');
  const [docAddMode, setDocAddMode] = useState<'manual' | 'local' | 'confluence'>('manual');
  const [confUrl, setConfUrl] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setActiveTab('overview');
    setMetaName(system.meta.name);
    setMetaDomain(system.meta.domain);
    setMetaOwner(system.meta.owner);
    setMetaDesc(system.meta.description);
    setMetaEnv(system.meta.environment);
    setMetaLifecycle(system.meta.lifecycle);
    setMetaTechStack(system.meta.techStack.join(', '));
    setMetaMcpUrl(system.meta.mcpServerUrl || '');
    setCapabilities(system.capabilities);
    setDocuments(system.documents);
    setRules(system.rules);
    setNewDocName('');
    setNewDocType('business');
    setNewDocSize('');
    setDocAddMode('manual');
    setConfUrl('');
  }, [system]);

  // ── Capability helpers ──
  const addCapability = () => {
    setCapabilities((prev) => [
      ...prev,
      {
        id: `cap_${Date.now()}`,
        name: '',
        description: '',
        exposedVia: 'REST API',
        input: '',
        output: '',
        tags: [],
        constraints: [],
        dependencies: [],
        useCases: [],
      },
    ]);
  };

  const updateCapability = (index: number, field: keyof Capability, value: string | string[]) => {
    setCapabilities((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  };

  const deleteCapability = (index: number) => {
    setCapabilities((prev) => prev.filter((_, i) => i !== index));
  };

  // ── Document helpers ──
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setDocuments((prev) => [
      ...prev,
      {
        id: `doc_${Date.now()}`,
        name: file.name,
        type: newDocType,
        size: formatFileSize(file.size),
        source: 'local',
      },
    ]);
    e.target.value = '';
  };

  const addConfluenceDoc = () => {
    if (!confUrl.trim()) return;
    // Extract page title from URL path
    try {
      const url = new URL(confUrl.trim());
      const pathParts = url.pathname.split('/');
      const pageId = pathParts[pathParts.length - 1] || pathParts[pathParts.length - 2] || 'Confluence Page';
      const displayName = decodeURIComponent(pageId).replace(/\+/g, ' ');
      setDocuments((prev) => [
        ...prev,
        {
          id: `doc_${Date.now()}`,
          name: displayName,
          type: newDocType,
          size: 'Confluence',
          source: 'confluence',
          url: confUrl.trim(),
        },
      ]);
      setConfUrl('');
    } catch {
      // Invalid URL, use raw input as name
      setDocuments((prev) => [
        ...prev,
        {
          id: `doc_${Date.now()}`,
          name: confUrl.trim(),
          type: newDocType,
          size: 'Confluence',
          source: 'confluence',
          url: confUrl.trim(),
        },
      ]);
      setConfUrl('');
    }
  };

  const addDocument = () => {
    if (!newDocName.trim() || !newDocSize.trim()) return;
    setDocuments((prev) => [
      ...prev,
      {
        id: `doc_${Date.now()}`,
        name: newDocName.trim(),
        type: newDocType,
        size: newDocSize.trim(),
        source: 'manual',
      },
    ]);
    setNewDocName('');
    setNewDocType('business');
    setNewDocSize('');
  };

  const deleteDocument = (index: number) => {
    setDocuments((prev) => prev.filter((_, i) => i !== index));
  };

  // ── Rule helpers ──
  const addRule = () => {
    setRules((prev) => [
      ...prev,
      {
        id: `rule_${Date.now()}`,
        name: '',
        condition: '',
        action: 'WARN',
        message: '',
      },
    ]);
  };

  const updateRule = (index: number, field: keyof ValidationRule, value: string) => {
    setRules((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  };

  const deleteRule = (index: number) => {
    setRules((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    onSave({
      ...system,
      meta: {
        ...system.meta,
        name: metaName,
        domain: metaDomain,
        owner: metaOwner,
        description: metaDesc,
        environment: metaEnv,
        lifecycle: metaLifecycle,
        techStack: metaTechStack.split(',').map((s) => s.trim()).filter(Boolean),
        mcpServerUrl: metaMcpUrl || undefined,
      },
      capabilities,
      documents,
      rules,
    });
    onOpenChange(false);
  };

  const inputClass =
    'w-full bg-[#1E293B] border border-[#334155] rounded-lg px-3 py-2 text-[13px] text-[#F8FAFC] placeholder:text-[#64748B] focus:outline-none focus:border-[#6366F1] focus:ring-1 focus:ring-[#6366F1]/30 transition-all';
  const labelClass = 'text-[11px] font-medium text-[#64748B] uppercase tracking-wider mb-1.5 block';

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          style={{ backgroundColor: 'rgba(3, 7, 18, 0.75)' }}
          onClick={() => onOpenChange(false)}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 12 }}
            transition={{ duration: 0.2, ease: EASE }}
            className="bg-[#0F172A] border border-[#1E293B] rounded-xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#1E293B]">
              <div className="flex items-center gap-2">
                <Pencil className="w-4 h-4 text-[#6366F1]" />
                <h3 className="text-sm font-semibold text-[#F8FAFC]">Edit System Knowledge</h3>
                <Badge className="bg-[#1E293B] text-[#94A3B8] border-[#334155] text-[10px]">{system.meta.id}</Badge>
              </div>
              <button
                onClick={() => onOpenChange(false)}
                className="rounded-lg p-1.5 text-[#64748B] hover:text-[#F8FAFC] hover:bg-[#1E293B] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Tab Bar */}
            <div className="flex border-b border-[#1E293B] px-5">
              {EDIT_TABS.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-1.5 px-4 py-2.5 text-[12px] font-medium border-b-2 transition-colors ${
                      isActive
                        ? 'text-[#6366F1] border-[#6366F1]'
                        : 'text-[#64748B] border-transparent hover:text-[#94A3B8]'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Body */}
            <div className="flex-1 overflow-y-auto p-5">
              {/* ── Overview Tab ── */}
              {activeTab === 'overview' && (
                <div>
                  <h4 className="text-[12px] font-semibold text-[#F8FAFC] mb-3 flex items-center gap-2">
                    <Info className="w-3.5 h-3.5 text-[#6366F1]" />
                    System Metadata
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className={labelClass}>Name</label>
                      <input type="text" value={metaName} onChange={(e) => setMetaName(e.target.value)} className={inputClass} />
                    </div>
                    <div>
                      <label className={labelClass}>Domain</label>
                      <input type="text" value={metaDomain} onChange={(e) => setMetaDomain(e.target.value)} className={inputClass} />
                    </div>
                    <div>
                      <label className={labelClass}>Owner</label>
                      <input type="text" value={metaOwner} onChange={(e) => setMetaOwner(e.target.value)} className={inputClass} />
                    </div>
                    <div>
                      <label className={labelClass}>Environment</label>
                      <select value={metaEnv} onChange={(e) => setMetaEnv(e.target.value)} className={inputClass}>
                        <option value="Production">Production</option>
                        <option value="Staging">Staging</option>
                        <option value="Development">Development</option>
                      </select>
                    </div>
                    <div>
                      <label className={labelClass}>Lifecycle</label>
                      <select value={metaLifecycle} onChange={(e) => setMetaLifecycle(e.target.value)} className={inputClass}>
                        <option value="Active">Active</option>
                        <option value="Deprecated">Deprecated</option>
                        <option value="Retired">Retired</option>
                      </select>
                    </div>
                    <div>
                      <label className={labelClass}>Onboarding</label>
                      <select
                        value={system.meta.onboardingMethod}
                        disabled
                        className={`${inputClass} opacity-50 cursor-not-allowed`}
                      >
                        <option value="manual">Manual</option>
                        <option value="openapi">OpenAPI</option>
                        <option value="mcp">MCP</option>
                      </select>
                    </div>
                    <div className="md:col-span-2">
                      <label className={labelClass}>Tech Stack (comma-separated)</label>
                      <input type="text" value={metaTechStack} onChange={(e) => setMetaTechStack(e.target.value)} className={inputClass} />
                    </div>
                    <div className="md:col-span-2">
                      <label className={labelClass}>Description</label>
                      <textarea
                        value={metaDesc}
                        onChange={(e) => setMetaDesc(e.target.value)}
                        rows={3}
                        className={`${inputClass} resize-none`}
                      />
                    </div>
                    {system.meta.onboardingMethod === 'mcp' && (
                      <div className="md:col-span-2">
                        <label className={labelClass}>MCP Server URL</label>
                        <input type="text" value={metaMcpUrl} onChange={(e) => setMetaMcpUrl(e.target.value)} className={inputClass} />
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ── Capabilities Tab ── */}
              {activeTab === 'capabilities' && (
                <div className="space-y-4">
                  {capabilities.map((cap, idx) => (
                    <div key={cap.id} className="rounded-lg border border-[#1E293B] bg-[#0F172A] p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-semibold text-[#F8FAFC] uppercase tracking-wider">
                          Capability {idx + 1}
                        </label>
                        <button
                          onClick={() => deleteCapability(idx)}
                          className="rounded-md p-1 text-[#EF4444] hover:bg-[#EF4444]/10 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <label className={labelClass}>Name</label>
                          <input
                            type="text"
                            value={cap.name}
                            onChange={(e) => updateCapability(idx, 'name', e.target.value)}
                            className={inputClass}
                          />
                        </div>
                        <div>
                          <label className={labelClass}>Exposed Via</label>
                          <select
                            value={cap.exposedVia}
                            onChange={(e) => updateCapability(idx, 'exposedVia', e.target.value)}
                            className={inputClass}
                          >
                            <option value="REST API">REST API</option>
                            <option value="MCP Tool">MCP Tool</option>
                            <option value="Event">Event</option>
                            <option value="File">File</option>
                          </select>
                        </div>
                        <div className="md:col-span-2">
                          <label className={labelClass}>Description</label>
                          <textarea
                            value={cap.description}
                            onChange={(e) => updateCapability(idx, 'description', e.target.value)}
                            rows={2}
                            className={`${inputClass} resize-none`}
                          />
                        </div>
                        <div>
                          <label className={labelClass}>Input</label>
                          <input
                            type="text"
                            value={cap.input}
                            onChange={(e) => updateCapability(idx, 'input', e.target.value)}
                            className={inputClass}
                          />
                        </div>
                        <div>
                          <label className={labelClass}>Output</label>
                          <input
                            type="text"
                            value={cap.output}
                            onChange={(e) => updateCapability(idx, 'output', e.target.value)}
                            className={inputClass}
                          />
                        </div>
                        <div>
                          <label className={labelClass}>Tags (comma-separated)</label>
                          <input
                            type="text"
                            value={cap.tags.join(', ')}
                            onChange={(e) => updateCapability(idx, 'tags', e.target.value.split(',').map((s) => s.trim()).filter(Boolean))}
                            className={inputClass}
                          />
                        </div>
                        <div>
                          <label className={labelClass}>Constraints (comma-separated)</label>
                          <input
                            type="text"
                            value={cap.constraints.join(', ')}
                            onChange={(e) => updateCapability(idx, 'constraints', e.target.value.split(',').map((s) => s.trim()).filter(Boolean))}
                            className={inputClass}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                  <button
                    onClick={addCapability}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-[12px] font-medium text-[#6366F1] bg-[#6366F1]/10 hover:bg-[#6366F1]/20 border border-[#6366F1]/20 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Capability
                  </button>
                </div>
              )}

              {/* ── Documents Tab ── */}
              {activeTab === 'documents' && (
                <div className="space-y-4">
                  {/* Existing documents */}
                  {documents.map((doc, idx) => (
                    <div
                      key={doc.id}
                      className="flex items-center justify-between rounded-lg border border-[#1E293B] bg-[#0F172A] px-4 py-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <FileText className="w-4 h-4 text-[#6366F1] shrink-0" />
                        <span className="text-[13px] text-[#F8FAFC] truncate">{doc.name}</span>
                        <Badge className={(DOCUMENT_COLORS[doc.type] || '') + ' text-[10px]'}>{doc.type}</Badge>
                        <span className="text-[11px] text-[#64748B]">{doc.size}</span>
                      </div>
                      <button
                        onClick={() => deleteDocument(idx)}
                        className="rounded-md p-1 text-[#EF4444] hover:bg-[#EF4444]/10 transition-colors shrink-0"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}

                  {documents.length === 0 && (
                    <p className="text-[13px] text-[#64748B] py-4 text-center">No documents yet.</p>
                  )}

                  {/* Add Document form */}
                  <div className="rounded-lg border border-[#1E293B] bg-[#0F172A] p-4 space-y-3">
                    <label className="text-[11px] font-semibold text-[#F8FAFC] uppercase tracking-wider block">
                      Add Document
                    </label>

                    {/* Mode switcher */}
                    <div className="flex gap-1 p-1 rounded-lg bg-[#1E293B] w-fit">
                      {([
                        { id: 'manual', label: 'Manual', icon: FileText },
                        { id: 'local', label: 'Local Upload', icon: Upload },
                        { id: 'confluence', label: 'Confluence', icon: Link },
                      ] as const).map((mode) => {
                        const ModeIcon = mode.icon;
                        const isActive = docAddMode === mode.id;
                        return (
                          <button
                            key={mode.id}
                            onClick={() => setDocAddMode(mode.id)}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[11px] font-medium transition-colors ${
                              isActive
                                ? 'bg-[#6366F1]/20 text-[#6366F1]'
                                : 'text-[#64748B] hover:text-[#94A3B8]'
                            }`}
                          >
                            <ModeIcon className="w-3 h-3" />
                            {mode.label}
                          </button>
                        );
                      })}
                    </div>

                    {/* Hidden file input */}
                    <input
                      ref={fileInputRef}
                      type="file"
                      onChange={handleFileSelect}
                      className="hidden"
                    />

                    {/* Type selector (shared) */}
                    <div className="w-48">
                      <label className={labelClass}>Document Type</label>
                      <select
                        value={newDocType}
                        onChange={(e) => setNewDocType(e.target.value as typeof newDocType)}
                        className={inputClass}
                      >
                        <option value="business">business</option>
                        <option value="technical">technical</option>
                        <option value="operational">operational</option>
                        <option value="api-spec">api-spec</option>
                      </select>
                    </div>

                    {/* Manual mode */}
                    {docAddMode === 'manual' && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <label className={labelClass}>Name</label>
                          <input
                            type="text"
                            value={newDocName}
                            onChange={(e) => setNewDocName(e.target.value)}
                            placeholder="e.g. API Guide"
                            className={inputClass}
                          />
                        </div>
                        <div>
                          <label className={labelClass}>Size</label>
                          <input
                            type="text"
                            value={newDocSize}
                            onChange={(e) => setNewDocSize(e.target.value)}
                            placeholder="e.g. 2.4 MB"
                            className={inputClass}
                          />
                        </div>
                        <div className="md:col-span-2">
                          <button
                            onClick={addDocument}
                            disabled={!newDocName.trim() || !newDocSize.trim()}
                            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-[12px] font-medium text-[#6366F1] bg-[#6366F1]/10 hover:bg-[#6366F1]/20 border border-[#6366F1]/20 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            Add Document
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Local upload mode */}
                    {docAddMode === 'local' && (
                      <div className="space-y-3">
                        <div
                          onClick={() => fileInputRef.current?.click()}
                          className="flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed border-[#334155] bg-[#0A0F1E] py-8 cursor-pointer hover:border-[#6366F1]/40 hover:bg-[rgba(99,102,241,0.04)] transition-colors"
                        >
                          <Upload className="w-6 h-6 text-[#64748B]" />
                          <p className="text-[13px] text-[#94A3B8]">Click to browse or drag a file here</p>
                          <p className="text-[11px] text-[#475569]">Any document format supported</p>
                        </div>
                      </div>
                    )}

                    {/* Confluence mode */}
                    {docAddMode === 'confluence' && (
                      <div className="space-y-3">
                        <div className="flex gap-3">
                          <div className="flex-1">
                            <label className={labelClass}>Confluence Page URL</label>
                            <input
                              type="text"
                              value={confUrl}
                              onChange={(e) => setConfUrl(e.target.value)}
                              placeholder="https://wiki.company.com/pages/viewpage.action?pageId=..."
                              className={inputClass}
                            />
                          </div>
                        </div>
                        <button
                          onClick={addConfluenceDoc}
                          disabled={!confUrl.trim()}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-[12px] font-medium text-[#6366F1] bg-[#6366F1]/10 hover:bg-[#6366F1]/20 border border-[#6366F1]/20 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          <Link className="w-3.5 h-3.5" />
                          Add from Confluence
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ── Rules Tab ── */}
              {activeTab === 'rules' && (
                <div className="space-y-3">
                  {rules.map((rule, idx) => (
                    <div
                      key={rule.id}
                      className="grid grid-cols-1 md:grid-cols-12 gap-3 items-start rounded-lg border border-[#1E293B] bg-[#0F172A] px-4 py-3"
                    >
                      <div className="md:col-span-3">
                        <label className={labelClass}>Name</label>
                        <input
                          type="text"
                          value={rule.name}
                          onChange={(e) => updateRule(idx, 'name', e.target.value)}
                          className={inputClass}
                        />
                      </div>
                      <div className="md:col-span-4">
                        <label className={labelClass}>Condition</label>
                        <input
                          type="text"
                          value={rule.condition}
                          onChange={(e) => updateRule(idx, 'condition', e.target.value)}
                          className={inputClass}
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className={labelClass}>Action</label>
                        <select
                          value={rule.action}
                          onChange={(e) => updateRule(idx, 'action', e.target.value)}
                          className={inputClass}
                        >
                          <option value="ALLOW">ALLOW</option>
                          <option value="REJECT">REJECT</option>
                          <option value="WARN">WARN</option>
                        </select>
                      </div>
                      <div className="md:col-span-2">
                        <label className={labelClass}>Message</label>
                        <input
                          type="text"
                          value={rule.message}
                          onChange={(e) => updateRule(idx, 'message', e.target.value)}
                          className={inputClass}
                        />
                      </div>
                      <div className="md:col-span-1 flex justify-end md:pt-6">
                        <button
                          onClick={() => deleteRule(idx)}
                          className="rounded-md p-1.5 text-[#EF4444] hover:bg-[#EF4444]/10 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}

                  {rules.length === 0 && (
                    <p className="text-[13px] text-[#64748B] py-4 text-center">No rules yet.</p>
                  )}

                  <button
                    onClick={addRule}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-[12px] font-medium text-[#6366F1] bg-[#6366F1]/10 hover:bg-[#6366F1]/20 border border-[#6366F1]/20 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Rule
                  </button>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-end gap-3 px-5 py-4 border-t border-[#1E293B]">
              <button
                onClick={() => onOpenChange(false)}
                className="px-4 py-2 rounded-lg text-[13px] font-medium text-[#94A3B8] hover:text-[#F8FAFC] hover:bg-[#1E293B] transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-[13px] font-medium text-white bg-[#6366F1] hover:bg-[#5558E0] transition-colors"
              >
                <Check className="w-3.5 h-3.5" />
                Save Changes
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── Tab 6: Documents ───────────────────────────────────────────────────────
function DocumentCard({ doc }: { doc: SystemDocument }) {
  const isConfluence = doc.source === 'confluence';
  const isLocal = doc.source === 'local';

  const cardContent = (
    <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] p-4 flex items-center gap-4 hover:border-[#334155] transition-colors">
      <div className="w-10 h-10 rounded-lg bg-[#1E293B] flex items-center justify-center shrink-0">
        {isConfluence ? (
          <Link className="w-5 h-5 text-[#0EA5E9]" />
        ) : isLocal ? (
          <Upload className="w-5 h-5 text-[#22C55E]" />
        ) : (
          <FileText className="w-5 h-5 text-[#6366F1]" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[13px] font-medium text-[#F8FAFC] truncate">{doc.name}</p>
        <div className="flex items-center gap-2 mt-0.5">
          <span className="text-[11px] text-[#64748B]">{doc.size}</span>
          {isConfluence && (
            <Badge className="bg-sky-500/10 text-sky-400 border-sky-500/20 text-[9px] px-1 py-0">Confluence</Badge>
          )}
          {isLocal && (
            <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-[9px] px-1 py-0">Local</Badge>
          )}
        </div>
      </div>
      <Badge className={DOCUMENT_COLORS[doc.type] || ''}>{doc.type}</Badge>
    </div>
  );

  if (doc.url) {
    return (
      <a href={doc.url} target="_blank" rel="noopener noreferrer" className="block">
        {cardContent}
      </a>
    );
  }
  return cardContent;
}

function DocumentsTab({ system }: { system: SystemKnowledge }) {
  if (system.documents.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 text-[#64748B] text-sm">
        No documents available for this system.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      {system.documents.map((doc) => (
        <DocumentCard key={doc.id} doc={doc} />
      ))}
    </div>
  );
}

// ─── Main Component ─────────────────────────────────────────
export default function Knowledge() {
  const [systems, setSystems] = useState<SystemKnowledge[]>(INITIAL_SYSTEMS);
  const [selectedId, setSelectedId] = useState('qtrack');
  const [activeTab, setActiveTab] = useState('capabilities');
  const [search, setSearch] = useState('');
  const [showWizard, setShowWizard] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingSystem, setEditingSystem] = useState<SystemKnowledge | null>(null);

  const selected = systems.find((s) => s.meta.id === selectedId)!;

  const filtered = systems.filter(
    (s) =>
      s.meta.name.toLowerCase().includes(search.toLowerCase()) ||
      s.meta.domain.toLowerCase().includes(search.toLowerCase())
  );

  const handleEditSave = (updated: SystemKnowledge) => {
    setSystems((prev) => prev.map((s) => (s.meta.id === updated.meta.id ? updated : s)));
  };

  const renderTab = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewTab system={selected} />;
      case 'capabilities':
        return <CapabilitiesTab system={selected} />;
      case 'endpoints':
        return <EndpointsTab system={selected} />;
      case 'rules':
        return <RulesTab system={selected} />;
      case 'documents':
        return <DocumentsTab system={selected} />;
      default:
        return null;
    }
  };

  return (
    <Layout>
      <div className="flex h-[calc(100vh-7rem)] gap-4">
        {/* Left: System List */}
        <aside className="w-64 shrink-0 flex flex-col">
          <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] flex flex-col h-full overflow-hidden">
            <div className="p-3 border-b border-[#1E293B]">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#64748B]" />
                <Input
                  placeholder="Search systems..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9 bg-[#1E293B] border-[#334155] text-[#F8FAFC] placeholder:text-[#64748B] h-9 text-[13px]"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-2 space-y-1">
              {filtered.map((system) => {
                const isActive = system.meta.id === selectedId;
                const color = SYSTEM_COLORS[system.meta.id] || '#6366F1';
                return (
                  <div
                    key={system.meta.id}
                    className={`group flex items-center gap-2 p-2 rounded-lg transition-colors ${
                      isActive
                        ? 'bg-[#1E293B] border border-[#334155]'
                        : 'hover:bg-[#1E293B]/50 border border-transparent'
                    }`}
                  >
                    <button
                      onClick={() => setSelectedId(system.meta.id)}
                      className="flex-1 flex items-center gap-2.5 text-left min-w-0"
                    >
                      <div
                        className="w-2.5 h-2.5 rounded-full shrink-0"
                        style={{ backgroundColor: color }}
                      />
                      <div className="flex-1 min-w-0">
                        <p className={`text-[13px] font-medium truncate ${isActive ? 'text-[#F8FAFC]' : 'text-[#CBD5E1]'}`}>
                          {system.meta.name}
                        </p>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] text-[#64748B] truncate">{system.meta.domain}</span>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-[9px] text-[#64748B] border-[#334155] px-1 py-0 shrink-0">
                        {system.meta.onboardingMethod}
                      </Badge>
                    </button>
                    {/* Edit button */}
                    <button
                      onClick={() => {
                        setEditingSystem(system);
                        setEditDialogOpen(true);
                      }}
                      title="Edit system knowledge"
                      className="shrink-0 rounded-md p-1.5 text-[#475569] hover:text-[#6366F1] hover:bg-[rgba(99,102,241,0.12)] transition-all"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
            <div className="p-3 border-t border-[#1E293B]">
              <button
                onClick={() => setShowWizard(true)}
                className="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-[13px] font-medium text-[#6366F1] bg-[rgba(99,102,241,0.08)] border border-[rgba(99,102,241,0.25)] hover:bg-[rgba(99,102,241,0.15)] transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add System
              </button>
            </div>
          </div>
        </aside>

        {/* Right: Content Tabs */}
        <main className="flex-1 min-w-0 flex flex-col">
          <div className="rounded-xl border border-[#1E293B] bg-[#0F172A] flex flex-col h-full overflow-hidden">
            {/* Tab Bar */}
            <div className="border-b border-[#1E293B] overflow-x-auto">
              <div className="flex p-1 gap-0.5 min-w-fit">
                {TABS.map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-[12px] font-medium transition-colors whitespace-nowrap ${
                        isActive
                          ? 'bg-[#1E293B] text-[#F8FAFC]'
                          : 'text-[#64748B] hover:text-[#CBD5E1] hover:bg-[#1E293B]/50'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Tab Content */}
            <div className="flex-1 overflow-y-auto p-4">
              <AnimatePresence mode="wait">
                <motion.div
                  key={`${selectedId}-${activeTab}`}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2, ease: EASE }}
                >
                  {renderTab()}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </main>
      </div>
      {editingSystem && (
        <EditSystemDialog
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          system={editingSystem}
          onSave={handleEditSave}
        />
      )}
      <OnboardingWizard
        open={showWizard}
        onOpenChange={setShowWizard}
        onSave={() => setShowWizard(false)}
      />
    </Layout>
  );
}
