import { useCallback, useState } from 'react';
import { Upload } from 'lucide-react';
import { cn } from '@/lib/utils';

interface UploadZoneProps {
  onFilesDrop?: (files: FileList) => void;
  compact?: boolean;
  accept?: string;
  multiple?: boolean;
  className?: string;
}

export default function UploadZone({
  onFilesDrop,
  compact = false,
  accept,
  multiple = true,
  className,
}: UploadZoneProps) {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDragOver(false);
      if (e.dataTransfer.files?.length && onFilesDrop) {
        onFilesDrop(e.dataTransfer.files);
      }
    },
    [onFilesDrop]
  );

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files?.length && onFilesDrop) {
        onFilesDrop(e.target.files);
      }
    },
    [onFilesDrop]
  );

  return (
    <div
      onDragEnter={handleDragEnter}
      onDragOver={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={cn(
        'relative flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-[#CBD5E1] bg-[#F8FAFC] transition-all duration-200 cursor-pointer hover:border-[#6366F1] hover:bg-[rgba(99,102,241,0.04)]',
        isDragOver && 'border-[#6366F1] bg-[rgba(99,102,241,0.08)]',
        compact ? 'py-6 px-4' : 'py-12 px-8',
        className
      )}
    >
      <input
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={handleChange}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
      />
      <Upload
        className={cn(
          'text-[#94A3B8] transition-colors',
          isDragOver ? 'text-[#6366F1]' : '',
          compact ? 'h-8 w-8 mb-2' : 'h-12 w-12 mb-3'
        )}
      />
      <p className={cn('text-sm font-medium text-[#334155]', compact && 'text-xs')}>
        Drag & drop or click to upload
      </p>
      {!compact && (
        <p className="mt-1 text-xs text-[#94A3B8]">
          Supports PDF, DOCX, TXT, and Markdown files
        </p>
      )}
    </div>
  );
}
