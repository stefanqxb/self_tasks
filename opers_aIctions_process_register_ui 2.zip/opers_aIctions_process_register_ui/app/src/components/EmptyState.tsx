import { FileSearch, Database, GitBranch, ClipboardList, type LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

const iconMap: Record<string, LucideIcon> = {
  requirements: ClipboardList,
  knowledge: Database,
  canvas: GitBranch,
  default: FileSearch,
};

interface EmptyStateProps {
  type?: 'requirements' | 'knowledge' | 'canvas' | 'default';
  title?: string;
  message?: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export default function EmptyState({
  type = 'default',
  title,
  message,
  actionLabel,
  onAction,
  className,
}: EmptyStateProps) {
  const Icon = iconMap[type] || iconMap.default;

  const defaultTitles: Record<string, string> = {
    requirements: 'No Workflows Yet',
    knowledge: 'No Knowledge Entries',
    canvas: 'No Workflows Yet',
    default: 'Nothing Here Yet',
  };

  const defaultMessages: Record<string, string> = {
    requirements: 'Start by creating your first requirement analysis.',
    knowledge: 'Upload documents to build your knowledge base.',
    canvas: 'Generate your first workflow to see it here.',
    default: 'Get started by creating your first item.',
  };

  return (
    <div className={cn('flex flex-col items-center justify-center py-16 text-center', className)}>
      <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-[#F1F5F9] text-[#94A3B8]">
        <Icon className="h-8 w-8" />
      </div>
      <h3 className="mt-4 text-base font-semibold text-[#0F172A]">
        {title || defaultTitles[type]}
      </h3>
      <p className="mt-1 max-w-sm text-sm text-[#64748B]">
        {message || defaultMessages[type]}
      </p>
      {actionLabel && onAction && (
        <Button
          onClick={onAction}
          className="mt-5 bg-[#6366F1] text-white hover:bg-[#4F46E5]"
        >
          {actionLabel}
        </Button>
      )}
    </div>
  );
}
