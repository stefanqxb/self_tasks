import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import {
  Sparkles,
  Mail,
  FileSpreadsheet,
  Search,
  Bot,
  User,
  Loader2,
  BarChart3,
  BrainCircuit,
  ArrowRightCircle,
  MessageSquare,
  CreditCard,
  TrendingUp,
  Plus,
  Workflow,
  ChevronDown,
  ChevronUp,
  X,
  Check,
  Send,
  Save,
  Upload,
  FileText,
  GitMerge,
  RefreshCw,
  BookMarked,
} from 'lucide-react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  useReactFlow,
  ReactFlowProvider,
  Handle,
  Position,
  applyNodeChanges,
  applyEdgeChanges,
  type Node,
  type Edge,
  type Connection,
  type NodeChange,
  type EdgeChange,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import Layout from '@/components/Layout';
import StatusBadge from '@/components/StatusBadge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  getStepById,
  getCapabilitiesByStepId,
  getStepsBySystemId,
  systems,
  type Capability,
  type Step,
} from './canvas/data';
import { INITIAL_SOPS } from '@/pages/Knowledge';
import type { SOPKnowledge } from '@/types/knowledge';

/* ─────────────────────────────────────────────
   System Colors & Data (6 Systems)
   ───────────────────────────────────────────── */

const SYSTEM_COLORS: Record<string, string> = {
  QTrack: '#6366F1',
  Transformer: '#14B8A6',
  SWB: '#F59E0B',
  SIRE: '#8B5CF6',
  OPAS: '#0EA5E9',
  GoldenEye: '#F97316',
};

const SYSTEM_ICONS: Record<string, React.ElementType> = {
  QTrack: Mail,
  Transformer: FileSpreadsheet,
  SWB: Search,
  SIRE: BrainCircuit,
  OPAS: CreditCard,
  GoldenEye: TrendingUp,
};

const ALL_SYSTEMS = [
  { id: 'qtrack', name: 'QTrack' },
  { id: 'transformer', name: 'Transformer' },
  { id: 'swb', name: 'SWB' },
  { id: 'sire', name: 'SIRE' },
  { id: 'opas', name: 'OPAS' },
  { id: 'goldeneye', name: 'GoldenEye' },
];

function getStepsBySystemName(systemName: string): Step[] {
  const sys = systems.find((s) => s.name === systemName);
  if (!sys) return [];
  return getStepsBySystemId(sys.id);
}

/* ─────────────────────────────────────────────
   All available capabilities per system (for editing)
   ───────────────────────────────────────────── */

interface SystemCapabilityDef {
  id: string;
  name: string;
  description: string;
}

const ALL_SYSTEM_CAPABILITIES: Record<string, SystemCapabilityDef[]> = {
  QTrack: [
    { id: 'cap-qt-1-1', name: 'POST /api/v1/emails/receive', description: 'Receive and process incoming emails with metadata parsing' },
    { id: 'cap-qt-1-2', name: 'Email Ingestion Pipeline', description: 'End-to-end email ingestion with parsing and attachment extraction' },
    { id: 'cap-qt-1-3', name: 'GET /api/v1/emails', description: 'List emails with filters for priority, status, and date range' },
    { id: 'cap-qt-2-1', name: 'POST /api/v1/emails/:id/prioritize', description: 'AI-prioritize email with urgency score and category' },
    { id: 'cap-qt-2-2', name: 'AI Priority Engine', description: 'Analyze email urgency using sentiment and content analysis' },
    { id: 'cap-qt-2-3', name: 'PUT /api/v1/emails/:id/status', description: 'Update email status (unread/read/resolved)' },
    { id: 'cap-qt-3-1', name: 'POST /api/v1/emails/:id/summarize', description: 'Generate AI summary of email thread with key points' },
    { id: 'cap-qt-3-2', name: 'POST /api/v1/emails/:id/translate', description: 'Translate email content to target language' },
  ],
  SWB: [
    { id: 'cap-swb-1-1', name: 'POST /api/v1/extract/pdf', description: 'Extract structured info from PDF documents' },
    { id: 'cap-swb-1-2', name: 'PDF Entity Recognition', description: 'Identify named entities in PDFs — names, dates, amounts' },
    { id: 'cap-swb-1-3', name: 'Table Extraction Engine', description: 'Extract tables from PDFs with structure preservation' },
    { id: 'cap-swb-2-1', name: 'POST /api/v1/extract/email', description: 'Extract structured info from email content' },
    { id: 'cap-swb-2-2', name: 'Email Content Parser', description: 'Parse email body text, headers, and metadata' },
    { id: 'cap-swb-2-3', name: 'Attachment Processing', description: 'Process email attachments (PDF, Excel) recursively' },
    { id: 'cap-swb-3-1', name: 'POST /api/v1/extraction/validate', description: 'Validate extracted data against schema' },
    { id: 'cap-swb-3-2', name: 'POST /api/v1/extraction/enrich', description: 'Enrich extracted data with external sources' },
    { id: 'cap-swb-3-3', name: 'Schema Matching Engine', description: 'Match extracted data fields to predefined schemas' },
  ],
  Transformer: [
    { id: 'cap-tr-1-1', name: 'POST /api/v1/transform/excel', description: 'Transform Excel data with extract, convert, merge' },
    { id: 'cap-tr-1-2', name: 'POST /api/v1/transform/pdf', description: 'Transform PDF extracting text, tables, converting formats' },
    { id: 'cap-tr-1-3', name: 'Data Format Converter', description: 'Convert between JSON, CSV, Excel with type preservation' },
    { id: 'cap-tr-2-1', name: 'POST /api/v1/workflows/recommend', description: 'Get AI workflow recommendations for transformation tasks' },
    { id: 'cap-tr-2-2', name: 'POST /api/v1/templates/match', description: 'Find matching templates for extracted data' },
    { id: 'cap-tr-2-3', name: 'GET /api/v1/workflows', description: 'List available transformation workflows' },
    { id: 'cap-tr-3-1', name: 'POST /api/v1/transform/batch', description: 'Batch process multiple documents in parallel' },
    { id: 'cap-tr-3-2', name: 'GET /api/v1/transform/jobs/:id', description: 'Get transformation job status and progress' },
    { id: 'cap-tr-3-3', name: 'POST /api/v1/workflows/generate', description: 'Auto-generate workflow from transformation requirements' },
  ],
  SIRE: [
    { id: 'cap-sr-1-1', name: 'GET /api/v1/reconcile/trades', description: 'List trade reconciliation jobs with status' },
    { id: 'cap-sr-1-2', name: 'POST /api/v1/reconcile/trades', description: 'Execute trade matching between front/back office' },
    { id: 'cap-sr-1-3', name: 'POST /api/v1/reconcile/positions', description: 'Compare positions across multiple systems' },
    { id: 'cap-sr-2-1', name: 'POST /api/v1/reconcile/settlements', description: 'Compare settlement instructions with actuals' },
    { id: 'cap-sr-2-2', name: 'POST /api/v1/reconcile/payments', description: 'Match payment instructions against settlements' },
    { id: 'cap-sr-2-3', name: 'GET /api/v1/reconcile/status', description: 'Overall platform status with pending jobs' },
    { id: 'cap-sr-3-1', name: 'GET /api/v1/breaks', description: 'List reconciliation breaks with filtering' },
    { id: 'cap-sr-3-2', name: 'PUT /api/v1/breaks/:id/resolve', description: 'Resolve a break by ID with match/override/escalate' },
    { id: 'cap-sr-3-3', name: 'Break Categorization Engine', description: 'Categorize breaks by type and severity' },
    { id: 'cap-sr-4-1', name: 'Exception Report Generator', description: 'Generate exception reports with break summaries' },
    { id: 'cap-sr-4-2', name: 'Reconciliation Dashboard', description: 'Real-time dashboard with reconciliation KPIs' },
    { id: 'cap-sr-4-3', name: 'Break Aging Analyzer', description: 'Analyze break aging and trigger SLA escalation' },
    { id: 'cap-sr-5-1', name: 'Break Routing Engine', description: 'Route breaks to operations teams by type/severity' },
    { id: 'cap-sr-5-2', name: 'Escalation Manager', description: 'Escalate critical breaks to senior staff' },
    { id: 'cap-sr-5-3', name: 'PUT /api/v1/breaks/:id/resolve', description: 'Resolve breaks with automated matching' },
  ],
  OPAS: [
    { id: 'cap-op-1-1', name: 'GET /api/v1/settlements', description: 'List settlements' },
    { id: 'cap-op-1-2', name: 'GET /api/v1/settlements/:id', description: 'Get settlement' },
    { id: 'cap-op-1-3', name: 'POST /api/v1/settlements', description: 'Set settlement (create/update)' },
    { id: 'cap-op-2-1', name: 'GET /api/v1/payments', description: 'List payments' },
    { id: 'cap-op-2-2', name: 'GET /api/v1/payments/:id', description: 'Get payment' },
    { id: 'cap-op-2-3', name: 'POST /api/v1/payments', description: 'Set payment (create/update)' },
    { id: 'cap-op-4-1', name: 'PUT /api/v1/payments/:id/status', description: 'Update payment status' },
    { id: 'cap-op-5-1', name: 'POST /api/v1/reconciliation-results', description: 'Store reconciliation results' },
  ],
  GoldenEye: [
    { id: 'cap-ge-1-1', name: 'GET /api/v1/trades', description: 'List trade info' },
    { id: 'cap-ge-1-2', name: 'GET /api/v1/trades/:id', description: 'Get trade info' },
    { id: 'cap-ge-1-3', name: 'POST /api/v1/trades', description: 'Set trade info (create/update)' },
    { id: 'cap-ge-2-1', name: 'GET /api/v1/trades/history', description: 'List trade history' },
    { id: 'cap-ge-2-2', name: 'GET /api/v1/trades/positions', description: 'Get trade positions' },
    { id: 'cap-ge-2-3', name: 'POST /api/v1/trades/lifecycle', description: 'Set trade lifecycle event' },
  ],
};

const SYSTEM_ACTIONS: Record<string, string> = {
  QTrack: 'receive and prioritize emails',
  SWB: 'extract structured data from documents',
  Transformer: 'transform data to required format',
  SIRE: 'reconcile records and identify breaks',
  OPAS: 'store payment records and track status',
  GoldenEye: 'store trade records and track positions',
};

const SYSTEM_REASONS: Record<string, { reason: string; confidence: number }> = {
  QTrack: { reason: 'Handle email communications and prioritize incoming messages based on content and sender.', confidence: 95 },
  SWB: { reason: 'Extract structured data from documents and emails with high accuracy using batch processing.', confidence: 98 },
  Transformer: { reason: 'Convert and transform data between formats with automated workflow generation.', confidence: 97 },
  SIRE: { reason: 'Reconcile data across systems and identify breaks, discrepancies, and mismatches.', confidence: 92 },
  OPAS: { reason: 'Store and manage payment records, settlement instructions, and track payment status.', confidence: 93 },
  GoldenEye: { reason: 'Store trade records, track positions, and provide trade lifecycle management.', confidence: 99 },
};

/* ─────────────────────────────────────────────
   Types
   ───────────────────────────────────────────── */

interface WorkflowNode {
  system: string;
  action: string;
  stepIds?: string[];
  /** Systems that feed INTO this node (SIRE always needs exactly 2) */
  inputs?: string[];
  /** System this node outputs TO (optional, for branch visualization) */
  output?: string;
}

interface SystemRecommendation {
  name: string;
  confidence: number;
  reason: string;
  apis: string[];
  matchedCapabilities?: string[];
}

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  workflow?: WorkflowNode[];
  recommendations?: SystemRecommendation[];
  overallConfidence?: number;
  timestamp: string;
}

interface Conversation {
  id: string;
  title: string;
  status: 'completed' | 'in_progress';
  date: string;
  overallConfidence: number;
  messages: Message[];
}

/* ─────────────────────────────────────────────
   Mock Conversations (4 workflows, 6 systems)
   ───────────────────────────────────────────── */

const MOCK_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv-001',
    title: 'Daily Trade Reconciliation',
    status: 'completed',
    date: 'May 20, 2026',
    overallConfidence: 95,
    messages: [
      {
        id: 'msg-001-1',
        type: 'user',
        content: 'Every morning I need to reconcile our trade positions from GoldenEye with settlement data and generate a break report. We execute trades throughout the day and need to identify any discrepancies before market open next day.',
        timestamp: 'May 20, 2026, 8:00 AM',
      },
      {
        id: 'msg-001-2',
        type: 'ai',
        content: 'This workflow requires 5 systems: Email receipt → Trade positions → Settlement extraction → Reconciliation → Email report. QTrack receives trade confirmation emails from counterparties. GoldenEye provides trade positions from the trading system. SWB extracts settlement instructions from confirmation emails. SIRE reconciles trade positions from GoldenEye against settlement data from SWB (2 inputs), identifying any breaks and discrepancies. QTrack sends the final break report email to the operations team.',
        workflow: [
          { system: 'QTrack', action: 'receive trade confirmation emails', stepIds: ['qt-step-1', 'qt-step-2'] },
          { system: 'GoldenEye', action: 'get trade positions', stepIds: ['ge-step-1', 'ge-step-2'] },
          { system: 'SWB', action: 'extract settlement instructions from emails', stepIds: ['swb-step-1', 'swb-step-2'] },
          { system: 'SIRE', action: 'reconcile trades vs settlements (2 inputs: GoldenEye + SWB) → break report', stepIds: ['sr-step-1', 'sr-step-3'], inputs: ['GoldenEye', 'SWB'] },
          { system: 'QTrack', action: 'send break report email', stepIds: ['qt-step-1', 'qt-step-3'] },
        ],
        recommendations: [
          {
            name: 'QTrack',
            confidence: 96,
            reason: 'Receive trade confirmation emails and send break report emails. Handles both inbound trade confirmations and outbound reconciliation reporting.',
            apis: ['POST /api/v1/emails/receive', 'POST /api/v1/emails/:id/prioritize'],
          },
          {
            name: 'GoldenEye',
            confidence: 99,
            reason: 'Get trade positions from the trading system. Provides trade lifecycle management and position tracking throughout the trading day. Serves as an independent input source to SIRE.',
            apis: ['GET /api/v1/trades/positions', 'GET /api/v1/trades', 'GET /api/v1/trades/history'],
          },
          {
            name: 'SWB',
            confidence: 97,
            reason: 'Extract settlement instructions from trade confirmation emails. Parses settlement dates, amounts, counterparty details, and delivery instructions. Serves as an independent input source to SIRE.',
            apis: ['POST /api/v1/extract/email', 'POST /api/v1/extract/pdf', 'Attachment Processing'],
          },
          {
            name: 'SIRE',
            confidence: 93,
            reason: 'Reconcile trade positions from GoldenEye against settlement data from SWB (2 inputs). Identifies breaks including unmatched trades, amount discrepancies, settlement date mismatches, and missing instructions. Outputs a break report.',
            apis: ['POST /api/v1/reconcile/positions', 'POST /api/v1/reconcile/settlements', 'GET /api/v1/breaks'],
          },
        ],
        overallConfidence: 95,
        timestamp: 'May 20, 2026, 8:01 AM',
      },
    ],
  },
  {
    id: 'conv-002',
    title: 'Invoice Processing Pipeline',
    status: 'completed',
    date: 'May 19, 2026',
    overallConfidence: 95,
    messages: [
      {
        id: 'msg-002-1',
        type: 'user',
        content: 'We receive vendor invoices via email. I need to extract invoice details, validate against purchase orders, convert to our ERP format, and record the payment obligation.',
        timestamp: 'May 19, 2026, 10:30 AM',
      },
      {
        id: 'msg-002-2',
        type: 'ai',
        content: 'This workflow requires 5 systems: Email receipt → Data extraction → Format transformation → Payment recording → Team notification. QTrack receives vendor invoices via email. SWB extracts invoice data including amount, vendor, and PO reference. Transformer converts the extracted data to ERP import format. OPAS records the payment obligation. QTrack notifies the AP team that invoices are ready for processing.',
        workflow: [
          { system: 'QTrack', action: 'receive vendor invoices', stepIds: ['qt-step-1', 'qt-step-2'] },
          { system: 'SWB', action: 'extract invoice data (amount, vendor, PO reference)', stepIds: ['swb-step-1', 'swb-step-2'] },
          { system: 'Transformer', action: 'convert to ERP import format', stepIds: ['tr-step-1', 'tr-step-2'] },
          { system: 'OPAS', action: 'record payment obligation', stepIds: ['op-step-2', 'op-step-3'] },
          { system: 'QTrack', action: 'notify AP team', stepIds: ['qt-step-1', 'qt-step-3'] },
        ],
        recommendations: [
          {
            name: 'QTrack',
            confidence: 96,
            reason: 'Receive vendor invoices via email and notify the AP team. Handles both inbound invoice receipt and outbound team communication.',
            apis: ['POST /api/v1/emails/receive', 'POST /api/v1/emails/:id/prioritize'],
          },
          {
            name: 'SWB',
            confidence: 98,
            reason: 'Extract invoice data (vendor name, amounts, PO reference, line items) from PDF attachments and email content. Batch extraction enables processing multiple invoices efficiently.',
            apis: ['POST /api/v1/extract/pdf', 'POST /api/v1/extract/email', 'POST /api/v1/extract/batch'],
          },
          {
            name: 'Transformer',
            confidence: 97,
            reason: 'Convert extracted invoice data into ERP import format. Workflow generation creates a repeatable transformation pipeline for consistent output.',
            apis: ['POST /api/v1/transform/excel', 'POST /api/v1/workflows/generate', 'Data Format Converter'],
          },
          {
            name: 'OPAS',
            confidence: 93,
            reason: 'Record payment obligation from the processed invoices. Stores and manages payment records, settlement instructions, and tracks payment status.',
            apis: ['POST /api/v1/payments', 'GET /api/v1/payments', 'GET /api/v1/settlements'],
          },
        ],
        overallConfidence: 95,
        timestamp: 'May 19, 2026, 10:31 AM',
      },
    ],
  },
  {
    id: 'conv-003',
    title: 'Payment Status Monitoring',
    status: 'completed',
    date: 'May 18, 2026',
    overallConfidence: 93,
    messages: [
      {
        id: 'msg-003-1',
        type: 'user',
        content: 'I need to check payment statuses for all settlements due today and send reminders for any pending payments. This should run every 4 hours during business hours.',
        timestamp: 'May 18, 2026, 9:00 AM',
      },
      {
        id: 'msg-003-2',
        type: 'ai',
        content: 'This workflow requires 3 systems: Settlement lookup → Payment matching → Reminder emails. OPAS lists all pending settlements due today. SIRE matches settlements against existing payment records (2 inputs from OPAS: settlements + payments), identifying any unmatched or pending items. QTrack sends payment reminder emails for any settlements that have not yet been paid.',
        workflow: [
          { system: 'OPAS', action: 'list pending settlements', stepIds: ['op-step-1', 'op-step-2'] },
          { system: 'SIRE', action: 'match settlements against payment records (2 inputs: OPAS settlements + OPAS payments) → pending items', stepIds: ['sr-step-2', 'sr-step-3'], inputs: ['OPAS', 'OPAS'] },
          { system: 'QTrack', action: 'send payment reminder for unmatched items', stepIds: ['qt-step-1', 'qt-step-3'] },
        ],
        recommendations: [
          {
            name: 'OPAS',
            confidence: 99,
            reason: 'List pending settlements and provide payment records as dual data sources for SIRE matching. Stores and manages payment records, settlement instructions, and tracks payment status.',
            apis: ['GET /api/v1/settlements', 'GET /api/v1/payments', 'GET /api/v1/payments/:id'],
          },
          {
            name: 'SIRE',
            confidence: 92,
            reason: 'Match settlements against payment records from OPAS (2 inputs). Identifies pending payments, amount mismatches, and unmatched settlements. Outputs a list of items requiring reminders.',
            apis: ['POST /api/v1/reconcile/payments', 'POST /api/v1/reconcile/settlements', 'GET /api/v1/breaks'],
          },
          {
            name: 'QTrack',
            confidence: 94,
            reason: 'Send payment reminder emails for unmatched or pending settlement items. Provides email prioritization and templated outbound communication.',
            apis: ['POST /api/v1/emails/receive', 'POST /api/v1/emails/:id/prioritize'],
          },
        ],
        overallConfidence: 93,
        timestamp: 'May 18, 2026, 9:01 AM',
      },
    ],
  },
  {
    id: 'conv-004',
    title: 'Monthly Position Report',
    status: 'completed',
    date: 'May 15, 2026',
    overallConfidence: 95,
    messages: [
      {
        id: 'msg-004-1',
        type: 'user',
        content: 'At month end I need to pull all trade positions, reconcile with counterparty statements, and generate a consolidated position report for senior management.',
        timestamp: 'May 15, 2026, 2:00 PM',
      },
      {
        id: 'msg-004-2',
        type: 'ai',
        content: 'This workflow requires 5 systems: Trade positions → Counterparty data → Reconciliation → Report formatting → Email distribution. GoldenEye lists all trade positions. SWB extracts counterparty statement data from statement files. SIRE reconciles internal positions from GoldenEye against counterparty statements from SWB (2 inputs), identifying any breaks. Transformer formats the consolidated report as Excel. QTrack emails the report to senior management.',
        workflow: [
          { system: 'GoldenEye', action: 'list all trade positions', stepIds: ['ge-step-1', 'ge-step-2'] },
          { system: 'SWB', action: 'extract counterparty statement data', stepIds: ['swb-step-1', 'swb-step-2'] },
          { system: 'SIRE', action: 'reconcile internal vs counterparty positions (2 inputs: GoldenEye + SWB) → breaks', stepIds: ['sr-step-1', 'sr-step-3'], inputs: ['GoldenEye', 'SWB'] },
          { system: 'Transformer', action: 'format report as Excel', stepIds: ['tr-step-1', 'tr-step-2'] },
          { system: 'QTrack', action: 'email report to management', stepIds: ['qt-step-1', 'qt-step-3'] },
        ],
        recommendations: [
          {
            name: 'GoldenEye',
            confidence: 99,
            reason: 'List all trade positions from the trading system. Provides comprehensive position data and trade lifecycle management. Serves as an independent input source to SIRE.',
            apis: ['GET /api/v1/trades/positions', 'GET /api/v1/trades', 'GET /api/v1/trades/history'],
          },
          {
            name: 'SWB',
            confidence: 96,
            reason: 'Extract counterparty statement data from statement PDFs and files. Parses position data, valuations, and adjustments from external counterparty documents. Serves as an independent input source to SIRE.',
            apis: ['POST /api/v1/extract/pdf', 'Table Extraction Engine', 'POST /api/v1/extract/email'],
          },
          {
            name: 'SIRE',
            confidence: 93,
            reason: 'Reconcile internal positions from GoldenEye against counterparty statements from SWB (2 inputs). Identifies position breaks, valuation differences, and unmatched trades. Outputs break details for the report.',
            apis: ['POST /api/v1/reconcile/positions', 'GET /api/v1/breaks', 'POST /api/v1/reconcile/trades'],
          },
          {
            name: 'Transformer',
            confidence: 97,
            reason: 'Format the consolidated position report as Excel. Converts reconciliation output into a professional management-ready format with charts and summaries.',
            apis: ['POST /api/v1/transform/excel', 'POST /api/v1/workflows/generate', 'Data Format Converter'],
          },
          {
            name: 'QTrack',
            confidence: 94,
            reason: 'Email the consolidated position report to senior management. Handles outbound distribution with priority and read receipt tracking.',
            apis: ['POST /api/v1/emails/receive', 'POST /api/v1/emails/:id/prioritize'],
          },
        ],
        overallConfidence: 95,
        timestamp: 'May 15, 2026, 2:01 PM',
      },
    ],
  },
];

/* ─────────────────────────────────────────────
   Helper: Generate AI Analysis from Input
   ───────────────────────────────────────────── */

/* ─────────────────────────────────────────────
   Helper: Confidence score color
   ───────────────────────────────────────────── */

function getConfidenceColor(score: number): string {
  if (score >= 90) return '#22C55E';
  if (score >= 70) return '#F59E0B';
  if (score >= 50) return '#F97316';
  return '#EF4444';
}

/* ─────────────────────────────────────────────
   Helper: Generate AI Analysis from Input
   Uses capability-based semantic matching.
   ───────────────────────────────────────────── */

function generateAnalysis(input: string): Conversation {
  const lowerInput = input.toLowerCase();
  const timestamp = Date.now();
  const title = input.split(/[.!?]/)[0].slice(0, 60) || 'New Requirement';

  // Keyword → synonym groups for semantic matching
  const keywordMatches: Record<string, string[]> = {
    email: ['email', 'mail', 'inbox', 'message', 'smtp', 'imap'],
    transform: ['transform', 'convert', 'excel', 'pdf', 'spreadsheet', 'format', 'parse'],
    extract: ['extract', 'information', 'entity', 'recognition', 'scrape', 'parse', 'data extraction'],
    reconcile: ['reconcile', 'reconciliation', 'break', 'match', 'discrepancy', 'difference'],
    payment: ['payment', 'settlement', 'pay', 'remittance', 'fund', 'transfer'],
    trade: ['trade', 'trading', 'position', 'portfolio', 'security', 'instrument'],
  };

  // Score each system based on capability description matching
  const systemScores: Record<string, { score: number; matchedCapabilities: string[] }> = {};

  for (const [systemName, capabilities] of Object.entries(ALL_SYSTEM_CAPABILITIES)) {
    let totalScore = 0;
    const matchedCapabilities: string[] = [];

    for (const cap of capabilities) {
      const capLower = (cap.name + ' ' + cap.description).toLowerCase();
      let capScore = 0;

      // 1. Synonym matching: input keyword AND capability description both contain the synonym
      for (const [, synonyms] of Object.entries(keywordMatches)) {
        if (synonyms.some((s) => lowerInput.includes(s) && capLower.includes(s))) {
          capScore += 1;
        }
      }

      // 2. Direct word overlap between input and capability description
      const inputWords = lowerInput.split(/\s+/).filter((w) => w.length > 2);
      for (const word of inputWords) {
        if (capLower.includes(word)) {
          capScore += 0.3;
        }
      }

      if (capScore > 0) {
        totalScore += capScore;
        matchedCapabilities.push(cap.name);
      }
    }

    systemScores[systemName] = { score: totalScore, matchedCapabilities };
  }

  // Sort systems by score and pick the top matches
  const sorted = Object.entries(systemScores)
    .filter(([, v]) => v.score > 0)
    .sort(([, a], [, b]) => b.score - a.score);

  let selectedSystems: string[];
  if (sorted.length === 0) {
    selectedSystems = ['QTrack', 'SWB'];
  } else {
    const topScore = sorted[0][1].score;
    const threshold = topScore * 0.2;
    selectedSystems = sorted
      .filter(([, v]) => v.score >= threshold)
      .map(([name]) => name)
      .slice(0, 5); // max 5 systems
  }

  // Normalise raw scores to 0 – 100 confidence values
  const maxScore = Math.max(...Object.values(systemScores).map((s) => s.score), 1);

  const recommendations: SystemRecommendation[] = selectedSystems.map((name) => {
    const rawScore = systemScores[name]?.score || 0;
    const normalizedConfidence = Math.min(
      99,
      Math.max(40, Math.round((rawScore / maxScore) * 95))
    );
    const matchedCaps = systemScores[name]?.matchedCapabilities || [];

    return {
      name,
      confidence: normalizedConfidence,
      reason: SYSTEM_REASONS[name].reason,
      apis: ALL_SYSTEM_CAPABILITIES[name]
        .filter((c) => matchedCaps.length === 0 || matchedCaps.includes(c.name))
        .slice(0, 3)
        .map((c) => c.name),
      matchedCapabilities: matchedCaps.slice(0, 5),
    };
  });

  // Build workflow nodes (SIRE needs exactly 2 inputs)
  const workflow: WorkflowNode[] = selectedSystems.map((system) => {
    const base: WorkflowNode = {
      system,
      action: SYSTEM_ACTIONS[system],
    };

    if (system === 'SIRE') {
      const otherSystems = selectedSystems.filter((s) => s !== 'SIRE');
      if (otherSystems.length >= 2) {
        base.inputs = [otherSystems[0], otherSystems[1]];
        base.action = `${SYSTEM_ACTIONS[system]} (2 inputs: ${otherSystems[0]} + ${otherSystems[1]}) → recon report`;
      } else if (otherSystems.length === 1) {
        base.inputs = [otherSystems[0], otherSystems[0]];
        base.action = `${SYSTEM_ACTIONS[system]} (2 inputs: ${otherSystems[0]} × 2) → recon report`;
      }
    }

    return base;
  });

  const overallConfidence =
    recommendations.length > 0
      ? Math.round(recommendations.reduce((sum, r) => sum + r.confidence, 0) / recommendations.length)
      : 0;

  const analysis = `This workflow requires ${selectedSystems.length} system${selectedSystems.length > 1 ? 's' : ''}: ${selectedSystems.join(' \u2192 ')}. ${selectedSystems.map((s) => `${s} ${s === 'SIRE' ? 'reconciles data from 2 inputs and outputs a recon report' : SYSTEM_ACTIONS[s]}.`).join(' ')}`;

  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

  return {
    id: `conv-${timestamp}`,
    title,
    status: 'completed',
    date: dateStr,
    overallConfidence,
    messages: [
      {
        id: `msg-${timestamp}-user`,
        type: 'user',
        content: input,
        timestamp: `${dateStr}, ${timeStr}`,
      },
      {
        id: `msg-${timestamp}-ai`,
        type: 'ai',
        content: analysis,
        workflow,
        recommendations,
        overallConfidence,
        timestamp: `${dateStr}, ${timeStr}`,
      },
    ],
  };
}

/* ─────────────────────────────────────────────
   Helper: Process Follow-Up Messages
   ───────────────────────────────────────────── */

function processFollowUp(
  followUpText: string,
  currentWorkflow: WorkflowNode[],
  currentRecs: SystemRecommendation[]
): { workflow: WorkflowNode[]; recommendations: SystemRecommendation[]; analysis: string } {
  const lower = followUpText.toLowerCase();
  const changes: string[] = [];
  let newWorkflow = [...currentWorkflow];
  let newRecs = [...currentRecs];

  const hasAny = (keywords: string[]) => keywords.some((k) => lower.includes(k));

  // Handle "remove [system]" or "don't need [system]"
  const systemNames = Object.keys(SYSTEM_COLORS);
  for (const sysName of systemNames) {
    const sysLower = sysName.toLowerCase();
    if (
      (lower.includes(`remove ${sysLower}`) || lower.includes(`remove ${sysName.toLowerCase()}`) ||
        lower.includes(`delete ${sysLower}`) || lower.includes(`drop ${sysLower}`) ||
        lower.includes(`dont need ${sysLower}`) || lower.includes(`don\'t need ${sysLower}`) ||
        lower.includes(`no ${sysLower}`)) &&
      newWorkflow.some((n) => n.system === sysName)
    ) {
      newWorkflow = newWorkflow.filter((n) => n.system !== sysName);
      newRecs = newRecs.filter((r) => r.name !== sysName);
      changes.push(`Removed ${sysName}`);
    }
  }

  // Handle "add [system]" or "also need [system]" or "include [system]"
  for (const sysName of systemNames) {
    const sysLower = sysName.toLowerCase();
    if (
      (hasAny([`add ${sysLower}`, `add ${sysName.toLowerCase()}`,
        `also need ${sysLower}`, `also need ${sysName.toLowerCase()}`,
        `include ${sysLower}`, `include ${sysName.toLowerCase()}`,
        `with ${sysLower}`, `using ${sysLower}`,
        `add ${sysLower}`]) ||
        lower.includes(sysLower)) &&
      !newWorkflow.some((n) => n.system === sysName)
    ) {
      // Check if this is genuinely an "add" request
      const isAddRequest =
        lower.includes(`add ${sysLower}`) ||
        lower.includes(`also need ${sysLower}`) ||
        lower.includes(`include ${sysLower}`) ||
        lower.includes(`with ${sysLower}`) ||
        lower.includes(`using ${sysLower}`) ||
        (hasAny([`add ${sysLower}`, 'add system', 'add another', 'also need']) && lower.includes(sysLower));

      if (isAddRequest) {
        newWorkflow = [...newWorkflow, { system: sysName, action: SYSTEM_ACTIONS[sysName] }];
        const caps = ALL_SYSTEM_CAPABILITIES[sysName];
        newRecs = [
          ...newRecs,
          {
            name: sysName,
            confidence: SYSTEM_REASONS[sysName].confidence,
            reason: SYSTEM_REASONS[sysName].reason,
            apis: caps.slice(0, 3).map((c) => c.name),
          },
        ];
        changes.push(`Added ${sysName}`);
      }
    }
  }

  // Handle capability-specific changes
  if (hasAny(['translate', 'translation'])) {
    const qtrackIdx = newRecs.findIndex((r) => r.name === 'QTrack');
    if (qtrackIdx !== -1) {
      const translateApi = 'POST /api/v1/emails/:id/translate';
      if (!newRecs[qtrackIdx].apis.includes(translateApi)) {
        newRecs[qtrackIdx] = {
          ...newRecs[qtrackIdx],
          apis: [...newRecs[qtrackIdx].apis, translateApi],
        };
        changes.push('Added email translation capability to QTrack');
      }
    } else {
      // Add QTrack if not present and translation requested
      newWorkflow = [{ system: 'QTrack', action: SYSTEM_ACTIONS['QTrack'] }, ...newWorkflow];
      newRecs = [
        {
          name: 'QTrack',
          confidence: 95,
          reason: 'Handle email communications including translation for global teams.',
          apis: ['POST /api/v1/emails/receive', 'POST /api/v1/emails/:id/prioritize', 'POST /api/v1/emails/:id/translate'],
        },
        ...newRecs,
      ];
      changes.push('Added QTrack for email translation');
    }
  }

  if (hasAny(['summarize', 'summarization'])) {
    const qtrackIdx = newRecs.findIndex((r) => r.name === 'QTrack');
    if (qtrackIdx !== -1) {
      const summarizeApi = 'POST /api/v1/emails/:id/summarize';
      if (!newRecs[qtrackIdx].apis.includes(summarizeApi)) {
        newRecs[qtrackIdx] = {
          ...newRecs[qtrackIdx],
          apis: [...newRecs[qtrackIdx].apis, summarizeApi],
        };
        changes.push('Added email summarization capability to QTrack');
      }
    }
  }

  if (hasAny(['settlement']) && !changes.some((c) => c.includes('settlement'))) {
    const opasIdx = newRecs.findIndex((r) => r.name === 'OPAS');
    if (opasIdx !== -1) {
      const settlementApi = 'POST /api/v1/settlements';
      if (!newRecs[opasIdx].apis.includes(settlementApi)) {
        newRecs[opasIdx] = {
          ...newRecs[opasIdx],
          apis: [...newRecs[opasIdx].apis, settlementApi],
        };
        changes.push('Added settlement handling to OPAS');
      }
    }
  }

  if (hasAny(['batch'])) {
    const swbIdx = newRecs.findIndex((r) => r.name === 'SWB');
    if (swbIdx !== -1) {
      const batchApi = 'POST /api/v1/extract/batch';
      if (!newRecs[swbIdx].apis.includes(batchApi)) {
        newRecs[swbIdx] = {
          ...newRecs[swbIdx],
          apis: [...newRecs[swbIdx].apis, batchApi],
        };
        changes.push('Added batch extraction to SWB');
      }
    }
  }

  // Handle "instead of" replacements
  if (lower.includes('instead of')) {
    for (const oldSys of systemNames) {
      for (const newSys of systemNames) {
        if (
          oldSys !== newSys &&
          lower.includes(`${newSys.toLowerCase()} instead of ${oldSys.toLowerCase()}`)
        ) {
          newWorkflow = newWorkflow.map((n) =>
            n.system === oldSys ? { system: newSys, action: SYSTEM_ACTIONS[newSys] } : n
          );
          newRecs = newRecs.filter((r) => r.name !== oldSys);
          if (!newRecs.some((r) => r.name === newSys)) {
            const caps = ALL_SYSTEM_CAPABILITIES[newSys];
            newRecs = [
              ...newRecs,
              {
                name: newSys,
                confidence: SYSTEM_REASONS[newSys].confidence,
                reason: SYSTEM_REASONS[newSys].reason,
                apis: caps.slice(0, 3).map((c) => c.name),
              },
            ];
          }
          changes.push(`Replaced ${oldSys} with ${newSys}`);
        }
      }
    }
  }

  if (changes.length === 0) {
    changes.push('Workflow reviewed. No changes detected in follow-up request.');
  }

  return {
    workflow: newWorkflow,
    recommendations: newRecs,
    analysis: changes.join('. '),
  };
}


/* ─────────────────────────────────────────────
   Helper Components
   ───────────────────────────────────────────── */

/* ─────────────────────────────────────────────
   3-Layer Drill-Down Canvas Node Types
   ───────────────────────────────────────────── */

interface Layer1NodeData {
  system: string;
  description: string;
  color: string;
  icon: React.ElementType;
  stepCount: number;
  capCount: number;
  isMerge?: boolean;
  isInput?: boolean;
  onDrillDown: (systemId: string) => void;
}

function Layer1SystemNode({ data }: { data: Layer1NodeData }) {
  const Icon = data.icon || Sparkles;
  const MergeIcon = data.isMerge ? GitMerge : null;
  return (
    <div
      className="rounded-xl border-2 px-4 py-3 bg-[#111827] min-w-[200px] cursor-pointer hover:brightness-125 transition-all"
      style={{
        borderColor: data.isMerge ? data.color : `${data.color}60`,
        boxShadow: data.isMerge ? `0 0 12px ${data.color}25` : 'none',
      }}
      onClick={() => data.onDrillDown(data.system)}
    >
      <div className="flex items-center gap-2 mb-1">
        <div
          className="flex h-6 w-6 items-center justify-center rounded"
          style={{
            backgroundColor: data.isMerge ? `${data.color}25` : `${data.color}15`,
          }}
        >
          {MergeIcon ? (
            <GitMerge className="h-3.5 w-3.5" style={{ color: data.color }} />
          ) : (
            <Icon className="h-3.5 w-3.5" style={{ color: data.color }} />
          )}
        </div>
        <span className="text-sm font-bold text-[#F1F5F9]">{data.system}</span>
        {data.isMerge && (
          <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#F59E0B]/15 text-[#F59E0B] font-bold">
            MERGE
          </span>
        )}
        {data.isInput && !data.isMerge && (
          <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#1E293B] text-[#64748B]">
            INPUT
          </span>
        )}
      </div>
      <p className="text-[11px] text-[#94A3B8] line-clamp-2 mb-2">{data.description}</p>
      <div className="flex items-center gap-3 text-[10px] text-[#475569]">
        <span>{data.stepCount} steps</span>
        <span>{data.capCount} capabilities</span>
      </div>
      <Handle
        type="target"
        position={Position.Left}
        style={{ background: data.color, border: 'none', width: 8, height: 8 }}
      />
      <Handle
        type="source"
        position={Position.Right}
        style={{ background: data.color, border: 'none', width: 8, height: 8 }}
      />
    </div>
  );
}

interface Layer2NodeData {
  step: Step;
  systemColor: string;
  capCount: number;
  onDrillDown: (stepId: string) => void;
  onBack: () => void;
}

function Layer2StepNode({ data }: { data: Layer2NodeData }) {
  const { step, systemColor, capCount, onDrillDown } = data;
  return (
    <div
      className="rounded-xl border-2 px-4 py-3 bg-[#111827] min-w-[220px] cursor-pointer hover:brightness-125 transition-all"
      style={{ borderColor: systemColor }}
      onClick={() => onDrillDown(step.id)}
    >
      <div className="flex items-center gap-2 mb-1">
        <div
          className="h-5 w-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
          style={{ backgroundColor: systemColor }}
        >
          {step.number}
        </div>
        <span className="text-sm font-bold text-[#F1F5F9] truncate">{step.name}</span>
      </div>
      <p className="text-[11px] text-[#94A3B8] line-clamp-2 mb-2">{step.description}</p>
      <div className="flex items-center justify-between">
        <span className="text-[10px] text-[#475569]">{capCount} capabilities</span>
        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#1E293B] text-[#94A3B8]">
          {step.status}
        </span>
      </div>
      <Handle
        type="target"
        position={Position.Left}
        style={{ background: systemColor, border: 'none', width: 8, height: 8 }}
      />
      <Handle
        type="source"
        position={Position.Right}
        style={{ background: systemColor, border: 'none', width: 8, height: 8 }}
      />
    </div>
  );
}

interface Layer3NodeData {
  capability: Capability;
  systemColor: string;
  onBack: () => void;
}

function Layer3CapabilityNode({ data }: { data: Layer3NodeData }) {
  const { capability: cap, systemColor } = data;
  const isApi = cap.type === 'API';
  return (
    <div
      className="rounded-xl border-2 px-4 py-3 bg-[#111827] min-w-[240px]"
      style={{ borderColor: systemColor }}
    >
      <div className="flex items-center gap-2 mb-1">
        <div
          className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase"
          style={{
            backgroundColor: isApi ? `${systemColor}15` : '#1E293B',
            color: isApi ? systemColor : '#64748B',
          }}
        >
          {cap.method || cap.type}
        </div>
        <span className="text-sm font-bold text-[#F1F5F9] truncate">{cap.name}</span>
      </div>
      <p className="text-[11px] text-[#94A3B8] line-clamp-2 mb-2">{cap.description}</p>
      {cap.endpoint && (
        <p className="text-[10px] text-[#475569] font-mono truncate">{cap.endpoint}</p>
      )}
      <div className="flex flex-wrap gap-1 mt-2">
        {cap.tags.map((tag) => (
          <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded-full bg-[#1E293B] text-[#64748B]">
            {tag}
          </span>
        ))}
      </div>
      <Handle
        type="target"
        position={Position.Left}
        style={{ background: systemColor, border: 'none', width: 8, height: 8 }}
      />
      <Handle
        type="source"
        position={Position.Right}
        style={{ background: systemColor, border: 'none', width: 8, height: 8 }}
      />
    </div>
  );
}

const nodeTypes = {
  layer1System: Layer1SystemNode,
  layer2Step: Layer2StepNode,
  layer3Capability: Layer3CapabilityNode,
};

type Layer = 'layer1' | 'layer2' | 'layer3';

/* ─────────────────────────────────────────────
   User Message Bubble
   ───────────────────────────────────────────── */

function UserMessage({ message }: { message: Message }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex items-start gap-3"
    >
      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#1E293B] flex-shrink-0 mt-0.5">
        <User className="h-4 w-4 text-[#94A3B8]" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="rounded-xl bg-[#111827] border border-[#1E293B] px-4 py-3">
          <p className="text-sm text-[#CBD5E1] leading-relaxed">{message.content}</p>
        </div>
        <span className="text-[10px] text-[#475569] mt-1 ml-1">{message.timestamp}</span>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────
   Editable System Card (expandable/collapsible)
   ───────────────────────────────────────────── */

function EditableSystemCard({
  recommendation,
  allCapabilities,
}: {
  recommendation: SystemRecommendation;
  allCapabilities: SystemCapabilityDef[];
}) {
  const [expanded, setExpanded] = useState(false);
  const Icon = SYSTEM_ICONS[recommendation.name] || Sparkles;
  const color = SYSTEM_COLORS[recommendation.name] || '#CBD5E1';

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-xl border border-[#1E293B] bg-[#111827] overflow-hidden transition-all"
      style={{ borderLeftColor: color, borderLeftWidth: '3px' }}
    >
      {/* Header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full text-left px-4 py-3 flex items-center gap-2.5 hover:bg-[#1a2235] transition-colors"
      >
        <div
          className="flex h-8 w-8 items-center justify-center rounded-lg flex-shrink-0"
          style={{ backgroundColor: `${color}18` }}
        >
          <Icon className="h-4 w-4" style={{ color }} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <span className="text-sm font-bold text-[#F1F5F9]">{recommendation.name}</span>
            <span
              className="rounded-full px-2 py-0.5 text-[11px] font-semibold"
              style={{
                backgroundColor: `${getConfidenceColor(recommendation.confidence)}20`,
                color: getConfidenceColor(recommendation.confidence),
              }}
            >
              {recommendation.confidence}% match
            </span>
          </div>
          <p className="text-xs text-[#94A3B8] leading-relaxed truncate">{recommendation.reason}</p>
        </div>
        {expanded ? (
          <ChevronUp className="h-4 w-4 text-[#64748B] flex-shrink-0 ml-2" />
        ) : (
          <ChevronDown className="h-4 w-4 text-[#64748B] flex-shrink-0 ml-2" />
        )}
      </button>

      {/* Expanded content */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-3 border-t border-[#1E293B]">
              <Progress value={recommendation.confidence} className="h-1.5 mt-3 mb-3 bg-[#1E293B]" />

              {/* Matched Capabilities */}
              {recommendation.matchedCapabilities && recommendation.matchedCapabilities.length > 0 && (
                <div className="mb-3">
                  <p className="text-[11px] font-medium text-[#64748B] mb-1.5">Matched Capabilities:</p>
                  <div className="flex flex-wrap gap-1.5">
                    {recommendation.matchedCapabilities.map((cap) => (
                      <span
                        key={cap}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-[#0A0F1E] border border-[#1E293B] text-[#94A3B8] truncate max-w-[200px]"
                        title={cap}
                      >
                        {cap}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <p className="text-[11px] font-medium text-[#64748B] mb-2">Capabilities used:</p>
              <div className="space-y-1.5">
                {recommendation.apis.map((api) => {
                  const capDef = allCapabilities.find((c) => c.name === api);
                  return (
                    <div
                      key={api}
                      className="flex items-start gap-2 rounded-lg bg-[#0A0F1E] px-3 py-2"
                    >
                      <div className="flex h-4 w-4 items-center justify-center rounded bg-[#6366F1] flex-shrink-0 mt-0.5">
                        <Check className="h-3 w-3 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="text-[11px] font-mono text-[#94A3B8] block truncate">{api}</span>
                        {capDef && (
                          <span className="text-[10px] text-[#64748B] block truncate">{capDef.description}</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}


/* ─────────────────────────────────────────────
   AI Message Card (with recommendations + workflow + action bar)
   ───────────────────────────────────────────── */

function AIMessage({
  message,
  onViewCanvas,
  onUpdateMessage,
  onRefreshAnalysis,
  onSaveAsSOP,
}: {
  message: Message;
  onViewCanvas: () => void;
  onUpdateMessage: (updatedMessage: Message) => void;
  onRefreshAnalysis?: () => void;
  onSaveAsSOP?: (workflow: WorkflowNode[]) => void;
}) {
  const recommendations = message.recommendations || [];
  const overallConfidence = recommendations.length > 0
    ? Math.round(recommendations.reduce((sum, r) => sum + r.confidence, 0) / recommendations.length)
    : 0;

  // onUpdateMessage is passed from parent but not used in read-only mode
  void onUpdateMessage;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex items-start gap-3"
    >
      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[rgba(99,102,241,0.15)] flex-shrink-0 mt-0.5">
        <Bot className="h-4 w-4 text-[#818CF8]" />
      </div>
      <div className="flex-1 min-w-0 space-y-4">
        {/* AI Card */}
        <div className="rounded-xl border border-[rgba(99,102,241,0.2)] bg-[rgba(99,102,241,0.06)] px-5 py-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-[#818CF8]" />
              <span className="text-sm font-semibold text-[#F1F5F9]">OPR AI</span>
            </div>
            <span className="text-[10px] text-[#64748B]">{message.timestamp}</span>
          </div>

          {/* Analysis text */}
          <p className="text-sm text-[#94A3B8] leading-relaxed mb-4">{message.content}</p>

          {/* Overall Confidence */}
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs font-medium text-[#64748B]">Overall Match</span>
            <div className="flex-1 max-w-[200px]">
              <Progress value={overallConfidence} className="h-2 bg-[#1E293B]" />
            </div>
            <span className="text-sm font-bold text-[#818CF8]">{overallConfidence}%</span>
          </div>

          {/* Recommended Systems */}
          <div className="mb-4">
            <h4 className="text-sm font-semibold text-[#F1F5F9] mb-3 flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-[#64748B]" />
              Recommended Systems
            </h4>
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
              {recommendations.map((rec) => (
                <EditableSystemCard
                  key={rec.name}
                  recommendation={rec}
                  allCapabilities={ALL_SYSTEM_CAPABILITIES[rec.name] || []}
                />
              ))}
            </div>

          </div>

          {/* Action Bar */}
          <div className="flex items-center gap-3 pt-2 border-t border-[rgba(99,102,241,0.15)]">
            {onRefreshAnalysis && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={onRefreshAnalysis}
                  className="text-[#94A3B8] hover:text-[#818CF8] text-xs h-8 hover:bg-[#1E293B]"
                >
                  <RefreshCw className="h-3.5 w-3.5 mr-1.5" />
                  Refresh Analysis
                </Button>
              )}
              {onSaveAsSOP && message.workflow && message.workflow.length > 0 && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => onSaveAsSOP(message.workflow!)}
                  className="text-[#94A3B8] hover:text-[#818CF8] text-xs h-8 hover:bg-[#1E293B]"
                >
                  <BookMarked className="h-3.5 w-3.5 mr-1.5" />
                  Save as SOP
                </Button>
              )}
              <Button
                size="sm"
                onClick={onViewCanvas}
                className="bg-[#6366F1] text-white hover:bg-[#4F46E5] text-xs h-8"
              >
                <ArrowRightCircle className="h-3.5 w-3.5 mr-1.5" />
                View in Canvas
              </Button>
            </div>
        </div>
      </div>
    </motion.div>
  );
}


/* ─────────────────────────────────────────────
   Chat Input (bottom input with mode switching)
   ───────────────────────────────────────────── */

function ChatInput({
  onSendFollowUp,
  isLoading,
}: {
  onSendFollowUp: (text: string) => void;
  isLoading: boolean;
}) {
  const [mode, setMode] = useState<'buttons' | 'input'>('buttons');
  const [text, setText] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const el = textareaRef.current;
    if (el) {
      el.style.height = 'auto';
      el.style.height = `${Math.min(el.scrollHeight, 80)}px`;
    }
  }, [text]);

  const handleSend = useCallback(() => {
    if (!text.trim()) return;
    onSendFollowUp(text.trim());
    setText('');
    setMode('buttons');
  }, [text, onSendFollowUp]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="border-t border-[#1E293B] bg-[#0A0F1E] px-4 py-3">
      {mode === 'buttons' ? (
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMode('input')}
            className="flex-1 flex items-center gap-2 rounded-xl border border-[#1E293B] bg-[#111827] px-4 py-2.5 text-sm text-[#64748B] hover:text-[#CBD5E1] hover:border-[#334155] transition-all text-left"
          >
            <MessageSquare className="h-4 w-4" />
            Type follow-up or edit instructions...
          </button>
        </div>
      ) : (
        <div className="flex items-end gap-2">
          <Textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Describe changes... e.g., 'Also add QTrack email translation'"
            className="flex-1 min-h-[40px] max-h-[80px] resize-none border-[#1E293B] bg-[#111827] text-sm text-[#F1F5F9] placeholder:text-[#475569] focus:border-[#6366F1] rounded-xl"
            autoFocus
          />
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setMode('buttons');
                setText('');
              }}
              className="h-9 w-9 p-0 text-[#64748B] hover:text-[#F1F5F9]"
            >
              <X className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              onClick={handleSend}
              disabled={!text.trim() || isLoading}
              className="h-9 w-9 p-0 bg-[#6366F1] text-white hover:bg-[#4F46E5] rounded-xl"
            >
              {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─────────────────────────────────────────────
   Chat Thread (scrollable message list)
   ───────────────────────────────────────────── */

function ChatThread({
  conversation,
  onViewCanvas,
  onUpdateConversation,
  onSaveAsSOP,
}: {
  conversation: Conversation;
  onViewCanvas: () => void;
  onUpdateConversation: (updated: Conversation) => void;
  onSaveAsSOP?: (workflow: WorkflowNode[]) => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversation.messages]);

  const handleUpdateMessage = useCallback(
    (msgIndex: number, updatedMessage: Message) => {
      const newMessages = [...conversation.messages];
      newMessages[msgIndex] = updatedMessage;
      // Recalculate overall confidence
      const aiMessages = newMessages.filter((m) => m.type === 'ai' && m.overallConfidence);
      const lastConfidence = aiMessages.length > 0 ? aiMessages[aiMessages.length - 1].overallConfidence! : conversation.overallConfidence;
      onUpdateConversation({
        ...conversation,
        messages: newMessages,
        overallConfidence: lastConfidence,
      });
    },
    [conversation, onUpdateConversation]
  );

  // Refresh analysis: re-run capability-based matching using the original user requirement
  const handleRefreshAnalysis = useCallback(() => {
    const firstUserMsg = conversation.messages.find((m) => m.type === 'user');
    if (!firstUserMsg) return;
    const fresh = generateAnalysis(firstUserMsg.content);
    // Keep the original conversation ID and timestamps, replace only the AI analysis
    const updatedMessages = conversation.messages.map((m) => {
      if (m.type === 'ai') {
        return {
          ...m,
          content: fresh.messages[1].content,
          workflow: fresh.messages[1].workflow,
          recommendations: fresh.messages[1].recommendations,
          overallConfidence: fresh.messages[1].overallConfidence,
        };
      }
      return m;
    });
    // If no AI message existed, append the fresh one
    if (!conversation.messages.some((m) => m.type === 'ai')) {
      updatedMessages.push(fresh.messages[1]);
    }
    const lastAi = updatedMessages.filter((m) => m.type === 'ai').pop();
    onUpdateConversation({
      ...conversation,
      messages: updatedMessages,
      overallConfidence: lastAi?.overallConfidence ?? conversation.overallConfidence,
    });
  }, [conversation, onUpdateConversation]);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 border-b border-[#1E293B] bg-[#0A0F1E] flex-shrink-0">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-4 w-4 text-[#818CF8]" />
          <h2 className="text-sm font-bold text-[#F1F5F9]">{conversation.title}</h2>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-[#818CF8]">{conversation.overallConfidence}%</span>
          <StatusBadge
            variant={conversation.status === 'completed' ? 'success' : 'info'}
            className={
              conversation.status === 'completed'
                ? 'bg-[rgba(34,197,94,0.15)] text-[#22C55E]'
                : 'bg-[rgba(99,102,241,0.15)] text-[#818CF8]'
            }
          >
            {conversation.status === 'completed' ? 'Completed' : 'In Progress'}
          </StatusBadge>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-5 space-y-6">
        {conversation.messages.map((msg, idx) =>
          msg.type === 'user' ? (
            <UserMessage key={msg.id} message={msg} />
          ) : (
            <AIMessage
              key={msg.id}
              message={msg}
              onViewCanvas={onViewCanvas}
              onUpdateMessage={(updated) => handleUpdateMessage(idx, updated)}
              onRefreshAnalysis={handleRefreshAnalysis}
              onSaveAsSOP={onSaveAsSOP}
            />
          )
        )}

      </div>
    </div>
  );
}


/* ─────────────────────────────────────────────
   Left Panel: Conversation List Item (updated for messages)
   ───────────────────────────────────────────── */

function ConversationListItem({
  conversation,
  isSelected,
  onClick,
  onViewCanvas,
}: {
  conversation: Conversation;
  isSelected: boolean;
  onClick: () => void;
  onViewCanvas: (e: React.MouseEvent) => void;
}) {
  // Get the last AI message for recommendations display
  const lastAiMsg = conversation.messages.filter((m) => m.type === 'ai').pop();
  const firstUserMsg = conversation.messages.find((m) => m.type === 'user');
  const recommendations = lastAiMsg?.recommendations || [];
  const userContent = firstUserMsg?.content || '';

  return (
    <motion.button
      layout
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      onClick={onClick}
      className={cn(
        'w-full text-left rounded-xl border transition-all duration-200 overflow-hidden',
        isSelected
          ? 'border-[#6366F1]/50 bg-[#1E293B] shadow-[0_0_20px_rgba(99,102,241,0.15)]'
          : 'border-[#1E293B] bg-[#111827] hover:border-[#334155] hover:bg-[#1a2235] hover:shadow-[0_0_12px_rgba(99,102,241,0.06)]'
      )}
    >
      <div className="flex items-stretch">
        <div
          className={cn(
            'w-[3px] flex-shrink-0 transition-all duration-200',
            isSelected ? 'bg-[#6366F1]' : 'bg-transparent'
          )}
        />
        <div className="flex-1 px-4 py-4">
          <div className="flex items-center gap-2 mb-1.5">
            <h3
              className={cn(
                'text-sm font-semibold truncate flex-1',
                isSelected ? 'text-[#F1F5F9]' : 'text-[#CBD5E1]'
              )}
            >
              {conversation.title}
            </h3>
            <button
              onClick={onViewCanvas}
              className="ml-auto flex h-6 w-6 items-center justify-center rounded-md bg-[#1E293B] text-[#64748B] hover:text-[#6366F1] hover:bg-[#6366F1]/10 transition-all flex-shrink-0"
              title="View Workflow"
            >
              <Workflow className="h-3 w-3" />
            </button>
          </div>

          <p className="text-xs text-[#64748B] truncate mb-3 leading-relaxed">
            {userContent}
          </p>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              {recommendations.map((rec) => (
                <div
                  key={rec.name}
                  className="h-2 w-2 rounded-full"
                  style={{ backgroundColor: SYSTEM_COLORS[rec.name] || '#CBD5E1' }}
                  title={rec.name}
                />
              ))}
            </div>
            <div className="flex items-center gap-2">
              <StatusBadge
                variant={conversation.status === 'completed' ? 'success' : 'info'}
                className={cn(
                  conversation.status === 'completed'
                    ? 'bg-[rgba(34,197,94,0.15)] text-[#22C55E]'
                    : 'bg-[rgba(99,102,241,0.15)] text-[#818CF8]'
                )}
              >
                {conversation.status === 'completed' ? 'Completed' : 'In Progress'}
              </StatusBadge>
              <span className="text-[11px] text-[#475569]">{conversation.date}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.button>
  );
}

/* ─────────────────────────────────────────────
   Right Panel: Workflow Canvas (Mini)
   ───────────────────────────────────────────── */

/**
 * Inner component that runs inside ReactFlowProvider to capture
 * screenToFlowPosition and expose it via ref to the parent.
 */
const FlowRefSetter = React.forwardRef<
  { screenToFlowPosition: ((pos: { x: number; y: number }) => { x: number; y: number }) | null }
>(function FlowRefSetter(_, ref) {
  const { screenToFlowPosition } = useReactFlow();
  React.useImperativeHandle(ref, () => ({
    screenToFlowPosition,
  }));
  return null;
});

function WorkflowCanvasMini({
  workflowNodes,
  conversationTitle,
  onBackToChat,
  onSendFollowUp,
  isLoading,
}: {
  workflowNodes: WorkflowNode[];
  conversationTitle: string;
  onBackToChat: () => void;
  onSendFollowUp: (text: string) => void;
  isLoading: boolean;
}) {
  const [currentLayer, setCurrentLayer] = useState<Layer>('layer1');
  const [selectedSystemId, setSelectedSystemId] = useState<string | null>(null);
  const [selectedStepId, setSelectedStepId] = useState<string | null>(null);
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [canvasInput, setCanvasInput] = useState('');
  const [editableWorkflow, setEditableWorkflow] = useState<WorkflowNode[]>(workflowNodes);

  // Editable node/edge state for layer1 (user can drag, connect, delete, drop)
  const [editableNodes, setEditableNodes] = useState<Node[]>([]);
  const [editableEdges, setEditableEdges] = useState<Edge[]>([]);

  // Ref to access screenToFlowPosition from within ReactFlowProvider
  const flowRef = useRef<{ screenToFlowPosition: ((pos: { x: number; y: number }) => { x: number; y: number }) | null }>({ screenToFlowPosition: null });

  // Ref to ensure one-time initialization of editable nodes/edges
  const hasInitialized = useRef(false);

  // Build Layer 1: Systems — with branch-aware layout
  const layer1Nodes = useMemo(() => {
    const uniqueSystems = Array.from(new Set(editableWorkflow.map((n) => n.system)));

    // Find merge nodes and their inputs
    const mergeNodes = new Map<string, string[]>(); // target -> input sources
    editableWorkflow.forEach((n) => {
      if (n.inputs && n.inputs.length > 1) {
        mergeNodes.set(n.system, n.inputs);
      }
    });

    // Assign x positions (left to right pipeline)
    const xPositions = new Map<string, number>();
    let x = 80;
    uniqueSystems.forEach((sys) => {
      xPositions.set(sys, x);
      x += 280;
    });

    // Assign y positions — merge inputs go above/below
    const yPositions = new Map<string, number>();
    const usedX = new Map<number, string[]>(); // x -> systems at this x

    uniqueSystems.forEach((sys) => {
      const px = xPositions.get(sys) || 0;
      const arr = usedX.get(px) || [];
      arr.push(sys);
      usedX.set(px, arr);
    });

    // Default all to center y
    uniqueSystems.forEach((sys) => {
      yPositions.set(sys, 200);
    });

    // For merge inputs, offset them vertically
    mergeNodes.forEach((inputs, target) => {
      if (inputs.length === 2) {
        // First input goes up, second goes down
        yPositions.set(inputs[0], 120);
        yPositions.set(inputs[1], 280);
        yPositions.set(target, 200); // merge node centered
      } else if (inputs.length > 2) {
        inputs.forEach((inp, idx) => {
          yPositions.set(inp, 100 + idx * 100);
        });
        yPositions.set(target, 200);
      }
    });

    return uniqueSystems.map((systemName) => {
      const sysColor = SYSTEM_COLORS[systemName] || '#6366F1';
      const sysIcon = SYSTEM_ICONS[systemName] || Sparkles;
      const sysSteps = getStepsBySystemName(systemName);
      const capCount = sysSteps.reduce((sum, s) => sum + getCapabilitiesByStepId(s.id).length, 0);
      const isMerge = mergeNodes.has(systemName);
      const isInput = Array.from(mergeNodes.values()).some((arr) => arr.includes(systemName));

      return {
        id: `sys-${systemName}`,
        type: 'layer1System' as const,
        position: {
          x: xPositions.get(systemName) || 0,
          y: yPositions.get(systemName) || 200,
        },
        data: {
          system: systemName,
          description: sysSteps[0]?.description?.slice(0, 80) + '...' || '',
          color: sysColor,
          icon: sysIcon,
          stepCount: sysSteps.length,
          capCount,
          isMerge,
          isInput,
          onDrillDown: (sid: string) => {
            setSelectedSystemId(sid);
            setCurrentLayer('layer2');
          },
        },
      };
    });
  }, [editableWorkflow]);

  const layer1Edges = useMemo(() => {
    const edges: { id: string; source: string; target: string; animated: boolean; style: { stroke: string; strokeWidth: number }; type: 'smoothstep' }[] = [];

    // Track which source→target pairs we've already added
    const edgeKey = (s: string, t: string) => `${s}→${t}`;
    const added = new Set<string>();

    // Find all systems that are used as inputs by ANY node
    // These systems' outputs go to those nodes, NOT sequentially
    const systemsUsedAsInputs = new Set<string>();
    editableWorkflow.forEach((n) => {
      n.inputs?.forEach((inSys) => systemsUsedAsInputs.add(inSys));
    });

    editableWorkflow.forEach((node, idx) => {
      const targetId = `sys-${node.system}`;
      const targetColor = SYSTEM_COLORS[node.system] || '#6366F1';

      // 1. Input edges: from each declared input source to this node
      if (node.inputs && node.inputs.length > 0) {
        node.inputs.forEach((inSys, inIdx) => {
          const key = edgeKey(`sys-${inSys}`, targetId);
          if (!added.has(key)) {
            added.add(key);
            edges.push({
              id: `e1-in-${inSys}-${node.system}-${inIdx}`,
              source: `sys-${inSys}`,
              target: targetId,
              animated: true,
              style: { stroke: SYSTEM_COLORS[inSys] || targetColor, strokeWidth: 2 },
              type: 'smoothstep' as const,
            });
          }
        });
      }

      // 2. Sequential edge: from previous node in workflow order
      // ONLY if:
      // - This node has NO inputs (otherwise inputs handle the edges)
      // - Previous node is NOT used as input by any other node
      //   (its output flows sequentially, not to a specific target)
      if ((!node.inputs || node.inputs.length === 0) && idx > 0) {
        const prevNode = editableWorkflow[idx - 1];
        const prevId = `sys-${prevNode.system}`;

        // CRITICAL: If previous node is used as an input source,
        // its output goes to that input target, NOT sequentially
        if (!systemsUsedAsInputs.has(prevNode.system)) {
          const key = edgeKey(prevId, targetId);
          if (!added.has(key)) {
            added.add(key);
            edges.push({
              id: `e1-seq-${node.system}`,
              source: prevId,
              target: targetId,
              animated: true,
              style: { stroke: targetColor, strokeWidth: 2 },
              type: 'smoothstep' as const,
            });
          }
        }
      }
    });

    return edges;
  }, [editableWorkflow]);

  // Build Layer 2: Steps for selected system
  const layer2Nodes = useMemo(() => {
    if (!selectedSystemId) return [];
    const sysSteps = getStepsBySystemName(selectedSystemId);
    const sysColor = SYSTEM_COLORS[selectedSystemId] || '#6366F1';
    return sysSteps.map((step, i) => {
      const caps = getCapabilitiesByStepId(step.id);
      return {
        id: `step-${step.id}`,
        type: 'layer2Step' as const,
        position: { x: 100 + i * 260, y: 200 },
        data: {
          step,
          systemColor: sysColor,
          capCount: caps.length,
          onDrillDown: (stepId: string) => {
            setSelectedStepId(stepId);
            setCurrentLayer('layer3');
          },
          onBack: () => setCurrentLayer('layer1'),
        },
      };
    });
  }, [selectedSystemId]);

  const layer2Edges = useMemo(() => {
    if (!selectedSystemId) return [];
    const sysSteps = getStepsBySystemName(selectedSystemId);
    const sysColor = SYSTEM_COLORS[selectedSystemId] || '#6366F1';
    return sysSteps.slice(0, -1).map((_s, i) => ({
      id: `e2-${i}`,
      source: `step-${sysSteps[i].id}`,
      target: `step-${sysSteps[i + 1].id}`,
      animated: true,
      style: { stroke: sysColor, strokeWidth: 2 },
      type: 'smoothstep' as const,
    }));
  }, [selectedSystemId]);

  // Build Layer 3: Capabilities for selected step
  const layer3Nodes = useMemo(() => {
    if (!selectedStepId) return [];
    const step = getStepById(selectedStepId);
    const sysColor = step ? SYSTEM_COLORS[step.systemId] || '#6366F1' : '#6366F1';
    const caps = getCapabilitiesByStepId(selectedStepId);
    return caps.map((cap, i) => ({
      id: `cap-${cap.id}`,
      type: 'layer3Capability' as const,
      position: { x: 80 + i * 270, y: 200 },
      data: {
        capability: cap,
        systemColor: sysColor,
        onBack: () => setCurrentLayer('layer2'),
      },
    }));
  }, [selectedStepId]);

  const layer3Edges = useMemo(() => {
    if (!selectedStepId) return [];
    const step = getStepById(selectedStepId);
    const sysColor = step ? SYSTEM_COLORS[step.systemId] || '#6366F1' : '#6366F1';
    const caps = getCapabilitiesByStepId(selectedStepId);
    return caps.slice(0, -1).map((_c, i) => ({
      id: `e3-${i}`,
      source: `cap-${caps[i].id}`,
      target: `cap-${caps[i + 1].id}`,
      animated: true,
      style: { stroke: sysColor, strokeWidth: 2 },
      type: 'smoothstep' as const,
    }));
  }, [selectedStepId]);

  // Select active nodes/edges
  const activeNodes = currentLayer === 'layer1' ? editableNodes : currentLayer === 'layer2' ? layer2Nodes : layer3Nodes;
  const activeEdges = currentLayer === 'layer1' ? editableEdges : currentLayer === 'layer2' ? layer2Edges : layer3Edges;

  const [nodes, setNodes] = useNodesState<Node>([]);
  const [edges, setEdges] = useEdgesState<Edge>([]);

  // Initialize editable nodes/edges from computed layer1 values — runs once on mount
  useEffect(() => {
    if (!hasInitialized.current && layer1Nodes.length > 0) {
      hasInitialized.current = true;
      setEditableNodes(layer1Nodes);
      setEditableEdges(layer1Edges);
    }
  }, [layer1Nodes, layer1Edges, setEditableNodes, setEditableEdges]);

  // Sync nodes/edges when layer changes
  useEffect(() => {
    setNodes(activeNodes);
    setEdges(activeEdges);
  }, [currentLayer, selectedSystemId, selectedStepId, activeNodes, activeEdges, setNodes, setEdges]);

  // ── Layer 1 Interactive Handlers ──────────────────────

  const onNodesChange = useCallback((changes: NodeChange[]) => {
    // Apply to ReactFlow internal state
    setNodes((nds) => applyNodeChanges(changes, nds));
    // Also update editableNodes so position changes / deletions persist
    setEditableNodes((nds) => applyNodeChanges(changes, nds));
  }, [setNodes]);

  const onEdgesChange = useCallback((changes: EdgeChange[]) => {
    setEdges((eds) => applyEdgeChanges(changes, eds));
    setEditableEdges((eds) => applyEdgeChanges(changes, eds));
  }, [setEdges]);

  const onConnect = useCallback((params: Connection) => {
    const sourceColor = SYSTEM_COLORS[params.source?.replace('sys-', '') || ''] || '#6366F1';
    const newEdge: Edge = {
      id: `e-manual-${params.source}-${params.target}-${Date.now()}`,
      source: params.source!,
      target: params.target!,
      animated: true,
      style: { stroke: sourceColor, strokeWidth: 2 },
      type: 'smoothstep',
    };
    setEditableEdges((eds) => [...eds, newEdge]);
  }, []);

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  }, []);

  const onDrop = useCallback((event: React.DragEvent) => {
    event.preventDefault();
    const data = event.dataTransfer.getData('application/opr-system');
    if (!data) return;

    try {
      const sys = JSON.parse(data);
      const position = flowRef.current?.screenToFlowPosition
        ? flowRef.current.screenToFlowPosition({
            x: event.clientX,
            y: event.clientY,
          })
        : { x: event.clientX, y: event.clientY };

      const sysColor = SYSTEM_COLORS[sys.name] || '#6366F1';
      const sysIcon = SYSTEM_ICONS[sys.name] || Sparkles;
      const sysSteps = getStepsBySystemName(sys.name);
      const capCount = sysSteps.reduce((sum: number, s: Step) => sum + getCapabilitiesByStepId(s.id).length, 0);

      const newNode: Node = {
        id: `sys-${sys.name}-${Date.now()}`,
        type: 'layer1System',
        position,
        data: {
          system: sys.name,
          description: sysSteps[0]?.description?.slice(0, 80) + '...' || '',
          color: sysColor,
          icon: sysIcon,
          stepCount: sysSteps.length,
          capCount,
          isMerge: false,
          isInput: false,
          onDrillDown: (sid: string) => {
            setSelectedSystemId(sid);
            setCurrentLayer('layer2');
          },
        },
      };

      setEditableNodes((nds) => [...nds, newNode]);
    } catch {
      // ignore invalid drop data
    }
  }, [flowRef]);

  const breadcrumb = (
    <div className="flex items-center gap-1 text-[11px] text-[#64748B]">
      <button
        onClick={() => { setCurrentLayer('layer1'); setSelectedSystemId(null); setSelectedStepId(null); }}
        className={cn('hover:text-[#F1F5F9] transition-colors', currentLayer === 'layer1' && 'text-[#F1F5F9] font-medium')}
      >
        Systems
      </button>
      {currentLayer !== 'layer1' && selectedSystemId && (
        <>
          <span>/</span>
          <button
            onClick={() => { setCurrentLayer('layer2'); setSelectedStepId(null); }}
            className={cn('hover:text-[#F1F5F9] transition-colors', currentLayer === 'layer2' && 'text-[#F1F5F9] font-medium')}
          >
            {selectedSystemId}
          </button>
        </>
      )}
      {currentLayer === 'layer3' && selectedStepId && (
        <>
          <span>/</span>
          <span className="text-[#F1F5F9] font-medium">
            {getStepById(selectedStepId)?.name || 'Step'}
          </span>
        </>
      )}
    </div>
  );

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#1E293B] bg-[#0A0F1E]">
        <div className="flex items-center gap-3">
          <Workflow className="h-4 w-4 text-[#6366F1]" />
          <span className="text-sm font-bold text-[#F1F5F9]">Workflow View</span>
          <span className="text-xs text-[#64748B]">{conversationTitle}</span>
          <div className="h-3 w-px bg-[#1E293B] mx-1" />
          {breadcrumb}
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onBackToChat}
          className="text-[#94A3B8] hover:text-[#F1F5F9]"
        >
          Back to Chat
        </Button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Systems Sidebar */}
        <div className="w-52 border-r border-[#1E293B] bg-[#0A0F1E] flex flex-col overflow-hidden">
          <div className="px-3 py-2.5 border-b border-[#1E293B]">
            <span className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider">Available Systems</span>
            <p className="text-[10px] text-[#475569] mt-0.5">Click to add/remove</p>
            <p className="text-[10px] text-[#475569] mt-0.5">Drag to canvas to add</p>
          </div>
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {ALL_SYSTEMS.map((sys) => {
              const isIncluded = editableWorkflow.some((n) => n.system === sys.name);
              return (
                <button
                  key={sys.id}
                  draggable
                  onDragStart={(e) => {
                    e.dataTransfer.setData('application/opr-system', JSON.stringify(sys));
                    e.dataTransfer.effectAllowed = 'copy';
                  }}
                  onClick={() => {
                    if (isIncluded) {
                      // Remove all nodes with this system
                      setEditableWorkflow((prev) => prev.filter((n) => n.system !== sys.name));
                    } else {
                      // Add a placeholder node for this system
                      setEditableWorkflow((prev) => [
                        ...prev,
                        {
                          id: `${sys.name}-${Date.now()}`,
                          system: sys.name,
                          action: `process-${sys.id}`,
                          description: `${sys.name} processing step`,
                          inputs: [],
                          output: '',
                          stepIds: [],
                        },
                      ]);
                    }
                  }}
                  className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-left transition-all text-[12px] ${
                    isIncluded
                      ? 'bg-[rgba(99,102,241,0.1)] border border-[#6366F1]/30 text-[#F1F5F9]'
                      : 'border border-transparent text-[#64748B] hover:bg-[#1E293B] hover:text-[#94A3B8]'
                  }`}
                  style={{ cursor: 'grab' }}
                >
                  <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: SYSTEM_COLORS[sys.name] || '#CBD5E1' }} />
                  <span className="flex-1 truncate">{sys.name}</span>
                  {isIncluded && <Check className="w-3 h-3 text-[#6366F1] shrink-0" />}
                </button>
              );
            })}
          </div>
          <div className="px-3 py-2 border-t border-[#1E293B] text-[10px] text-[#475569]">
            {editableWorkflow.length} system(s) in workflow
          </div>
        </div>

        {/* ReactFlow Area */}
        <div className="flex-1 relative" style={{ background: '#030712' }}>
          <ReactFlowProvider>
            {/* Inner component to capture screenToFlowPosition from within Provider */}
            <FlowRefSetter ref={flowRef} />
            <ReactFlow
            key={currentLayer + selectedSystemId + selectedStepId}
            nodes={nodes}
            edges={edges}
            onNodesChange={currentLayer === 'layer1' ? onNodesChange : undefined}
            onEdgesChange={currentLayer === 'layer1' ? onEdgesChange : undefined}
            onConnect={currentLayer === 'layer1' ? onConnect : undefined}
            onDragOver={currentLayer === 'layer1' ? onDragOver : undefined}
            onDrop={currentLayer === 'layer1' ? onDrop : undefined}
            onNodeClick={(_event, node) => setSelectedNodeId(node.id)}
            deleteKeyCode="Delete"
            nodeTypes={nodeTypes}
            fitView
            fitViewOptions={{ padding: 0.3 }}
            attributionPosition="bottom-right"
          >
            <Background color="#1E293B" gap={20} size={1} />
            <Controls className="bg-[#111827] border-[#1E293B] text-[#94A3B8]" />
            <MiniMap
              className="bg-[#111827] border-[#1E293B]"
              nodeColor={(n: any) => n.data?.color || n.data?.systemColor || '#6366F1'}
              maskColor="rgba(3, 7, 18, 0.7)"
            />
          </ReactFlow>
          </ReactFlowProvider>

          {/* Layer 1 Interaction Legend */}
          {currentLayer === 'layer1' && (
            <div className="absolute bottom-3 left-3 z-10 bg-[#0A0F1E]/90 backdrop-blur-sm border border-[#1E293B] rounded-lg px-3 py-2 text-[10px] text-[#64748B] space-y-0.5">
              <div className="flex items-center gap-1.5"><span className="text-[#6366F1]">●</span> Drag nodes to reposition</div>
              <div className="flex items-center gap-1.5"><span className="text-[#6366F1]">●</span> Drag from handle to connect</div>
              <div className="flex items-center gap-1.5"><span className="text-[#6366F1]">●</span> Select + Delete to remove</div>
              <div className="flex items-center gap-1.5"><span className="text-[#6366F1]">●</span> Drag system from sidebar to add</div>
            </div>
          )}

          {/* Selected Node Detail Panel */}
          {selectedNodeId && currentLayer === 'layer1' && (() => {
            const node = editableNodes.find((n) => n.id === selectedNodeId);
            if (!node) return null;
            const nodeData = node.data as Record<string, any>;
            const sysName = nodeData.system as string;
            const sysSteps = getStepsBySystemName(sysName);
            const sysColor = SYSTEM_COLORS[sysName] || '#6366F1';
            const firstStep = sysSteps[0];
            return (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="absolute top-4 right-4 z-10 w-64 bg-[#0A0F1E]/95 backdrop-blur-sm border border-[#1E293B] rounded-xl shadow-xl"
              >
                <div className="px-4 py-3 border-b border-[#1E293B] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: sysColor }} />
                    <span className="text-sm font-semibold text-[#F1F5F9]">{sysName}</span>
                  </div>
                  <button
                    onClick={() => setSelectedNodeId(null)}
                    className="text-[#64748B] hover:text-[#F1F5F9] transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="px-4 py-3 space-y-3">
                  <div>
                    <span className="text-[10px] font-medium text-[#64748B] uppercase tracking-wider">Role</span>
                    <p className="text-xs text-[#94A3B8] mt-0.5">{firstStep?.description || `${sysName} processes data in this workflow`}</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-medium text-[#64748B] uppercase tracking-wider">Capabilities</span>
                    <p className="text-xs text-[#94A3B8] mt-0.5">{nodeData.capCount as number} capabilities available</p>
                  </div>
                  <div>
                    <span className="text-[10px] font-medium text-[#64748B] uppercase tracking-wider">Steps</span>
                    <p className="text-xs text-[#94A3B8] mt-0.5">{nodeData.stepCount as number} steps in this workflow</p>
                  </div>
                  <div className="pt-2 border-t border-[#1E293B]">
                    <span className="text-[10px] font-medium text-[#64748B] uppercase tracking-wider">Action</span>
                    <p className="text-xs text-[#F1F5F9] mt-0.5 font-medium">{firstStep?.name || sysName}</p>
                  </div>
                </div>
              </motion.div>
            );
          })()}
        </div>
      </div>

      {/* Canvas Bottom Input — real-time workflow editing */}
      <div className="shrink-0 border-t border-[#1E293B] bg-[#0A0F1E] px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex-1 relative">
            <input
              value={canvasInput}
              onChange={(e) => setCanvasInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey && canvasInput.trim()) {
                  e.preventDefault();
                  onSendFollowUp(canvasInput);
                  setCanvasInput('');
                }
              }}
              placeholder="Edit this workflow — e.g., 'Add GoldenEye for trade tracking' or 'Remove SIRE'"
              className="w-full h-9 bg-[#111827] border border-[#1E293B] rounded-lg px-3 pr-10 text-sm text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1] focus:ring-1 focus:ring-[#6366F1]/20"
            />
            {canvasInput.trim() && (
              <button
                onClick={() => {
                  onSendFollowUp(canvasInput);
                  setCanvasInput('');
                }}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-[#6366F1] hover:text-[#818CF8] transition-colors"
              >
                <Send className="h-4 w-4" />
              </button>
            )}
          </div>
          <Button
            onClick={() => {
              if (canvasInput.trim()) {
                onSendFollowUp(canvasInput);
                setCanvasInput('');
              }
            }}
            disabled={!canvasInput.trim() || isLoading}
            className="bg-[#6366F1] hover:bg-[#4F46E5] text-white h-9 px-4 text-sm"
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <span className="flex items-center gap-1.5">
                <Sparkles className="h-3.5 w-3.5" />
                Update
              </span>
            )}
          </Button>
        </div>
        <div className="flex items-center gap-3 mt-2">
          <span className="text-[10px] text-[#475569]">Quick edits:</span>
          {[
            'Add email translation',
            'Add GoldenEye',
            'Remove SIRE',
            'Add batch processing',
          ].map((hint) => (
            <button
              key={hint}
              onClick={() => {
                onSendFollowUp(hint);
              }}
              className="text-[10px] px-2 py-0.5 rounded-md bg-[#1E293B] text-[#64748B] hover:bg-[#6366F1]/10 hover:text-[#94A3B8] transition-colors"
            >
              {hint}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Right Panel: Hero Input Area
   ───────────────────────────────────────────── */

/* ─────────────────────────────────────────────
   Matching SOP Card
   ───────────────────────────────────────────── */

function MatchingSOPCard({ sop, score }: { sop: SOPKnowledge; score: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-lg border border-[#1E293B] bg-[#0A0F1E] p-3"
    >
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs font-semibold text-[#CBD5E1] truncate flex-1">{sop.title}</span>
        <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#1E293B] text-[#94A3B8] ml-2 shrink-0">
          {score} pts
        </span>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#6366F1]/10 text-[#818CF8]">
          {sop.category}
        </span>
        <div className="flex items-center gap-1">
          {sop.systemsInvolved.map((sys) => (
            <div
              key={sys}
              className="h-2 w-2 rounded-full"
              style={{ backgroundColor: SYSTEM_COLORS[sys] || '#CBD5E1' }}
              title={sys}
            />
          ))}
        </div>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────
   New Requirement Panel (fixed right panel)
   ───────────────────────────────────────────── */

function NewRequirementPanel({
  newConvText,
  setNewConvText,
  isNewConvLoading,
  handleNewConversationAnalyze,
  uploadedFile,
  setUploadedFile,
  emailSender,
  setEmailSender,
  emailSubject,
  setEmailSubject,
  activeTab,
  setActiveTab,
}: {
  newConvText: string;
  setNewConvText: (v: string) => void;
  isNewConvLoading: boolean;
  handleNewConversationAnalyze: () => void;
  uploadedFile: File | null;
  setUploadedFile: (f: File | null) => void;
  emailSender: string;
  setEmailSender: (v: string) => void;
  emailSubject: string;
  setEmailSubject: (v: string) => void;
  activeTab: string;
  setActiveTab: (v: string) => void;
}) {
  const findMatchingSOPs = useCallback((text: string): SOPKnowledge[] => {
    if (!text.trim() || text.trim().length < 5) return [];
    const query = text.toLowerCase();
    return INITIAL_SOPS.filter((sop) => {
      const score = [
        sop.title.toLowerCase().includes(query) ? 3 : 0,
        sop.category.toLowerCase().includes(query) ? 2 : 0,
        sop.description.toLowerCase().includes(query) ? 1 : 0,
        sop.tags.some((t) => t.toLowerCase().includes(query)) ? 2 : 0,
        sop.systemsInvolved.some((s) => query.includes(s.toLowerCase())) ? 1 : 0,
      ].reduce((a, b) => a + b, 0);
      return score >= 1;
    }).slice(0, 3);
  }, []);

  const matchingSOPs = useMemo(() => findMatchingSOPs(newConvText), [newConvText, findMatchingSOPs]);

  return (
    <div className="flex flex-col h-full bg-[#030712]">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 border-b border-[#1E293B] bg-[#0A0F1E] flex-shrink-0">
        <Sparkles className="h-5 w-5 text-[#6366F1]" />
        <div>
          <h2 className="text-sm font-bold text-[#F1F5F9]">Workflow Analysis</h2>
          <p className="text-[11px] text-[#64748B]">Describe your business requirement to generate a workflow</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-6 py-5">
        <div className="max-w-[640px] mx-auto space-y-4">
          <Tabs defaultValue="text" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-[#111827] border border-[#1E293B]">
              <TabsTrigger value="text" className="data-[state=active]:bg-[#6366F1] data-[state=active]:text-white text-[#94A3B8]">
                <FileText className="h-3.5 w-3.5 mr-1.5" />
                Text Input
              </TabsTrigger>
              <TabsTrigger value="document" className="data-[state=active]:bg-[#6366F1] data-[state=active]:text-white text-[#94A3B8]">
                <Upload className="h-3.5 w-3.5 mr-1.5" />
                Upload Document
              </TabsTrigger>
              <TabsTrigger value="email" className="data-[state=active]:bg-[#6366F1] data-[state=active]:text-white text-[#94A3B8]">
                <Mail className="h-3.5 w-3.5 mr-1.5" />
                Upload Email
              </TabsTrigger>
            </TabsList>

            {/* Tab 1: Text Input */}
            <TabsContent value="text" className="mt-4">
              <textarea
                value={newConvText}
                onChange={(e) => setNewConvText(e.target.value)}
                placeholder="Describe your business requirement in detail..."
                className="w-full min-h-[160px] bg-[#111827] border border-[#1E293B] rounded-lg px-4 py-3 text-sm text-[#F1F5F9] placeholder-[#475569] resize-none focus:outline-none focus:border-[#6366F1] focus:ring-1 focus:ring-[#6366F1]/30"
              />
              <div className="flex items-center justify-between mt-3">
                <span className="text-[11px] text-[#475569]">{newConvText.length}/5000</span>
                <Button
                  onClick={handleNewConversationAnalyze}
                  disabled={!newConvText.trim() || isNewConvLoading}
                  className="bg-[#6366F1] hover:bg-[#4F46E5] text-white h-8 text-xs"
                >
                  {isNewConvLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="h-3 w-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Analyzing...
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5">
                      <Sparkles className="h-3.5 w-3.5" />
                      Analyze
                    </span>
                  )}
                </Button>
              </div>

              {/* Matching SOPs */}
              <AnimatePresence>
                {matchingSOPs.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-4 overflow-hidden"
                  >
                    <p className="text-xs font-medium text-[#64748B] mb-2 flex items-center gap-1.5">
                      <BookMarked className="h-3 w-3" />
                      Matching SOPs
                    </p>
                    <div className="space-y-2">
                      {matchingSOPs.map((sop) => {
                        const query = newConvText.toLowerCase();
                        const score = [
                          sop.title.toLowerCase().includes(query) ? 3 : 0,
                          sop.category.toLowerCase().includes(query) ? 2 : 0,
                          sop.description.toLowerCase().includes(query) ? 1 : 0,
                          sop.tags.some((t) => t.toLowerCase().includes(query)) ? 2 : 0,
                          sop.systemsInvolved.some((s) => query.includes(s.toLowerCase())) ? 1 : 0,
                        ].reduce((a, b) => a + b, 0);
                        return <MatchingSOPCard key={sop.id} sop={sop} score={score} />;
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </TabsContent>

            {/* Tab 2: Upload Document */}
            <TabsContent value="document" className="mt-4">
              <div
                onDragOver={(e) => { e.preventDefault(); }}
                onDrop={(e) => {
                  e.preventDefault();
                  const files = Array.from(e.dataTransfer.files);
                  const file = files[0];
                  if (file) {
                    setUploadedFile(file);
                    setNewConvText(`Document uploaded: ${file.name}. Size: ${(file.size / 1024).toFixed(1)} KB. Type: ${file.type || 'unknown'}. Please analyze the requirements from this document.`);
                  }
                }}
                onClick={() => document.getElementById('doc-upload')?.click()}
                className="w-full h-[160px] border-2 border-dashed border-[#1E293B] rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-[#6366F1] hover:bg-[#6366F1]/5 transition-all"
              >
                <Upload className="h-8 w-8 text-[#475569] mb-2" />
                <p className="text-sm text-[#94A3B8]">Drop instruction manual here or click to browse</p>
                <p className="text-[11px] text-[#475569] mt-1">Supports: PDF, DOC, DOCX, TXT, XLSX</p>
                <input
                  id="doc-upload"
                  type="file"
                  accept=".pdf,.doc,.docx,.txt,.xlsx"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setUploadedFile(file);
                      setNewConvText(`Document uploaded: ${file.name}. Size: ${(file.size / 1024).toFixed(1)} KB. Type: ${file.type || 'unknown'}. Please analyze the requirements from this document.`);
                    }
                  }}
                />
              </div>
              {uploadedFile && (
                <div className="mt-3 flex items-center gap-2 p-2 rounded-lg bg-[#111827] border border-[#1E293B]">
                  <FileText className="h-4 w-4 text-[#6366F1]" />
                  <span className="text-xs text-[#94A3B8] flex-1 truncate">{uploadedFile.name}</span>
                  <span className="text-[10px] text-[#475569]">{(uploadedFile.size / 1024).toFixed(1)} KB</span>
                  <button onClick={() => { setUploadedFile(null); setNewConvText(''); }} className="text-[#475569] hover:text-[#F1F5F9]">
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}
              <div className="flex justify-end mt-3">
                <Button
                  onClick={handleNewConversationAnalyze}
                  disabled={!uploadedFile || isNewConvLoading}
                  className="bg-[#6366F1] hover:bg-[#4F46E5] text-white h-8 text-xs"
                >
                  {isNewConvLoading ? 'Analyzing...' : 'Parse & Analyze'}
                </Button>
              </div>
            </TabsContent>

            {/* Tab 3: Upload Email */}
            <TabsContent value="email" className="mt-4 space-y-3">
              <input
                value={emailSender}
                onChange={(e) => setEmailSender(e.target.value)}
                placeholder="Sender"
                className="w-full h-9 bg-[#111827] border border-[#1E293B] rounded-lg px-3 text-sm text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1]"
              />
              <input
                value={emailSubject}
                onChange={(e) => setEmailSubject(e.target.value)}
                placeholder="Subject"
                className="w-full h-9 bg-[#111827] border border-[#1E293B] rounded-lg px-3 text-sm text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1]"
              />
              <textarea
                value={newConvText}
                onChange={(e) => setNewConvText(e.target.value)}
                placeholder="Email Body"
                className="w-full min-h-[120px] bg-[#111827] border border-[#1E293B] rounded-lg px-4 py-3 text-sm text-[#F1F5F9] placeholder-[#475569] resize-none focus:outline-none focus:border-[#6366F1]"
              />
              <div className="flex justify-end">
                <Button
                  onClick={() => {
                    const fullText = `Email from: ${emailSender}\nSubject: ${emailSubject}\n\nBody:\n${newConvText}`;
                    setNewConvText(fullText);
                    handleNewConversationAnalyze();
                  }}
                  disabled={!newConvText.trim() || isNewConvLoading}
                  className="bg-[#6366F1] hover:bg-[#4F46E5] text-white h-8 text-xs"
                >
                  {isNewConvLoading ? 'Analyzing...' : 'Parse & Analyze'}
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────
   Save SOP Dialog
   ───────────────────────────────────────────── */

function SaveSOPDialog({
  open,
  onOpenChange,
  workflow,
  title,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  workflow: WorkflowNode[];
  title: string;
}) {
  const [sopTitle, setSopTitle] = useState(title);
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [owner, setOwner] = useState('');
  const [tags, setTags] = useState('');

  useEffect(() => {
    if (open) {
      setSopTitle(title);
    }
  }, [open, title]);

  const systemsInvolved = useMemo(() => Array.from(new Set(workflow.map((n) => n.system))), [workflow]);

  const handleSave = useCallback(() => {
    const newSOP: SOPKnowledge = {
      id: `sop-${Date.now()}`,
      title: sopTitle || title,
      description: description || 'SOP created from workflow analysis',
      category: category || 'General',
      sourceWorkflow: title,
      systemsInvolved,
      steps: workflow.map((node, i) => ({
        order: i + 1,
        title: `${node.system} — ${node.action}`,
        description: node.action,
        system: node.system,
        action: node.action,
        expectedOutput: '',
        notes: '',
      })),
      bestPractices: [],
      commonIssues: [],
      reviewHistory: [],
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      nextReviewDue: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'draft',
      owner: owner || 'Unassigned',
      tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
    };

    // In a real app, this would save to a backend
    // For now, we push to the INITIAL_SOPS array
    INITIAL_SOPS.push(newSOP);

    toast.success('SOP saved to Knowledge Base', {
      description: `"${newSOP.title}" has been added as a draft SOP.`,
    });

    onOpenChange(false);
    setDescription('');
    setCategory('');
    setOwner('');
    setTags('');
  }, [sopTitle, title, description, category, owner, tags, systemsInvolved, workflow, onOpenChange]);

  if (!open) return null;

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 z-50"
            onClick={() => onOpenChange(false)}
          />
          {/* Dialog */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed left-1/2 top-[8%] -translate-x-1/2 w-full max-w-[520px] bg-[#0A0F1E] border border-[#1E293B] rounded-xl shadow-2xl z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#1E293B]">
              <div className="flex items-center gap-2">
                <BookMarked className="h-4 w-4 text-[#6366F1]" />
                <h3 className="text-sm font-bold text-[#F1F5F9]">Save as SOP Knowledge</h3>
              </div>
              <button
                onClick={() => onOpenChange(false)}
                className="flex h-6 w-6 items-center justify-center rounded hover:bg-[#1E293B] text-[#64748B] hover:text-[#F1F5F9] transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Body */}
            <div className="px-5 py-4 space-y-4 max-h-[60vh] overflow-y-auto">
              {/* Title */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Title</label>
                <input
                  value={sopTitle}
                  onChange={(e) => setSopTitle(e.target.value)}
                  className="w-full h-9 bg-[#111827] border border-[#1E293B] rounded-lg px-3 text-sm text-[#F1F5F9] focus:outline-none focus:border-[#6366F1]"
                />
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe the purpose of this SOP..."
                  className="w-full min-h-[80px] bg-[#111827] border border-[#1E293B] rounded-lg px-3 py-2 text-sm text-[#F1F5F9] placeholder-[#475569] resize-none focus:outline-none focus:border-[#6366F1]"
                />
              </div>

              {/* Category */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Category</label>
                <input
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="e.g., Reconciliation, Payment Processing..."
                  className="w-full h-9 bg-[#111827] border border-[#1E293B] rounded-lg px-3 text-sm text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1]"
                />
              </div>

              {/* Source Workflow (read-only) */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Source Workflow</label>
                <div className="w-full h-9 bg-[#111827] border border-[#1E293B] rounded-lg px-3 flex items-center text-sm text-[#64748B]">
                  {title}
                </div>
              </div>

              {/* Systems Involved (read-only) */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Systems Involved</label>
                <div className="flex items-center gap-2 flex-wrap">
                  {systemsInvolved.map((sys) => (
                    <span
                      key={sys}
                      className="text-[11px] px-2 py-0.5 rounded bg-[#1E293B] text-[#94A3B8] flex items-center gap-1"
                    >
                      <div className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: SYSTEM_COLORS[sys] || '#CBD5E1' }} />
                      {sys}
                    </span>
                  ))}
                </div>
              </div>

              {/* Owner */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Owner</label>
                <input
                  value={owner}
                  onChange={(e) => setOwner(e.target.value)}
                  placeholder="e.g., Operations Team"
                  className="w-full h-9 bg-[#111827] border border-[#1E293B] rounded-lg px-3 text-sm text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1]"
                />
              </div>

              {/* Tags */}
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-[#94A3B8]">Tags</label>
                <input
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  placeholder="Comma-separated tags..."
                  className="w-full h-9 bg-[#111827] border border-[#1E293B] rounded-lg px-3 text-sm text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1]"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-end gap-3 px-5 py-4 border-t border-[#1E293B]">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onOpenChange(false)}
                className="text-[#94A3B8] hover:text-[#F1F5F9] text-xs h-8"
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={handleSave}
                className="bg-[#6366F1] text-white hover:bg-[#4F46E5] text-xs h-8"
              >
                <Save className="h-3.5 w-3.5 mr-1.5" />
                Save SOP
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/* ─────────────────────────────────────────────
   Main Page Component — Left/Right Split
   ───────────────────────────────────────────── */

export default function RequirementsPage() {
  const [selectedConvId, setSelectedConvId] = useState<string | null>(null);
  const [rightMode, setRightMode] = useState<'chat' | 'canvas'>('chat');
  const [newConvText, setNewConvText] = useState('');
  const [isNewConvLoading, setIsNewConvLoading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [emailSender, setEmailSender] = useState('');
  const [emailSubject, setEmailSubject] = useState('');
  const [activeTab, setActiveTab] = useState('text');
  const [conversations, setConversations] = useState<Conversation[]>(MOCK_CONVERSATIONS);
  const [isFollowUpLoading, setIsFollowUpLoading] = useState(false);
  const [saveSOPDialogOpen, setSaveSOPDialogOpen] = useState(false);
  const [savingWorkflow, setSavingWorkflow] = useState<WorkflowNode[]>([]);
  const [savingTitle, setSavingTitle] = useState('');

  const selectedConversation = conversations.find((c) => c.id === selectedConvId) || null;

  const handleNewConversationAnalyze = useCallback(() => {
    if (!newConvText.trim()) return;
    setIsNewConvLoading(true);
    setTimeout(() => {
      const newConv = generateAnalysis(newConvText);
      setConversations((prev) => [newConv, ...prev]);
      setSelectedConvId(newConv.id);
      setRightMode('chat');
      setIsNewConvLoading(false);
      setNewConvText('');
      setUploadedFile(null);
      setEmailSender('');
      setEmailSubject('');
    }, 2000);
  }, [newConvText]);

  const handleUpdateConversation = useCallback((updated: Conversation) => {
    setConversations((prev) =>
      prev.map((c) => (c.id === updated.id ? updated : c))
    );
  }, []);

  const handleSendFollowUp = useCallback(
    (text: string) => {
      if (!selectedConversation) return;

      const conv = selectedConversation;
      const lastAiMsg = conv.messages.filter((m) => m.type === 'ai').pop();
      if (!lastAiMsg) return;

      // 1. Add user message
      const now = new Date();
      const dateStr = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
      const userMsg: Message = {
        id: `msg-${Date.now()}-user`,
        type: 'user',
        content: text,
        timestamp: `${dateStr}, ${timeStr}`,
      };

      const updatedConvWithUser = {
        ...conv,
        messages: [...conv.messages, userMsg],
      };
      setConversations((prev) =>
        prev.map((c) => (c.id === conv.id ? updatedConvWithUser : c))
      );

      // 2. Show loading
      setIsFollowUpLoading(true);

      // 3. Generate AI response after 1.5s
      setTimeout(() => {
        const currentWorkflow = lastAiMsg.workflow || [];
        const currentRecs = lastAiMsg.recommendations || [];

        const result = processFollowUp(text, currentWorkflow, currentRecs);

        const newConfidence =
          result.recommendations.length > 0
            ? Math.round(
                result.recommendations.reduce((sum, r) => sum + r.confidence, 0) /
                  result.recommendations.length
              )
            : 0;

        const aiMsg: Message = {
          id: `msg-${Date.now()}-ai`,
          type: 'ai',
          content: `Updated workflow: ${result.analysis}`,
          workflow: result.workflow,
          recommendations: result.recommendations,
          overallConfidence: newConfidence,
          timestamp: `${dateStr}, ${timeStr}`,
        };

        const finalConv = {
          ...updatedConvWithUser,
          messages: [...updatedConvWithUser.messages, aiMsg],
          overallConfidence: newConfidence,
        };

        setConversations((prev) =>
          prev.map((c) => (c.id === conv.id ? finalConv : c))
        );
        setIsFollowUpLoading(false);
      }, 1500);
    },
    [selectedConversation]
  );

  // Get the latest AI message workflow for canvas view
  const canvasWorkflowNodes = useMemo(() => {
    if (!selectedConversation) return [];
    const lastAi = selectedConversation.messages.filter((m) => m.type === 'ai').pop();
    return lastAi?.workflow || [];
  }, [selectedConversation]);

  return (
    <Layout>
      {/* Page fills entire viewport minus sidebar/nav */}
      <div
        className="fixed inset-0 flex"
        style={{
          left: 'var(--sidebar-width, 260px)',
          top: 'var(--top-nav-height, 56px)',
          right: 0,
          bottom: 0,
        }}
      >
        {/* ── LEFT PANEL: Conversation History (~35%) ── */}
        <div
          className="flex flex-col border-r border-[#1E293B] bg-[#0A0F1E] overflow-hidden"
          style={{ width: '35%', minWidth: '320px', maxWidth: '420px' }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-[#1E293B] flex-shrink-0">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-[#64748B]" />
              <h2 className="text-sm font-bold text-[#F1F5F9]">Conversations</h2>
              <span className="text-[11px] text-[#475569] bg-[#111827] px-2 py-0.5 rounded-full">
                {conversations.length}
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedConvId(null)}
              className="h-8 px-3 text-[11px] bg-[#6366F1]/10 text-[#818CF8] hover:bg-[#6366F1]/20 hover:text-[#6366F1]"
            >
              <Plus className="h-3.5 w-3.5 mr-1" />
              New
            </Button>
          </div>

          {/* Conversation List */}
          <div className="flex-1 overflow-y-auto px-3 py-3 space-y-2">
            {conversations.map((conv) => (
              <ConversationListItem
                key={conv.id}
                conversation={conv}
                isSelected={selectedConvId === conv.id}
                onClick={() => {
                  setSelectedConvId(conv.id);
                  setRightMode('chat');
                }}
                onViewCanvas={(e) => {
                  e.stopPropagation();
                  setSelectedConvId(conv.id);
                  setRightMode('canvas');
                }}
              />
            ))}
          </div>
        </div>

        {/* ── RIGHT PANEL: Chat Thread / Canvas / New Input (~65%) ── */}
        <div className="flex-1 flex flex-col bg-[#030712] overflow-hidden">
          {rightMode === 'canvas' && selectedConversation ? (
            <WorkflowCanvasMini
              workflowNodes={canvasWorkflowNodes}
              conversationTitle={selectedConversation.title}
              onBackToChat={() => setRightMode('chat')}
              onSendFollowUp={(text) => {
                handleSendFollowUp(text);
              }}
              isLoading={isFollowUpLoading}
            />
          ) : (
            <>
              {/* Scrollable content area */}
              <div className="flex-1 overflow-y-auto">
                <div className="max-w-[900px] mx-auto px-6 py-6 space-y-6 h-full">
                  {/* Chat Thread (when conversation selected) */}
                  <AnimatePresence mode="wait">
                    {selectedConversation ? (
                      <motion.div
                        key="chat"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="border border-[#1E293B] rounded-2xl overflow-hidden bg-[#030712]"
                        style={{ minHeight: '400px' }}
                      >
                        <ChatThread
                          conversation={selectedConversation}
                          onViewCanvas={() => setRightMode('canvas')}
                          onUpdateConversation={handleUpdateConversation}
                          onSaveAsSOP={(workflow) => {
                            setSavingWorkflow(workflow);
                            setSavingTitle(selectedConversation.title);
                            setSaveSOPDialogOpen(true);
                          }}
                        />
                      </motion.div>
                    ) : (
                      <motion.div
                        key="new-panel"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="h-full"
                      >
                        <NewRequirementPanel
                          newConvText={newConvText}
                          setNewConvText={setNewConvText}
                          isNewConvLoading={isNewConvLoading}
                          handleNewConversationAnalyze={handleNewConversationAnalyze}
                          uploadedFile={uploadedFile}
                          setUploadedFile={setUploadedFile}
                          emailSender={emailSender}
                          setEmailSender={setEmailSender}
                          emailSubject={emailSubject}
                          setEmailSubject={setEmailSubject}
                          activeTab={activeTab}
                          setActiveTab={setActiveTab}
                        />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              {/* Bottom Input — always visible for follow-up */}
              {selectedConversation && (
                <div className="shrink-0 border-t border-[#1E293B] bg-[#0A0F1E]">
                  <div className="max-w-[900px] mx-auto px-6 py-3">
                    <ChatInput onSendFollowUp={handleSendFollowUp} isLoading={isFollowUpLoading} />
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Save SOP Dialog */}
      <SaveSOPDialog
        open={saveSOPDialogOpen}
        onOpenChange={setSaveSOPDialogOpen}
        workflow={savingWorkflow}
        title={savingTitle}
      />
    </Layout>
  );
}
