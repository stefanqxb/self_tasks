import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ReactFlow,
  Background,
  MiniMap,
  useNodesState,
  useEdgesState,
  useReactFlow,
  ReactFlowProvider,
  MarkerType,
  Panel,
  type Node,
  type Edge,
  type NodeTypes,
  type EdgeTypes,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { AnimatePresence, motion } from 'framer-motion';

import Layout from '@/components/Layout';
import SystemNode from './canvas/nodes/SystemNode';
import StepNode from './canvas/nodes/StepNode';
import CapabilityNode from './canvas/nodes/CapabilityNode';
import AnimatedEdge from './canvas/edges/AnimatedEdge';
import InfoPanel from './canvas/InfoPanel';
import { CanvasBreadcrumb, FloatingControls, SystemLegend } from './canvas/CanvasControls';
import {
  systems,
  getSystemById,
  getStepsBySystemId,
  getStepById,
  getCapabilitiesByStepId,
  getCapabilityById,
  systemEdges,
  workflowViews,
} from './canvas/data';
import type { System, Step, Capability } from './canvas/data';

// ─── Types ──────────────────────────────────────────────────────────

type CanvasLayer = 1 | 2 | 3;

// ─── Node/Edge Type Registration ────────────────────────────────────

const nodeTypes: NodeTypes = {
  systemNode: SystemNode,
  stepNode: StepNode,
  capabilityNode: CapabilityNode,
};

const edgeTypes: EdgeTypes = {
  animated: AnimatedEdge,
};

// ─── Color helpers ──────────────────────────────────────────────────

const systemColorMap: Record<string, string> = {
  qtrack: '#6366F1',
  transformer: '#14B8A6',
  swb: '#F59E0B',
  sire: '#8B5CF6',
  opas: '#0EA5E9',
  goldeneye: '#F97316',
};

// ─── Layer 1: System View Layout ────────────────────────────────────

function buildSystemNodes(
  onSelect: (id: string) => void,
  filteredSystems?: typeof systems
): Node[] {
  const positions: Record<string, { x: number; y: number }> = {
    qtrack: { x: 0, y: -250 },
    transformer: { x: -450, y: -80 },
    swb: { x: 450, y: -80 },
    sire: { x: -280, y: 250 },
    opas: { x: 0, y: 280 },
    goldeneye: { x: 280, y: 250 },
  };

  const sourceSystems = filteredSystems || systems;

  return sourceSystems.map((system) => ({
    id: system.id,
    type: 'systemNode',
    position: positions[system.id] || { x: 0, y: 0 },
    data: {
      system,
      stepCount: getStepsBySystemId(system.id).length,
      onSelect,
    },
  }));
}

function buildSystemEdges(filteredEdges?: typeof systemEdges): Edge[] {
  const sourceEdges = filteredEdges || systemEdges;
  return sourceEdges.map((e) => ({
    id: e.id,
    source: e.source,
    target: e.target,
    type: 'animated',
    label: e.label,
    markerEnd: { type: MarkerType.ArrowClosed, width: 8, height: 8, color: '#64748B' },
  }));
}

// ─── Layer 2: Step View Layout ──────────────────────────────────────

function buildStepNodes(systemId: string, onSelect: (stepId: string) => void): Node[] {
  const systemSteps = getStepsBySystemId(systemId);
  const color = systemColorMap[systemId] || '#6366F1';

  const nodes: Node[] = [];

  // Parent system node at center
  nodes.push({
    id: 'parent-system',
    type: 'default',
    position: { x: 0, y: 60 },
    data: { label: systemId },
    style: {
      width: 260,
      height: 140,
      backgroundColor: `${color}14`,
      border: `2px solid ${color}99`,
      borderRadius: 16,
      boxShadow: `0 0 0 4px ${color}1A, 0 8px 32px ${color}33`,
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'white',
      fontSize: 16,
      fontWeight: 700,
    },
  });

  // Step nodes in a fan pattern above the parent
  const angleStep = Math.PI / (systemSteps.length + 1);
  const radius = 320;
  const startAngle = -Math.PI + angleStep;

  systemSteps.forEach((step, i) => {
    const angle = startAngle + i * angleStep;
    nodes.push({
      id: step.id,
      type: 'stepNode',
      position: {
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius - 40,
      },
      data: {
        step,
        systemColor: color,
        onSelect,
      },
    });
  });

  return nodes;
}

function buildStepEdges(systemId: string): Edge[] {
  const systemSteps = getStepsBySystemId(systemId);
  return systemSteps.map((step) => ({
    id: `e-parent-${step.id}`,
    source: 'parent-system',
    target: step.id,
    type: 'animated',
    markerEnd: { type: MarkerType.ArrowClosed, width: 6, height: 6, color: `${systemColorMap[systemId]}66` },
    style: { stroke: `${systemColorMap[systemId]}4D` },
  }));
}

// ─── Layer 3: Capability View Layout ────────────────────────────────

function buildCapabilityNodes(stepId: string, onSelect: (capId: string) => void): Node[] {
  const step = getStepById(stepId)!;
  const caps = getCapabilitiesByStepId(stepId);
  const color = systemColorMap[step.systemId] || '#6366F1';

  const nodes: Node[] = [];

  // Parent system reference pill
  nodes.push({
    id: 'parent-system-ref',
    type: 'default',
    position: { x: -400, y: -280 },
    data: { label: step.systemId.toUpperCase() },
    style: {
      width: 180,
      height: 36,
      backgroundColor: 'rgba(30, 41, 59, 0.9)',
      border: `1px solid ${color}4D`,
      borderRadius: 20,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: color,
      fontSize: 11,
      fontWeight: 600,
    },
  });

  // Step header node
  nodes.push({
    id: 'step-header',
    type: 'default',
    position: { x: -130, y: -220 },
    data: { label: step.name },
    style: {
      width: 260,
      height: 80,
      backgroundColor: 'rgba(30, 41, 59, 0.8)',
      border: `1px solid ${color}4D`,
      borderLeft: `3px solid ${color}`,
      borderRadius: 12,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#E2E8F0',
      fontSize: 14,
      fontWeight: 600,
      padding: '0 16px',
      textAlign: 'center',
    },
  });

  // Capability nodes in a grid below
  const cols = 2;
  const gapX = 280;
  const gapY = 200;
  const startX = -((cols - 1) * gapX) / 2;
  const startY = -80;

  caps.forEach((cap, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    nodes.push({
      id: cap.id,
      type: 'capabilityNode',
      position: {
        x: startX + col * gapX,
        y: startY + row * gapY,
      },
      data: {
        capability: cap,
        systemColor: color,
        onSelect,
      },
    });
  });

  return nodes;
}

function buildCapabilityEdges(stepId: string): Edge[] {
  const caps = getCapabilitiesByStepId(stepId);

  return caps.map((cap) => ({
    id: `e-step-${cap.id}`,
    source: 'step-header',
    target: cap.id,
    type: 'default',
    style: {
      stroke: 'rgba(148, 163, 184, 0.2)',
      strokeWidth: 1,
      strokeDasharray: '4 4',
    },
  }));
}

// ─── Internal Canvas Component ──────────────────────────────────────

function CanvasInner() {
  // Read workflow URL parameter (HashRouter format: /#/canvas?workflow=invoice)
  const searchParams = new URLSearchParams(window.location.search);
  const workflowId = searchParams.get('workflow');
  const activeView = workflowId ? workflowViews[workflowId] : null;

  // Filter systems and edges for per-workflow view (always activeView when rendering flow)
  const filteredSystems = activeView
    ? systems.filter((s) => activeView.nodeIds.includes(s.id))
    : [];
  const filteredEdges = activeView
    ? systemEdges.filter((e) => activeView.edgeIds.includes(e.id))
    : [];

  const [layer, setLayer] = useState<CanvasLayer>(1);
  const [selectedSystemId, setSelectedSystemId] = useState<string | null>(null);
  const [selectedStepId, setSelectedStepId] = useState<string | null>(null);
  const [selectedCapId, setSelectedCapId] = useState<string | null>(null);
  const [infoPanelOpen, setInfoPanelOpen] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const [transitioning, setTransitioning] = useState(false);

  const [nodes, setNodes, onNodesChange] = useNodesState([] as Node[]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([] as Edge[]);

  const { fitView, zoomIn, zoomOut, getZoom } = useReactFlow();

  // Computed selections
  const selectedSystem = useMemo<System | null>(
    () => getSystemById(selectedSystemId || '') ?? null,
    [selectedSystemId]
  );
  const selectedStep = useMemo<Step | null>(
    () => getStepById(selectedStepId || '') ?? null,
    [selectedStepId]
  );
  const selectedCapability = useMemo<Capability | null>(
    () => getCapabilityById(selectedCapId || '') ?? null,
    [selectedCapId]
  );

  // ─── Layer Loaders ────────────────────────────────────────────────

  const loadLayer1 = useCallback(() => {
    const newNodes = buildSystemNodes(
      (id: string) => {
        setSelectedSystemId(id);
        setTransitioning(true);
        setTimeout(() => {
          setLayer(2);
          setTransitioning(false);
        }, 300);
      },
      filteredSystems
    );
    const newEdges = buildSystemEdges(filteredEdges);
    setNodes(newNodes);
    setEdges(newEdges);
    setTimeout(() => fitView({ padding: 0.2, duration: 500 }), 50);
  }, [setNodes, setEdges, fitView, filteredSystems, filteredEdges]);

  const loadLayer2 = useCallback(
    (systemId: string) => {
      const newNodes = buildStepNodes(systemId, (stepId: string) => {
        setSelectedStepId(stepId);
        setTransitioning(true);
        setTimeout(() => {
          setLayer(3);
          setTransitioning(false);
        }, 300);
      });
      const newEdges = buildStepEdges(systemId);
      setNodes(newNodes);
      setEdges(newEdges);
      setTimeout(() => fitView({ padding: 0.25, duration: 500 }), 50);
    },
    [setNodes, setEdges, fitView]
  );

  const loadLayer3 = useCallback(
    (stepId: string) => {
      const newNodes = buildCapabilityNodes(stepId, (capId: string) => {
        setSelectedCapId(capId);
        setInfoPanelOpen(true);
      });
      const newEdges = buildCapabilityEdges(stepId);
      setNodes(newNodes);
      setEdges(newEdges);
      setTimeout(() => fitView({ padding: 0.2, duration: 500 }), 50);
    },
    [setNodes, setEdges, fitView]
  );

  // ─── Navigation ───────────────────────────────────────────────────

  const navigateToLayer = useCallback(
    (targetLayer: number) => {
      setInfoPanelOpen(false);
      setSelectedCapId(null);
      if (targetLayer === 1) {
        setSelectedSystemId(null);
        setSelectedStepId(null);
        setTransitioning(true);
        setTimeout(() => {
          setLayer(1);
          setTransitioning(false);
          loadLayer1();
        }, 200);
      } else if (targetLayer === 2 && selectedSystemId) {
        setSelectedStepId(null);
        setTransitioning(true);
        setTimeout(() => {
          setLayer(2);
          setTransitioning(false);
          loadLayer2(selectedSystemId);
        }, 200);
      }
    },
    [selectedSystemId, loadLayer1, loadLayer2]
  );

  const handleBack = useCallback(() => {
    if (layer === 3) navigateToLayer(2);
    else if (layer === 2) navigateToLayer(1);
  }, [layer, navigateToLayer]);

  // ─── Node Click Handler ───────────────────────────────────────────

  const handleNodeClick = useCallback(
    (_event: React.MouseEvent, node: Node) => {
      if (layer === 1) {
        setSelectedSystemId(node.id);
        setTransitioning(true);
        setTimeout(() => {
          setLayer(2);
          setTransitioning(false);
          loadLayer2(node.id);
        }, 300);
      } else if (layer === 2 && node.id !== 'parent-system') {
        setSelectedStepId(node.id);
        setTransitioning(true);
        setTimeout(() => {
          setLayer(3);
          setTransitioning(false);
          loadLayer3(node.id);
        }, 300);
      } else if (layer === 3) {
        if (node.id === 'parent-system-ref') {
          handleBack();
        } else if (node.id === 'step-header') {
          // Step header clicked
        } else {
          setSelectedCapId(node.id);
          setInfoPanelOpen(true);
        }
      }
    },
    [layer, loadLayer2, loadLayer3, handleBack]
  );

  // ─── Initial Load ─────────────────────────────────────────────────

  useEffect(() => {
    loadLayer1();
  }, [loadLayer1]);

  // ─── Keyboard Shortcuts ───────────────────────────────────────────

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') handleBack();
      if (e.key === '1') navigateToLayer(1);
      if (e.key === 'i' || e.key === 'I') setInfoPanelOpen((p) => !p);
      if (e.key === 'g' || e.key === 'G') setShowGrid((g) => !g);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleBack, navigateToLayer]);

  // ─── Zoom Tracking ────────────────────────────────────────────────

  const [currentZoom, setCurrentZoom] = useState(1);
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentZoom(getZoom());
    }, 200);
    return () => clearInterval(interval);
  }, [getZoom]);

  // ─── Right-click Context Menu ─────────────────────────────────────

  const [contextMenu, setContextMenu] = useState<{ x: number; y: number } | null>(null);

  const handleContextMenu = useCallback(
    (event: React.MouseEvent) => {
      event.preventDefault();
      setContextMenu({ x: event.clientX, y: event.clientY });
    },
    []
  );

  useEffect(() => {
    if (!contextMenu) return;
    const handler = () => setContextMenu(null);
    window.addEventListener('click', handler);
    return () => window.removeEventListener('click', handler);
  }, [contextMenu]);

  // ─── MiniMap Node Color ───────────────────────────────────────────

  const miniMapNodeColor = useCallback((n: Node) => {
    if (n.type === 'systemNode') {
      return systemColorMap[n.id] || '#64748B';
    }
    if (n.type === 'stepNode') return '#94A3B8';
    if (n.type === 'capabilityNode') return '#CBD5E1';
    return '#334155';
  }, []);

  // ─── Render ───────────────────────────────────────────────────────

  if (!activeView) {
    return (
      <div className="relative w-full h-full flex items-center justify-center" style={{ backgroundColor: '#030712' }}>
        <div className="max-w-2xl w-full mx-4">
          <div className="text-center mb-8">
            <GitBranchIcon className="h-12 w-12 text-[#6366F1] mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-[#F1F5F9] mb-2">Workflow Canvas</h2>
            <p className="text-[#64748B]">Select a requirement analysis to view its generated workflow</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { id: 'invoice', title: 'Invoice Processing', systems: ['QTrack', 'SWB', 'Transformer', 'SIRE', 'OPAS'], color: '#6366F1' },
              { id: 'trade', title: 'Trade Settlement', systems: ['GoldenEye', 'SIRE', 'OPAS'], color: '#F97316' },
              { id: 'payment', title: 'Payment Confirmation', systems: ['QTrack', 'SWB', 'OPAS', 'SIRE'], color: '#0EA5E9' },
              { id: 'contract', title: 'Contract Settlement', systems: ['QTrack', 'SWB', 'Transformer', 'SIRE', 'OPAS'], color: '#8B5CF6' },
            ].map((wf) => (
              <button
                key={wf.id}
                onClick={() => {
                  window.location.href = `/#/canvas?workflow=${wf.id}`;
                }}
                className="group text-left p-5 rounded-xl border border-[#1E293B] bg-[#111827] hover:border-[#6366F1] hover:shadow-[0_0_20px_rgba(99,102,241,0.15)] transition-all duration-300"
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: wf.color }} />
                  <h3 className="text-[#F1F5F9] font-semibold text-sm">{wf.title}</h3>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {wf.systems.map((s) => (
                    <span key={s} className="text-[11px] px-2 py-0.5 rounded-md bg-[#1E293B] text-[#94A3B8]">{s}</span>
                  ))}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="relative w-full h-full"
      style={{ backgroundColor: '#0F172A' }}
      onContextMenu={handleContextMenu}
    >
      {/* CSS for animated edges */}
      <style>{`
        @keyframes edge-flow {
          to { stroke-dashoffset: -24; }
        }
        .react-flow__edge-path {
          animation: edge-flow 1.2s linear infinite;
        }
      `}</style>

      {/* Minimal Top Bar */}
      <div
        className="absolute left-0 right-0 top-0 z-20 flex h-9 items-center justify-between px-4"
        style={{
          backgroundColor: 'rgba(15, 23, 42, 0.8)',
          backdropFilter: 'blur(8px)',
          borderBottom: '1px solid #334155',
        }}
      >
        <div className="flex items-center gap-2">
          <GitBranchIcon className="h-4 w-4 text-[#6366F1]" />
          <span className="text-[13px] font-semibold text-[#CBD5E1]">Workflow Canvas</span>
        </div>
        <div className="flex items-center gap-2 text-[12px] text-[#64748B]">
          {activeView ? (
            <span className="text-[#818CF8]">{activeView.title}</span>
          ) : (
            <span>Analyzing: REQ-2024-001 — Automated Employee Onboarding</span>
          )}
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setInfoPanelOpen((p) => !p)}
            className="flex h-7 w-7 items-center justify-center rounded-md text-[#64748B] transition-colors hover:bg-[#334155] hover:text-white"
            title="Toggle Info Panel"
          >
            <PanelRightIcon className="h-4 w-4" />
          </button>
          <button
            onClick={() => navigateToLayer(1)}
            className="flex h-7 w-7 items-center justify-center rounded-md text-[#64748B] transition-colors hover:bg-[#334155] hover:text-white"
            title="Reset View"
          >
            <RotateCcwIcon className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* React Flow Canvas */}
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeClick={handleNodeClick}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        fitView
        fitViewOptions={{ padding: 0.2, duration: 500 }}
        minZoom={0.25}
        maxZoom={3}
        defaultEdgeOptions={{
          type: 'animated',
          markerEnd: { type: MarkerType.ArrowClosed },
        }}
        proOptions={{ hideAttribution: true }}
        style={{ backgroundColor: '#0F172A' }}
      >
        {/* Background */}
        {showGrid && (
          <Background
            color="#334155"
            gap={20}
            size={2}
            style={{ opacity: 0.04 }}
          />
        )}

        {/* Radial vignette overlay */}
        <div
          className="pointer-events-none absolute inset-0 z-[5]"
          style={{
            background:
              'radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.3) 100%)',
          }}
        />

        {/* MiniMap */}
        <MiniMap
          nodeColor={miniMapNodeColor}
          maskColor="rgba(15, 23, 42, 0.7)"
          className="!absolute !bottom-4 !left-4 !h-32 !w-48 rounded-lg border border-[#334155]"
          style={{
            backgroundColor: 'rgba(30, 41, 59, 0.8)',
          }}
          pannable
          zoomable
        />

        {/* Top Left: Back button (layer 2/3) */}
        {layer > 1 && (
          <Panel position="top-left">
            <button
              onClick={handleBack}
              className="flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium text-[#CBD5E1] transition-all hover:text-white"
              style={{
                backgroundColor: 'rgba(30, 41, 59, 0.9)',
                backdropFilter: 'blur(8px)',
                border: '1px solid #334155',
              }}
            >
              <ArrowLeftIcon className="h-4 w-4" />
              Back
            </button>
          </Panel>
        )}

        {/* Bottom Left: Legend */}
        <Panel position="bottom-left" className="!bottom-20 !left-4">
          <SystemLegend systemIds={activeView?.nodeIds} />
        </Panel>

        {/* Bottom Center: Breadcrumb */}
        <Panel position="bottom-center" className="!bottom-4">
          <CanvasBreadcrumb
            layer={layer}
            selectedSystem={selectedSystem}
            selectedStep={selectedStep}
            onNavigateLayer={navigateToLayer}
          />
        </Panel>

        {/* Bottom Right: Controls */}
        <Panel position="bottom-right" className="!bottom-4 !right-4">
          <FloatingControls
            zoom={currentZoom}
            onZoomIn={() => zoomIn()}
            onZoomOut={() => zoomOut()}
            onFitView={() => fitView({ padding: 0.2, duration: 500 })}
            onReset={() => navigateToLayer(1)}
            showGrid={showGrid}
            onToggleGrid={() => setShowGrid((g) => !g)}
            onTogglePanel={() => setInfoPanelOpen((p) => !p)}
          />
        </Panel>
      </ReactFlow>

      {/* Layer transition overlay */}
      <AnimatePresence>
        {transitioning && (
          <motion.div
            className="pointer-events-none absolute inset-0 z-10"
            style={{ backgroundColor: '#0F172A' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          />
        )}
      </AnimatePresence>

      {/* Context Menu */}
      <AnimatePresence>
        {contextMenu && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute z-50 w-44 rounded-lg border border-[#334155] py-1 shadow-xl"
            style={{
              left: contextMenu.x,
              top: contextMenu.y,
              backgroundColor: 'rgba(30, 41, 59, 0.98)',
            }}
          >
            <ContextMenuItem
              icon={<Maximize2Icon className="h-3.5 w-3.5" />}
              label="Fit to View"
              onClick={() => fitView({ padding: 0.2, duration: 500 })}
            />
            <ContextMenuItem
              icon={<RotateCcwIcon className="h-3.5 w-3.5" />}
              label="Reset Layout"
              onClick={() => navigateToLayer(1)}
            />
            <ContextMenuItem
              icon={<GridIcon className="h-3.5 w-3.5" />}
              label="Toggle Grid"
              onClick={() => setShowGrid((g) => !g)}
              checked={showGrid}
            />
            <div className="my-1 h-px bg-[#334155]" />
            <ContextMenuItem
              icon={<SettingsIcon className="h-3.5 w-3.5" />}
              label="Canvas Settings"
              onClick={() => {}}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Right Info Panel */}
      <div className="absolute right-0 top-9 bottom-0 z-30">
        <InfoPanel
          isOpen={infoPanelOpen}
          onClose={() => setInfoPanelOpen(false)}
          selectedSystem={selectedSystem}
          selectedStep={selectedStep}
          selectedCapability={selectedCapability}
        />
      </div>
    </div>
  );
}

// ─── Context Menu Item ──────────────────────────────────────────────

function ContextMenuItem({
  icon,
  label,
  onClick,
  checked,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  checked?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm text-[#CBD5E1] transition-colors hover:bg-[rgba(51,65,85,0.5)]"
    >
      <span className="text-[#64748B]">{icon}</span>
      <span className="flex-1">{label}</span>
      {checked && <CheckIcon />}
    </button>
  );
}

// ─── Inline SVG Icons ───────────────────────────────────────────────

function GitBranchIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="6" y1="3" x2="6" y2="15" />
      <circle cx="18" cy="6" r="3" />
      <circle cx="6" cy="18" r="3" />
      <path d="M18 9a9 9 0 0 1-9 9" />
    </svg>
  );
}

function PanelRightIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect width="18" height="18" x="3" y="3" rx="2" />
      <path d="M15 3v18" />
    </svg>
  );
}

function RotateCcwIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
      <path d="M3 3v5h5" />
    </svg>
  );
}

function ArrowLeftIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 12H5M12 19l-7-7 7-7" />
    </svg>
  );
}

function Maximize2Icon({ className }: { className?: string }) {
  return (
    <svg className={className} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="15 3 21 3 21 9" />
      <polyline points="9 21 3 21 3 15" />
      <line x1="21" x2="14" y1="3" y2="10" />
      <line x1="3" x2="10" y1="21" y2="14" />
    </svg>
  );
}

function GridIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect width="18" height="18" x="3" y="3" rx="2" />
      <path d="M3 9h18" />
      <path d="M3 15h18" />
      <path d="M9 3v18" />
      <path d="M15 3v18" />
    </svg>
  );
}

function SettingsIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#22C55E" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}

// ─── Exported Page ──────────────────────────────────────────────────

export default function Canvas() {
  return (
    <Layout>
      <div className="-m-6 h-[calc(100vh-56px)]">
        <ReactFlowProvider>
          <CanvasInner />
        </ReactFlowProvider>
      </div>
    </Layout>
  );
}
