import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  MessageSquare,
  Sparkles,
  Rocket,
  ClipboardList,
  Database,
  Globe,
  ArrowRight,
  Zap,
  Server,
  Layers,
  CircleDot,
  ChevronRight,
} from 'lucide-react';
import Layout from '@/components/Layout';

/* ─── Animation Variants ─── */
const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  },
};

const fadeInUp = {
  hidden: { opacity: 0, y: 24 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  },
};

/* ─── Data ─── */
const steps = [
  {
    num: 1,
    title: 'Describe Your Need',
    description: 'Tell the AI what business process you want to automate using natural language',
    icon: MessageSquare,
    color: '#6366F1',
  },
  {
    num: 2,
    title: 'AI Designs Workflow',
    description: 'OPR analyzes your requirements and recommends the optimal system orchestration',
    icon: Sparkles,
    color: '#14B8A6',
  },
  {
    num: 3,
    title: 'Deploy & Monitor',
    description: 'Deploy your workflow to production and monitor execution in real-time',
    icon: Rocket,
    color: '#F59E0B',
  },
];

const modules = [
  {
    title: 'Workflow Studio',
    path: '/requirements',
    icon: ClipboardList,
    description: 'Transform natural language requirements into intelligent system workflows',
    features: [
      'AI requirement analysis with 95%+ accuracy',
      'Auto-recommends optimal system combinations',
      'Interactive workflow canvas with branch support',
      'Follow-up refinement and iteration',
    ],
    color: '#6366F1',
  },
  {
    title: 'Operations Hub',
    path: '/deploy',
    icon: Rocket,
    description: 'Deploy workflows and monitor their execution across all connected systems',
    features: [
      'One-click workflow deployment',
      'Real-time execution monitoring',
      'Schedule, event, or manual triggers',
      'Full execution history and logs',
    ],
    color: '#14B8A6',
  },
  {
    title: 'Knowledge Base',
    path: '/knowledge',
    icon: Database,
    description: 'Explore system capabilities, APIs, and integration patterns',
    features: [
      'Complete system capability catalog',
      'API endpoint documentation',
      'Step-by-step capability explorer',
      'Integration pattern library',
    ],
    color: '#F59E0B',
  },
  {
    title: 'Service Registry',
    path: '/registry',
    icon: Globe,
    description: 'Manage service registration, discovery, and API gateway routing',
    features: [
      'Service registration & health monitoring',
      'Dynamic routing & load balancing',
      'API rate limiting & analytics',
      'Multi-tenant access control',
    ],
    color: '#8B5CF6',
  },
];

const systems = [
  { name: 'QTrack', color: '#6366F1', role: 'Email processing & prioritization', icon: Zap },
  { name: 'Transformer', color: '#14B8A6', role: 'Data transformation & format conversion', icon: Layers },
  { name: 'SWB', color: '#F59E0B', role: 'Document extraction & entity recognition', icon: ClipboardList },
  { name: 'SIRE', color: '#8B5CF6', role: 'Reconciliation & break management', icon: Server },
  { name: 'OPAS', color: '#0EA5E9', role: 'Payment & settlement tracking', icon: CircleDot },
  { name: 'GoldenEye', color: '#F97316', role: 'Trade lifecycle & position management', icon: Globe },
];

/* ─── Section Divider ─── */
function SectionDivider() {
  return (
    <div className="flex items-center gap-4 py-2">
      <div className="h-px flex-1 bg-[#1E293B]" />
      <div className="h-1 w-1 rounded-full bg-[#334155]" />
      <div className="h-px flex-1 bg-[#1E293B]" />
    </div>
  );
}

/* ─── Step Card ─── */
function StepCard({
  step,
  isLast,
}: {
  step: (typeof steps)[0];
  isLast: boolean;
}) {
  const Icon = step.icon;
  return (
    <div className="flex items-center gap-4">
      <motion.div
        variants={itemVariants}
        className="group relative flex flex-1 items-start gap-4 rounded-xl border border-[#1E293B] bg-[#0A0F1E] p-5 transition-all duration-300 hover:border-[rgba(99,102,241,0.3)] hover:bg-[rgba(99,102,241,0.03)]"
      >
        {/* Numbered circle */}
        <div
          className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full border-2 transition-transform duration-300 group-hover:scale-110"
          style={{ borderColor: step.color, backgroundColor: `${step.color}12` }}
        >
          <span className="text-lg font-bold" style={{ color: step.color }}>
            {step.num}
          </span>
        </div>

        {/* Content */}
        <div className="flex-1 pt-0.5">
          <div className="flex items-center gap-2">
            <Icon className="h-4 w-4" style={{ color: step.color }} />
            <h3 className="text-sm font-semibold text-[#F1F5F9]">{step.title}</h3>
          </div>
          <p className="mt-1.5 text-xs leading-relaxed text-[#94A3B8]">{step.description}</p>
        </div>
      </motion.div>

      {/* Arrow connector (hidden on mobile, visible on lg) */}
      {!isLast && (
        <div className="hidden flex-shrink-0 items-center lg:flex">
          <ArrowRight className="h-5 w-5 text-[#475569]" />
        </div>
      )}
    </div>
  );
}

/* ─── Module Card ─── */
function ModuleCard({ module }: { module: (typeof modules)[0] }) {
  const navigate = useNavigate();
  const Icon = module.icon;

  return (
    <motion.div
      variants={itemVariants}
      className="group relative flex flex-col rounded-xl border border-[#1E293B] bg-[#0A0F1E] p-6 transition-all duration-300 hover:border-[rgba(99,102,241,0.25)]"
    >
      {/* Glow effect */}
      <div
        className="pointer-events-none absolute inset-0 rounded-xl opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        style={{
          background: `radial-gradient(ellipse 80% 60% at 80% 20%, ${module.color}08 0%, transparent 60%)`,
        }}
      />

      {/* Content */}
      <div className="relative flex flex-1 flex-col">
        {/* Icon & Title */}
        <div className="flex items-center gap-3">
          <div
            className="flex h-11 w-11 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${module.color}15`, color: module.color }}
          >
            <Icon className="h-5 w-5" />
          </div>
          <h3 className="text-base font-semibold text-[#F1F5F9]">{module.title}</h3>
        </div>

        {/* Description */}
        <p className="mt-3 text-sm leading-relaxed text-[#94A3B8]">{module.description}</p>

        {/* Feature bullets */}
        <ul className="mt-4 space-y-2 flex-1">
          {module.features.map((feature, i) => (
            <li key={i} className="flex items-start gap-2 text-xs text-[#94A3B8]">
              <span
                className="mt-1 h-1 w-1 flex-shrink-0 rounded-full"
                style={{ backgroundColor: module.color }}
              />
              <span className="leading-relaxed">{feature}</span>
            </li>
          ))}
        </ul>

        {/* Explore button */}
        <button
          onClick={() => navigate(module.path)}
          className="mt-5 flex items-center gap-1.5 self-start rounded-lg px-4 py-2 text-xs font-medium transition-all duration-200 hover:gap-2.5"
          style={{
            backgroundColor: `${module.color}12`,
            color: module.color,
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.backgroundColor = `${module.color}20`;
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.backgroundColor = `${module.color}12`;
          }}
        >
          Explore
          <ChevronRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </motion.div>
  );
}

/* ─── System Card ─── */
function SystemCard({ system }: { system: (typeof systems)[0] }) {
  const Icon = system.icon;
  return (
    <motion.div
      variants={itemVariants}
      className="group flex items-center gap-3 rounded-xl border border-[#1E293B] bg-[#0A0F1E] px-4 py-4 transition-all duration-300 hover:border-[rgba(99,102,241,0.2)]"
    >
      <div
        className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg transition-transform duration-300 group-hover:scale-110"
        style={{ backgroundColor: `${system.color}12`, color: system.color }}
      >
        <Icon className="h-4 w-4" />
      </div>
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full" style={{ backgroundColor: system.color }} />
          <span className="text-sm font-semibold text-[#F1F5F9]">{system.name}</span>
        </div>
        <p className="mt-0.5 truncate text-[11px] text-[#64748B]">{system.role}</p>
      </div>
    </motion.div>
  );
}

/* ─── Architecture Diagram ─── */
function ArchitectureDiagram() {
  return (
    <motion.div variants={itemVariants} className="rounded-xl border border-[#1E293B] bg-[#0A0F1E] p-6">
      <div className="flex flex-col items-center gap-5 lg:flex-row lg:items-stretch lg:justify-center">
        {/* External Consumers */}
        <div className="flex flex-col items-center justify-center gap-2">
          <div className="flex items-center gap-2 rounded-lg border border-[#1E293B] bg-[rgba(255,255,255,0.02)] px-4 py-3">
            <Globe className="h-4 w-4 text-[#94A3B8]" />
            <span className="text-xs font-medium text-[#F1F5F9]">External Consumers</span>
          </div>
          <div className="flex flex-col items-center gap-0.5">
            <span className="text-[10px] text-[#64748B]">PS · AgentHub · n8n</span>
          </div>
        </div>

        {/* Arrow */}
        <div className="flex items-center justify-center lg:w-8">
          <ArrowRight className="h-4 w-4 rotate-90 text-[#475569] lg:rotate-0" />
        </div>

        {/* Registry */}
        <div className="flex flex-col items-center justify-center">
          <div className="flex items-center gap-2 rounded-lg border border-[#8B5CF640] bg-[#8B5CF612] px-4 py-3">
            <Server className="h-4 w-4 text-[#8B5CF6]" />
            <span className="text-xs font-medium text-[#F1F5F9]">Registry</span>
          </div>
          <span className="mt-1 text-[10px] text-[#64748B]">Gateway</span>
        </div>

        {/* Arrow */}
        <div className="flex items-center justify-center lg:w-8">
          <ArrowRight className="h-4 w-4 rotate-90 text-[#475569] lg:rotate-0" />
        </div>

        {/* OPR Core */}
        <div className="flex flex-col items-center justify-center">
          <div className="flex items-center gap-2 rounded-lg border border-[#6366F140] bg-[#6366F112] px-4 py-3">
            <Layers className="h-4 w-4 text-[#6366F1]" />
            <span className="text-xs font-medium text-[#F1F5F9]">OPR Core</span>
          </div>
          <span className="mt-1 text-[10px] text-[#64748B]">Orchestration</span>
        </div>

        {/* Arrow */}
        <div className="flex items-center justify-center lg:w-8">
          <ArrowRight className="h-4 w-4 rotate-90 text-[#475569] lg:rotate-0" />
        </div>

        {/* 6 Systems */}
        <div className="grid grid-cols-3 gap-2 sm:grid-cols-3">
          {systems.map((sys) => {
            const SysIcon = sys.icon;
            return (
              <div
                key={sys.name}
                className="flex flex-col items-center gap-1 rounded-lg border px-3 py-2"
                style={{
                  borderColor: `${sys.color}30`,
                  backgroundColor: `${sys.color}08`,
                }}
              >
                <SysIcon className="h-3.5 w-3.5" style={{ color: sys.color }} />
                <span className="text-[10px] font-medium text-[#F1F5F9]">{sys.name}</span>
              </div>
            );
          })}
        </div>

        {/* Arrow */}
        <div className="flex items-center justify-center lg:w-8">
          <ArrowRight className="h-4 w-4 rotate-90 text-[#475569] lg:rotate-0" />
        </div>

        {/* External APIs */}
        <div className="flex flex-col items-center justify-center">
          <div className="flex items-center gap-2 rounded-lg border border-[#1E293B] bg-[rgba(255,255,255,0.02)] px-4 py-3">
            <Zap className="h-4 w-4 text-[#94A3B8]" />
            <span className="text-xs font-medium text-[#F1F5F9]">External APIs</span>
          </div>
          <span className="mt-1 text-[10px] text-[#64748B]">Upstream Systems</span>
        </div>
      </div>
    </motion.div>
  );
}

/* ─── Home Page (Module Intro Dashboard) ─── */
export default function Home() {
  return (
    <Layout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="space-y-8"
      >
        {/* ═══════════════════════════════════════════
            1. WELCOME HERO SECTION
        ═══════════════════════════════════════════ */}
        <motion.section
          variants={fadeInUp}
          className="relative overflow-hidden rounded-2xl border border-[#1E293B] bg-[#0A0F1E] px-8 py-12"
        >
          {/* Decorative gradient */}
          <div
            className="pointer-events-none absolute -right-20 -top-20 h-80 w-80 rounded-full opacity-[0.07]"
            style={{ background: 'radial-gradient(circle, #6366F1 0%, transparent 70%)' }}
          />
          <div
            className="pointer-events-none absolute -bottom-16 -left-16 h-64 w-64 rounded-full opacity-[0.05]"
            style={{ background: 'radial-gradient(circle, #14B8A6 0%, transparent 70%)' }}
          />

          <div className="relative">
            <h1 className="text-3xl font-bold tracking-tight text-[#F1F5F9] sm:text-4xl">
              Welcome to <span className="text-[#6366F1]">OPR</span>
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-relaxed text-[#94A3B8] sm:text-base">
              AI-powered workflow orchestration across your enterprise systems. Design, deploy, and
              monitor intelligent automation pipelines — all in one platform.
            </p>
          </div>
        </motion.section>

        {/* ═══════════════════════════════════════════
            2. GETTING STARTED PIPELINE
        ═══════════════════════════════════════════ */}
        <motion.section variants={fadeInUp}>
          <div className="mb-5 flex items-center gap-3">
            <div className="h-px flex-1 bg-[#1E293B]" />
            <span className="text-xs font-semibold uppercase tracking-widest text-[#64748B]">
              Getting Started
            </span>
            <div className="h-px flex-1 bg-[#1E293B]" />
          </div>

          <div className="flex flex-col gap-4 lg:flex-row lg:items-stretch">
            {steps.map((step, i) => (
              <StepCard key={step.num} step={step} isLast={i === steps.length - 1} />
            ))}
          </div>
        </motion.section>

        <SectionDivider />

        {/* ═══════════════════════════════════════════
            3. CORE MODULES SECTION
        ═══════════════════════════════════════════ */}
        <motion.section variants={fadeInUp}>
          <div className="mb-5">
            <h2 className="text-lg font-bold text-[#F1F5F9]">Core Modules</h2>
            <p className="mt-1 text-sm text-[#94A3B8]">
              Explore the four pillars of the OPR platform
            </p>
          </div>

          <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
            {modules.map((module) => (
              <ModuleCard key={module.title} module={module} />
            ))}
          </div>
        </motion.section>

        <SectionDivider />

        {/* ═══════════════════════════════════════════
            4. CONNECTED SYSTEMS SECTION
        ═══════════════════════════════════════════ */}
        <motion.section variants={fadeInUp}>
          <div className="mb-5">
            <h2 className="text-lg font-bold text-[#F1F5F9]">Connected Systems</h2>
            <p className="mt-1 text-sm text-[#94A3B8]">
              Six enterprise systems seamlessly integrated into your workflows
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
            {systems.map((system) => (
              <SystemCard key={system.name} system={system} />
            ))}
          </div>
        </motion.section>

        <SectionDivider />

        {/* ═══════════════════════════════════════════
            5. ARCHITECTURE AT A GLANCE
        ═══════════════════════════════════════════ */}
        <motion.section variants={fadeInUp}>
          <div className="mb-5">
            <h2 className="text-lg font-bold text-[#F1F5F9]">Architecture at a Glance</h2>
            <p className="mt-1 text-sm text-[#94A3B8]">
              How data flows through the OPR platform
            </p>
          </div>

          <ArchitectureDiagram />
        </motion.section>
      </motion.div>
    </Layout>
  );
}
