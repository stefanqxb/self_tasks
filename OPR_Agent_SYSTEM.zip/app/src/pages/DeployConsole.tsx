import { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Rocket,
  Activity,
  Clock,
  AlertTriangle,
  Plus,
  Play,
  Pencil,
  FileText,
  Trash2,
  Calendar,
  Zap,
  Hand,
  Upload,
  Mail,
  Webhook,
} from 'lucide-react';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

/* ─────────────────────────────────────────────
   Types
   ───────────────────────────────────────────── */

type DeployStatus = 'Deployed' | 'Draft' | 'Running' | 'Failed' | 'Stopped';
type TriggerType = 'Schedule' | 'Event' | 'Manual';
type EventType = 'File Upload' | 'Email Received' | 'Webhook';

interface Deployment {
  id: string;
  workflowName: string;
  status: DeployStatus;
  trigger: TriggerType;
  schedule: string;
  lastRun: string;
  nextRun: string;
  successRate: number;
  active: boolean;
}

interface ExecutionRecord {
  id: string;
  workflow: string;
  status: 'Success' | 'Failed' | 'Running';
  startedAt: string;
  duration: string;
  triggeredBy: string;
  message: string;
  systems: string[];
}

/* ─────────────────────────────────────────────
   Mock Data
   ───────────────────────────────────────────── */

const MOCK_CONVERSATIONS = [
  { id: 'conv-001', title: 'Daily Trade Reconciliation' },
  { id: 'conv-002', title: 'Invoice Processing Pipeline' },
  { id: 'conv-003', title: 'Payment Status Monitoring' },
  { id: 'conv-004', title: 'Monthly Position Report' },
  { id: 'conv-005', title: 'Daily Trade Reconciliation' },
  { id: 'conv-006', title: 'Invoice Processing Pipeline' },
  { id: 'conv-007', title: 'Payment Status Monitoring' },
];

const INITIAL_DEPLOYMENTS: Deployment[] = [
  {
    id: 'dep-001',
    workflowName: 'Daily Trade Reconciliation',
    status: 'Deployed',
    trigger: 'Schedule',
    schedule: '0 9 * * *',
    lastRun: '15 min ago',
    nextRun: 'in 8 hours',
    successRate: 98,
    active: true,
  },
  {
    id: 'dep-002',
    workflowName: 'Invoice Processing Pipeline',
    status: 'Running',
    trigger: 'Manual',
    schedule: '',
    lastRun: '5 min ago',
    nextRun: '',
    successRate: 100,
    active: true,
  },
  {
    id: 'dep-003',
    workflowName: 'Monthly Position Report',
    status: 'Deployed',
    trigger: 'Event',
    schedule: 'On Upload',
    lastRun: '1 hour ago',
    nextRun: 'On event',
    successRate: 95,
    active: true,
  },
  {
    id: 'dep-004',
    workflowName: 'Payment Status Monitoring',
    status: 'Failed',
    trigger: 'Schedule',
    schedule: '0 */6 * * *',
    lastRun: '3 hours ago',
    nextRun: 'in 3 hours',
    successRate: 87,
    active: true,
  },
  {
    id: 'dep-005',
    workflowName: 'Invoice Processing Pipeline',
    status: 'Draft',
    trigger: 'Manual',
    schedule: '',
    lastRun: 'Never',
    nextRun: '',
    successRate: 0,
    active: false,
  },
  {
    id: 'dep-006',
    workflowName: 'Daily Trade Reconciliation',
    status: 'Deployed',
    trigger: 'Schedule',
    schedule: '0 0 * * *',
    lastRun: '12 hours ago',
    nextRun: 'in 12 hours',
    successRate: 99,
    active: true,
  },
];

const EXECUTION_HISTORY: ExecutionRecord[] = [
  { id: 'exec-001', workflow: 'Daily Trade Reconciliation', status: 'Success', startedAt: '10:30 AM', duration: '2m 15s', triggeredBy: 'Schedule', message: 'Completed successfully', systems: ['QTrack', 'GoldenEye', 'SWB', 'SIRE', 'QTrack'] },
  { id: 'exec-002', workflow: 'Invoice Processing Pipeline', status: 'Running', startedAt: '10:25 AM', duration: '5m 30s', triggeredBy: 'Manual', message: 'Processing batch 3 of 12', systems: ['QTrack', 'SWB', 'Transformer', 'OPAS', 'QTrack'] },
  { id: 'exec-003', workflow: 'Payment Status Monitoring', status: 'Failed', startedAt: '07:00 AM', duration: '45s', triggeredBy: 'Schedule', message: 'Connection timeout to payment API', systems: ['OPAS', 'SIRE', 'QTrack'] },
  { id: 'exec-004', workflow: 'Monthly Position Report', status: 'Success', startedAt: '09:15 AM', duration: '1m 30s', triggeredBy: 'Event', message: 'Uploaded 45 trade records', systems: ['GoldenEye', 'SWB', 'SIRE', 'Transformer', 'QTrack'] },
  { id: 'exec-005', workflow: 'Daily Trade Reconciliation', status: 'Success', startedAt: '12:00 AM', duration: '8m 45s', triggeredBy: 'Schedule', message: 'All 1,234 records reconciled', systems: ['QTrack', 'GoldenEye', 'SWB', 'SIRE', 'QTrack'] },
  { id: 'exec-006', workflow: 'Daily Trade Reconciliation', status: 'Success', startedAt: 'Yesterday', duration: '2m 05s', triggeredBy: 'Schedule', message: 'Completed successfully', systems: ['QTrack', 'GoldenEye', 'SWB', 'SIRE', 'QTrack'] },
  { id: 'exec-007', workflow: 'Payment Status Monitoring', status: 'Success', startedAt: 'Yesterday', duration: '1m 50s', triggeredBy: 'Schedule', message: 'Completed successfully', systems: ['OPAS', 'SIRE', 'QTrack'] },
  { id: 'exec-008', workflow: 'Invoice Processing Pipeline', status: 'Failed', startedAt: 'Yesterday', duration: '3m 10s', triggeredBy: 'Manual', message: 'Invalid email format in batch', systems: ['QTrack', 'SWB', 'Transformer', 'OPAS', 'QTrack'] },
];

/* ─────────────────────────────────────────────
   Status & Trigger Helpers
   ───────────────────────────────────────────── */

const STATUS_COLORS: Record<DeployStatus, { bg: string; text: string; dot: string }> = {
  Deployed: { bg: 'bg-[rgba(34,197,94,0.12)]', text: 'text-[#22C55E]', dot: 'bg-[#22C55E]' },
  Running: { bg: 'bg-[rgba(59,130,246,0.12)]', text: 'text-[#3B82F6]', dot: 'bg-[#3B82F6]' },
  Failed: { bg: 'bg-[rgba(239,68,68,0.12)]', text: 'text-[#EF4444]', dot: 'bg-[#EF4444]' },
  Draft: { bg: 'bg-[rgba(107,114,128,0.12)]', text: 'text-[#6B7280]', dot: 'bg-[#6B7280]' },
  Stopped: { bg: 'bg-[rgba(245,158,11,0.12)]', text: 'text-[#F59E0B]', dot: 'bg-[#F59E0B]' },
};

function StatusBadge({ status }: { status: DeployStatus }) {
  const colors = STATUS_COLORS[status];
  return (
    <span className={cn('inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium', colors.bg, colors.text)}>
      <span className={cn('h-1.5 w-1.5 rounded-full', colors.dot)} />
      {status}
    </span>
  );
}

function TriggerDisplay({ trigger }: { trigger: TriggerType }) {
  const icons = {
    Schedule: Calendar,
    Event: Zap,
    Manual: Hand,
  };
  const Icon = icons[trigger];
  return (
    <span className="inline-flex items-center gap-1.5 text-sm text-[#94A3B8]">
      <Icon className="h-3.5 w-3.5" />
      {trigger}
    </span>
  );
}

function ExecutionStatusBadge({ status }: { status: ExecutionRecord['status'] }) {
  const colors = {
    Success: 'bg-[rgba(34,197,94,0.12)] text-[#22C55E]',
    Failed: 'bg-[rgba(239,68,68,0.12)] text-[#EF4444]',
    Running: 'bg-[rgba(59,130,246,0.12)] text-[#3B82F6]',
  };
  return (
    <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium', colors[status])}>
      {status}
    </span>
  );
}

/* ─────────────────────────────────────────────
   System Colors & Pipeline (from Requirements.tsx)
   ───────────────────────────────────────────── */

const SYSTEM_COLORS: Record<string, string> = {
  QTrack: '#6366F1',
  Transformer: '#14B8A6',
  SWB: '#F59E0B',
  SIRE: '#8B5CF6',
  OPAS: '#0EA5E9',
  GoldenEye: '#F97316',
};

/** Linear system pipeline — if start === end system, listed twice (head + tail), no loopback */
function WorkflowPipeline({ systems }: { systems: string[] }) {
  if (!systems || systems.length === 0) return null;

  const first = systems[0];
  const last = systems[systems.length - 1];
  const hasSameEndpoints = first === last;

  // For endpoints-same workflows, display linearly (no loopback arrow)
  const displaySystems = systems;

  return (
    <div className="flex items-center gap-1 flex-wrap">
      {displaySystems.map((sys, idx) => {
        const color = SYSTEM_COLORS[sys] || '#CBD5E1';
        const isLast = idx === displaySystems.length - 1;
        return (
          <div key={`${sys}-${idx}`} className="flex items-center gap-1">
            <div
              className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-medium border"
              style={{ backgroundColor: `${color}12`, color, borderColor: `${color}25` }}
            >
              <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />
              {sys}
            </div>
            {!isLast && (
              <svg width="12" height="8" viewBox="0 0 12 8" fill="none" className="shrink-0 mx-0.5">
                <path d="M1 4h10M8 1l3 3-3 3" stroke="#475569" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
          </div>
        );
      })}
      {hasSameEndpoints && (
        <span className="text-[9px] text-[#475569] ml-1 italic">(linear)</span>
      )}
    </div>
  );
}

/* ─────────────────────────────────────────────
   Animation Variants
   ───────────────────────────────────────────── */

const containerVariants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35, ease: "easeOut" as const } },
};

/* ─────────────────────────────────────────────
   New Deployment Dialog
   ───────────────────────────────────────────── */

function NewDeploymentDialog({ open, onOpenChange, onDeploy }: { open: boolean; onOpenChange: (v: boolean) => void; onDeploy: (dep: Deployment) => void }) {
  const [selectedWorkflow, setSelectedWorkflow] = useState('');
  const [triggerType, setTriggerType] = useState<TriggerType>('Schedule');
  const [cronExpression, setCronExpression] = useState('0 9 * * *');
  const [eventType, setEventType] = useState<EventType>('File Upload');

  const cronPresets = [
    { label: 'Hourly', value: '0 * * * *' },
    { label: 'Daily 9AM', value: '0 9 * * *' },
    { label: 'Daily Midnight', value: '0 0 * * *' },
    { label: 'Weekly', value: '0 0 * * 0' },
  ];

  const handleDeploy = () => {
    const selectedConv = MOCK_CONVERSATIONS.find((c) => c.id === selectedWorkflow);
    if (!selectedConv) return;
    const newDep: Deployment = {
      id: `dep-${Date.now()}`,
      workflowName: selectedConv.title,
      status: 'Deployed',
      trigger: triggerType,
      schedule: triggerType === 'Schedule' ? cronExpression : triggerType === 'Event' ? eventType : '',
      lastRun: 'Never',
      nextRun: triggerType === 'Schedule' ? 'Pending' : triggerType === 'Event' ? 'On event' : 'Manual',
      successRate: 0,
      active: true,
    };
    onDeploy(newDep);
    onOpenChange(false);
    setSelectedWorkflow('');
    setTriggerType('Schedule');
    setCronExpression('0 9 * * *');
  };

  const eventIcons: Record<EventType, React.ElementType> = {
    'File Upload': Upload,
    'Email Received': Mail,
    'Webhook': Webhook,
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#0A0F1E] border-[#1E293B] text-[#F1F5F9] max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-[#F1F5F9]">New Deployment</DialogTitle>
        </DialogHeader>
        <div className="space-y-5 py-2">
          {/* Workflow Selection */}
          <div className="space-y-2">
            <Label className="text-sm text-[#94A3B8]">Select Workflow</Label>
            <Select value={selectedWorkflow} onValueChange={setSelectedWorkflow}>
              <SelectTrigger className="w-full bg-[#111827] border-[#1E293B] text-[#F1F5F9]">
                <SelectValue placeholder="Choose a workflow..." />
              </SelectTrigger>
              <SelectContent className="bg-[#0A0F1E] border-[#1E293B]">
                {MOCK_CONVERSATIONS.map((conv) => (
                  <SelectItem key={conv.id} value={conv.id} className="text-[#F1F5F9] focus:bg-[#1E293B] focus:text-[#F1F5F9]">
                    {conv.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Trigger Type */}
          <div className="space-y-2">
            <Label className="text-sm text-[#94A3B8]">Trigger Type</Label>
            <div className="grid grid-cols-3 gap-2">
              {(['Schedule', 'Event', 'Manual'] as TriggerType[]).map((type) => (
                <button
                  key={type}
                  onClick={() => setTriggerType(type)}
                  className={cn(
                    'flex items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-sm font-medium transition-all',
                    triggerType === type
                      ? 'border-[#6366F1] bg-[rgba(99,102,241,0.12)] text-[#6366F1]'
                      : 'border-[#1E293B] bg-[#111827] text-[#94A3B8] hover:border-[#334155]'
                  )}
                >
                  {type === 'Schedule' && <Calendar className="h-3.5 w-3.5" />}
                  {type === 'Event' && <Zap className="h-3.5 w-3.5" />}
                  {type === 'Manual' && <Hand className="h-3.5 w-3.5" />}
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Schedule Configuration */}
          {triggerType === 'Schedule' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-3"
            >
              <div className="space-y-2">
                <Label className="text-sm text-[#94A3B8]">Cron Expression</Label>
                <Input
                  value={cronExpression}
                  onChange={(e) => setCronExpression(e.target.value)}
                  placeholder="0 9 * * *"
                  className="bg-[#111827] border-[#1E293B] text-[#F1F5F9] font-mono"
                />
              </div>
              <div className="flex flex-wrap gap-2">
                {cronPresets.map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => setCronExpression(preset.value)}
                    className={cn(
                      'rounded-full px-3 py-1 text-xs font-medium border transition-all',
                      cronExpression === preset.value
                        ? 'border-[#6366F1] bg-[rgba(99,102,241,0.12)] text-[#6366F1]'
                        : 'border-[#1E293B] bg-[#111827] text-[#94A3B8] hover:border-[#334155]'
                    )}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Event Configuration */}
          {triggerType === 'Event' && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-2"
            >
              <Label className="text-sm text-[#94A3B8]">Event Type</Label>
              <div className="grid grid-cols-1 gap-2">
                {(['File Upload', 'Email Received', 'Webhook'] as EventType[]).map((type) => {
                  const EventIcon = eventIcons[type];
                  return (
                    <button
                      key={type}
                      onClick={() => setEventType(type)}
                      className={cn(
                        'flex items-center gap-3 rounded-lg border px-3 py-2.5 text-sm font-medium transition-all',
                        eventType === type
                          ? 'border-[#6366F1] bg-[rgba(99,102,241,0.12)] text-[#6366F1]'
                          : 'border-[#1E293B] bg-[#111827] text-[#94A3B8] hover:border-[#334155]'
                      )}
                    >
                      <EventIcon className="h-4 w-4" />
                      {type}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Manual - no extra config */}
          {triggerType === 'Manual' && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-sm text-[#64748B]"
            >
              This workflow will only run when triggered manually.
            </motion.p>
          )}
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="border-[#1E293B] bg-transparent text-[#94A3B8] hover:bg-[#1E293B] hover:text-[#F1F5F9]"
          >
            Cancel
          </Button>
          <Button
            onClick={handleDeploy}
            disabled={!selectedWorkflow}
            className="bg-[#6366F1] text-white hover:bg-[#5558E0]"
          >
            <Rocket className="h-4 w-4" />
            Deploy
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ─────────────────────────────────────────────
   Edit Config Dialog
   ───────────────────────────────────────────── */

function EditConfigDialog({
  open,
  onOpenChange,
  deployment,
  onSave,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  deployment: Deployment | null;
  onSave: (updated: Deployment) => void;
}) {
  const [triggerType, setTriggerType] = useState<TriggerType>('Schedule');
  const [cronExpression, setCronExpression] = useState('');
  const [eventType, setEventType] = useState<EventType>('File Upload');
  const [isActive, setIsActive] = useState(true);

  useEffect(() => {
    if (deployment) {
      setTriggerType(deployment.trigger);
      setCronExpression(deployment.schedule);
      setIsActive(deployment.active);
    }
  }, [deployment]);

  const handleSave = () => {
    if (deployment) {
      onSave({
        ...deployment,
        trigger: triggerType,
        schedule: triggerType === 'Schedule' ? cronExpression : triggerType === 'Event' ? eventType : '',
        active: isActive,
      });
    }
    onOpenChange(false);
  };

  if (!deployment) return null;

  const cronPresets = [
    { label: 'Hourly', value: '0 * * * *' },
    { label: 'Daily 9AM', value: '0 9 * * *' },
    { label: 'Daily Midnight', value: '0 0 * * *' },
    { label: 'Weekly', value: '0 0 * * 0' },
  ];

  const eventIcons: Record<EventType, React.ElementType> = {
    'File Upload': Upload,
    'Email Received': Mail,
    'Webhook': Webhook,
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#0A0F1E] border-[#1E293B] text-[#F1F5F9] max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-[#F1F5F9]">Edit Config</DialogTitle>
        </DialogHeader>
        <div className="space-y-5 py-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-[#F1F5F9]">{deployment.workflowName}</p>
              <p className="text-xs text-[#64748B]">{deployment.id}</p>
            </div>
            <div className="flex items-center gap-2">
              <span className={cn('text-xs', isActive ? 'text-[#22C55E]' : 'text-[#6B7280]')}>{isActive ? 'Active' : 'Inactive'}</span>
              <Switch checked={isActive} onCheckedChange={setIsActive} />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-sm text-[#94A3B8]">Trigger Type</Label>
            <div className="grid grid-cols-3 gap-2">
              {(['Schedule', 'Event', 'Manual'] as TriggerType[]).map((type) => (
                <button
                  key={type}
                  onClick={() => setTriggerType(type)}
                  className={cn(
                    'flex items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-sm font-medium transition-all',
                    triggerType === type
                      ? 'border-[#6366F1] bg-[rgba(99,102,241,0.12)] text-[#6366F1]'
                      : 'border-[#1E293B] bg-[#111827] text-[#94A3B8] hover:border-[#334155]'
                  )}
                >
                  {type === 'Schedule' && <Calendar className="h-3.5 w-3.5" />}
                  {type === 'Event' && <Zap className="h-3.5 w-3.5" />}
                  {type === 'Manual' && <Hand className="h-3.5 w-3.5" />}
                  {type}
                </button>
              ))}
            </div>
          </div>

          {triggerType === 'Schedule' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
              <div className="space-y-2">
                <Label className="text-sm text-[#94A3B8]">Cron Expression</Label>
                <Input
                  value={cronExpression}
                  onChange={(e) => setCronExpression(e.target.value)}
                  className="bg-[#111827] border-[#1E293B] text-[#F1F5F9] font-mono"
                />
              </div>
              <div className="flex flex-wrap gap-2">
                {cronPresets.map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => setCronExpression(preset.value)}
                    className={cn(
                      'rounded-full px-3 py-1 text-xs font-medium border transition-all',
                      cronExpression === preset.value
                        ? 'border-[#6366F1] bg-[rgba(99,102,241,0.12)] text-[#6366F1]'
                        : 'border-[#1E293B] bg-[#111827] text-[#94A3B8] hover:border-[#334155]'
                    )}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {triggerType === 'Event' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-2">
              <Label className="text-sm text-[#94A3B8]">Event Type</Label>
              <div className="grid grid-cols-1 gap-2">
                {(['File Upload', 'Email Received', 'Webhook'] as EventType[]).map((type) => {
                  const EventIcon = eventIcons[type];
                  return (
                    <button
                      key={type}
                      onClick={() => setEventType(type)}
                      className={cn(
                        'flex items-center gap-3 rounded-lg border px-3 py-2.5 text-sm font-medium transition-all',
                        eventType === type
                          ? 'border-[#6366F1] bg-[rgba(99,102,241,0.12)] text-[#6366F1]'
                          : 'border-[#1E293B] bg-[#111827] text-[#94A3B8] hover:border-[#334155]'
                      )}
                    >
                      <EventIcon className="h-4 w-4" />
                      {type}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="border-[#1E293B] bg-transparent text-[#94A3B8] hover:bg-[#1E293B] hover:text-[#F1F5F9]"
          >
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-[#6366F1] text-white hover:bg-[#5558E0]">
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ─────────────────────────────────────────────
   Stats Card
   ───────────────────────────────────────────── */

function StatsCard({
  title,
  value,
  icon: Icon,
  color,
  delay,
}: {
  title: string;
  value: number;
  icon: React.ElementType;
  color: string;
  delay: number;
}) {
  return (
    <motion.div
      variants={itemVariants}
      className="rounded-xl border border-[#1E293B] bg-[#0A0F1E] p-5"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-[#64748B] uppercase tracking-wide">{title}</p>
          <motion.p
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: delay + 0.2, duration: 0.4 }}
            className="mt-2 text-2xl font-bold text-[#F1F5F9]"
          >
            {value}
          </motion.p>
        </div>
        <div
          className="flex h-10 w-10 items-center justify-center rounded-lg"
          style={{ backgroundColor: `${color}18` }}
        >
          <Icon className="h-5 w-5" style={{ color }} />
        </div>
      </div>
    </motion.div>
  );
}

/* ─────────────────────────────────────────────
   Main Operations Hub
   ───────────────────────────────────────────── */

export default function OperationsHub() {
  const [deployments, setDeployments] = useState<Deployment[]>(INITIAL_DEPLOYMENTS);
  const [newDialogOpen, setNewDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingDeployment, setEditingDeployment] = useState<Deployment | null>(null);
  const [viewLogsDepId, setViewLogsDepId] = useState<string | null>(null);

  const stats = useMemo(
    () => ({
      totalDeployed: deployments.filter((d) => d.status === 'Deployed').length,
      activeRunning: deployments.filter((d) => d.status === 'Running').length,
      scheduledJobs: deployments.filter((d) => d.trigger === 'Schedule').length,
      failed24h: deployments.filter((d) => d.status === 'Failed').length,
    }),
    [deployments]
  );

  const handleEdit = (dep: Deployment) => {
    setEditingDeployment(dep);
    setEditDialogOpen(true);
  };

  const handleSaveEdit = (updated: Deployment) => {
    setDeployments((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
  };

  const handleDelete = (id: string) => {
    setDeployments((prev) => prev.filter((d) => d.id !== id));
  };

  const handleRunNow = (id: string) => {
    setDeployments((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status: 'Running' as DeployStatus, lastRun: 'Just now' } : d))
    );
  };

  const handleDeploy = (dep: Deployment) => {
    setDeployments((prev) => [...prev, dep]);
  };

  return (
    <Layout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="show"
        className="space-y-6"
      >
        {/* ── Section 1: Page Header ── */}
        <motion.div variants={itemVariants} className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[#F1F5F9]">Operations Hub</h1>
            <p className="mt-0.5 text-sm text-[#64748B]">Manage and monitor workflow operations</p>
          </div>
          <Button
            onClick={() => setNewDialogOpen(true)}
            className="bg-[#6366F1] text-white hover:bg-[#5558E0] gap-2"
          >
            <Plus className="h-4 w-4" />
            New Deployment
          </Button>
        </motion.div>

        {/* ── Section 2: Stats Cards ── */}
        <motion.div variants={itemVariants} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatsCard title="Total Deployed" value={stats.totalDeployed} icon={Rocket} color="#6366F1" delay={0} />
          <StatsCard title="Active Running" value={stats.activeRunning} icon={Activity} color="#22C55E" delay={0.1} />
          <StatsCard title="Scheduled Jobs" value={stats.scheduledJobs} icon={Clock} color="#3B82F6" delay={0.2} />
          <StatsCard title="Failed (24h)" value={stats.failed24h} icon={AlertTriangle} color="#EF4444" delay={0.3} />
        </motion.div>

        {/* ── Section 3: Deployments Table ── */}
        <motion.div variants={itemVariants} className="rounded-xl border border-[#1E293B] bg-[#0A0F1E] overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-[#1E293B]">
            <h2 className="text-sm font-semibold text-[#F1F5F9]">Deployments</h2>
            <Badge variant="outline" className="border-[#1E293B] text-[#64748B]">
              {deployments.length} total
            </Badge>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-[#1E293B] hover:bg-transparent">
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Workflow Name</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Status</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Trigger</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Schedule</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Last Run</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Next Run</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Success Rate</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {deployments.map((dep, idx) => (
                  <>
                  <motion.tr
                    key={dep.id}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.04 + 0.3, duration: 0.3 }}
                    className="border-b border-[#1E293B]/60 hover:bg-[rgba(99,102,241,0.04)] transition-colors group"
                  >
                    <TableCell className="text-sm font-medium text-[#CBD5E1]">{dep.workflowName}</TableCell>
                    <TableCell><StatusBadge status={dep.status} /></TableCell>
                    <TableCell><TriggerDisplay trigger={dep.trigger} /></TableCell>
                    <TableCell className="text-sm text-[#64748B] font-mono text-xs">{dep.schedule || '—'}</TableCell>
                    <TableCell className="text-sm text-[#94A3B8]">{dep.lastRun}</TableCell>
                    <TableCell className="text-sm text-[#64748B]">{dep.nextRun || '—'}</TableCell>
                    <TableCell>
                      {dep.successRate > 0 ? (
                        <div className="flex items-center gap-2 min-w-[80px]">
                          <Progress value={dep.successRate} className="h-1.5 w-12 bg-[#1E293B]" />
                          <span className="text-xs text-[#94A3B8]">{dep.successRate}%</span>
                        </div>
                      ) : (
                        <span className="text-xs text-[#475569]">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => handleRunNow(dep.id)}
                          title="Run Now"
                          className="rounded-md p-1.5 text-[#94A3B8] hover:bg-[rgba(34,197,94,0.12)] hover:text-[#22C55E] transition-colors"
                        >
                          <Play className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => handleEdit(dep)}
                          title="Edit Config"
                          className="rounded-md p-1.5 text-[#94A3B8] hover:bg-[rgba(99,102,241,0.12)] hover:text-[#6366F1] transition-colors"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => setViewLogsDepId(viewLogsDepId === dep.id ? null : dep.id)}
                          title="View Logs"
                          className={cn(
                            'rounded-md p-1.5 transition-colors',
                            viewLogsDepId === dep.id
                              ? 'bg-[rgba(59,130,246,0.12)] text-[#3B82F6]'
                              : 'text-[#94A3B8] hover:bg-[rgba(59,130,246,0.12)] hover:text-[#3B82F6]'
                          )}
                        >
                          <FileText className="h-3.5 w-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(dep.id)}
                          title="Delete"
                          className="rounded-md p-1.5 text-[#94A3B8] hover:bg-[rgba(239,68,68,0.12)] hover:text-[#EF4444] transition-colors"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </TableCell>
                  </motion.tr>
                  {viewLogsDepId === dep.id && (
                    <TableRow>
                      <TableCell colSpan={8} className="px-0 py-0">
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.2 }}
                          className="bg-[#050914] border-y border-[#1E293B]/40"
                        >
                          <div className="px-5 py-3 space-y-1.5">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-xs font-semibold text-[#64748B] uppercase tracking-wider">Execution Logs</span>
                              <span className="text-[10px] text-[#475569]">{dep.workflowName} — {dep.id}</span>
                            </div>
                            {[
                              { time: '10:30:15', level: 'info', msg: `Starting ${dep.workflowName} workflow execution` },
                              { time: '10:30:16', level: 'info', msg: 'Connected to all required system endpoints' },
                              { time: '10:30:18', level: dep.status === 'Failed' ? 'error' : 'info', msg: dep.status === 'Failed' ? 'Error: Connection timeout to payment API after 30s' : 'Processing batch data...' },
                              { time: '10:30:45', level: dep.status === 'Failed' ? 'error' : 'success', msg: dep.status === 'Failed' ? 'Execution failed — retry scheduled' : 'Workflow completed successfully' },
                            ].map((log, i) => (
                              <div key={i} className="flex items-start gap-3 text-xs font-mono">
                                <span className="text-[#475569] shrink-0">{log.time}</span>
                                <span className={cn(
                                  'shrink-0 w-[52px] text-center rounded px-1 py-0.5 text-[10px] font-bold uppercase',
                                  log.level === 'error' ? 'bg-[rgba(239,68,68,0.15)] text-[#EF4444]' :
                                  log.level === 'success' ? 'bg-[rgba(34,197,94,0.15)] text-[#22C55E]' :
                                  'bg-[rgba(59,130,246,0.15)] text-[#3B82F6]'
                                )}>
                                  {log.level}
                                </span>
                                <span className={cn(
                                  'text-[#94A3B8]',
                                  log.level === 'error' && 'text-[#EF4444]'
                                )}>{log.msg}</span>
                              </div>
                            ))}
                          </div>
                        </motion.div>
                      </TableCell>
                    </TableRow>
                  )}
                  </>
                ))}
                {deployments.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-[#64748B]">
                      No deployments yet. Click "New Deployment" to get started.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </motion.div>

        {/* ── Section 4: Execution History ── */}
        <motion.div variants={itemVariants} className="rounded-xl border border-[#1E293B] bg-[#0A0F1E] overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-[#1E293B]">
            <h2 className="text-sm font-semibold text-[#F1F5F9]">Execution History</h2>
            <button className="text-xs font-medium text-[#6366F1] hover:text-[#818CF8] transition-colors">
              View All
            </button>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-[#1E293B] hover:bg-transparent">
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Workflow</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Pipeline</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Status</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Started At</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Duration</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Triggered By</TableHead>
                  <TableHead className="text-[#94A3B8] font-medium text-xs uppercase tracking-wider">Message</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {EXECUTION_HISTORY.map((exec, idx) => (
                  <motion.tr
                    key={exec.id}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.035 + 0.4, duration: 0.3 }}
                    className="border-b border-[#1E293B]/60 hover:bg-[rgba(99,102,241,0.04)] transition-colors"
                  >
                    <TableCell className="text-sm font-medium text-[#CBD5E1]">{exec.workflow}</TableCell>
                    <TableCell><WorkflowPipeline systems={exec.systems} /></TableCell>
                    <TableCell><ExecutionStatusBadge status={exec.status} /></TableCell>
                    <TableCell className="text-sm text-[#94A3B8]">{exec.startedAt}</TableCell>
                    <TableCell className="text-sm text-[#94A3B8]">{exec.duration}</TableCell>
                    <TableCell className="text-sm text-[#64748B]">{exec.triggeredBy}</TableCell>
                    <TableCell className="text-sm text-[#64748B] max-w-[240px] truncate">{exec.message}</TableCell>
                  </motion.tr>
                ))}
              </TableBody>
            </Table>
          </div>
        </motion.div>
      </motion.div>

      {/* Dialogs */}
      <NewDeploymentDialog open={newDialogOpen} onOpenChange={setNewDialogOpen} onDeploy={handleDeploy} />
      <EditConfigDialog
        open={editDialogOpen}
        onOpenChange={setEditDialogOpen}
        deployment={editingDeployment}
        onSave={handleSaveEdit}
      />
    </Layout>
  );
}
