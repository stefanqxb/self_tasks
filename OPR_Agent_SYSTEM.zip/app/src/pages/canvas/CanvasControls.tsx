import { memo } from 'react';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  RotateCcw,
  ChevronRight,
  PanelLeft,
} from 'lucide-react';
import type { System, Step } from './data';
import { systems } from './data';

// ─── Breadcrumb ─────────────────────────────────────────────────────

type BreadcrumbProps = {
  layer: number;
  selectedSystem: System | null;
  selectedStep: Step | null;
  onNavigateLayer: (layer: number) => void;
};

export const CanvasBreadcrumb = memo(function CanvasBreadcrumb({
  layer,
  selectedSystem,
  selectedStep,
  onNavigateLayer,
}: BreadcrumbProps) {
  if (layer === 1) return null;

  return (
    <div
      className="pointer-events-auto flex items-center gap-1 rounded-[20px] px-4 py-2"
      style={{
        backgroundColor: 'rgba(30, 41, 59, 0.8)',
        backdropFilter: 'blur(8px)',
      }}
    >
      {/* Systems */}
      <button
        onClick={() => onNavigateLayer(1)}
        className="text-xs font-medium text-[#94A3B8] transition-colors hover:text-white"
      >
        Systems
      </button>

      {layer >= 2 && selectedSystem && (
        <>
          <ChevronRight className="h-3 w-3 text-[#64748B]" />
          <button
            onClick={() => onNavigateLayer(2)}
            className="text-xs font-medium transition-colors hover:text-white"
            style={{ color: selectedSystem.color }}
          >
            {selectedSystem.name}
          </button>
        </>
      )}

      {layer >= 3 && selectedStep && (
        <>
          <ChevronRight className="h-3 w-3 text-[#64748B]" />
          <span className="text-xs font-medium text-white">
            {selectedStep.name}
          </span>
        </>
      )}
    </div>
  );
});

// ─── Floating Controls ──────────────────────────────────────────────

type FloatingControlsProps = {
  zoom: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onFitView: () => void;
  onReset: () => void;
  showGrid: boolean;
  onToggleGrid: () => void;
  onTogglePanel: () => void;
};

export const FloatingControls = memo(function FloatingControls({
  zoom,
  onZoomIn,
  onZoomOut,
  onFitView,
  onReset,
  showGrid,
  onToggleGrid,
  onTogglePanel,
}: FloatingControlsProps) {
  return (
    <div
      className="pointer-events-auto flex items-center gap-1 rounded-xl p-2"
      style={{
        backgroundColor: 'rgba(30, 41, 59, 0.9)',
        backdropFilter: 'blur(12px)',
      }}
    >
      <ControlButton onClick={onZoomOut} title="Zoom Out">
        <ZoomOut className="h-4 w-4" />
      </ControlButton>
      <span className="flex w-[52px] items-center justify-center font-mono text-xs text-[#64748B]">
        {Math.round(zoom * 100)}%
      </span>
      <ControlButton onClick={onZoomIn} title="Zoom In">
        <ZoomIn className="h-4 w-4" />
      </ControlButton>

      <div className="mx-1 h-5 w-px bg-[#334155]" />

      <ControlButton onClick={onFitView} title="Fit to View">
        <Maximize2 className="h-4 w-4" />
      </ControlButton>
      <ControlButton onClick={onReset} title="Reset Layout">
        <RotateCcw className="h-4 w-4" />
      </ControlButton>

      <div className="mx-1 h-5 w-px bg-[#334155]" />

      <ControlButton onClick={onToggleGrid} title="Toggle Grid" isActive={showGrid}>
        <GridIcon />
      </ControlButton>
      <ControlButton onClick={onTogglePanel} title="Toggle Info Panel">
        <PanelLeft className="h-4 w-4" />
      </ControlButton>
    </div>
  );
});

function ControlButton({
  onClick,
  title,
  children,
  isActive,
}: {
  onClick: () => void;
  title: string;
  children: React.ReactNode;
  isActive?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      className="flex h-9 w-9 items-center justify-center rounded-lg text-[#64748B] transition-all duration-100 hover:bg-[rgba(51,65,85,0.4)] hover:text-white"
      style={{
        color: isActive ? '#818CF8' : undefined,
        backgroundColor: isActive ? 'rgba(99,102,241,0.12)' : undefined,
      }}
    >
      {children}
    </button>
  );
}

function GridIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M3 9h18M3 15h18M9 3v18M15 3v18" />
    </svg>
  );
}

// ─── Legend ─────────────────────────────────────────────────────────

export const SystemLegend = memo(function SystemLegend({ systemIds }: { systemIds?: string[] }) {
  const displaySystems = systemIds ? systems.filter((s) => systemIds.includes(s.id)) : systems;
  return (
    <div
      className="pointer-events-auto flex flex-col gap-1.5 rounded-xl p-3"
      style={{
        backgroundColor: 'rgba(30, 41, 59, 0.8)',
        backdropFilter: 'blur(8px)',
      }}
    >
      <span className="mb-1 text-[10px] font-semibold uppercase tracking-wider text-[#64748B]">Systems</span>
      {displaySystems.map((s) => (
        <div key={s.id} className="flex items-center gap-2">
          <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: s.color }} />
          <span className="text-xs text-[#94A3B8]">{s.name}</span>
        </div>
      ))}
    </div>
  );
});
