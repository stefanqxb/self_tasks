// Mock data for the Workflow Canvas — Document Processing Pipeline workflow

export interface System {
  id: string;
  name: string;
  description: string;
  color: string;
  icon: string;
  stats: { label: string; value: number }[];
}

export interface Step {
  id: string;
  systemId: string;
  number: number;
  name: string;
  description: string;
  requirement: string;
  status: 'pending' | 'active' | 'completed';
  capabilities: Capability[];
}

export interface Capability {
  id: string;
  stepId: string;
  systemId: string;
  name: string;
  description: string;
  type: 'API' | 'Feature' | 'Config';
  code?: string;
  tags: string[];
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  endpoint?: string;
}

// ─── Systems ────────────────────────────────────────────────────────

export const systems: System[] = [
  {
    id: 'qtrack',
    name: 'QTrack',
    description: 'Intelligent email management system that receives, prioritizes, translates, and summarizes emails with AI. Handles the full email lifecycle including attachments.',
    color: '#6366F1',
    icon: 'Mail',
    stats: [
      { label: 'Steps', value: 3 },
      { label: 'APIs', value: 7 },
      { label: 'Files', value: 4 },
    ],
  },
  {
    id: 'transformer',
    name: 'Transformer',
    description: 'Workflow platform for document and data transformation. Processes Excel and PDF data with intelligent workflows for extraction, conversion, and restructuring.',
    color: '#14B8A6',
    icon: 'RefreshCw',
    stats: [
      { label: 'Steps', value: 3 },
      { label: 'APIs', value: 6 },
      { label: 'Files', value: 3 },
    ],
  },
  {
    id: 'swb',
    name: 'SWB',
    description: 'Information extraction workflow platform that builds and runs workflows for extracting structured data from PDF and Email content including entities, amounts, and dates.',
    color: '#F59E0B',
    icon: 'ScanSearch',
    stats: [
      { label: 'Steps', value: 3 },
      { label: 'APIs', value: 6 },
      { label: 'Files', value: 4 },
    ],
  },
  {
    id: 'sire',
    name: 'SIRE',
    description: 'Enterprise Reconciliation Platform handling trade reconciliation, settlement reconciliation, payment reconciliation, break identification, and exception management.',
    color: '#8B5CF6',
    icon: 'BrainCircuit',
    stats: [
      { label: 'Steps', value: 5 },
      { label: 'APIs', value: 8 },
      { label: 'Files', value: 3 },
    ],
  },
  {
    id: 'opas',
    name: 'OPAS',
    description: 'Operations and Payment Administration System handling settlement records, payment records, payment status tracking, batch storage, and reconciliation result storage.',
    color: '#0EA5E9',
    icon: 'CreditCard',
    stats: [
      { label: 'Steps', value: 5 },
      { label: 'APIs', value: 8 },
      { label: 'Files', value: 3 },
    ],
  },
  {
    id: 'goldeneye',
    name: 'GoldenEye',
    description: 'Trade and Position Management System handling trade records, trade lifecycle tracking, position aggregation, and trade history for front-to-back reconciliation.',
    color: '#F97316',
    icon: 'TrendingUp',
    stats: [
      { label: 'Steps', value: 2 },
      { label: 'APIs', value: 6 },
      { label: 'Files', value: 2 },
    ],
  },
];

// ─── Steps ──────────────────────────────────────────────────────────

const steps: Step[] = [
  // QTrack steps
  {
    id: 'qt-step-1',
    systemId: 'qtrack',
    number: 1,
    name: 'Receive Incoming Email',
    description: 'Receive an incoming email with attachments through the QTrack email ingestion API. Parse email headers, body content, and extract attached files (PDF, Excel) for downstream processing.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'completed',
    capabilities: [],
  },
  {
    id: 'qt-step-2',
    systemId: 'qtrack',
    number: 2,
    name: 'AI Prioritize Email',
    description: 'Run AI prioritization on the received email to determine urgency level, category, and processing priority. High-priority emails with attachments are flagged for immediate extraction.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'active',
    capabilities: [],
  },
  {
    id: 'qt-step-3',
    systemId: 'qtrack',
    number: 3,
    name: 'Summarize Email Content',
    description: 'Generate an AI summary of the email thread to extract key points, action items, and context. The summary helps downstream systems understand the email purpose without reading full content.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'pending',
    capabilities: [],
  },
  // SWB steps
  {
    id: 'swb-step-1',
    systemId: 'swb',
    number: 1,
    name: 'Extract PDF Information',
    description: 'Run SWB extraction workflow on the PDF attachment to identify and extract structured data — entities, dates, amounts, vendor names, invoice numbers, and line items.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'completed',
    capabilities: [],
  },
  {
    id: 'swb-step-2',
    systemId: 'swb',
    number: 2,
    name: 'Extract Email Information',
    description: 'Run SWB extraction workflow on the email body and metadata to extract sender info, dates, mentioned entities, amounts, and attachment references.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'active',
    capabilities: [],
  },
  {
    id: 'swb-step-3',
    systemId: 'swb',
    number: 3,
    name: 'Validate Extracted Data',
    description: 'Validate extracted data against defined schemas checking data types, required fields, and business rules. Enrich data with external lookups (vendor details, currency conversion).',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'pending',
    capabilities: [],
  },
  // Transformer steps
  {
    id: 'tr-step-1',
    systemId: 'transformer',
    number: 1,
    name: 'Transform Extracted Data',
    description: 'Apply transformation workflows to the extracted PDF and email data — convert formats, restructure content, merge related fields, and normalize data types for downstream consumption.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'completed',
    capabilities: [],
  },
  {
    id: 'tr-step-2',
    systemId: 'transformer',
    number: 2,
    name: 'Recommend Transformation Template',
    description: 'Get AI-powered workflow recommendation for the best transformation template based on the extracted data structure, source document type, and target output requirements.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'active',
    capabilities: [],
  },
  {
    id: 'tr-step-3',
    systemId: 'transformer',
    number: 3,
    name: 'Batch Process Documents',
    description: 'Run batch transformation across all extracted documents (email + PDF attachments) to produce consolidated output in the target format for the analytics pipeline.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'pending',
    capabilities: [],
  },
  // OPAS steps
  {
    id: 'op-step-1',
    systemId: 'opas',
    number: 1,
    name: 'Retrieve Historical Payment Records',
    description: 'Retrieve historical settlement and payment records from OPAS for comparison against incoming payment confirmations and extracted documents.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'completed',
    capabilities: [],
  },
  {
    id: 'op-step-2',
    systemId: 'opas',
    number: 2,
    name: 'Retrieve Settlement and Payment History',
    description: 'Query payment and settlement history with filtering by date range, counterparty, amount, and status to support reconciliation processes.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'active',
    capabilities: [],
  },
  {
    id: 'op-step-3',
    systemId: 'opas',
    number: 3,
    name: 'Store Extracted Payment Details',
    description: 'Store payment details extracted from documents and emails into OPAS as structured payment records for downstream reconciliation.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'completed',
    capabilities: [],
  },
  {
    id: 'op-step-4',
    systemId: 'opas',
    number: 4,
    name: 'Update Payment Status',
    description: 'Update payment status through its lifecycle — from pending to processed, failed, or reconciled based on reconciliation outcomes.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'active',
    capabilities: [],
  },
  {
    id: 'op-step-5',
    systemId: 'opas',
    number: 5,
    name: 'Store Reconciliation Results',
    description: 'Store final reconciliation results including match status, identified breaks, adjustments, and resolution actions taken.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'pending',
    capabilities: [],
  },
  // GoldenEye steps
  {
    id: 'ge-step-1',
    systemId: 'goldeneye',
    number: 1,
    name: 'Load Trade Positions',
    description: 'Load trade records from GoldenEye with filtering by date, instrument, counterparty, and status for reconciliation with settlement data.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'completed',
    capabilities: [],
  },
  {
    id: 'ge-step-2',
    systemId: 'goldeneye',
    number: 2,
    name: 'Get Trade History',
    description: 'Retrieve trade history with lifecycle events and current positions aggregated by book, instrument, and counterparty.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'active',
    capabilities: [],
  },
  // SIRE steps
  {
    id: 'sr-step-1',
    systemId: 'sire',
    number: 1,
    name: 'Reconcile Trade Data with Settlement Records',
    description: 'Run trade reconciliation to match trades between front office and back office systems. Identify unmatched trades, price mismatches, quantity differences, and missing records.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'completed',
    capabilities: [],
  },
  {
    id: 'sr-step-2',
    systemId: 'sire',
    number: 2,
    name: 'Match Payment Instructions Against Actual Settlements',
    description: 'Execute payment reconciliation to match payment instructions against actual settlements. Identify payment breaks including amount mismatches, timing differences, and missing payments.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'active',
    capabilities: [],
  },
  {
    id: 'sr-step-3',
    systemId: 'sire',
    number: 3,
    name: 'Identify and Categorize Reconciliation Breaks',
    description: 'Identify all reconciliation breaks from trade, settlement, and payment matching. Categorize breaks by type (trade mismatch, settlement failure, payment discrepancy) and severity.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'active',
    capabilities: [],
  },
  {
    id: 'sr-step-4',
    systemId: 'sire',
    number: 4,
    name: 'Generate Reconciliation Exception Report',
    description: 'Generate a comprehensive exception report listing all open breaks, their categorization, aging, and resolution status. Include reconciliation summary statistics and match rates.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'pending',
    capabilities: [],
  },
  {
    id: 'sr-step-5',
    systemId: 'sire',
    number: 5,
    name: 'Route Breaks to Operations Team for Resolution',
    description: 'Route categorized breaks to the appropriate operations teams based on break type and SLA requirements. Trigger escalation for critical breaks exceeding tolerance thresholds.',
    requirement: 'REQ-DOC-001 — Automated Document Processing Pipeline',
    status: 'pending',
    capabilities: [],
  },
];

// ─── Capabilities ───────────────────────────────────────────────────

const capabilities: Capability[] = [
  // QTrack — Step 1: Receive Incoming Email
  {
    id: 'cap-qt-1-1',
    stepId: 'qt-step-1',
    systemId: 'qtrack',
    name: 'Receive Email API',
    description: 'POST /api/v1/emails/receive — Receive and process incoming email with metadata parsing and attachment handling.',
    type: 'API',
    code: 'POST /api/v1/emails/receive',
    tags: ['email', 'receive', 'ingestion'],
    method: 'POST',
    endpoint: '/api/v1/emails/receive',
  },
  {
    id: 'cap-qt-1-2',
    stepId: 'qt-step-1',
    systemId: 'qtrack',
    name: 'Email Ingestion Pipeline',
    description: 'Feature that handles end-to-end email ingestion including parsing, attachment extraction, and storage.',
    type: 'Feature',
    tags: ['email', 'pipeline', 'parsing'],
  },
  {
    id: 'cap-qt-1-3',
    stepId: 'qt-step-1',
    systemId: 'qtrack',
    name: 'List Emails API',
    description: 'GET /api/v1/emails — List emails with filters for priority, status, and date range.',
    type: 'API',
    code: 'GET /api/v1/emails',
    tags: ['email', 'list', 'filter'],
    method: 'GET',
    endpoint: '/api/v1/emails',
  },
  // QTrack — Step 2: AI Prioritize Email
  {
    id: 'cap-qt-2-1',
    stepId: 'qt-step-2',
    systemId: 'qtrack',
    name: 'Prioritize Email API',
    description: 'POST /api/v1/emails/:id/prioritize — AI-prioritize email returning urgency score and category classification.',
    type: 'API',
    code: 'POST /api/v1/emails/:id/prioritize',
    tags: ['email', 'ai', 'prioritization'],
    method: 'POST',
    endpoint: '/api/v1/emails/:id/prioritize',
  },
  {
    id: 'cap-qt-2-2',
    stepId: 'qt-step-2',
    systemId: 'qtrack',
    name: 'AI Priority Engine',
    description: 'Feature that analyzes email urgency using sentiment, content analysis, and sender importance scoring.',
    type: 'Feature',
    tags: ['ai', 'priority', 'scoring'],
  },
  {
    id: 'cap-qt-2-3',
    stepId: 'qt-step-2',
    systemId: 'qtrack',
    name: 'Update Email Status API',
    description: 'PUT /api/v1/emails/:id/status — Update email status (unread/read/resolved) after prioritization.',
    type: 'API',
    code: 'PUT /api/v1/emails/:id/status',
    tags: ['email', 'status', 'update'],
    method: 'PUT',
    endpoint: '/api/v1/emails/:id/status',
  },
  // QTrack — Step 3: Summarize Email Content
  {
    id: 'cap-qt-3-1',
    stepId: 'qt-step-3',
    systemId: 'qtrack',
    name: 'Summarize Email API',
    description: 'POST /api/v1/emails/:id/summarize — Generate AI summary of email thread with key points and action items.',
    type: 'API',
    code: 'POST /api/v1/emails/:id/summarize',
    tags: ['email', 'summarization', 'ai'],
    method: 'POST',
    endpoint: '/api/v1/emails/:id/summarize',
  },
  {
    id: 'cap-qt-3-2',
    stepId: 'qt-step-3',
    systemId: 'qtrack',
    name: 'Translation API',
    description: 'POST /api/v1/emails/:id/translate — Translate email content to target language for global teams.',
    type: 'API',
    code: 'POST /api/v1/emails/:id/translate',
    tags: ['email', 'translation', 'global'],
    method: 'POST',
    endpoint: '/api/v1/emails/:id/translate',
  },
  // SWB — Step 1: Extract PDF Information
  {
    id: 'cap-swb-1-1',
    stepId: 'swb-step-1',
    systemId: 'swb',
    name: 'Extract PDF API',
    description: 'POST /api/v1/extract/pdf — Extract structured information from PDF documents including entities, tables, and metadata.',
    type: 'API',
    code: 'POST /api/v1/extract/pdf',
    tags: ['extraction', 'pdf', 'entities'],
    method: 'POST',
    endpoint: '/api/v1/extract/pdf',
  },
  {
    id: 'cap-swb-1-2',
    stepId: 'swb-step-1',
    systemId: 'swb',
    name: 'PDF Entity Recognition',
    description: 'Feature that identifies named entities in PDFs — names, dates, amounts, addresses, invoice numbers.',
    type: 'Feature',
    tags: ['pdf', 'entities', 'recognition'],
  },
  {
    id: 'cap-swb-1-3',
    stepId: 'swb-step-1',
    systemId: 'swb',
    name: 'Table Extraction Engine',
    description: 'Feature that extracts tables from PDF documents with cell-level accuracy and structure preservation.',
    type: 'Feature',
    tags: ['pdf', 'tables', 'extraction'],
  },
  // SWB — Step 2: Extract Email Information
  {
    id: 'cap-swb-2-1',
    stepId: 'swb-step-2',
    systemId: 'swb',
    name: 'Extract Email API',
    description: 'POST /api/v1/extract/email — Extract structured information from email content and attachments.',
    type: 'API',
    code: 'POST /api/v1/extract/email',
    tags: ['extraction', 'email', 'content'],
    method: 'POST',
    endpoint: '/api/v1/extract/email',
  },
  {
    id: 'cap-swb-2-2',
    stepId: 'swb-step-2',
    systemId: 'swb',
    name: 'Email Content Parser',
    description: 'Feature that parses email body text, headers, and metadata to identify key data fields and entities.',
    type: 'Feature',
    tags: ['email', 'parsing', 'content'],
  },
  {
    id: 'cap-swb-2-3',
    stepId: 'swb-step-2',
    systemId: 'swb',
    name: 'Attachment Processing',
    description: 'Feature that recursively processes email attachments (PDF, Excel) through extraction workflows.',
    type: 'Feature',
    tags: ['email', 'attachments', 'processing'],
  },
  // SWB — Step 3: Validate Extracted Data
  {
    id: 'cap-swb-3-1',
    stepId: 'swb-step-3',
    systemId: 'swb',
    name: 'Validate Extraction API',
    description: 'POST /api/v1/extraction/validate — Validate extracted data against schema with confidence scoring.',
    type: 'API',
    code: 'POST /api/v1/extraction/validate',
    tags: ['validation', 'extraction', 'schema'],
    method: 'POST',
    endpoint: '/api/v1/extraction/validate',
  },
  {
    id: 'cap-swb-3-2',
    stepId: 'swb-step-3',
    systemId: 'swb',
    name: 'Data Enrichment API',
    description: 'POST /api/v1/extraction/enrich — Enrich extracted data with external sources like vendor lookups and currency conversion.',
    type: 'API',
    code: 'POST /api/v1/extraction/enrich',
    tags: ['enrichment', 'data', 'external'],
    method: 'POST',
    endpoint: '/api/v1/extraction/enrich',
  },
  {
    id: 'cap-swb-3-3',
    stepId: 'swb-step-3',
    systemId: 'swb',
    name: 'Schema Matching Engine',
    description: 'Feature that matches extracted data fields to predefined schemas with automatic field mapping.',
    type: 'Feature',
    tags: ['schema', 'matching', 'mapping'],
  },
  // Transformer — Step 1: Transform Extracted Data
  {
    id: 'cap-tr-1-1',
    stepId: 'tr-step-1',
    systemId: 'transformer',
    name: 'Transform Excel API',
    description: 'POST /api/v1/transform/excel — Transform Excel data with extract, convert, and merge operations.',
    type: 'API',
    code: 'POST /api/v1/transform/excel',
    tags: ['excel', 'transform', 'data'],
    method: 'POST',
    endpoint: '/api/v1/transform/excel',
  },
  {
    id: 'cap-tr-1-2',
    stepId: 'tr-step-1',
    systemId: 'transformer',
    name: 'Transform PDF API',
    description: 'POST /api/v1/transform/pdf — Transform PDF document extracting text, tables, and converting formats.',
    type: 'API',
    code: 'POST /api/v1/transform/pdf',
    tags: ['pdf', 'transform', 'document'],
    method: 'POST',
    endpoint: '/api/v1/transform/pdf',
  },
  {
    id: 'cap-tr-1-3',
    stepId: 'tr-step-1',
    systemId: 'transformer',
    name: 'Data Format Converter',
    description: 'Feature that converts between data formats — JSON, CSV, Excel, structured text — with type preservation.',
    type: 'Feature',
    tags: ['conversion', 'format', 'data'],
  },
  // Transformer — Step 2: Recommend Transformation Template
  {
    id: 'cap-tr-2-1',
    stepId: 'tr-step-2',
    systemId: 'transformer',
    name: 'Recommend Workflow API',
    description: 'POST /api/v1/workflows/recommend — Get AI workflow recommendations for a transformation task.',
    type: 'API',
    code: 'POST /api/v1/workflows/recommend',
    tags: ['workflow', 'recommend', 'ai'],
    method: 'POST',
    endpoint: '/api/v1/workflows/recommend',
  },
  {
    id: 'cap-tr-2-2',
    stepId: 'tr-step-2',
    systemId: 'transformer',
    name: 'Template Matching API',
    description: 'POST /api/v1/templates/match — Find matching templates for input extracted data.',
    type: 'API',
    code: 'POST /api/v1/templates/match',
    tags: ['template', 'matching', 'recommendation'],
    method: 'POST',
    endpoint: '/api/v1/templates/match',
  },
  {
    id: 'cap-tr-2-3',
    stepId: 'tr-step-2',
    systemId: 'transformer',
    name: 'List Workflows API',
    description: 'GET /api/v1/workflows — List available transformation workflows filtered by document type.',
    type: 'API',
    code: 'GET /api/v1/workflows',
    tags: ['workflow', 'list', 'catalog'],
    method: 'GET',
    endpoint: '/api/v1/workflows',
  },
  // Transformer — Step 3: Batch Process Documents
  {
    id: 'cap-tr-3-1',
    stepId: 'tr-step-3',
    systemId: 'transformer',
    name: 'Batch Transform API',
    description: 'POST /api/v1/transform/batch — Batch process multiple documents with parallel execution.',
    type: 'API',
    code: 'POST /api/v1/transform/batch',
    tags: ['batch', 'transform', 'documents'],
    method: 'POST',
    endpoint: '/api/v1/transform/batch',
  },
  {
    id: 'cap-tr-3-2',
    stepId: 'tr-step-3',
    systemId: 'transformer',
    name: 'Batch Job Status API',
    description: 'GET /api/v1/transform/jobs/:id — Get transformation job status and progress tracking.',
    type: 'API',
    code: 'GET /api/v1/transform/jobs/:id',
    tags: ['batch', 'status', 'monitoring'],
    method: 'GET',
    endpoint: '/api/v1/transform/jobs/:id',
  },
  {
    id: 'cap-tr-3-3',
    stepId: 'tr-step-3',
    systemId: 'transformer',
    name: 'Generate Workflow API',
    description: 'POST /api/v1/workflows/generate — Auto-generate a workflow from transformation requirements.',
    type: 'API',
    code: 'POST /api/v1/workflows/generate',
    tags: ['workflow', 'generate', 'auto'],
    method: 'POST',
    endpoint: '/api/v1/workflows/generate',
  },
  // SIRE — Step 1: Reconcile Trade Data
  {
    id: 'cap-sr-1-1',
    stepId: 'sr-step-1',
    systemId: 'sire',
    name: 'GET /api/v1/reconcile/trades',
    description: 'Execute Trade Reconciliation — List trade reconciliation jobs with status and results.',
    type: 'API',
    code: 'GET /api/v1/reconcile/trades',
    tags: ['trade', 'reconciliation', 'list'],
    method: 'GET',
    endpoint: '/api/v1/reconcile/trades',
  },
  {
    id: 'cap-sr-1-2',
    stepId: 'sr-step-1',
    systemId: 'sire',
    name: 'POST /api/v1/reconcile/trades',
    description: 'Submit Trade Matching Job — Execute trade matching between front and back office systems.',
    type: 'API',
    code: 'POST /api/v1/reconcile/trades',
    tags: ['trade', 'reconciliation', 'matching'],
    method: 'POST',
    endpoint: '/api/v1/reconcile/trades',
  },
  {
    id: 'cap-sr-1-3',
    stepId: 'sr-step-1',
    systemId: 'sire',
    name: 'POST /api/v1/reconcile/positions',
    description: 'Execute Position Reconciliation — Compare positions across multiple systems and books.',
    type: 'API',
    code: 'POST /api/v1/reconcile/positions',
    tags: ['positions', 'reconciliation'],
    method: 'POST',
    endpoint: '/api/v1/reconcile/positions',
  },
  // SIRE — Step 2: Match Payment Instructions
  {
    id: 'cap-sr-2-1',
    stepId: 'sr-step-2',
    systemId: 'sire',
    name: 'POST /api/v1/reconcile/settlements',
    description: 'Run Settlement Reconciliation — Compare settlement instructions with actual settlements.',
    type: 'API',
    code: 'POST /api/v1/reconcile/settlements',
    tags: ['settlement', 'reconciliation'],
    method: 'POST',
    endpoint: '/api/v1/reconcile/settlements',
  },
  {
    id: 'cap-sr-2-2',
    stepId: 'sr-step-2',
    systemId: 'sire',
    name: 'POST /api/v1/reconcile/payments',
    description: 'Run Payment Reconciliation — Match payment instructions against actual settlements.',
    type: 'API',
    code: 'POST /api/v1/reconcile/payments',
    tags: ['payment', 'reconciliation'],
    method: 'POST',
    endpoint: '/api/v1/reconcile/payments',
  },
  {
    id: 'cap-sr-2-3',
    stepId: 'sr-step-2',
    systemId: 'sire',
    name: 'GET /api/v1/reconcile/status',
    description: 'Get Reconciliation Status — Overall platform status including pending jobs and open breaks.',
    type: 'API',
    code: 'GET /api/v1/reconcile/status',
    tags: ['status', 'overview'],
    method: 'GET',
    endpoint: '/api/v1/reconcile/status',
  },
  // SIRE — Step 3: Identify and Categorize Breaks
  {
    id: 'cap-sr-3-1',
    stepId: 'sr-step-3',
    systemId: 'sire',
    name: 'GET /api/v1/breaks',
    description: 'List All Reconciliation Breaks — Paginated list with filtering by type, severity, and status.',
    type: 'API',
    code: 'GET /api/v1/breaks',
    tags: ['breaks', 'exceptions', 'list'],
    method: 'GET',
    endpoint: '/api/v1/breaks',
  },
  {
    id: 'cap-sr-3-2',
    stepId: 'sr-step-3',
    systemId: 'sire',
    name: 'PUT /api/v1/breaks/:id/resolve',
    description: 'Resolve Break Item — Resolve a break by ID with match, override, escalate, or manual actions.',
    type: 'API',
    code: 'PUT /api/v1/breaks/:id/resolve',
    tags: ['breaks', 'resolve'],
    method: 'PUT',
    endpoint: '/api/v1/breaks/:id/resolve',
  },
  {
    id: 'cap-sr-3-3',
    stepId: 'sr-step-3',
    systemId: 'sire',
    name: 'Break Categorization Engine',
    description: 'Feature that categorizes breaks by type (trade mismatch, settlement failure, payment discrepancy) and severity.',
    type: 'Feature',
    tags: ['breaks', 'categorization', 'routing'],
  },
  // SIRE — Step 4: Generate Exception Report
  {
    id: 'cap-sr-4-1',
    stepId: 'sr-step-4',
    systemId: 'sire',
    name: 'Exception Report Generator',
    description: 'Feature that generates comprehensive exception reports with break summaries, aging analysis, and match rate statistics.',
    type: 'Feature',
    tags: ['exceptions', 'reporting', 'analytics'],
  },
  {
    id: 'cap-sr-4-2',
    stepId: 'sr-step-4',
    systemId: 'sire',
    name: 'Reconciliation Dashboard',
    description: 'Feature providing real-time dashboard with reconciliation KPIs, break trends, and resolution metrics.',
    type: 'Feature',
    tags: ['dashboard', 'kpi', 'monitoring'],
  },
  {
    id: 'cap-sr-4-3',
    stepId: 'sr-step-4',
    systemId: 'sire',
    name: 'Break Aging Analyzer',
    description: 'Feature that analyzes break aging and triggers escalation for items exceeding SLA thresholds.',
    type: 'Feature',
    tags: ['breaks', 'aging', 'sla'],
  },
  // SIRE — Step 5: Route Breaks for Resolution
  {
    id: 'cap-sr-5-1',
    stepId: 'sr-step-5',
    systemId: 'sire',
    name: 'Break Routing Engine',
    description: 'Feature that routes breaks to operations teams based on type, severity, and SLA requirements.',
    type: 'Feature',
    tags: ['breaks', 'routing', 'workflow'],
  },
  {
    id: 'cap-sr-5-2',
    stepId: 'sr-step-5',
    systemId: 'sire',
    name: 'Escalation Manager',
    description: 'Feature that escalates critical breaks and overdue items to senior operations staff.',
    type: 'Feature',
    tags: ['escalation', 'sla', 'alerts'],
  },
  {
    id: 'cap-sr-5-3',
    stepId: 'sr-step-5',
    systemId: 'sire',
    name: 'Resolution Workflow API',
    description: 'PUT /api/v1/breaks/:id/resolve — Resolve breaks with automated matching or manual intervention.',
    type: 'API',
    code: 'PUT /api/v1/breaks/:id/resolve',
    tags: ['breaks', 'resolve', 'workflow'],
    method: 'PUT',
    endpoint: '/api/v1/breaks/:id/resolve',
  },
  // OPAS — Step 1: Retrieve Historical Payment Records
  {
    id: 'cap-op-1-1',
    stepId: 'op-step-1',
    systemId: 'opas',
    name: 'GET /api/v1/settlements',
    description: 'List Settlement — Retrieve all settlement records with filtering by date, status, and counterparty.',
    type: 'API',
    code: 'GET /api/v1/settlements',
    tags: ['settlement', 'list', 'query'],
    method: 'GET',
    endpoint: '/api/v1/settlements',
  },
  {
    id: 'cap-op-1-2',
    stepId: 'op-step-1',
    systemId: 'opas',
    name: 'GET /api/v1/settlements/:id',
    description: 'Get Settlement — Retrieve a specific settlement record by ID with full details.',
    type: 'API',
    code: 'GET /api/v1/settlements/:id',
    tags: ['settlement', 'get', 'detail'],
    method: 'GET',
    endpoint: '/api/v1/settlements/:id',
  },
  {
    id: 'cap-op-1-3',
    stepId: 'op-step-1',
    systemId: 'opas',
    name: 'POST /api/v1/settlements',
    description: 'Set Settlement — Create or update a settlement record with instruction data.',
    type: 'API',
    code: 'POST /api/v1/settlements',
    tags: ['settlement', 'create', 'update'],
    method: 'POST',
    endpoint: '/api/v1/settlements',
  },
  // OPAS — Step 2: Retrieve Settlement and Payment History
  {
    id: 'cap-op-2-1',
    stepId: 'op-step-2',
    systemId: 'opas',
    name: 'GET /api/v1/payments',
    description: 'List Payment — Retrieve all payment records with filtering by date, status, and amount.',
    type: 'API',
    code: 'GET /api/v1/payments',
    tags: ['payment', 'list', 'query'],
    method: 'GET',
    endpoint: '/api/v1/payments',
  },
  {
    id: 'cap-op-2-2',
    stepId: 'op-step-2',
    systemId: 'opas',
    name: 'GET /api/v1/payments/:id',
    description: 'Get Payment — Retrieve a specific payment record by ID with full transaction details.',
    type: 'API',
    code: 'GET /api/v1/payments/:id',
    tags: ['payment', 'get', 'detail'],
    method: 'GET',
    endpoint: '/api/v1/payments/:id',
  },
  {
    id: 'cap-op-2-3',
    stepId: 'op-step-2',
    systemId: 'opas',
    name: 'POST /api/v1/payments',
    description: 'Set Payment — Create or update a payment record with instruction and settlement data.',
    type: 'API',
    code: 'POST /api/v1/payments',
    tags: ['payment', 'create', 'update'],
    method: 'POST',
    endpoint: '/api/v1/payments',
  },
  // OPAS — Step 3: Store Extracted Payment Details
  {
    id: 'cap-op-3-1',
    stepId: 'op-step-3',
    systemId: 'opas',
    name: 'POST /api/v1/payments/batch',
    description: 'Batch Store Payments — Store multiple payment records extracted from documents in a single batch operation.',
    type: 'API',
    code: 'POST /api/v1/payments/batch',
    tags: ['payment', 'batch', 'store'],
    method: 'POST',
    endpoint: '/api/v1/payments/batch',
  },
  // OPAS — Step 4: Update Payment Status
  {
    id: 'cap-op-4-1',
    stepId: 'op-step-4',
    systemId: 'opas',
    name: 'PUT /api/v1/payments/:id/status',
    description: 'Update Payment Status — Change payment status (pending, processed, failed, reconciled).',
    type: 'API',
    code: 'PUT /api/v1/payments/:id/status',
    tags: ['payment', 'status', 'update'],
    method: 'PUT',
    endpoint: '/api/v1/payments/:id/status',
  },
  // OPAS — Step 5: Store Reconciliation Results
  {
    id: 'cap-op-5-1',
    stepId: 'op-step-5',
    systemId: 'opas',
    name: 'POST /api/v1/reconciliation-results',
    description: 'Store Reconciliation Results — Save reconciliation output including match status, breaks, and adjustments.',
    type: 'API',
    code: 'POST /api/v1/reconciliation-results',
    tags: ['reconciliation', 'results', 'store'],
    method: 'POST',
    endpoint: '/api/v1/reconciliation-results',
  },
  // GoldenEye — Step 1: Load Trade Positions
  {
    id: 'cap-ge-1-1',
    stepId: 'ge-step-1',
    systemId: 'goldeneye',
    name: 'GET /api/v1/trades',
    description: 'List Trade Info — Retrieve all trade records with filtering by date, instrument, counterparty, and status.',
    type: 'API',
    code: 'GET /api/v1/trades',
    tags: ['trade', 'list', 'query'],
    method: 'GET',
    endpoint: '/api/v1/trades',
  },
  {
    id: 'cap-ge-1-2',
    stepId: 'ge-step-1',
    systemId: 'goldeneye',
    name: 'GET /api/v1/trades/:id',
    description: 'Get Trade Info — Retrieve a specific trade record by ID with full lifecycle details.',
    type: 'API',
    code: 'GET /api/v1/trades/:id',
    tags: ['trade', 'get', 'detail'],
    method: 'GET',
    endpoint: '/api/v1/trades/:id',
  },
  {
    id: 'cap-ge-1-3',
    stepId: 'ge-step-1',
    systemId: 'goldeneye',
    name: 'POST /api/v1/trades',
    description: 'Set Trade Info — Create or update a trade record with execution, booking, and allocation data.',
    type: 'API',
    code: 'POST /api/v1/trades',
    tags: ['trade', 'create', 'update'],
    method: 'POST',
    endpoint: '/api/v1/trades',
  },
  // GoldenEye — Step 2: Get Trade History
  {
    id: 'cap-ge-2-1',
    stepId: 'ge-step-2',
    systemId: 'goldeneye',
    name: 'GET /api/v1/trades/history',
    description: 'List Trade History — Retrieve historical trade data with time-series filtering and audit trail.',
    type: 'API',
    code: 'GET /api/v1/trades/history',
    tags: ['trade', 'history', 'audit'],
    method: 'GET',
    endpoint: '/api/v1/trades/history',
  },
  {
    id: 'cap-ge-2-2',
    stepId: 'ge-step-2',
    systemId: 'goldeneye',
    name: 'GET /api/v1/trades/positions',
    description: 'Get Trade Positions — Retrieve current position data aggregated by book, instrument, and counterparty.',
    type: 'API',
    code: 'GET /api/v1/trades/positions',
    tags: ['trade', 'positions', 'aggregation'],
    method: 'GET',
    endpoint: '/api/v1/trades/positions',
  },
  {
    id: 'cap-ge-2-3',
    stepId: 'ge-step-2',
    systemId: 'goldeneye',
    name: 'POST /api/v1/trades/lifecycle',
    description: 'Set Trade Lifecycle — Record a lifecycle event (executed, booked, affirmed, settled) for a trade.',
    type: 'API',
    code: 'POST /api/v1/trades/lifecycle',
    tags: ['trade', 'lifecycle', 'event'],
    method: 'POST',
    endpoint: '/api/v1/trades/lifecycle',
  },
];

// ─── Helpers ────────────────────────────────────────────────────────

export function getSystemById(id: string): System | undefined {
  return systems.find((s) => s.id === id);
}

export function getStepsBySystemId(systemId: string): Step[] {
  return steps.filter((s) => s.systemId === systemId);
}

export function getStepById(id: string): Step | undefined {
  return steps.find((s) => s.id === id);
}

export function getCapabilitiesByStepId(stepId: string): Capability[] {
  return capabilities.filter((c) => c.stepId === stepId);
}

export function getCapabilityById(id: string): Capability | undefined {
  return capabilities.find((c) => c.id === id);
}

// ─── Layer 1 edges (system-to-system connections) ───────────────────

interface SystemEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
}

export const systemEdges: SystemEdge[] = [
  { id: 'e-qtrack-swb', source: 'qtrack', target: 'swb', label: 'email + attachments' },
  { id: 'e-swb-transformer', source: 'swb', target: 'transformer', label: 'extracted data' },
  { id: 'e-transformer-opas', source: 'transformer', target: 'opas', label: 'transformed output' },
  { id: 'e-opas-sire', source: 'opas', target: 'sire', label: 'payment records for reconcile' },
  { id: 'e-sire-opas', source: 'sire', target: 'opas', label: 'reconciliation results' },
  { id: 'e-swb-opas', source: 'swb', target: 'opas', label: 'extraction results' },
  { id: 'e-qtrack-opas', source: 'qtrack', target: 'opas', label: 'email metadata' },
  { id: 'e-goldeneye-sire', source: 'goldeneye', target: 'sire', label: 'trade records for reconcile' },
  { id: 'e-goldeneye-opas', source: 'goldeneye', target: 'opas', label: 'trade position data' },
];

// Per-workflow canvas views — each shows only relevant systems
export const workflowViews: Record<string, { nodeIds: string[]; edgeIds: string[]; title: string }> = {
  invoice: {
    title: 'Invoice Processing Automation',
    // QTrack → SWB → Transformer ──┐
    //                                ├──→ SIRE → OPAS
    // QTrack → OPAS ────────────────┘
    nodeIds: ['qtrack', 'swb', 'transformer', 'opas', 'sire'],
    edgeIds: ['e-qtrack-swb', 'e-swb-transformer', 'e-transformer-opas', 'e-opas-sire'],
  },
  trade: {
    title: 'Trade Settlement Reconciliation',
    // GoldenEye ───┐
    //              ├──→ SIRE → OPAS
    // OPAS ────────┘
    nodeIds: ['goldeneye', 'opas', 'sire'],
    edgeIds: ['e-goldeneye-sire', 'e-opas-sire'],
  },
  payment: {
    title: 'Payment Confirmation Reconciliation',
    nodeIds: ['qtrack', 'swb', 'opas', 'sire'],
    edgeIds: ['e-qtrack-swb', 'e-swb-opas', 'e-opas-sire'],
  },
  contract: {
    title: 'Contract Settlement Review',
    nodeIds: ['qtrack', 'swb', 'transformer', 'opas', 'sire'],
    edgeIds: ['e-qtrack-swb', 'e-swb-transformer', 'e-transformer-opas', 'e-opas-sire'],
  },
};
