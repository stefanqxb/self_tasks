import { memo } from 'react';
import { X, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import type { System, Step, Capability } from './data';

type InfoPanelProps = {
  isOpen: boolean;
  onClose: () => void;
  selectedSystem: System | null;
  selectedStep: Step | null;
  selectedCapability: Capability | null;
};

const panelVariants = {
  closed: { x: 360, opacity: 0 },
  open: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  },
};

const contentVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.3 },
  }),
};

const InfoPanel = memo(function InfoPanel({
  isOpen,
  onClose,
  selectedSystem,
  selectedStep,
  selectedCapability,
}: InfoPanelProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="absolute right-0 top-0 z-30 flex h-full flex-col border-l border-[#334155]"
          style={{
            width: 360,
            backgroundColor: 'rgba(30, 41, 59, 0.95)',
            backdropFilter: 'blur(16px)',
          }}
          variants={panelVariants}
          initial="closed"
          animate="open"
          exit="closed"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#334155] px-4 py-3">
            <h3 className="text-[15px] font-semibold text-[#E2E8F0]">
              {selectedCapability
                ? `API: ${selectedCapability.name}`
                : selectedStep
                ? `Step: ${selectedStep.name}`
                : selectedSystem
                ? `${selectedSystem.name} Details`
                : 'Details'}
            </h3>
            <button
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-lg text-[#94A3B8] transition-colors hover:bg-[#334155] hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* System Info */}
            {selectedSystem && !selectedStep && (
              <>
                <motion.div custom={0} variants={contentVariants} initial="hidden" animate="visible">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="h-3 w-3 rounded-full" style={{ backgroundColor: selectedSystem.color }} />
                    <span className="text-sm font-medium" style={{ color: selectedSystem.color }}>
                      {selectedSystem.name}
                    </span>
                  </div>
                  <p className="text-xs text-[#94A3B8] leading-relaxed">{selectedSystem.description}</p>
                </motion.div>

                <motion.div custom={1} variants={contentVariants} initial="hidden" animate="visible">
                  <div className="grid grid-cols-3 gap-2">
                    {selectedSystem.stats.map((s) => (
                      <div
                        key={s.label}
                        className="flex flex-col items-center rounded-lg py-2"
                        style={{ backgroundColor: 'rgba(15, 23, 42, 0.5)' }}
                      >
                        <span className="text-lg font-bold text-white">{s.value}</span>
                        <span className="text-[10px] text-[#64748B]">{s.label}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>

                <motion.div custom={2} variants={contentVariants} initial="hidden" animate="visible">
                  <div className="flex items-center gap-1 text-xs text-[#818CF8] cursor-pointer hover:underline">
                    <span>View in Knowledge Layer</span>
                    <ArrowRight className="h-3 w-3" />
                  </div>
                </motion.div>

                <motion.div custom={3} variants={contentVariants} initial="hidden" animate="visible">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-2">Recent Files</h4>
                  <div className="space-y-1.5">
                    {['config.yaml', 'schema.json', 'workflow.bpmn'].map((f) => (
                      <div
                        key={f}
                        className="flex items-center gap-2 rounded-md px-2 py-1.5 text-xs text-[#94A3B8]"
                        style={{ backgroundColor: 'rgba(15, 23, 42, 0.3)' }}
                      >
                        <span className="font-mono">{f}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>

                <motion.div custom={4} variants={contentVariants} initial="hidden" animate="visible">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-2">Steps ({selectedSystem.stats[0].value})</h4>
                  <div className="space-y-1.5">
                    {selectedSystem.stats[0] && Array.from({ length: Math.min(selectedSystem.stats[0].value, 4) }).map((_, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-2 rounded-md px-2 py-1.5"
                        style={{ backgroundColor: 'rgba(15, 23, 42, 0.3)' }}
                      >
                        <div
                          className="flex h-4 w-4 items-center justify-center rounded-full text-[9px] font-bold text-white"
                          style={{ backgroundColor: selectedSystem.color }}
                        >
                          {i + 1}
                        </div>
                        <span className="text-xs text-[#CBD5E1]">Step {i + 1}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              </>
            )}

            {/* Step Info */}
            {selectedStep && (
              <>
                <motion.div custom={0} variants={contentVariants} initial="hidden" animate="visible">
                  <div className="flex items-center gap-2 mb-2">
                    <div
                      className="flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-bold text-white"
                      style={{ backgroundColor: selectedSystem?.color || '#6366F1' }}
                    >
                      {selectedStep.number}
                    </div>
                    <span className="text-sm font-semibold text-white">{selectedStep.name}</span>
                  </div>
                </motion.div>

                <motion.div custom={1} variants={contentVariants} initial="hidden" animate="visible">
                  <div className="rounded-md px-2 py-1 text-[11px] text-[#64748B]" style={{ backgroundColor: 'rgba(15, 23, 42, 0.3)' }}>
                    From {selectedStep.requirement}
                  </div>
                </motion.div>

                <motion.div custom={2} variants={contentVariants} initial="hidden" animate="visible">
                  <p className="text-xs text-[#94A3B8] leading-relaxed">{selectedStep.description}</p>
                </motion.div>

                <motion.div custom={3} variants={contentVariants} initial="hidden" animate="visible">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-2">Status</h4>
                  <div className="flex items-center gap-2">
                    <div
                      className="h-2 w-2 rounded-full"
                      style={{
                        backgroundColor:
                          selectedStep.status === 'completed'
                            ? '#22C55E'
                            : selectedStep.status === 'active'
                            ? '#F59E0B'
                            : '#64748B',
                      }}
                    />
                    <span
                      className="text-xs font-medium capitalize"
                      style={{
                        color:
                          selectedStep.status === 'completed'
                            ? '#22C55E'
                            : selectedStep.status === 'active'
                            ? '#F59E0B'
                            : '#64748B',
                      }}
                    >
                      {selectedStep.status}
                    </span>
                  </div>
                </motion.div>

                <motion.div custom={4} variants={contentVariants} initial="hidden" animate="visible">
                  <div className="flex items-center gap-1 text-xs text-[#818CF8] cursor-pointer hover:underline">
                    <span>View Full Analysis</span>
                    <ArrowRight className="h-3 w-3" />
                  </div>
                </motion.div>
              </>
            )}

            {/* Capability Info */}
            {selectedCapability && (
              <>
                <motion.div custom={0} variants={contentVariants} initial="hidden" animate="visible">
                  <div
                    className="inline-block rounded-md px-2 py-0.5 text-[11px] font-semibold mb-2"
                    style={{
                      backgroundColor:
                        selectedCapability.type === 'API'
                          ? 'rgba(99,102,241,0.15)'
                          : selectedCapability.type === 'Feature'
                          ? 'rgba(20,184,166,0.15)'
                          : 'rgba(245,158,11,0.15)',
                      color:
                        selectedCapability.type === 'API'
                          ? '#6366F1'
                          : selectedCapability.type === 'Feature'
                          ? '#14B8A6'
                          : '#F59E0B',
                    }}
                  >
                    {selectedCapability.type}
                  </div>
                  <h4 className="text-sm font-semibold text-white">{selectedCapability.name}</h4>
                </motion.div>

                <motion.div custom={1} variants={contentVariants} initial="hidden" animate="visible">
                  <p className="text-xs text-[#94A3B8] leading-relaxed">{selectedCapability.description}</p>
                </motion.div>

                {selectedCapability.method && selectedCapability.endpoint && (
                  <motion.div custom={2} variants={contentVariants} initial="hidden" animate="visible">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1">Endpoint</h4>
                    <div className="flex items-center gap-2 rounded-md px-3 py-2" style={{ backgroundColor: '#0F172A' }}>
                      <span
                        className="rounded px-1.5 py-0.5 text-[10px] font-bold"
                        style={{
                          backgroundColor:
                            selectedCapability.method === 'GET'
                              ? 'rgba(59,130,246,0.2)'
                              : selectedCapability.method === 'POST'
                              ? 'rgba(34,197,94,0.2)'
                              : selectedCapability.method === 'PUT'
                              ? 'rgba(245,158,11,0.2)'
                              : 'rgba(239,68,68,0.2)',
                          color:
                            selectedCapability.method === 'GET'
                              ? '#3B82F6'
                              : selectedCapability.method === 'POST'
                              ? '#22C55E'
                              : selectedCapability.method === 'PUT'
                              ? '#F59E0B'
                              : '#EF4444',
                        }}
                      >
                        {selectedCapability.method}
                      </span>
                      <span className="font-mono text-[11px] text-[#CBD5E1]">{selectedCapability.endpoint}</span>
                    </div>
                  </motion.div>
                )}

                {selectedCapability.code && (
                  <motion.div custom={3} variants={contentVariants} initial="hidden" animate="visible">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1">Request</h4>
                    <pre className="overflow-x-auto rounded-md p-3 font-mono text-[11px] text-[#CBD5E1]" style={{ backgroundColor: '#0F172A' }}>
                      {selectedCapability.code}
                    </pre>
                  </motion.div>
                )}

                <motion.div custom={4} variants={contentVariants} initial="hidden" animate="visible">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-[#64748B] mb-1">Tags</h4>
                  <div className="flex flex-wrap gap-1">
                    {selectedCapability.tags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-full px-2 py-0.5 text-[10px] text-[#64748B]"
                        style={{ backgroundColor: 'rgba(51, 65, 85, 0.4)' }}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </motion.div>

                <motion.div custom={5} variants={contentVariants} initial="hidden" animate="visible">
                  <div className="flex items-center gap-1 text-xs text-[#818CF8] cursor-pointer hover:underline">
                    <span>View in Knowledge Layer</span>
                    <ArrowRight className="h-3 w-3" />
                  </div>
                </motion.div>
              </>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
});

export default InfoPanel;
