import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import type { NodeProps } from '@xyflow/react';
import type { Step } from '../data';

interface StepNodeData {
  step: Step;
  systemColor: string;
  onSelect?: (stepId: string) => void;
}

const StepNode = memo(function StepNode(props: NodeProps) {
  const data = props.data as unknown as StepNodeData;
  const { step, systemColor, onSelect } = data;

  const statusColors: Record<string, string> = {
    completed: '#22C55E',
    active: systemColor,
    pending: '#64748B',
  };

  const statusColor = statusColors[step.status] || '#64748B';

  return (
    <div
      className="group cursor-pointer"
      onClick={() => onSelect?.(step.id)}
    >
      <div
        className="flex items-center gap-2 rounded-[24px] px-4 py-2.5 transition-all duration-150 min-w-[160px]"
        style={{
          backgroundColor: 'rgba(30, 41, 59, 0.8)',
          border: `1px solid ${statusColor}66`,
          backdropFilter: 'blur(12px)',
        }}
      >
        {/* Step number badge */}
        <div
          className="flex h-5 w-5 flex-shrink-0 items-center justify-center rounded-full text-[11px] font-bold text-white"
          style={{ backgroundColor: systemColor }}
        >
          {step.number}
        </div>

        {/* Step name */}
        <span className="truncate text-[13px] font-medium" style={{ color: '#E2E8F0' }}>
          {step.name}
        </span>

        {/* Status dot */}
        <div
          className="ml-1 h-1.5 w-1.5 flex-shrink-0 rounded-full"
          style={{ backgroundColor: statusColor }}
        />
      </div>

      {/* Hover glow */}
      <div
        className="pointer-events-none absolute inset-0 rounded-[24px] opacity-0 transition-opacity duration-150 group-hover:opacity-100"
        style={{ boxShadow: `0 0 16px ${systemColor}30` }}
      />

      <Handle type="target" position={Position.Top} className="!bg-transparent !border-0" />
      <Handle type="source" position={Position.Bottom} className="!bg-transparent !border-0" />
    </div>
  );
});

export default StepNode;
