import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import type { NodeProps } from '@xyflow/react';
import {
  Activity,
  RefreshCw,
  Workflow,
  FileCheck,
  Database,
} from 'lucide-react';
import type { System } from '../data';

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties; strokeWidth?: number }>> = {
  Activity,
  RefreshCw,
  Workflow,
  FileCheck,
  Database,
};

interface SystemNodeData {
  system: System;
  stepCount: number;
  isSelected?: boolean;
  onSelect?: (systemId: string) => void;
}

const SystemNode = memo(function SystemNode(props: NodeProps) {
  const data = props.data as unknown as SystemNodeData;
  const { system, stepCount, isSelected, onSelect } = data;
  const Icon = iconMap[system.icon] || Activity;

  return (
    <div
      className="group cursor-pointer"
      onClick={() => onSelect?.(system.id)}
    >
      <div
        className="relative flex flex-col items-center justify-center gap-1.5 rounded-[16px] p-4 transition-all duration-200"
        style={{
          width: isSelected ? 220 : 180,
          height: isSelected ? 120 : 100,
          backgroundColor: `${system.color}14`,
          border: `${isSelected ? '2px' : '1px'} solid ${isSelected ? system.color : `${system.color}80`}`,
          boxShadow: isSelected
            ? `0 0 0 3px ${system.color}26, 0 4px 20px ${system.color}26`
            : `0 4px 20px ${system.color}26`,
          backdropFilter: 'blur(8px)',
        }}
      >
        {/* Left accent bar */}
        {isSelected && (
          <div
            className="absolute left-0 top-3 bottom-3 rounded-r-full"
            style={{ width: 3, backgroundColor: system.color }}
          />
        )}

        <Icon className="h-6 w-6" style={{ color: system.color }} strokeWidth={1.5} />
        <span className="text-sm font-semibold text-white">{system.name}</span>

        {/* Step count badge */}
        <div
          className="absolute -bottom-2 -right-2 rounded-full px-2 py-0.5 text-[11px] font-medium"
          style={{
            backgroundColor: `${system.color}33`,
            color: system.color,
          }}
        >
          {stepCount} steps
        </div>

        {/* Hover glow ring */}
        <div
          className="pointer-events-none absolute inset-0 rounded-[16px] opacity-0 transition-opacity duration-200 group-hover:opacity-100"
          style={{ boxShadow: `0 0 24px ${system.color}40` }}
        />
      </div>

      {/* Handles */}
      <Handle type="target" position={Position.Top} className="!bg-transparent !border-0" />
      <Handle type="source" position={Position.Bottom} className="!bg-transparent !border-0" />
      <Handle type="target" position={Position.Left} className="!bg-transparent !border-0" />
      <Handle type="source" position={Position.Right} className="!bg-transparent !border-0" />
    </div>
  );
});

export default SystemNode;
