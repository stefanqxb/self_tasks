import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import { ExternalLink } from 'lucide-react';
import type { NodeProps } from '@xyflow/react';
import type { Capability } from '../data';

interface CapabilityNodeData {
  capability: Capability;
  systemColor: string;
  onSelect?: (capId: string) => void;
}

const typeColors: Record<string, string> = {
  API: '#6366F1',
  Feature: '#14B8A6',
  Config: '#F59E0B',
};

const CapabilityNode = memo(function CapabilityNode(props: NodeProps) {
  const data = props.data as unknown as CapabilityNodeData;
  const { capability, systemColor, onSelect } = data;
  const typeColor = typeColors[capability.type] || systemColor;

  return (
    <div
      className="group cursor-pointer"
      onClick={() => onSelect?.(capability.id)}
    >
      <div
        className="relative flex flex-col rounded-[12px] p-3 transition-all duration-200 w-[260px] min-h-[110px]"
        style={{
          backgroundColor: 'rgba(30, 41, 59, 0.6)',
          border: '1px solid rgba(51, 65, 85, 0.4)',
          borderLeft: `3px solid ${typeColor}`,
        }}
      >
        {/* Header row */}
        <div className="flex items-center justify-between">
          <div
            className="rounded-md px-2 py-0.5 text-[11px] font-semibold"
            style={{
              backgroundColor: `${typeColor}22`,
              color: typeColor,
            }}
          >
            {capability.type}
          </div>
          <ExternalLink className="h-3.5 w-3.5 text-[#64748B] transition-colors group-hover:text-[#94A3B8]" />
        </div>

        {/* Title */}
        <h4 className="mt-2 text-sm font-semibold text-[#E2E8F0]">{capability.name}</h4>

        {/* Description */}
        <p className="mt-1 line-clamp-3 text-xs text-[#94A3B8] leading-relaxed">
          {capability.description}
        </p>

        {/* Code snippet */}
        {capability.code && (
          <div
            className="mt-2 rounded-md px-2 py-1.5 font-mono text-[11px] text-[#CBD5E1]"
            style={{ backgroundColor: '#0F172A' }}
          >
            {capability.code}
          </div>
        )}

        {/* Tags */}
        <div className="mt-2 flex flex-wrap gap-1">
          {capability.tags.map((tag) => (
            <span
              key={tag}
              className="rounded-full px-1.5 py-0.5 text-[10px] text-[#64748B]"
              style={{ backgroundColor: 'rgba(51, 65, 85, 0.3)' }}
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-2 text-[11px] text-[#818CF8]">
          View in Knowledge &rarr;
        </div>

        {/* Hover overlay */}
        <div
          className="pointer-events-none absolute inset-0 rounded-[12px] opacity-0 transition-all duration-200 group-hover:opacity-100"
          style={{
            border: `1px solid ${systemColor}80`,
            boxShadow: '0 8px 24px rgba(0,0,0,0.3)',
            transform: 'translateY(-4px)',
          }}
        />
      </div>

      <Handle type="target" position={Position.Top} className="!bg-transparent !border-0" />
      <Handle type="source" position={Position.Bottom} className="!bg-transparent !border-0" />
    </div>
  );
});

export default CapabilityNode;
