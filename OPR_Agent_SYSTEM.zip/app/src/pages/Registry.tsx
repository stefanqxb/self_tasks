import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Globe,
  Users,
  Zap,
  Shield,
  Check,
  ChevronDown,
  Copy,
  Download,
  Terminal,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import Layout from '@/components/Layout';

// ── Types ───────────────────────────────────────────────────────────────────

interface EndpointParam {
  name: string;
  type: string;
  required: boolean;
  description: string;
}

interface Endpoint {
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  description: string;
  tags: string[];
  params: EndpointParam[];
  responseExample: string;
  curlExample: string;
  tsExample: string;
}

// ── Animation helpers ───────────────────────────────────────────────────────

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' as const } },
};

// ── Mock data ───────────────────────────────────────────────────────────────

const ENDPOINTS: Endpoint[] = [
  {
    method: 'GET',
    path: '/systems',
    description: 'List all registered systems with metadata',
    tags: ['systems', 'list'],
    params: [
      { name: 'page', type: 'number', required: false, description: 'Page number (default: 1)' },
      { name: 'limit', type: 'number', required: false, description: 'Items per page (default: 20)' },
      { name: 'search', type: 'string', required: false, description: 'Filter by system name' },
    ],
    responseExample: JSON.stringify(
      {
        data: [
          { id: 'sys-001', name: 'CRM', status: 'active', capabilities: 12 },
          { id: 'sys-002', name: 'ERP', status: 'active', capabilities: 8 },
        ],
        total: 2,
        page: 1,
        limit: 20,
      },
      null,
      2
    ),
    curlExample: `curl -X GET "https://api.opr.dev/v1/systems?page=1&limit=20" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Accept: application/json"`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst systems = await client.systems.list({\n  page: 1,\n  limit: 20,\n});\nconsole.log(systems.data);`,
  },
  {
    method: 'GET',
    path: '/systems/:id/capabilities',
    description: 'Get capabilities for a specific system',
    tags: ['capabilities', 'system'],
    params: [
      { name: 'id', type: 'string', required: true, description: 'System ID' },
      { name: 'includeDeprecated', type: 'boolean', required: false, description: 'Include deprecated capabilities' },
    ],
    responseExample: JSON.stringify(
      {
        systemId: 'sys-001',
        systemName: 'CRM',
        capabilities: [
          { id: 'cap-001', name: 'createContact', description: 'Create a new contact' },
          { id: 'cap-002', name: 'updateContact', description: 'Update existing contact' },
        ],
      },
      null,
      2
    ),
    curlExample: `curl -X GET "https://api.opr.dev/v1/systems/sys-001/capabilities" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Accept: application/json"`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst caps = await client.systems.getCapabilities('sys-001', {\n  includeDeprecated: false,\n});\nconsole.log(caps.capabilities);`,
  },
  {
    method: 'POST',
    path: '/match',
    description: 'Match systems to a business requirement (AI-powered)',
    tags: ['ai', 'matching'],
    params: [
      { name: 'requirement', type: 'string', required: true, description: 'Natural language requirement description' },
      { name: 'context', type: 'object', required: false, description: 'Additional business context' },
      { name: 'maxResults', type: 'number', required: false, description: 'Maximum results (default: 5)' },
    ],
    responseExample: JSON.stringify(
      {
        matches: [
          { system: 'CRM', capability: 'createContact', confidence: 0.95, reasoning: 'Direct match for contact creation' },
          { system: 'ERP', capability: 'createVendor', confidence: 0.72, reasoning: 'Similar vendor onboarding flow' },
        ],
        query: 'I need to add a new customer',
      },
      null,
      2
    ),
    curlExample: `curl -X POST "https://api.opr.dev/v1/match" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "requirement": "I need to add a new customer",\n    "maxResults": 5\n  }'`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst result = await client.match({\n  requirement: 'I need to add a new customer',\n  maxResults: 5,\n});\nconsole.log(result.matches);`,
  },
  {
    method: 'GET',
    path: '/capabilities',
    description: 'List all capabilities across systems',
    tags: ['capabilities', 'list'],
    params: [
      { name: 'systemId', type: 'string', required: false, description: 'Filter by system ID' },
      { name: 'search', type: 'string', required: false, description: 'Search by capability name' },
      { name: 'page', type: 'number', required: false, description: 'Page number (default: 1)' },
    ],
    responseExample: JSON.stringify(
      {
        data: [
          { id: 'cap-001', name: 'createContact', system: 'CRM', type: 'action' },
          { id: 'cap-002', name: 'getContact', system: 'CRM', type: 'query' },
          { id: 'cap-003', name: 'createInvoice', system: 'ERP', type: 'action' },
        ],
        total: 3,
        page: 1,
        limit: 20,
      },
      null,
      2
    ),
    curlExample: `curl -X GET "https://api.opr.dev/v1/capabilities?systemId=sys-001" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Accept: application/json"`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst caps = await client.capabilities.list({\n  systemId: 'sys-001',\n  page: 1,\n});\nconsole.log(caps.data);`,
  },
  {
    method: 'POST',
    path: '/workflows',
    description: 'Create a new workflow from a DAG definition',
    tags: ['workflows', 'create'],
    params: [
      { name: 'name', type: 'string', required: true, description: 'Workflow name' },
      { name: 'dag', type: 'object[]', required: true, description: 'DAG nodes array with step definitions' },
      { name: 'trigger', type: 'string', required: false, description: 'Trigger type: webhook | schedule | manual' },
    ],
    responseExample: JSON.stringify(
      {
        workflowId: 'wf-001',
        name: 'Customer Onboarding',
        status: 'created',
        steps: 3,
        url: 'https://api.opr.dev/v1/workflows/wf-001',
      },
      null,
      2
    ),
    curlExample: `curl -X POST "https://api.opr.dev/v1/workflows" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "name": "Customer Onboarding",\n    "dag": [\n      { "id": "step-1", "action": "createContact" },\n      { "id": "step-2", "action": "sendEmail" }\n    ],\n    "trigger": "webhook"\n  }'`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst wf = await client.workflows.create({\n  name: 'Customer Onboarding',\n  dag: [\n    { id: 'step-1', action: 'createContact' },\n    { id: 'step-2', action: 'sendEmail' },\n  ],\n  trigger: 'webhook',\n});\nconsole.log(wf.workflowId);`,
  },
  {
    method: 'GET',
    path: '/workflows/:id/audit',
    description: 'Get full audit trail for a workflow execution',
    tags: ['audit', 'compliance'],
    params: [
      { name: 'id', type: 'string', required: true, description: 'Workflow ID' },
      { name: 'from', type: 'string', required: false, description: 'Start date (ISO 8601)' },
      { name: 'to', type: 'string', required: false, description: 'End date (ISO 8601)' },
    ],
    responseExample: JSON.stringify(
      {
        workflowId: 'wf-001',
        executions: [
          {
            id: 'exec-001',
            startedAt: '2026-05-20T14:30:00Z',
            status: 'completed',
            stepsExecuted: 3,
            triggeredBy: 'user@example.com',
          },
        ],
        total: 1,
      },
      null,
      2
    ),
    curlExample: `curl -X GET "https://api.opr.dev/v1/workflows/wf-001/audit" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Accept: application/json"`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst audit = await client.workflows.getAudit('wf-001', {\n  from: '2026-05-01T00:00:00Z',\n  to: '2026-05-31T23:59:59Z',\n});\nconsole.log(audit.executions);`,
  },
  // ── Operations Hub ──
  {
    method: 'POST',
    path: '/deployments',
    description: 'Deploy a workflow to the Operations Hub',
    tags: ['deployments', 'ops'],
    params: [
      { name: 'workflowId', type: 'string', required: true, description: 'Workflow ID to deploy' },
      { name: 'trigger', type: 'string', required: false, description: 'Trigger: schedule | event | manual' },
      { name: 'schedule', type: 'string', required: false, description: 'Cron expression (for schedule trigger)' },
      { name: 'environment', type: 'string', required: false, description: 'Target env: production | staging' },
    ],
    responseExample: JSON.stringify(
      {
        deploymentId: 'dep-001',
        workflowId: 'wf-001',
        status: 'deployed',
        trigger: 'schedule',
        schedule: '0 9 * * *',
        deployedAt: '2026-05-25T09:00:00Z',
        deployedBy: 'admin@opr.io',
      },
      null,
      2
    ),
    curlExample: `curl -X POST "https://api.opr.dev/v1/deployments" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "workflowId": "wf-001",\n    "trigger": "schedule",\n    "schedule": "0 9 * * *",\n    "environment": "production"\n  }'`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst dep = await client.deployments.create({\n  workflowId: 'wf-001',\n  trigger: 'schedule',\n  schedule: '0 9 * * *',\n  environment: 'production',\n});\nconsole.log(dep.deploymentId);`,
  },
  {
    method: 'GET',
    path: '/deployments',
    description: 'List all active deployments in the Operations Hub',
    tags: ['deployments', 'ops', 'list'],
    params: [
      { name: 'status', type: 'string', required: false, description: 'Filter: deployed | running | failed | paused' },
      { name: 'workflowId', type: 'string', required: false, description: 'Filter by workflow ID' },
      { name: 'page', type: 'number', required: false, description: 'Page number (default: 1)' },
    ],
    responseExample: JSON.stringify(
      {
        data: [
          {
            deploymentId: 'dep-001',
            workflowName: 'Daily Trade Reconciliation',
            status: 'deployed',
            trigger: 'schedule',
            lastRun: '2026-05-25T09:00:00Z',
            nextRun: '2026-05-26T09:00:00Z',
            successRate: 98.5,
          },
          {
            deploymentId: 'dep-002',
            workflowName: 'Invoice Processing',
            status: 'running',
            trigger: 'manual',
            lastRun: '2026-05-25T14:30:00Z',
            nextRun: 'On completion',
            successRate: 100,
          },
        ],
        total: 2,
        page: 1,
      },
      null,
      2
    ),
    curlExample: `curl -X GET "https://api.opr.dev/v1/deployments?status=deployed" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Accept: application/json"`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst deps = await client.deployments.list({\n  status: 'deployed',\n  page: 1,\n});\nconsole.log(deps.data);`,
  },
  {
    method: 'POST',
    path: '/deployments/:id/execute',
    description: 'Trigger a manual execution of a deployed workflow',
    tags: ['deployments', 'execute', 'ops'],
    params: [
      { name: 'id', type: 'string', required: true, description: 'Deployment ID' },
      { name: 'input', type: 'object', required: false, description: 'Runtime input parameters' },
    ],
    responseExample: JSON.stringify(
      {
        executionId: 'exec-001',
        deploymentId: 'dep-001',
        status: 'running',
        startedAt: '2026-05-25T09:00:00Z',
        estimatedDuration: '2m 30s',
        logStream: '/v1/executions/exec-001/logs',
      },
      null,
      2
    ),
    curlExample: `curl -X POST "https://api.opr.dev/v1/deployments/dep-001/execute" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "input": { "date": "2026-05-25" }\n  }'`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst run = await client.deployments.execute('dep-001', {\n  input: { date: '2026-05-25' },\n});\nconsole.log(run.executionId);`,
  },
  {
    method: 'GET',
    path: '/executions/:id',
    description: 'Get execution status and progress of a running workflow',
    tags: ['executions', 'ops', 'monitor'],
    params: [
      { name: 'id', type: 'string', required: true, description: 'Execution ID' },
    ],
    responseExample: JSON.stringify(
      {
        executionId: 'exec-001',
        deploymentId: 'dep-001',
        workflowName: 'Daily Trade Reconciliation',
        status: 'running',
        progress: 65,
        currentStep: 'SWB — Document Extraction',
        startedAt: '2026-05-25T09:00:00Z',
        elapsed: '1m 45s',
        logs: [
          { time: '09:00:00', level: 'info', message: 'Starting workflow execution' },
          { time: '09:00:02', level: 'info', message: 'Connected to QTrack' },
          { time: '09:01:15', level: 'info', message: 'Processing batch data at SWB' },
        ],
      },
      null,
      2
    ),
    curlExample: `curl -X GET "https://api.opr.dev/v1/executions/exec-001" \\\n  -H "Authorization: Bearer YOUR_API_KEY" \\\n  -H "Accept: application/json"`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nconst status = await client.executions.get('exec-001');\nconsole.log(status.progress + '% — ' + status.currentStep);`,
  },
  {
    method: 'DELETE',
    path: '/deployments/:id',
    description: 'Undeploy (remove) a workflow from the Operations Hub',
    tags: ['deployments', 'undeploy', 'ops'],
    params: [
      { name: 'id', type: 'string', required: true, description: 'Deployment ID' },
      { name: 'force', type: 'boolean', required: false, description: 'Force undeploy even if running' },
    ],
    responseExample: JSON.stringify(
      {
        deploymentId: 'dep-001',
        status: 'undeployed',
        undeployedAt: '2026-05-25T10:00:00Z',
        message: 'Workflow successfully undeployed',
      },
      null,
      2
    ),
    curlExample: `curl -X DELETE "https://api.opr.dev/v1/deployments/dep-001" \\\n  -H "Authorization: Bearer YOUR_API_KEY"`,
    tsExample: `import { OPRClient } from '@opr/sdk';\n\nconst client = new OPRClient({ apiKey: 'YOUR_API_KEY' });\n\nawait client.deployments.delete('dep-001');\nconsole.log('Undeployed successfully');`,
  },
];

const TREND_DATA = [
  { day: 'Mon', success: 320, failed: 5 },
  { day: 'Tue', success: 380, failed: 3 },
  { day: 'Wed', success: 450, failed: 8 },
  { day: 'Thu', success: 410, failed: 4 },
  { day: 'Fri', success: 520, failed: 6 },
  { day: 'Sat', success: 280, failed: 2 },
  { day: 'Sun', success: 310, failed: 3 },
];

const CONSUMER_DATA = [
  { name: 'Customer A', value: 30, color: '#6366F1' },
  { name: 'Customer B', value: 25, color: '#22C55E' },
  { name: 'Customer C', value: 25, color: '#F59E0B' },
  { name: 'Customer D', value: 20, color: '#0EA5E9' },
];

// ── Small helper components ─────────────────────────────────────────────────

function MethodBadge({ method }: { method: Endpoint['method'] }) {
  const colors: Record<Endpoint['method'], string> = {
    GET: 'bg-[#22C55E]/15 text-[#22C55E] border-[#22C55E]/25',
    POST: 'bg-[#6366F1]/15 text-[#6366F1] border-[#6366F1]/25',
    PUT: 'bg-[#F59E0B]/15 text-[#F59E0B] border-[#F59E0B]/25',
    DELETE: 'bg-[#EF4444]/15 text-[#EF4444] border-[#EF4444]/25',
  };

  return (
    <span
      className={`inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-bold uppercase tracking-wide ${colors[method]}`}
    >
      {method}
    </span>
  );
}

function TagBadge({ tag }: { tag: string }) {
  return (
    <span className="inline-flex items-center rounded-full bg-[#0D1117] border border-[#1E293B] px-2 py-0.5 text-[10px] font-medium text-[#94A3B8]">
      {tag}
    </span>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }, [text]);

  return (
    <button
      onClick={handleCopy}
      className="flex items-center gap-1.5 rounded-md border border-[#1E293B] bg-[#0D1117] px-2 py-1 text-[11px] text-[#94A3B8] hover:text-[#F1F5F9] hover:border-[#30363D] transition-colors"
      aria-label="Copy to clipboard"
    >
      {copied ? (
        <>
          <Check size={12} className="text-[#22C55E]" />
          <span className="text-[#22C55E]">Copied!</span>
        </>
      ) : (
        <>
          <Copy size={12} />
          <span>Copy</span>
        </>
      )}
    </button>
  );
}

function CodeBlock({ code, label }: { code: string; label: string }) {
  return (
    <div className="mt-3">
      <div className="flex items-center justify-between mb-2">
        <span className="text-[11px] font-medium text-[#94A3B8] uppercase tracking-wide">{label}</span>
        <CopyButton text={code} />
      </div>
      <pre className="bg-[#0D1117] border border-[#30363D] rounded-lg p-4 overflow-x-auto">
        <code className="text-[13px] font-mono text-[#E6EDF3] leading-relaxed whitespace-pre">
          {code}
        </code>
      </pre>
    </div>
  );
}

// ── Main page ───────────────────────────────────────────────────────────────

export default function Registry() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);

  const toggleExpand = useCallback((index: number) => {
    setExpandedIndex((prev) => (prev === index ? null : index));
  }, []);

  const BASE_URL = 'https://api.opr.dev/v1';

  return (
    <Layout>
      <div className="space-y-6">
        {/* ══════════ Section 1: Page Header ══════════ */}
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4"
        >
          <motion.div variants={fadeUp}>
            <h1 className="text-2xl font-bold text-[#F1F5F9] tracking-tight">Capability Registry</h1>
            <p className="mt-1 text-sm text-[#94A3B8]">
              Enterprise System Knowledge API — Query system capabilities across your stack
            </p>
          </motion.div>

          <motion.div variants={fadeUp} className="flex items-center gap-3 flex-wrap">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-[#22C55E]/10 border border-[#22C55E]/25 px-3 py-1 text-xs font-medium text-[#22C55E]">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#22C55E] opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-[#22C55E]" />
              </span>
              Online
            </span>
            <span className="inline-flex items-center rounded-full bg-[#0A0F1E] border border-[#1E293B] px-3 py-1 text-xs font-mono text-[#94A3B8]">
              v2.1.0
            </span>
            <CopyButton text={BASE_URL} />
          </motion.div>
        </motion.div>

        {/* ══════════ Section 2: Stats Cards ══════════ */}
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {[
            {
              label: 'Total API Calls Today',
              value: '2,847',
              change: '+12% vs yesterday',
              changePositive: true,
              icon: Globe,
            },
            {
              label: 'Active Consumers',
              value: '4',
              sub: 'PS / AgentHub / n8n / Internal',
              icon: Users,
            },
            {
              label: 'Avg Response Time',
              value: '45ms',
              change: '-8ms',
              changePositive: true,
              icon: Zap,
            },
            {
              label: 'Uptime',
              value: '99.97%',
              icon: Shield,
            },
          ].map((stat, i) => (
            <motion.div
              key={i}
              variants={fadeUp}
              className="rounded-xl border border-[#1E293B] bg-[#0A0F1E] p-5 hover:border-[#30363D] transition-colors"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-[#94A3B8]">{stat.label}</span>
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#0D1117] border border-[#1E293B]">
                  <stat.icon size={14} className="text-[#6366F1]" />
                </div>
              </div>
              <div className="text-2xl font-bold text-[#F1F5F9] tracking-tight">{stat.value}</div>
              {stat.change && (
                <div className="mt-1 text-xs text-[#22C55E]">{stat.change}</div>
              )}
              {stat.sub && (
                <div className="mt-1 text-xs text-[#94A3B8]">{stat.sub}</div>
              )}
            </motion.div>
          ))}
        </motion.div>

        {/* ══════════ Section 3: API Endpoints ══════════ */}
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="rounded-xl border border-[#1E293B] bg-[#0A0F1E] overflow-hidden"
        >
          <motion.div variants={fadeUp} className="px-5 py-4 border-b border-[#1E293B]">
            <h2 className="text-sm font-semibold text-[#F1F5F9]">API Endpoints</h2>
            <p className="text-xs text-[#94A3B8] mt-0.5">Explore and test available endpoints</p>
          </motion.div>

          {/* Table header */}
          <div className="grid grid-cols-[100px_1fr_1fr_140px_80px] gap-4 px-5 py-2.5 border-b border-[#1E293B] bg-[#030712]/50 text-[10px] font-semibold uppercase tracking-wider text-[#94A3B8]">
            <div>Method</div>
            <div>Path</div>
            <div>Description</div>
            <div>Tags</div>
            <div className="text-right">Action</div>
          </div>

          {/* Endpoint rows */}
          <div className="divide-y divide-[#1E293B]">
            {ENDPOINTS.map((ep, i) => {
              const isExpanded = expandedIndex === i;
              return (
                <motion.div
                  key={ep.path + ep.method}
                  variants={fadeUp}
                  layout
                  className="hover:bg-[rgba(255,255,255,0.02)] transition-colors"
                >
                  {/* Main row */}
                  <button
                    onClick={() => toggleExpand(i)}
                    className="w-full grid grid-cols-[100px_1fr_1fr_140px_80px] gap-4 px-5 py-3.5 items-center text-left"
                  >
                    <div>
                      <MethodBadge method={ep.method} />
                    </div>
                    <div className="font-mono text-sm text-[#F1F5F9]">{ep.path}</div>
                    <div className="text-xs text-[#94A3B8]">{ep.description}</div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {ep.tags.map((tag) => (
                        <TagBadge key={tag} tag={tag} />
                      ))}
                    </div>
                    <div className="flex justify-end">
                      <span className="inline-flex items-center gap-1 text-[11px] font-medium text-[#6366F1]">
                        <Terminal size={12} />
                        Try It
                        <motion.span
                          animate={{ rotate: isExpanded ? 180 : 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <ChevronDown size={12} />
                        </motion.span>
                      </span>
                    </div>
                  </button>

                  {/* Expanded detail */}
                  <AnimatePresence initial={false}>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.25, ease: 'easeInOut' }}
                        className="overflow-hidden"
                      >
                        <div className="px-5 pb-5 pt-1 border-t border-[#1E293B]/50">
                          {/* Request Parameters */}
                          <div className="mt-4">
                            <h3 className="text-[11px] font-semibold uppercase tracking-wide text-[#94A3B8] mb-2">
                              Request Parameters
                            </h3>
                            <div className="rounded-lg border border-[#1E293B] overflow-hidden">
                              <table className="w-full text-xs">
                                <thead className="bg-[#030712]/80 text-[#94A3B8]">
                                  <tr>
                                    <th className="px-3 py-2 text-left font-medium">Name</th>
                                    <th className="px-3 py-2 text-left font-medium">Type</th>
                                    <th className="px-3 py-2 text-left font-medium">Required</th>
                                    <th className="px-3 py-2 text-left font-medium">Description</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-[#1E293B]">
                                  {ep.params.map((p) => (
                                    <tr key={p.name} className="hover:bg-[rgba(255,255,255,0.015)]">
                                      <td className="px-3 py-2.5 font-mono text-[#E6EDF3]">{p.name}</td>
                                      <td className="px-3 py-2.5 text-[#6366F1]">{p.type}</td>
                                      <td className="px-3 py-2.5">
                                        {p.required ? (
                                          <span className="text-[#EF4444]">required</span>
                                        ) : (
                                          <span className="text-[#94A3B8]">optional</span>
                                        )}
                                      </td>
                                      <td className="px-3 py-2.5 text-[#94A3B8]">{p.description}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>

                          {/* Response Example */}
                          <CodeBlock code={ep.responseExample} label="Response Example" />

                          {/* curl Example */}
                          <CodeBlock code={ep.curlExample} label="cURL Example" />

                          {/* TypeScript SDK Example */}
                          <CodeBlock code={ep.tsExample} label="TypeScript SDK" />
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* ══════════ Section 4 & 5: Charts Row ══════════ */}
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 lg:grid-cols-3 gap-4"
        >
          {/* API Call Trend */}
          <motion.div
            variants={fadeUp}
            className="lg:col-span-2 rounded-xl border border-[#1E293B] bg-[#0A0F1E] p-5"
          >
            <h2 className="text-sm font-semibold text-[#F1F5F9] mb-1">API Call Trend</h2>
            <p className="text-xs text-[#94A3B8] mb-4">Last 7 days — successful vs failed calls</p>
            <div className="h-[260px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={TREND_DATA} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="successGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22C55E" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#22C55E" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="failedGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#EF4444" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#EF4444" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                  <XAxis
                    dataKey="day"
                    tick={{ fill: '#94A3B8', fontSize: 11 }}
                    axisLine={{ stroke: '#1E293B' }}
                    tickLine={{ stroke: '#1E293B' }}
                  />
                  <YAxis
                    tick={{ fill: '#94A3B8', fontSize: 11 }}
                    axisLine={{ stroke: '#1E293B' }}
                    tickLine={{ stroke: '#1E293B' }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0D1117',
                      borderColor: '#30363D',
                      borderRadius: 8,
                      fontSize: 12,
                      color: '#F1F5F9',
                    }}
                    itemStyle={{ fontSize: 12 }}
                    labelStyle={{ color: '#94A3B8', marginBottom: 4 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="success"
                    name="Success"
                    stroke="#22C55E"
                    strokeWidth={2}
                    fill="url(#successGrad)"
                    dot={{ r: 3, fill: '#22C55E', strokeWidth: 0 }}
                    activeDot={{ r: 5 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="failed"
                    name="Failed"
                    stroke="#EF4444"
                    strokeWidth={2}
                    fill="url(#failedGrad)"
                    dot={{ r: 3, fill: '#EF4444', strokeWidth: 0 }}
                    activeDot={{ r: 5 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Consumer Distribution */}
          <motion.div
            variants={fadeUp}
            className="rounded-xl border border-[#1E293B] bg-[#0A0F1E] p-5"
          >
            <h2 className="text-sm font-semibold text-[#F1F5F9] mb-1">Consumer Distribution</h2>
            <p className="text-xs text-[#94A3B8] mb-4">By source application</p>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={CONSUMER_DATA}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                    stroke="none"
                  >
                    {CONSUMER_DATA.map((entry, idx) => (
                      <Cell key={idx} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0D1117',
                      borderColor: '#30363D',
                      borderRadius: 8,
                      fontSize: 12,
                      color: '#F1F5F9',
                    }}
                    formatter={(value: number, name: string) => [`${value}%`, name]}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            {/* Legend */}
            <div className="flex flex-col gap-2 mt-2">
              {CONSUMER_DATA.map((item) => (
                <div key={item.name} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className="inline-block h-2.5 w-2.5 rounded-full"
                      style={{ backgroundColor: item.color }}
                    />
                    <span className="text-[#94A3B8]">{item.name}</span>
                  </div>
                  <span className="font-medium text-[#F1F5F9]">{item.value}%</span>
                </div>
              ))}
            </div>
          </motion.div>
        </motion.div>

        {/* ══════════ Section 6: SDK Download Cards ══════════ */}
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 sm:grid-cols-3 gap-4"
        >
          {[
            {
              title: 'TypeScript SDK',
              command: 'npm install @opr/sdk',
              icon: Terminal,
              accent: '#6366F1',
            },
            {
              title: 'Python SDK',
              command: 'pip install opr',
              icon: Terminal,
              accent: '#22C55E',
            },
            {
              title: 'Postman Collection',
              command: 'Import to Postman',
              icon: Globe,
              accent: '#F59E0B',
            },
          ].map((sdk) => (
            <motion.div
              key={sdk.title}
              variants={fadeUp}
              className="rounded-xl border border-[#1E293B] bg-[#0A0F1E] p-5 hover:border-[#30363D] transition-colors"
            >
              <div className="flex items-center justify-between mb-3">
                <div
                  className="flex h-9 w-9 items-center justify-center rounded-lg"
                  style={{ backgroundColor: `${sdk.accent}15`, border: `1px solid ${sdk.accent}25` }}
                >
                  <sdk.icon size={16} style={{ color: sdk.accent }} />
                </div>
                <button className="inline-flex items-center gap-1.5 rounded-md border border-[#1E293B] bg-[#0D1117] px-3 py-1.5 text-xs font-medium text-[#F1F5F9] hover:border-[#30363D] transition-colors">
                  <Download size={13} />
                  Download
                </button>
              </div>
              <h3 className="text-sm font-semibold text-[#F1F5F9]">{sdk.title}</h3>
              <p className="mt-1 text-xs font-mono text-[#94A3B8] bg-[#0D1117] rounded-md px-2.5 py-1.5 border border-[#1E293B]">
                {sdk.command}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </Layout>
  );
}
