import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Requirements from './pages/Requirements';
import Knowledge from './pages/Knowledge';
import OperationsHub from './pages/DeployConsole';
import Registry from './pages/Registry';


export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/requirements" element={<Requirements />} />
      <Route path="/knowledge" element={<Knowledge />} />
      <Route path="/deploy" element={<OperationsHub />} />
      <Route path="/registry" element={<Registry />} />

    </Routes>
  );
}
