/**
 * Workflow Analysis API — analyzes requirements and recommends systems
 */

import { post } from './client';
import type { AnalyzeResponse, CreateSOPRequest, SOPKnowledge } from './types';

export interface AnalyzeRequest {
  text: string;
  mode?: 'text' | 'document' | 'email';
  constraints?: string[];
}

/**
 * Analyze a requirement and get workflow recommendations.
 * Called when user clicks "Analyze" in the Workflow Studio.
 */
export async function analyzeWorkflow(request: AnalyzeRequest): Promise<AnalyzeResponse> {
  return post<AnalyzeResponse>('/api/analyze', request);
}

/**
 * Save a workflow as a new SOP Knowledge entry.
 * Called from "Save as SOP Knowledge" button in chat.
 */
export async function saveWorkflowAsSOP(request: CreateSOPRequest): Promise<SOPKnowledge> {
  return post<SOPKnowledge>('/api/workflows/save', request);
}
