/**
 * API Configuration
 * 
 * Base URL for the backend FastAPI service.
 * In development: http://localhost:8000
 * In production: set via VITE_API_BASE_URL env var
 */
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';

export const API_ENDPOINTS = {
  chat: `${API_BASE_URL}/api/chat`,
  chatStream: `${API_BASE_URL}/api/chat/stream`,
  analyze: `${API_BASE_URL}/api/analyze`,
  sops: `${API_BASE_URL}/api/sops`,
  sopsMatch: `${API_BASE_URL}/api/sops/match`,
  workflowSave: `${API_BASE_URL}/api/workflows/save`,
  systems: `${API_BASE_URL}/api/systems`,
  health: `${API_BASE_URL}/api/health`,
} as const;
