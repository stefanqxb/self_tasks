/**
 * TypeScript types matching the backend Pydantic models.
 * These ensure type safety across the frontend-backend boundary.
 */

export interface ChatMessage {
  id: string;
  role: 'user' | 'ai';
  content: string;
  type: 'text' | 'workflow' | 'code' | 'error';
  timestamp: string;
  confidence?: number;
  recommendations?: SystemRecommendation[];
  workflow?: WorkflowStep[];
}

export interface SystemRecommendation {
  id: string;
  name: string;
  confidence: number;
  reason: string;
  apis: string[];
  matched_capabilities: string[];
}

export interface WorkflowStep {
  id: string;
  system: string;
  action: string;
  description: string;
}

export interface ChatResponse {
  message: ChatMessage;
  conversation_id: string;
}

export interface StreamChunk {
  type: 'token' | 'workflow' | 'done' | 'error';
  content: string;
  data?: {
    recommendations?: SystemRecommendation[];
    workflow?: WorkflowStep[];
    confidence?: number;
  } | null;
}

export interface AnalyzeRequest {
  text: string;
  mode?: 'text' | 'document' | 'email';
  constraints?: string[];
}

export interface AnalyzeResponse {
  conversation_id: string;
  summary: string;
  recommendations: SystemRecommendation[];
  workflow: WorkflowStep[];
  overall_confidence: number;
}

export interface SOPStep {
  order: number;
  title: string;
  description: string;
  system: string;
  action: string;
  expected_output: string;
  notes: string;
}

export interface SOPReviewRecord {
  id: string;
  reviewed_at: string;
  reviewer: string;
  findings: string;
  actions: string;
  status: 'completed' | 'pending' | 'overdue';
}

export interface SOPKnowledge {
  id: string;
  title: string;
  description: string;
  category: string;
  source_workflow?: string;
  systems_involved: string[];
  steps: SOPStep[];
  best_practices: string[];
  common_issues: string[];
  review_history: SOPReviewRecord[];
  created_at: string;
  updated_at: string;
  next_review_due: string;
  status: 'active' | 'draft' | 'under-review' | 'deprecated';
  owner: string;
  tags: string[];
}

export interface CreateSOPRequest {
  title: string;
  description: string;
  category: string;
  source_workflow?: string;
  systems_involved: string[];
  owner: string;
  tags: string[];
}

export interface MatchSOPResponse {
  matches: Array<{
    sop: SOPKnowledge;
    score: number;
    matched_systems: string[];
  }>;
}

export interface SystemInfo {
  id: string;
  name: string;
  capabilities: string[];
  color: string;
  description: string;
}

export interface SystemCapability {
  id: string;
  name: string;
  description: string;
  exposed_via: string;
  input: string;
  output: string;
  tags: string[];
  constraints: string[];
}
