/**
 * SOP Management API — CRUD and matching for Process SOP Knowledge
 */

import { get, post } from './client';
import type { SOPKnowledge, MatchSOPResponse, CreateSOPRequest } from './types';

/**
 * List all SOPs.
 * Used by Knowledge page's "Process SOP" layer.
 */
export async function listSOPs(): Promise<SOPKnowledge[]> {
  return get<SOPKnowledge[]>('/api/sops');
}

/**
 * Get a single SOP by ID.
 */
export async function getSOP(sopId: string): Promise<SOPKnowledge> {
  return get<SOPKnowledge>(`/api/sops/${sopId}`);
}

/**
 * Create a new SOP.
 */
export async function createSOP(request: CreateSOPRequest): Promise<SOPKnowledge> {
  return post<SOPKnowledge>('/api/sops', request);
}

/**
 * Find matching SOPs for a text query.
 * Called in real-time as user types in Workflow Studio input.
 */
export async function matchSOPs(text: string, maxResults: number = 3): Promise<MatchSOPResponse> {
  return post<MatchSOPResponse>('/api/sops/match', { text, max_results: maxResults });
}
