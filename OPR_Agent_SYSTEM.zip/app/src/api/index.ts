/**
 * OPR API Client — unified exports for all backend API modules
 * 
 * Backend: FastAPI service running at http://localhost:8000
 * 
 * ## Setup
 * ```bash
 * cd backend && pip install -r requirements.txt && uvicorn main:app --reload
 * ```
 * 
 * ## Usage in Components
 * ```tsx
 * import { sendChat, matchSOPs, analyzeWorkflow } from '@/api';
 * 
 * // Send a chat message
 * const response = await sendChat({
 *   conversation_id: 'conv-001',
 *   messages: [{ id: 'm1', role: 'user', content: 'Trade reconciliation', ... }],
 *   mode: 'text',
 * });
 * 
 * // Match SOPs in real-time
 * const matches = await matchSOPs('trade reconciliation', 3);
 * 
 * // Analyze requirement
 * const analysis = await analyzeWorkflow({ text: 'Daily trade reconciliation' });
 * ```
 */

// Config
export { API_BASE_URL, API_ENDPOINTS } from './config';

// Types
export type {
  ChatMessage,
  ChatResponse,
  StreamChunk,
  SystemRecommendation,
  WorkflowStep,
  AnalyzeRequest,
  AnalyzeResponse,
  SOPKnowledge,
  SOPStep,
  SOPReviewRecord,
  CreateSOPRequest,
  MatchSOPResponse,
  SystemInfo,
  SystemCapability,
} from './types';

// API functions
export { sendChat, streamChat } from './chat';
export { analyzeWorkflow, saveWorkflowAsSOP } from './workflow';
export { listSOPs, getSOP, createSOP, matchSOPs } from './sop';
export { listSystems, getSystem } from './systems';

// Error handling
export { APIError } from './client';
