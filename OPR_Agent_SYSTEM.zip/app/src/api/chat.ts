/**
 * Chat API — handles conversation with the AI workflow agent
 */

import { post, streamPost } from './client';
import type { ChatMessage, ChatResponse, StreamChunk } from './types';

export interface ChatRequest {
  conversation_id: string;
  messages: ChatMessage[];
  mode: 'text' | 'document' | 'email';
  system_id?: string;
}

/**
 * Send a chat message and get the complete AI response.
 * Used by the Workflow Studio's right-panel input.
 */
export async function sendChat(request: ChatRequest): Promise<ChatResponse> {
  return post<ChatResponse>('/api/chat', request);
}

/**
 * Send a chat message and get a streaming SSE response.
 * Yields token-by-token for real-time typing effect.
 */
export async function* streamChat(request: ChatRequest): AsyncGenerator<StreamChunk> {
  for await (const chunk of streamPost('/api/chat/stream', request)) {
    try {
      yield JSON.parse(chunk) as StreamChunk;
    } catch {
      // Skip unparsable chunks
    }
  }
}
