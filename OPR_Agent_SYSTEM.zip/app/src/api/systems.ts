/**
 * System Knowledge API — provides system capability catalog
 */

import { get } from './client';
import type { SystemInfo } from './types';

/**
 * List all systems with their capabilities.
 * Used by Knowledge page and Canvas sidebar.
 */
export async function listSystems(): Promise<SystemInfo[]> {
  return get<SystemInfo[]>('/api/systems');
}

/**
 * Get a single system's details.
 * Used by Canvas detail panel.
 */
export async function getSystem(systemId: string): Promise<SystemInfo> {
  return get<SystemInfo>(`/api/systems/${systemId}`);
}
