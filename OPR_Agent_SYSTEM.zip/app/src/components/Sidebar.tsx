import { useCallback } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ClipboardList,
  Database,
  Settings,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
  Hexagon,
  Rocket,
  LayoutDashboard,
  Globe,
} from 'lucide-react';
import { useSidebar } from '@/hooks/use-sidebar.tsx';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const modules = [
  { name: 'Dashboard', path: '/', icon: LayoutDashboard },
  { name: 'Workflow Studio', path: '/requirements', icon: ClipboardList },
  { name: 'Knowledge', path: '/knowledge', icon: Database },
  { name: 'Operations Hub', path: '/deploy', icon: Rocket },
  { name: 'Registry', path: '/registry', icon: Globe },

];

const system = [
  { name: 'Settings', path: '/settings', icon: Settings },
  { name: 'Help', path: '/help', icon: HelpCircle },
];

function NavItem({ item, collapsed }: { item: typeof modules[0]; collapsed: boolean }) {
  const location = useLocation();
  const isActive = location.pathname === item.path || location.pathname.startsWith(`${item.path}/`);
  const Icon = item.icon;

  const content = (
    <Link
      to={item.path}
      className={cn(
        'group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-150 relative',
        isActive
          ? 'text-[#6366F1] bg-[rgba(99,102,241,0.12)]'
          : 'text-[#94A3B8] hover:bg-[rgba(255,255,255,0.05)] hover:text-[#F1F5F9]'
      )}
    >
      {isActive && (
        <motion.div
          layoutId="sidebar-active"
          className="absolute left-0 top-1.5 bottom-1.5 w-1 rounded-r-full bg-[#6366F1]"
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        />
      )}
      <Icon className="h-5 w-5 flex-shrink-0" />
      {!collapsed && <span className="truncate">{item.name}</span>}
    </Link>
  );

  if (collapsed) {
    return (
      <Tooltip delayDuration={100}>
        <TooltipTrigger asChild>{content}</TooltipTrigger>
        <TooltipContent side="right" sideOffset={8}>
          <p>{item.name}</p>
        </TooltipContent>
      </Tooltip>
    );
  }

  return content;
}

export default function Sidebar() {
  const { collapsed, toggle } = useSidebar();
  const location = useLocation();

  const isRouteActive = useCallback(
    (path: string) =>
      location.pathname === path || location.pathname.startsWith(`${path}/`),
    [location]
  );

  return (
    <TooltipProvider delayDuration={100}>
      <aside
        className={cn(
          'fixed left-0 top-0 z-50 flex h-full flex-col border-r border-[#1E293B] bg-[#0A0F1E] transition-[width] duration-300',
          collapsed ? 'w-[72px]' : 'w-[260px]'
        )}
        style={{
          transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)',
        }}
      >
        {/* Logo */}
        <div className="flex h-14 items-center gap-3 border-b border-[#1E293B] px-4">
          <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-[#6366F1]">
            <Hexagon className="h-5 w-5 text-white" strokeWidth={2.5} />
          </div>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-lg font-bold tracking-tight text-[#F1F5F9]"
            >
              OPR
            </motion.span>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 px-3">
          {!collapsed && (
            <div className="mb-2 px-3">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">
                Modules
              </span>
            </div>
          )}
          <div className="mb-6 space-y-1">
            {modules.map((item) => (
              <NavItem key={item.path} item={item} collapsed={collapsed} />
            ))}
          </div>

          {!collapsed && (
            <div className="mb-2 px-3">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">
                System
              </span>
            </div>
          )}
          <div className="space-y-1">
            {system.map((item) => {
              const Icon = item.icon;
              const active = isRouteActive(item.path);
              const link = (
                <Link
                  to={item.path}
                  className={cn(
                    'group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-150 relative',
                    active
                      ? 'text-[#6366F1] bg-[rgba(99,102,241,0.12)]'
                      : 'text-[#94A3B8] hover:bg-[rgba(255,255,255,0.05)] hover:text-[#F1F5F9]'
                  )}
                >
                  {active && (
                    <motion.div
                      layoutId="sidebar-active-system"
                      className="absolute left-0 top-1.5 bottom-1.5 w-1 rounded-r-full bg-[#6366F1]"
                      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
                    />
                  )}
                  <Icon className="h-5 w-5 flex-shrink-0" />
                  {!collapsed && <span className="truncate">{item.name}</span>}
                </Link>
              );
              if (collapsed) {
                return (
                  <Tooltip key={item.path} delayDuration={100}>
                    <TooltipTrigger asChild>{link}</TooltipTrigger>
                    <TooltipContent side="right" sideOffset={8}>
                      <p>{item.name}</p>
                    </TooltipContent>
                  </Tooltip>
                );
              }
              return <div key={item.path}>{link}</div>;
            })}
          </div>
        </nav>

        {/* User + Collapse */}
        <div className="border-t border-[#1E293B] p-3">
          <div className="flex items-center gap-3 px-3 py-2">
            <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-[#6366F1] text-[11px] font-bold text-white">
              AU
            </div>
            {!collapsed && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex-1 overflow-hidden"
              >
                <p className="truncate text-sm font-medium text-[#F1F5F9]">Admin User</p>
                <p className="truncate text-xs text-[#94A3B8]">admin@opr.io</p>
              </motion.div>
            )}
          </div>
          <button
            onClick={toggle}
            className="mt-2 flex w-full items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm text-[#64748B] transition-colors hover:bg-[rgba(255,255,255,0.05)] hover:text-[#94A3B8]"
          >
            {collapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <>
                <ChevronLeft className="h-4 w-4" />
                <span className="text-xs font-medium">Collapse</span>
              </>
            )}
          </button>
        </div>
      </aside>
    </TooltipProvider>
  );
}
