import type { ReactNode } from 'react';
import { SidebarProvider, useSidebar } from '@/hooks/use-sidebar.tsx';
import Sidebar from './Sidebar';
import TopNav from './TopNav';
import { cn } from '@/lib/utils';

function LayoutInner({ children }: { children: ReactNode }) {
  const { collapsed } = useSidebar();

  return (
    <div className="min-h-[100dvh] bg-[#030712]">
      <Sidebar />
      <div
        className={cn(
          'flex min-h-[100dvh] flex-col transition-[margin-left] duration-300',
          collapsed ? 'ml-[72px]' : 'ml-[260px]'
        )}
        style={{
          transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)',
        }}
      >
        <TopNav />
        <main
          className="flex-1 p-6 relative"
          style={{
            backgroundImage: 'radial-gradient(circle, #1E293B 1px, transparent 1px)',
            backgroundSize: '24px 24px',
          }}
        >
          {children}
        </main>
      </div>
    </div>
  );
}

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <SidebarProvider>
      <LayoutInner>{children}</LayoutInner>
    </SidebarProvider>
  );
}
