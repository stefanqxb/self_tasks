import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Server,
  Link,
  Sparkles,
  ShieldCheck,
  ClipboardCheck,
  Check,
  ChevronLeft,
  ChevronRight,
  X,
  Plus,
  Trash2,
  Pencil,
  RotateCcw,
  TestTubes,
  Upload,
  Wifi,
  FileText,
  BookOpen,
  Code,
  Hand,
  AlertTriangle,
  Ban,
  CheckCircle2,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

// ═══════════════════════════════════════════════════════════════════════════════
//  TYPES
// ═══════════════════════════════════════════════════════════════════════════════

/** Legacy system shape — kept for backward compat with consumers */
export interface NewSystem {
  name: string;
  color: string;
  description: string;
  category: string;
  tags: string[];
  apis: Array<{
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
    path: string;
    name: string;
    description: string;
  }>;
  capabilities: Array<{
    name: string;
    description: string;
    type: 'API' | 'Feature' | 'Config';
    tags: string[];
  }>;
}

interface OnboardingWizardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (system: NewSystem) => void;
}

interface Capability {
  id: string;
  name: string;
  description: string;
  exposedVia: 'MCP Tool' | 'OpenAPI' | 'Manual';
  inputSummary: string;
  outputSummary: string;
  tags: string[];
  selected: boolean;
}

interface BusinessRule {
  id: string;
  name: string;
  condition: string;
  action: 'ALLOW' | 'REJECT' | 'WARN';
  message: string;
}

interface UploadedDocument {
  name: string;
  type: string;
  size: string;
  status: 'uploaded' | 'pending';
}

interface OnboardingFormState {
  systemName: string;
  domain: string;
  ownerTeam: string;
  description: string;
  lifecycle: 'Active' | 'Beta' | 'Coming Soon';
  environment: 'Internal' | 'Public' | 'Hybrid';
  exposureMethod: 'mcp' | 'openapi' | 'manual';
  mcpServerUrl: string;
  mcpTransport: 'HTTP' | 'SSE' | 'STDIO';
  mcpAuth: 'API Key' | 'OAuth' | 'None';
  openapiUrl: string;
  capabilities: Capability[];
  rules: BusinessRule[];
  documents: UploadedDocument[];
}

// ═══════════════════════════════════════════════════════════════════════════════
//  CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════════

const STEP_CONFIG = [
  { id: 1, label: 'System Basics', icon: Server, description: 'Name, domain, owner' },
  { id: 2, label: 'Exposure Method', icon: Link, description: 'MCP, OpenAPI, or Manual' },
  { id: 3, label: 'Discover Caps', icon: Sparkles, description: 'Auto-discover capabilities' },
  { id: 4, label: 'Upload Documents', icon: FileText, description: 'PDF, Confluence, API specs' },
  { id: 5, label: 'Business Rules', icon: ShieldCheck, description: 'Set constraints & rules' },
  { id: 6, label: 'Review & Save', icon: ClipboardCheck, description: 'Review everything' },
] as const;

const DOMAIN_OPTIONS = [
  'email-management',
  'workflow-platform',
  'information-extraction',
  'reconciliation-engine',
  'payment-storage',
  'trade-storage',
  'procurement',
  'custom',
] as const;

const EASE_TRANSITION = { duration: 0.25, ease: 'easeInOut' as const };

// ═══════════════════════════════════════════════════════════════════════════════
//  MOCK DATA
// ═══════════════════════════════════════════════════════════════════════════════

const INITIAL_FORM: OnboardingFormState = {
  systemName: 'ProcurementPro',
  domain: 'procurement',
  ownerTeam: '供应链团队',
  description: '采购管理系统，负责处理采购订单、供应商管理和库存查询',
  lifecycle: 'Active',
  environment: 'Internal',
  exposureMethod: 'mcp',
  mcpServerUrl: 'http://localhost:3001/sse',
  mcpTransport: 'HTTP',
  mcpAuth: 'API Key',
  openapiUrl: '',
  capabilities: [
    {
      id: 'cap-1',
      name: 'create_order',
      description: 'Create a new purchase order',
      exposedVia: 'MCP Tool',
      inputSummary: 'productId + quantity + supplier',
      outputSummary: 'orderId + status',
      tags: ['procurement', 'order', 'create'],
      selected: true,
    },
    {
      id: 'cap-2',
      name: 'query_inventory',
      description: 'Check inventory for a product',
      exposedVia: 'MCP Tool',
      inputSummary: 'productId',
      outputSummary: 'quantity + warehouse',
      tags: ['procurement', 'inventory', 'query'],
      selected: true,
    },
    {
      id: 'cap-3',
      name: 'get_supplier_info',
      description: 'Retrieve supplier details and contact',
      exposedVia: 'MCP Tool',
      inputSummary: 'supplierId',
      outputSummary: 'name + contact + rating',
      tags: ['procurement', 'supplier'],
      selected: true,
    },
    {
      id: 'cap-4',
      name: 'update_order_status',
      description: 'Update status of an existing order',
      exposedVia: 'MCP Tool',
      inputSummary: 'orderId + newStatus',
      outputSummary: 'success + updatedOrder',
      tags: ['procurement', 'order', 'update'],
      selected: true,
    },
  ],
  rules: [
    {
      id: 'rule-1',
      name: 'Requires 2 inputs',
      condition: 'inputs.count < 2',
      action: 'REJECT',
      message: 'SIRE requires exactly 2 input sources',
    },
    {
      id: 'rule-2',
      name: 'No downstream',
      condition: 'output.type == "report"',
      action: 'WARN',
      message: 'Output is report, should not connect to other systems',
    },
    {
      id: 'rule-3',
      name: 'Valid order amount',
      condition: 'totalAmt <= 0',
      action: 'REJECT',
      message: 'Order amount must be greater than zero',
    },
  ],
  documents: [],
};

// ═══════════════════════════════════════════════════════════════════════════════
//  UTILITY
// ═══════════════════════════════════════════════════════════════════════════════

function generateId(prefix: string): string {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

/** Convert the rich form state back to the legacy NewSystem shape */
function toNewSystem(form: OnboardingFormState): NewSystem {
  const selectedCaps = form.capabilities.filter(c => c.selected);
  return {
    name: form.systemName,
    color: '#6366F1',
    description: form.description,
    category: form.domain,
    tags: [...new Set(form.capabilities.flatMap(c => c.tags))],
    apis: selectedCaps.map(cap => {
      const method = cap.name.startsWith('create') || cap.name.startsWith('add')
        ? 'POST'
        : cap.name.startsWith('update') || cap.name.startsWith('modify')
        ? 'PUT'
        : cap.name.startsWith('delete') || cap.name.startsWith('remove')
        ? 'DELETE'
        : 'GET';
      return {
        method: method as NewSystem['apis'][number]['method'],
        path: `/${cap.name.replace(/_/g, '/')}`,
        name: cap.name,
        description: cap.description,
      };
    }),
    capabilities: selectedCaps.map(cap => ({
      name: cap.name,
      description: cap.description,
      type: (cap.exposedVia === 'MCP Tool' || cap.exposedVia === 'OpenAPI' ? 'API' : 'Feature') as NewSystem['capabilities'][number]['type'],
      tags: cap.tags,
    })),
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
//  SHARED COMPONENTS
// ═══════════════════════════════════════════════════════════════════════════════

function StepWrapper({ children, stepKey, direction }: {
  children: React.ReactNode;
  stepKey: number;
  direction: number;
}) {
  return (
    <motion.div
      key={stepKey}
      initial={{ x: direction > 0 ? 80 : -80, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: direction > 0 ? -80 : 80, opacity: 0 }}
      transition={EASE_TRANSITION}
      className="w-full"
    >
      {children}
    </motion.div>
  );
}

function StepIndicator({ step, totalSteps }: { step: number; totalSteps: number }) {
  return (
    <div className="flex items-center justify-between">
      {STEP_CONFIG.slice(0, totalSteps).map((s, idx) => {
        const Icon = s.icon;
        const isActive = step === s.id;
        const isCompleted = step > s.id;
        return (
          <div key={s.id} className="flex items-center flex-1">
            <div className="flex flex-col items-center">
              <div
                className={cn(
                  'h-10 w-10 rounded-full flex items-center justify-center transition-all duration-300 border-2',
                  isActive && 'border-[#6366F1] bg-[#6366F1]/15 text-[#6366F1] shadow-[0_0_12px_rgba(99,102,241,0.3)]',
                  isCompleted && 'border-[#6366F1] bg-[#6366F1] text-white',
                  !isActive && !isCompleted && 'border-[#334155] bg-[#0A0F1E] text-[#64748B]'
                )}
              >
                {isCompleted ? (
                  <Check className="h-5 w-5" />
                ) : (
                  <Icon className="h-4 w-4" />
                )}
              </div>
              <span
                className={cn(
                  'text-[10px] mt-1.5 font-medium transition-colors text-center leading-tight',
                  isActive && 'text-[#818CF8]',
                  isCompleted && 'text-[#6366F1]',
                  !isActive && !isCompleted && 'text-[#475569]'
                )}
              >
                {s.label}
              </span>
            </div>
            {idx < totalSteps - 1 && (
              <div className="flex-1 h-0.5 mx-2 bg-[#1E293B] relative top-[-10px]">
                <motion.div
                  className="h-full bg-[#6366F1]"
                  initial={{ width: '0%' }}
                  animate={{
                    width: step > s.id + 1 ? '100%' : step === s.id + 1 ? '50%' : '0%',
                  }}
                  transition={{ duration: 0.4, ease: 'easeInOut' as const }}
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  STEP 1: SYSTEM BASICS
// ═══════════════════════════════════════════════════════════════════════════════

function StepSystemBasics({
  data,
  onChange,
}: {
  data: OnboardingFormState;
  onChange: (patch: Partial<OnboardingFormState>) => void;
}) {
  return (
    <div className="space-y-5">
      <div>
        <label className="block text-sm font-medium text-[#94A3B8] mb-2">
          System Name <span className="text-[#EF4444]">*</span>
        </label>
        <Input
          value={data.systemName}
          onChange={e => onChange({ systemName: e.target.value })}
          placeholder="e.g., ProcurementPro"
          className="bg-[#0A0F1E] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] focus:border-[#6366F1] focus:ring-1 focus:ring-[#6366F1]"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-[#94A3B8] mb-2">Domain</label>
        <div className="flex flex-wrap gap-2">
          {DOMAIN_OPTIONS.map(opt => (
            <button
              key={opt}
              onClick={() => onChange({ domain: opt })}
              className={cn(
                'px-3 py-1.5 rounded-md text-sm font-medium transition-all border',
                data.domain === opt
                  ? 'bg-[#6366F1]/15 border-[#6366F1] text-[#818CF8]'
                  : 'bg-[#0A0F1E] border-[#1E293B] text-[#94A3B8] hover:border-[#475569]'
              )}
            >
              {opt}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-[#94A3B8] mb-2">Owner Team</label>
        <Input
          value={data.ownerTeam}
          onChange={e => onChange({ ownerTeam: e.target.value })}
          placeholder="Platform Team"
          className="bg-[#0A0F1E] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] focus:border-[#6366F1] focus:ring-1 focus:ring-[#6366F1]"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-[#94A3B8] mb-2">Description</label>
        <Textarea
          value={data.description}
          onChange={e => onChange({ description: e.target.value })}
          placeholder="这个系统是做什么的，面向谁"
          rows={3}
          className="bg-[#0A0F1E] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] focus:border-[#6366F1] focus:ring-1 focus:ring-[#6366F1] resize-none"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-[#94A3B8] mb-2">Lifecycle</label>
        <div className="flex gap-2">
          {(['Active', 'Beta', 'Coming Soon'] as const).map(opt => (
            <button
              key={opt}
              onClick={() => onChange({ lifecycle: opt })}
              className={cn(
                'px-4 py-1.5 rounded-md text-sm font-medium transition-all border flex-1',
                data.lifecycle === opt
                  ? 'bg-[#6366F1]/15 border-[#6366F1] text-[#818CF8]'
                  : 'bg-[#0A0F1E] border-[#1E293B] text-[#94A3B8] hover:border-[#475569]'
              )}
            >
              {opt}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-[#94A3B8] mb-2">Environment</label>
        <div className="flex gap-2">
          {(['Internal', 'Public', 'Hybrid'] as const).map(opt => (
            <button
              key={opt}
              onClick={() => onChange({ environment: opt })}
              className={cn(
                'px-4 py-1.5 rounded-md text-sm font-medium transition-all border flex-1',
                data.environment === opt
                  ? 'bg-[#6366F1]/15 border-[#6366F1] text-[#818CF8]'
                  : 'bg-[#0A0F1E] border-[#1E293B] text-[#94A3B8] hover:border-[#475569]'
              )}
            >
              {opt}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  STEP 2: EXPOSURE METHOD
// ═══════════════════════════════════════════════════════════════════════════════

function StepExposureMethod({
  data,
  onChange,
}: {
  data: OnboardingFormState;
  onChange: (patch: Partial<OnboardingFormState>) => void;
}) {
  const [testing, setTesting] = useState(false);
  const [testStatus, setTestStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [importing, setImporting] = useState(false);
  const [importStatus, setImportStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleTest = useCallback(() => {
    setTesting(true);
    setTestStatus('idle');
    setTimeout(() => {
      setTesting(false);
      setTestStatus('success');
    }, 1200);
  }, []);

  const handleImport = useCallback(() => {
    if (!data.openapiUrl.trim()) return;
    setImporting(true);
    setImportStatus('idle');
    setTimeout(() => {
      setImporting(false);
      setImportStatus('success');
    }, 1200);
  }, [data.openapiUrl]);

  const methods = [
    { key: 'mcp' as const, label: 'MCP Server', desc: 'Connect via MCP', icon: Wifi },
    { key: 'openapi' as const, label: 'OpenAPI / Swagger', desc: 'Import from OpenAPI URL', icon: FileText },
    { key: 'manual' as const, label: 'Manual Entry', desc: 'Define everything manually', icon: Hand },
  ];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-3">
        {methods.map(m => {
          const Icon = m.icon;
          const isActive = data.exposureMethod === m.key;
          return (
            <button
              key={m.key}
              onClick={() => onChange({ exposureMethod: m.key })}
              className={cn(
                'relative flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all text-center',
                isActive
                  ? 'border-[#6366F1] bg-[#6366F1]/10 text-[#F1F5F9]'
                  : 'border-[#1E293B] bg-[#0A0F1E] text-[#94A3B8] hover:border-[#475569]'
              )}
            >
              <Icon className={cn('h-6 w-6', isActive ? 'text-[#6366F1]' : 'text-[#64748B]')} />
              <div className="text-sm font-semibold">{m.label}</div>
              <div className="text-xs text-[#64748B]">{m.desc}</div>
              {isActive && (
                <div className="absolute top-2 right-2 h-4 w-4 rounded-full bg-[#6366F1] flex items-center justify-center">
                  <Check className="h-3 w-3 text-white" />
                </div>
              )}
            </button>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        {data.exposureMethod === 'mcp' && (
          <motion.div
            key="mcp"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={EASE_TRANSITION}
            className="space-y-4 bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-4"
          >
            <div>
              <label className="block text-xs font-medium text-[#94A3B8] mb-1.5">Server URL</label>
              <Input
                value={data.mcpServerUrl}
                onChange={e => onChange({ mcpServerUrl: e.target.value })}
                placeholder="http://localhost:3001/sse"
                className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] focus:border-[#6366F1]"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#94A3B8] mb-1.5">Transport</label>
                <select
                  value={data.mcpTransport}
                  onChange={e => onChange({ mcpTransport: e.target.value as 'HTTP' | 'SSE' | 'STDIO' })}
                  className="w-full h-9 rounded-md border border-[#1E293B] bg-[#0F172A] text-[#F1F5F9] text-sm px-3 outline-none focus:border-[#6366F1] cursor-pointer"
                >
                  <option value="HTTP">HTTP</option>
                  <option value="SSE">SSE</option>
                  <option value="STDIO">STDIO</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-[#94A3B8] mb-1.5">Auth</label>
                <select
                  value={data.mcpAuth}
                  onChange={e => onChange({ mcpAuth: e.target.value as 'API Key' | 'OAuth' | 'None' })}
                  className="w-full h-9 rounded-md border border-[#1E293B] bg-[#0F172A] text-[#F1F5F9] text-sm px-3 outline-none focus:border-[#6366F1] cursor-pointer"
                >
                  <option value="API Key">API Key</option>
                  <option value="OAuth">OAuth</option>
                  <option value="None">None</option>
                </select>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={handleTest}
                disabled={testing}
                variant="outline"
                className="border-[#6366F1] text-[#818CF8] hover:bg-[#6366F1]/15 gap-2"
              >
                {testing ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' as const }}
                  >
                    <RotateCcw className="h-4 w-4" />
                  </motion.div>
                ) : (
                  <TestTubes className="h-4 w-4" />
                )}
                Test Connection
              </Button>
              <AnimatePresence>
                {testStatus === 'success' && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex items-center gap-1.5 text-sm text-[#22C55E]"
                  >
                    <CheckCircle2 className="h-4 w-4" />
                    Connection successful
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}

        {data.exposureMethod === 'openapi' && (
          <motion.div
            key="openapi"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={EASE_TRANSITION}
            className="space-y-4 bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-4"
          >
            <div>
              <label className="block text-xs font-medium text-[#94A3B8] mb-1.5">OpenAPI URL</label>
              <div className="flex gap-2">
                <Input
                  value={data.openapiUrl}
                  onChange={e => onChange({ openapiUrl: e.target.value })}
                  placeholder="https://api.example.com/openapi.json"
                  className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] focus:border-[#6366F1]"
                />
                <Button
                  onClick={handleImport}
                  disabled={importing || !data.openapiUrl.trim()}
                  className="bg-[#6366F1] text-white hover:bg-[#4F46E5] gap-2 shrink-0"
                >
                  {importing ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' as const }}
                    >
                      <Upload className="h-4 w-4" />
                    </motion.div>
                  ) : (
                    <Upload className="h-4 w-4" />
                  )}
                  Import & Parse
                </Button>
              </div>
            </div>
            <AnimatePresence>
              {importStatus === 'success' && (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="flex items-center gap-1.5 text-sm text-[#22C55E]"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  OpenAPI spec imported successfully — 5 endpoints parsed
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {data.exposureMethod === 'manual' && (
          <motion.div
            key="manual"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={EASE_TRANSITION}
            className="bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-6 text-center"
          >
            <Hand className="h-8 w-8 text-[#475569] mx-auto mb-3" />
            <p className="text-sm text-[#94A3B8]">
              You will define everything manually in the next steps.
            </p>
            <p className="text-xs text-[#64748B] mt-1">
              Capabilities, data models, rules, and tags can all be added by hand.
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  STEP 3: DISCOVER CAPABILITIES
// ═══════════════════════════════════════════════════════════════════════════════

function StepDiscoverCapabilities({
  data,
  onChange,
}: {
  data: OnboardingFormState;
  onChange: (patch: Partial<OnboardingFormState>) => void;
}) {
  const [editingId, setEditingId] = useState<string | null>(null);

  const toggleCap = useCallback((id: string) => {
    const updated = data.capabilities.map(c =>
      c.id === id ? { ...c, selected: !c.selected } : c
    );
    onChange({ capabilities: updated });
  }, [data.capabilities, onChange]);

  const removeCap = useCallback((id: string) => {
    onChange({ capabilities: data.capabilities.filter(c => c.id !== id) });
  }, [data.capabilities, onChange]);

  const updateCap = useCallback((id: string, patch: Partial<Capability>) => {
    const updated = data.capabilities.map(c =>
      c.id === id ? { ...c, ...patch } : c
    );
    onChange({ capabilities: updated });
  }, [data.capabilities, onChange]);

  const addCap = useCallback(() => {
    const newCap: Capability = {
      id: generateId('cap'),
      name: '',
      description: '',
      exposedVia: 'Manual',
      inputSummary: '',
      outputSummary: '',
      tags: [],
      selected: true,
    };
    onChange({ capabilities: [...data.capabilities, newCap] });
    setEditingId(newCap.id);
  }, [data.capabilities, onChange]);

  const selectedCount = data.capabilities.filter(c => c.selected).length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="text-sm text-[#94A3B8]">
          自动发现 <span className="text-[#F1F5F9] font-semibold">{data.capabilities.length}</span> 个 Capabilities
          <span className="text-[#64748B] ml-2">({selectedCount} selected)</span>
        </div>
      </div>

      <ScrollArea className="h-[380px] pr-2">
        <div className="space-y-2">
          <AnimatePresence>
            {data.capabilities.map(cap => (
              <motion.div
                key={cap.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.15 }}
                className={cn(
                  'bg-[#0A0F1E] border rounded-lg overflow-hidden transition-colors',
                  cap.selected ? 'border-[#1E293B]' : 'border-[#1E293B]/50 opacity-60'
                )}
              >
                {/* Header row */}
                <div className="flex items-center gap-3 p-3">
                  <button
                    onClick={() => toggleCap(cap.id)}
                    className={cn(
                      'h-5 w-5 rounded border flex items-center justify-center transition-colors shrink-0',
                      cap.selected
                        ? 'bg-[#6366F1] border-[#6366F1] text-white'
                        : 'border-[#475569] bg-transparent'
                    )}
                  >
                    {cap.selected && <Check className="h-3.5 w-3.5" />}
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-[#F1F5F9]">{cap.name}</span>
                      <Badge
                        variant="secondary"
                        className={cn(
                          'text-[10px] px-1.5 py-0',
                          cap.exposedVia === 'MCP Tool' && 'text-[#0EA5E9] bg-[#0EA5E9]/10',
                          cap.exposedVia === 'OpenAPI' && 'text-[#F59E0B] bg-[#F59E0B]/10',
                          cap.exposedVia === 'Manual' && 'text-[#94A3B8] bg-[#1E293B]',
                        )}
                      >
                        {cap.exposedVia}
                      </Badge>
                    </div>
                    <p className="text-xs text-[#94A3B8] mt-0.5">{cap.description}</p>
                    <p className="text-xs text-[#64748B] mt-0.5">
                      Input: {cap.inputSummary} → Output: {cap.outputSummary}
                    </p>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {cap.tags.map(tag => (
                        <Badge
                          key={tag}
                          variant="secondary"
                          className="bg-[#1E293B] text-[#94A3B8] text-[10px] px-1.5 py-0"
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setEditingId(editingId === cap.id ? null : cap.id)}
                      className="h-7 w-7 text-[#64748B] hover:text-[#F1F5F9] hover:bg-[#1E293B]"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeCap(cap.id)}
                      className="h-7 w-7 text-[#64748B] hover:text-[#EF4444] hover:bg-[#EF4444]/10"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>

                {/* Edit panel */}
                <AnimatePresence>
                  {editingId === cap.id && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="px-3 pb-3 pt-1 border-t border-[#1E293B] space-y-3">
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs text-[#94A3B8] mb-1">Name</label>
                            <Input
                              value={cap.name}
                              onChange={e => updateCap(cap.id, { name: e.target.value })}
                              className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] h-8 text-sm"
                            />
                          </div>
                          <div>
                            <label className="block text-xs text-[#94A3B8] mb-1">Exposed Via</label>
                            <select
                              value={cap.exposedVia}
                              onChange={e => updateCap(cap.id, { exposedVia: e.target.value as Capability['exposedVia'] })}
                              className="w-full h-8 rounded-md border border-[#1E293B] bg-[#0F172A] text-[#F1F5F9] text-sm px-2 outline-none focus:border-[#6366F1] cursor-pointer"
                            >
                              <option value="MCP Tool">MCP Tool</option>
                              <option value="OpenAPI">OpenAPI</option>
                              <option value="Manual">Manual</option>
                            </select>
                          </div>
                        </div>
                        <div>
                          <label className="block text-xs text-[#94A3B8] mb-1">Description</label>
                          <Input
                            value={cap.description}
                            onChange={e => updateCap(cap.id, { description: e.target.value })}
                            className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] h-8 text-sm"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs text-[#94A3B8] mb-1">Input Summary</label>
                            <Input
                              value={cap.inputSummary}
                              onChange={e => updateCap(cap.id, { inputSummary: e.target.value })}
                              placeholder="e.g. productId + quantity"
                              className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] h-8 text-sm"
                            />
                          </div>
                          <div>
                            <label className="block text-xs text-[#94A3B8] mb-1">Output Summary</label>
                            <Input
                              value={cap.outputSummary}
                              onChange={e => updateCap(cap.id, { outputSummary: e.target.value })}
                              placeholder="e.g. orderId + status"
                              className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] h-8 text-sm"
                            />
                          </div>
                        </div>
                        <CapTagsEditor
                          tags={cap.tags}
                          onChange={newTags => updateCap(cap.id, { tags: newTags })}
                        />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </ScrollArea>

      <Button
        variant="outline"
        onClick={addCap}
        className="w-full border-dashed border-[#1E293B] text-[#94A3B8] hover:bg-[#1E293B] hover:text-[#F1F5F9] gap-2"
      >
        <Plus className="h-4 w-4" />
        Add Capability Manually
      </Button>
    </div>
  );
}

// Capability inline tag editor
function CapTagsEditor({ tags, onChange }: { tags: string[]; onChange: (tags: string[]) => void }) {
  const [input, setInput] = useState('');

  const add = useCallback(() => {
    const t = input.trim();
    if (t && !tags.includes(t)) {
      onChange([...tags, t]);
      setInput('');
    }
  }, [input, tags, onChange]);

  const remove = useCallback((tag: string) => {
    onChange(tags.filter(t => t !== tag));
  }, [tags, onChange]);

  return (
    <div>
      <label className="block text-xs text-[#94A3B8] mb-1">Tags</label>
      <div className="flex gap-1 mb-1">
        <Input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); add(); } }}
          placeholder="tag + Enter"
          className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] h-7 text-xs px-2"
        />
      </div>
      <div className="flex flex-wrap gap-1">
        {tags.map(tag => (
          <Badge
            key={tag}
            variant="secondary"
            className="bg-[#1E293B] text-[#94A3B8] hover:bg-[#334155] cursor-pointer text-[10px] px-1.5 py-0 gap-0.5"
            onClick={() => remove(tag)}
          >
            {tag}
            <X className="h-2.5 w-2.5" />
          </Badge>
        ))}
      </div>
    </div>
  );
}

//  STEP 4: UPLOAD DOCUMENTS
// ═══════════════════════════════════════════════════════════════════════════════

function StepUploadDocuments({
  data,
  onChange,
}: {
  data: OnboardingFormState;
  onChange: (patch: Partial<OnboardingFormState>) => void;
}) {
  const [dragOver, setDragOver] = useState(false);

  const handleUpload = useCallback(() => {
    const mockFiles: UploadedDocument[] = [
      { name: 'API-Reference-v2.pdf', type: 'API Spec', size: '2.4 MB', status: 'uploaded' },
      { name: 'Business-Overview.docx', type: 'Business Doc', size: '1.1 MB', status: 'uploaded' },
    ];
    onChange({ documents: [...data.documents, ...mockFiles] });
    setDragOver(false);
  }, [data.documents, onChange]);

  const removeDoc = useCallback((name: string) => {
    onChange({ documents: data.documents.filter(d => d.name !== name) });
  }, [data.documents, onChange]);

  return (
    <div className="space-y-6">
      {/* Drag & Drop Zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => { e.preventDefault(); handleUpload(); }}
        onClick={handleUpload}
        className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors cursor-pointer ${
          dragOver
            ? 'border-[#6366F1] bg-[rgba(99,102,241,0.08)]'
            : 'border-[#334155] bg-[#0A0F1E] hover:border-[#475569]'
        }`}
      >
        <Upload className="w-8 h-8 text-[#475569] mx-auto mb-3" />
        <p className="text-sm text-[#94A3B8] mb-1">
          <span className="text-[#6366F1] font-medium">Click to upload</span> or drag and drop
        </p>
        <p className="text-[11px] text-[#64748B]">
          PDF, Word, Confluence export, OpenAPI YAML — up to 50MB each
        </p>
      </div>

      {/* Document Type Quick Buttons */}
      {data.documents.length === 0 && (
        <div className="grid grid-cols-3 gap-3">
          {[
            { icon: FileText, label: 'Business Doc', desc: 'What this system does' },
            { icon: Code, label: 'API Spec', desc: 'OpenAPI/Swagger YAML' },
            { icon: BookOpen, label: 'Runbook', desc: 'Operations guide' },
          ].map((item) => (
            <button
              key={item.label}
              onClick={handleUpload}
              className="rounded-lg border border-[#1E293B] bg-[#0A0F1E] p-4 text-left hover:border-[#334155] transition-colors"
            >
              <item.icon className="w-5 h-5 text-[#6366F1] mb-2" />
              <p className="text-[12px] font-medium text-[#F1F5F9]">{item.label}</p>
              <p className="text-[10px] text-[#64748B]">{item.desc}</p>
            </button>
          ))}
        </div>
      )}

      {/* Uploaded Files List */}
      {data.documents.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-[12px] font-medium text-[#64748B] uppercase tracking-wider">
            Uploaded Documents ({data.documents.length})
          </h4>
          {data.documents.map((doc) => (
            <div key={doc.name} className="flex items-center gap-3 rounded-lg border border-[#1E293B] bg-[#0A0F1E] p-3">
              <div className="w-8 h-8 rounded-lg bg-[rgba(99,102,241,0.1)] flex items-center justify-center">
                <FileText className="w-4 h-4 text-[#6366F1]" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-medium text-[#F1F5F9] truncate">{doc.name}</p>
                <p className="text-[11px] text-[#64748B]">{doc.type} · {doc.size}</p>
              </div>
              <Badge variant="outline" className="text-[10px] text-[#22C55E] border-[#22C55E]/25 bg-[#22C55E]/10">
                {doc.status}
              </Badge>
              <button
                onClick={() => removeDoc(doc.name)}
                className="p-1.5 rounded-md text-[#64748B] hover:text-[#EF4444] hover:bg-[rgba(239,68,68,0.1)] transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

//  STEP 5: BUSINESS RULES
// ═══════════════════════════════════════════════════════════════════════════════

function StepBusinessRules({
  data,
  onChange,
}: {
  data: OnboardingFormState;
  onChange: (patch: Partial<OnboardingFormState>) => void;
}) {
  const addRule = useCallback(() => {
    const newRule: BusinessRule = {
      id: generateId('rule'),
      name: '',
      condition: '',
      action: 'WARN',
      message: '',
    };
    onChange({ rules: [...data.rules, newRule] });
  }, [data.rules, onChange]);

  const updateRule = useCallback((id: string, patch: Partial<BusinessRule>) => {
    const updated = data.rules.map(r => r.id === id ? { ...r, ...patch } : r);
    onChange({ rules: updated });
  }, [data.rules, onChange]);

  const removeRule = useCallback((id: string) => {
    onChange({ rules: data.rules.filter(r => r.id !== id) });
  }, [data.rules, onChange]);

  const actionMeta: Record<BusinessRule['action'], { color: string; icon: typeof Ban }> = {
    ALLOW: { color: 'text-[#22C55E] bg-[#22C55E]/10 border-[#22C55E]/30', icon: CheckCircle2 },
    REJECT: { color: 'text-[#EF4444] bg-[#EF4444]/10 border-[#EF4444]/30', icon: Ban },
    WARN: { color: 'text-[#F59E0B] bg-[#F59E0B]/10 border-[#F59E0B]/30', icon: AlertTriangle },
  };

  return (
    <div className="space-y-4">
      <div className="text-sm text-[#94A3B8]">
        Define business constraints for workflow generation:
      </div>

      <ScrollArea className="h-[380px] pr-2">
        <div className="space-y-2">
          <AnimatePresence>
            {data.rules.map((rule, idx) => {
              const meta = actionMeta[rule.action];
              const ActionIcon = meta.icon;
              return (
                <motion.div
                  key={rule.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.15 }}
                  className="bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-3 space-y-3"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#64748B] font-medium">Rule {idx + 1}:</span>
                    <Badge
                      variant="secondary"
                      className={cn('text-[10px] px-1.5 py-0 gap-1', meta.color)}
                    >
                      <ActionIcon className="h-3 w-3" />
                      {rule.action}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeRule(rule.id)}
                      className="h-6 w-6 text-[#64748B] hover:text-[#EF4444] hover:bg-[#EF4444]/10 ml-auto"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-[#94A3B8] mb-1">Name</label>
                      <Input
                        value={rule.name}
                        onChange={e => updateRule(rule.id, { name: e.target.value })}
                        placeholder="Rule name"
                        className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] h-8 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-[#94A3B8] mb-1">Action</label>
                      <select
                        value={rule.action}
                        onChange={e => updateRule(rule.id, { action: e.target.value as BusinessRule['action'] })}
                        className="w-full h-8 rounded-md border border-[#1E293B] bg-[#0F172A] text-[#F1F5F9] text-sm px-2 outline-none focus:border-[#6366F1] cursor-pointer"
                      >
                        <option value="ALLOW">ALLOW</option>
                        <option value="REJECT">REJECT</option>
                        <option value="WARN">WARN</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-[#94A3B8] mb-1">Condition</label>
                    <Input
                      value={rule.condition}
                      onChange={e => updateRule(rule.id, { condition: e.target.value })}
                      placeholder="inputs.count < 2"
                      className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] h-8 text-sm font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-[#94A3B8] mb-1">Message</label>
                    <Input
                      value={rule.message}
                      onChange={e => updateRule(rule.id, { message: e.target.value })}
                      placeholder="Error or warning message"
                      className="bg-[#0F172A] border-[#1E293B] text-[#F1F5F9] placeholder:text-[#475569] h-8 text-sm"
                    />
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </ScrollArea>

      <Button
        variant="outline"
        onClick={addRule}
        className="w-full border-dashed border-[#1E293B] text-[#94A3B8] hover:bg-[#1E293B] hover:text-[#F1F5F9] gap-2"
      >
        <Plus className="h-4 w-4" />
        Add Rule
      </Button>
    </div>
  );
}

function StepReviewSave({ data }: { data: OnboardingFormState }) {
  const selectedCaps = data.capabilities.filter(c => c.selected);

  const methodLabel =
    data.exposureMethod === 'mcp' ? 'MCP Server' :
    data.exposureMethod === 'openapi' ? 'OpenAPI / Swagger' :
    'Manual Entry';

  const lifecycleColor =
    data.lifecycle === 'Active' ? 'text-[#22C55E] bg-[#22C55E]/10' :
    data.lifecycle === 'Beta' ? 'text-[#F59E0B] bg-[#F59E0B]/10' :
    'text-[#94A3B8] bg-[#1E293B]';

  return (
    <div className="space-y-5">
      {/* Summary Card */}
      <div className="bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-4 space-y-4">
        <h4 className="text-sm font-semibold text-[#F1F5F9] flex items-center gap-2">
          <Server className="h-4 w-4 text-[#6366F1]" />
          System Summary
        </h4>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <span className="text-[#64748B]">Name: </span>
            <span className="text-[#F1F5F9] font-medium">{data.systemName || '—'}</span>
          </div>
          <div>
            <span className="text-[#64748B]">Domain: </span>
            <span className="text-[#F1F5F9] font-medium">{data.domain}</span>
          </div>
          <div>
            <span className="text-[#64748B]">Owner: </span>
            <span className="text-[#F1F5F9] font-medium">{data.ownerTeam || '—'}</span>
          </div>
          <div>
            <span className="text-[#64748B]">Method: </span>
            <span className="text-[#F1F5F9] font-medium">{methodLabel}</span>
          </div>
          <div>
            <span className="text-[#64748B]">Lifecycle: </span>
            <Badge variant="secondary" className={cn('text-[10px] px-1.5 py-0', lifecycleColor)}>
              {data.lifecycle}
            </Badge>
          </div>
          <div>
            <span className="text-[#64748B]">Environment: </span>
            <span className="text-[#F1F5F9] font-medium">{data.environment}</span>
          </div>
        </div>

        {data.description && (
          <div className="text-sm">
            <span className="text-[#64748B]">Description: </span>
            <span className="text-[#94A3B8]">{data.description}</span>
          </div>
        )}

      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-3 text-center">
          <Sparkles className="h-5 w-5 text-[#6366F1] mx-auto mb-1.5" />
          <div className="text-xl font-bold text-[#F1F5F9]">{selectedCaps.length}</div>
          <div className="text-xs text-[#64748B]">Capabilities</div>
        </div>
        <div className="bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-3 text-center">
          <ShieldCheck className="h-5 w-5 text-[#6366F1] mx-auto mb-1.5" />
          <div className="text-xl font-bold text-[#F1F5F9]">{data.rules.length}</div>
          <div className="text-xs text-[#64748B]">Business Rules</div>
        </div>
        <div className="bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-3 text-center">
          <FileText className="h-5 w-5 text-[#6366F1] mx-auto mb-1.5" />
          <div className="text-xl font-bold text-[#F1F5F9]">{data.documents?.length || 0}</div>
          <div className="text-xs text-[#64748B]">Documents</div>
        </div>
      </div>

      {/* Capabilities preview */}
      <div className="bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-4 space-y-2">
        <h4 className="text-sm font-semibold text-[#F1F5F9] flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-[#6366F1]" />
          Selected Capabilities
          <Badge className="bg-[#6366F1]/15 text-[#818CF8] ml-1 text-xs">{selectedCaps.length}</Badge>
        </h4>
        {selectedCaps.length === 0 ? (
          <p className="text-xs text-[#475569]">No capabilities selected.</p>
        ) : (
          <ScrollArea className="max-h-[120px]">
            <div className="space-y-1.5">
              {selectedCaps.map(cap => (
                <div key={cap.id} className="flex items-center gap-2 text-xs">
                  <Badge
                    variant="secondary"
                    className={cn(
                      'text-[10px] font-medium px-1.5 py-0',
                      cap.exposedVia === 'MCP Tool' && 'text-[#0EA5E9] bg-[#0EA5E9]/10',
                      cap.exposedVia === 'OpenAPI' && 'text-[#F59E0B] bg-[#F59E0B]/10',
                      cap.exposedVia === 'Manual' && 'text-[#94A3B8] bg-[#1E293B]',
                    )}
                  >
                    {cap.exposedVia}
                  </Badge>
                  <span className="text-[#F1F5F9] font-medium">{cap.name}</span>
                  <span className="text-[#64748B]">{cap.description}</span>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </div>

      {/* Rules preview */}
      <div className="bg-[#0A0F1E] border border-[#1E293B] rounded-lg p-4 space-y-2">
        <h4 className="text-sm font-semibold text-[#F1F5F9] flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-[#6366F1]" />
          Business Rules
          <Badge className="bg-[#6366F1]/15 text-[#818CF8] ml-1 text-xs">{data.rules.length}</Badge>
        </h4>
        {data.rules.length === 0 ? (
          <p className="text-xs text-[#475569]">No rules defined.</p>
        ) : (
          <div className="space-y-1">
            {data.rules.map(rule => (
              <div key={rule.id} className="flex items-center gap-2 text-xs">
                <Badge
                  variant="secondary"
                  className={cn(
                    'text-[10px] font-medium px-1.5 py-0',
                    rule.action === 'ALLOW' && 'text-[#22C55E] bg-[#22C55E]/10',
                    rule.action === 'REJECT' && 'text-[#EF4444] bg-[#EF4444]/10',
                    rule.action === 'WARN' && 'text-[#F59E0B] bg-[#F59E0B]/10',
                  )}
                >
                  {rule.action}
                </Badge>
                <span className="text-[#F1F5F9] font-medium">{rule.name || '—'}</span>
                <span className="text-[#64748B]">{rule.message}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
//  MAIN WIZARD COMPONENT
// ═══════════════════════════════════════════════════════════════════════════════

export default function OnboardingWizard({ open, onOpenChange, onSave }: OnboardingWizardProps) {
  const [step, setStep] = useState(1);
  const [direction, setDirection] = useState(1);
  const [form, setForm] = useState<OnboardingFormState>(INITIAL_FORM);

  const updateForm = useCallback((patch: Partial<OnboardingFormState>) => {
    setForm(prev => ({ ...prev, ...patch }));
  }, []);

  const goNext = useCallback(() => {
    if (step < STEP_CONFIG.length) {
      setDirection(1);
      setStep(s => s + 1);
    }
  }, [step]);

  const goBack = useCallback(() => {
    if (step > 1) {
      setDirection(-1);
      setStep(s => s - 1);
    }
  }, [step]);

  const handleSave = useCallback(() => {
    onSave(toNewSystem(form));
    // Reset
    setStep(1);
    setDirection(1);
    setForm(INITIAL_FORM);
    onOpenChange(false);
  }, [form, onSave, onOpenChange]);

  const handleClose = useCallback(() => {
    onOpenChange(false);
    setTimeout(() => {
      setStep(1);
      setDirection(1);
      setForm(INITIAL_FORM);
    }, 200);
  }, [onOpenChange]);

  // Step validation
  const canProceed = useCallback(() => {
    switch (step) {
      case 1:
        return form.systemName.trim().length > 0;
      case 2:
        return true;
      case 3:
        return form.capabilities.some(c => c.selected);
      case 4:
        return true;
      case 5:
        return true;
      case 6:
        return true;
      default:
        return false;
    }
  }, [step, form]);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-5xl bg-[#0F172A] border-[#1E293B] p-0 overflow-hidden max-h-[92vh]">
        {/* Header */}
        <DialogHeader className="px-6 pt-5 pb-0">
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2 text-[#F1F5F9] text-lg">
              <Server className="h-5 w-5 text-[#6366F1]" />
              System Onboarding
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="text-[#64748B] hover:text-[#F1F5F9] hover:bg-[#1E293B]"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        {/* Step Indicator */}
        <div className="px-6 mt-3">
          <StepIndicator step={step} totalSteps={STEP_CONFIG.length} />
        </div>

        {/* Step Description */}
        <div className="px-6">
          <div className="text-xs text-[#64748B] flex items-center gap-1.5">
            <span className="text-[#6366F1] font-medium">Step {step} of {STEP_CONFIG.length}:</span>
            <span className="text-[#94A3B8]">{STEP_CONFIG[step - 1]?.description}</span>
          </div>
        </div>

        {/* Content */}
        <div className="px-6 py-3 min-h-[340px] max-h-[52vh] overflow-y-auto">
          <AnimatePresence mode="wait" initial={false}>
            {step === 1 && (
              <StepWrapper stepKey={1} direction={direction}>
                <StepSystemBasics data={form} onChange={updateForm} />
              </StepWrapper>
            )}
            {step === 2 && (
              <StepWrapper stepKey={2} direction={direction}>
                <StepExposureMethod data={form} onChange={updateForm} />
              </StepWrapper>
            )}
            {step === 3 && (
              <StepWrapper stepKey={3} direction={direction}>
                <StepDiscoverCapabilities data={form} onChange={updateForm} />
              </StepWrapper>
            )}
            {step === 4 && (
              <StepWrapper stepKey={4} direction={direction}>
                <StepUploadDocuments data={form} onChange={updateForm} />
              </StepWrapper>
            )}
            {step === 5 && (
              <StepWrapper stepKey={5} direction={direction}>
                <StepBusinessRules data={form} onChange={updateForm} />
              </StepWrapper>
            )}
            {step === 6 && (
              <StepWrapper stepKey={6} direction={direction}>
                <StepReviewSave data={form} />
              </StepWrapper>
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#1E293B] bg-[#0A0F1E] flex items-center justify-between">
          <Button
            variant="outline"
            onClick={handleClose}
            className="border-[#1E293B] text-[#94A3B8] hover:bg-[#1E293B] hover:text-[#F1F5F9]"
          >
            Cancel
          </Button>

          <div className="flex items-center gap-2">
            {step > 1 && (
              <Button
                variant="outline"
                onClick={goBack}
                className="border-[#1E293B] text-[#94A3B8] hover:bg-[#1E293B] hover:text-[#F1F5F9] gap-2"
              >
                <ChevronLeft className="h-4 w-4" />
                Back
              </Button>
            )}
            {step < STEP_CONFIG.length ? (
              <Button
                onClick={goNext}
                disabled={!canProceed()}
                className="bg-[#6366F1] text-white hover:bg-[#4F46E5] gap-2 disabled:opacity-50"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            ) : (
              <Button
                onClick={handleSave}
                className="bg-[#6366F1] text-white hover:bg-[#4F46E5] gap-2 shadow-[0_0_16px_rgba(99,102,241,0.4)]"
              >
                <Check className="h-4 w-4" />
                Save System
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
