import { cn } from '@/lib/utils';

type StatusVariant = 'success' | 'warning' | 'error' | 'info' | 'neutral';

interface StatusBadgeProps {
  variant?: StatusVariant;
  children: React.ReactNode;
  className?: string;
}

const variantStyles: Record<StatusVariant, string> = {
  success: 'bg-[rgba(34,197,94,0.12)] text-[#16A34A]',
  warning: 'bg-[rgba(245,158,11,0.12)] text-[#D97706]',
  error: 'bg-[rgba(239,68,68,0.12)] text-[#DC2626]',
  info: 'bg-[rgba(99,102,241,0.12)] text-[#6366F1]',
  neutral: 'bg-[#F1F5F9] text-[#64748B]',
};

export default function StatusBadge({ variant = 'neutral', children, className }: StatusBadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
        variantStyles[variant],
        className
      )}
    >
      {children}
    </span>
  );
}
