import { Search, Bell, ChevronRight } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const routeTitles: Record<string, string> = {
  '/': 'Dashboard',
  '/requirements': 'Requirement Analysis',
  '/knowledge': 'Knowledge Layer',
  '/canvas': 'Workflow Canvas',
  '/settings': 'Settings',
  '/help': 'Help',
};

const routeBreadcrumbs: Record<string, { label: string; path?: string }[]> = {
  '/': [{ label: 'Home' }],
  '/requirements': [{ label: 'Home', path: '/' }, { label: 'Workflow Studio' }],
  '/knowledge': [{ label: 'Home', path: '/' }, { label: 'Knowledge' }],
  '/canvas': [{ label: 'Home', path: '/' }, { label: 'Canvas' }],
  '/settings': [{ label: 'Home', path: '/' }, { label: 'Settings' }],
  '/help': [{ label: 'Home', path: '/' }, { label: 'Help' }],
};

export default function TopNav() {
  const location = useLocation();
  const title = routeTitles[location.pathname] || 'OPR';
  const breadcrumbs = routeBreadcrumbs[location.pathname] || [{ label: 'Home' }];

  return (
    <header className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-[#1E293B] bg-[#0A0F1E] px-6">
      {/* Left: Title + Breadcrumb */}
      <div className="flex items-center gap-4">
        <div>
          <h1 className="text-base font-semibold text-[#F1F5F9]">{title}</h1>
          <nav className="flex items-center gap-1 text-xs text-[#94A3B8]">
            {breadcrumbs.map((crumb, i) => (
              <div key={crumb.label} className="flex items-center gap-1">
                {i > 0 && <ChevronRight className="h-3 w-3" />}
                {crumb.path ? (
                  <span className="hover:text-[#6366F1] cursor-default">{crumb.label}</span>
                ) : (
                  <span className="text-[#94A3B8]">{crumb.label}</span>
                )}
              </div>
            ))}
          </nav>
        </div>
      </div>

      {/* Right: Search + Notifications + User */}
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#64748B]" />
          <input
            type="text"
            placeholder="Search..."
            className={cn(
              'h-9 w-[240px] rounded-full border border-[#1E293B] bg-[#111827] pl-9 pr-4',
              'text-sm text-[#F1F5F9] placeholder:text-[#475569]',
              'focus:border-[#6366F1] focus:bg-[#111827] focus:outline-none focus:ring-2 focus:ring-[rgba(99,102,241,0.12)]',
              'transition-all duration-200'
            )}
          />
        </div>

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="relative flex h-9 w-9 items-center justify-center rounded-lg text-[#94A3B8] transition-colors hover:bg-[rgba(255,255,255,0.05)] hover:text-[#F1F5F9]">
              <Bell className="h-[18px] w-[18px]" />
              <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-[#F43F5E] ring-2 ring-[#0A0F1E]" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80 bg-[#0A0F1E] border-[#1E293B]">
            <DropdownMenuLabel className="text-sm font-semibold text-[#F1F5F9]">Notifications</DropdownMenuLabel>
            <DropdownMenuSeparator className="bg-[#1E293B]" />
            <div className="max-h-72 overflow-y-auto">
              <DropdownMenuItem className="flex flex-col items-start gap-1 py-2.5 cursor-default focus:bg-[#111827]">
                <span className="text-sm font-medium text-[#F1F5F9]">Workflow Generated</span>
                <span className="text-xs text-[#64748B]">Project Alpha workflow was generated successfully</span>
                <span className="text-[11px] text-[#475569]">2 hours ago</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="flex flex-col items-start gap-1 py-2.5 cursor-default focus:bg-[#111827]">
                <span className="text-sm font-medium text-[#F1F5F9]">Knowledge Updated</span>
                <span className="text-xs text-[#64748B]">QTrack knowledge base has 3 new APIs</span>
                <span className="text-[11px] text-[#475569]">5 hours ago</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="flex flex-col items-start gap-1 py-2.5 cursor-default focus:bg-[#111827]">
                <span className="text-sm font-medium text-[#F1F5F9]">New Requirement</span>
                <span className="text-xs text-[#64748B]">REQ-2024-008 has been submitted</span>
                <span className="text-[11px] text-[#475569]">1 day ago</span>
              </DropdownMenuItem>
            </div>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex h-9 w-9 items-center justify-center rounded-full bg-[#6366F1] text-[11px] font-bold text-white transition-opacity hover:opacity-90">
              AU
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-[#0A0F1E] border-[#1E293B]">
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col">
                <span className="text-sm font-medium text-[#F1F5F9]">Admin User</span>
                <span className="text-xs text-[#64748B]">admin@opr.io</span>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator className="bg-[#1E293B]" />
            <DropdownMenuItem className="cursor-pointer text-[#F1F5F9] focus:bg-[#111827] focus:text-[#F1F5F9]">Profile</DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer text-[#F1F5F9] focus:bg-[#111827] focus:text-[#F1F5F9]">Settings</DropdownMenuItem>
            <DropdownMenuSeparator className="bg-[#1E293B]" />
            <DropdownMenuItem className="cursor-pointer text-[#F43F5E] focus:bg-[#111827]">Sign out</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
