"""SOP Management API Router — CRUD and matching for Process SOP Knowledge.

GET  /api/sops           — List all SOPs
GET  /api/sops/{id}      — Get single SOP
POST /api/sops           — Create new SOP
POST /api/sops/match     — Find matching SOPs for text
POST /api/workflows/save — Save workflow as SOP
"""
from fastapi import APIRouter, HTTPException
from backend.models import (
    SOPKnowledge, CreateSOPRequest, MatchSOPRequest, MatchSOPResponse
)
from backend.services.agent import agent, SOP_DB

router = APIRouter(prefix="/api", tags=["SOP Management"])


@router.get("/sops", response_model=list[SOPKnowledge])
async def list_sops():
    """List all Process SOP Knowledge entries.
    
    **Response:** Array of SOPKnowledge objects with full step details,
    best practices, common issues, and review history.
    
    **How frontend uses this:**
    The Knowledge page's "Process SOP" layer fetches this to display
    all available SOPs. Each SOP can be expanded to show its pipeline
    visualization, steps, and review history.
    """
    return SOP_DB


@router.get("/sops/{sop_id}", response_model=SOPKnowledge)
async def get_sop(sop_id: str):
    """Get a single SOP by ID.
    
    **Path Parameter:** `sop_id` — The SOP identifier (e.g., "sop-001")
    
    **How frontend uses this:**
    Used when drilling down into a specific SOP from the listing view
    or when navigating from a workflow recommendation to its source SOP.
    """
    for sop in SOP_DB:
        if sop.id == sop_id:
            return sop
    raise HTTPException(status_code=404, detail=f"SOP {sop_id} not found")


@router.post("/sops", response_model=SOPKnowledge, status_code=201)
async def create_sop(request: CreateSOPRequest):
    """Create a new SOP from a workflow definition.
    
    **Request Body:**
    - `title`: SOP title
    - `description`: Detailed description
    - `category`: Category (e.g., "Reconciliation", "Payment Processing")
    - `source_workflow`: Optional parent workflow name
    - `systems_involved`: List of system names
    - `owner`: Team/individual responsible
    - `tags`: List of classification tags
    
    **How frontend uses this:**
    The Workflow Studio's "Save as SOP Knowledge" button calls this
    after the user reviews and confirms the workflow details.
    """
    from datetime import datetime, timedelta
    import uuid
    
    new_sop = SOPKnowledge(
        id=f"sop-{uuid.uuid4().hex[:6]}",
        title=request.title,
        description=request.description,
        category=request.category,
        source_workflow=request.source_workflow,
        systems_involved=request.systems_involved,
        steps=[],  # User fills in later via edit
        best_practices=[],
        common_issues=[],
        review_history=[],
        created_at=datetime.now().isoformat(),
        updated_at=datetime.now().isoformat(),
        next_review_due=(datetime.now() + timedelta(days=90)).isoformat(),
        status="draft",
        owner=request.owner,
        tags=request.tags
    )
    SOP_DB.append(new_sop)
    return new_sop


@router.post("/sops/match", response_model=MatchSOPResponse)
async def match_sops(request: MatchSOPRequest):
    """Find matching SOPs for a given text query.
    
    **Request Body:**
    - `text`: The search text (e.g., "trade reconciliation")
    - `max_results`: Maximum matches to return (default: 3)
    
    **Response:**
    - `matches`: Array of scored matches, each containing:
      - `sop`: The full SOP object
      - `score`: Match score (1-9)
      - `matched_systems`: Which systems matched
    
    **Scoring Algorithm:**
    - Title match: 3 pts | Category match: 2 pts | Tag match: 2 pts
    - Description match: 1 pt | System match: 1 pt
    
    **How frontend uses this:**
    The Workflow Studio's right-panel input calls this in real-time
    (>=5 chars typed) to show "Matching SOPs" suggestions below
    the text area. Clicking a match navigates to the SOP detail.
    """
    if not request.text or not request.text.strip():
        raise HTTPException(status_code=400, detail="Search text is required")
    
    matches = agent.match_sops(request.text, request.max_results)
    return MatchSOPResponse(matches=matches)


@router.post("/workflows/save", response_model=SOPKnowledge, status_code=201)
async def save_workflow_as_sop(request: CreateSOPRequest):
    """Save a completed workflow as a new SOP Knowledge entry.
    
    This is a convenience endpoint that is functionally identical to
    POST /api/sops but semantically represents "save from workflow studio".
    
    **How frontend uses this:**
    The "Save as SOP Knowledge" button in the Workflow Studio's
    chat thread calls this endpoint. The dialog pre-fills data from
    the current conversation's workflow analysis results.
    """
    return await create_sop(request)
