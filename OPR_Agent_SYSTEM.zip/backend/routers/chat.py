"""Chat API Router — handles real-time conversation with the AI agent.

POST /api/chat           — Send message, get full response
POST /api/chat/stream    — Send message, get SSE stream
"""
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from backend.models import ChatRequest, ChatResponse
from backend.services.agent import agent

router = APIRouter(prefix="/api/chat", tags=["Chat"])


@router.post("", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Send a chat message and receive the AI's complete response.
    
    **Request Body:**
    - `conversation_id`: Unique conversation identifier
    - `messages`: List of chat messages (last one is the user's new message)
    - `mode`: Input mode — "text" | "document" | "email"
    
    **Response:**
    - `message`: AI response with content, type, confidence, recommendations
    - `conversation_id`: Same ID for conversation continuity
    
    **How frontend uses this:**
    The Workflow Studio's right-panel input sends the user's requirement
    here. The backend's LangChain agent analyzes it and returns a workflow
    recommendation that the frontend renders as expandable system cards.
    """
    if not request.messages:
        raise HTTPException(status_code=400, detail="No messages provided")
    
    ai_msg = await agent.chat(request.messages)
    return ChatResponse(message=ai_msg, conversation_id=request.conversation_id)


@router.post("/stream")
async def chat_stream(request: ChatRequest):
    """Send a chat message and receive a streaming SSE response.
    
    **Stream Events:**
    - `type: "token"` — Individual words for typing effect
    - `type: "workflow"` — Complete workflow data when analysis finishes
    - `type: "done"` — Stream complete
    
    **How frontend uses this:**
    The frontend connects via EventSource to show real-time typing
    animation while the agent processes the requirement.
    """
    if not request.messages:
        raise HTTPException(status_code=400, detail="No messages provided")
    
    async def event_generator():
        async for chunk in agent.stream_chat(request.messages):
            yield chunk
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        }
    )
