"""System Knowledge API Router — provides system capability catalog.

GET /api/systems      — List all systems with capabilities
GET /api/systems/{id} — Get single system details
"""
from fastapi import APIRouter, HTTPException
from backend.services.agent import SYSTEM_DB

router = APIRouter(prefix="/api/systems", tags=["System Knowledge"])


@router.get("")
async def list_systems():
    """List all connected systems with their capabilities.
    
    **Response:** Array of system objects, each containing:
    - `name`: System name (QTrack, Transformer, etc.)
    - `capabilities`: List of available capability names
    - `color`: UI color code for the system
    - `description`: One-line system description
    
    **How frontend uses this:**
    The Knowledge page's "System Knowledge" layer uses this to
    populate the system list sidebar. The Canvas also uses this
    to show the "Available Systems" panel for drag-and-drop.
    """
    return [
        {
            "id": key.lower(),
            "name": key,
            "capabilities": val["capabilities"],
            "color": val["color"],
            "description": val["description"],
        }
        for key, val in SYSTEM_DB.items()
    ]


@router.get("/{system_id}")
async def get_system(system_id: str):
    """Get detailed information about a specific system.
    
    **Path Parameter:** `system_id` — System identifier (e.g., "qtrack")
    
    **How frontend uses this:**
    Used by the Canvas detail panel (top-right) when a user clicks
    on a system node. Shows the system's role, capabilities, and
    available actions in the workflow.
    """
    for key, val in SYSTEM_DB.items():
        if key.lower() == system_id.lower():
            return {
                "id": key.lower(),
                "name": key,
                "capabilities": val["capabilities"],
                "color": val["color"],
                "description": val["description"],
            }
    raise HTTPException(status_code=404, detail=f"System {system_id} not found")
