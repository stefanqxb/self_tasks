"""Workflow Analysis API Router — analyzes requirements and recommends workflows.

POST /api/analyze  — Analyze requirement text, return workflow recommendations
"""
from fastapi import APIRouter, HTTPException
from backend.models import AnalyzeRequest, AnalyzeResponse
from backend.services.agent import agent

router = APIRouter(prefix="/api", tags=["Workflow Analysis"])


@router.post("/analyze", response_model=AnalyzeResponse)
async def analyze_workflow(request: AnalyzeRequest):
    """Analyze a business requirement and return recommended workflow.
    
    **Request Body:**
    - `text`: The requirement description (e.g., "Daily trade reconciliation")
    - `mode`: Input type — "text" | "document" | "email"
    - `constraints`: Optional list of constraints
    
    **Response:**
    - `conversation_id`: Unique analysis session ID
    - `summary`: Human-readable analysis summary
    - `recommendations`: List of recommended systems with confidence scores
    - `workflow`: Structured workflow definition
    - `overall_confidence`: Aggregate confidence score
    
    **How frontend uses this:**
    The Workflow Studio's "Analyze" button triggers this endpoint.
    The response populates the system recommendation cards and the
    canvas visualization. The frontend also uses `recommendations`
    to show the SOP matching panel (via /api/sops/match).
    """
    if not request.text or not request.text.strip():
        raise HTTPException(status_code=400, detail="Analysis text is required")
    
    result = agent.analyze(request.text, request.mode)
    return AnalyzeResponse(**result)
