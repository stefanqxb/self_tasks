"""Pydantic models for API request/response schemas.

These models mirror the frontend TypeScript types to ensure
seamless frontend-backend integration.
"""
from pydantic import BaseModel, Field
from typing import List, Optional, Literal
from datetime import datetime


class ChatMessage(BaseModel):
    """A single chat message in the conversation."""
    id: str
    role: Literal["user", "ai"]
    content: str
    type: Literal["text", "workflow", "code", "error"]
    timestamp: str
    confidence: Optional[int] = None
    recommendations: Optional[List[dict]] = None
    workflow: Optional[List[dict]] = None
    editMode: bool = False


class ChatRequest(BaseModel):
    """Request body for sending a chat message."""
    conversation_id: str
    messages: List[ChatMessage]
    mode: Literal["text", "document", "email"] = "text"
    system_id: Optional[str] = None


class ChatResponse(BaseModel):
    """Response from the AI agent for a chat message."""
    message: ChatMessage
    conversation_id: str


class AnalyzeRequest(BaseModel):
    """Request body for workflow requirement analysis."""
    text: str = Field(..., description="User's requirement description")
    mode: Literal["text", "document", "email"] = "text"
    constraints: Optional[List[str]] = None


class SystemRecommendation(BaseModel):
    """A recommended system for a workflow."""
    id: str
    name: str
    confidence: int
    reason: str
    apis: List[str]
    matched_capabilities: List[str]


class AnalyzeResponse(BaseModel):
    """Response containing workflow analysis results."""
    conversation_id: str
    summary: str
    recommendations: List[SystemRecommendation]
    workflow: List[dict]
    overall_confidence: int


class SOPStep(BaseModel):
    """A single step in a SOP workflow."""
    order: int
    title: str
    description: str
    system: str
    action: str
    expected_output: str
    notes: str


class SOPReviewRecord(BaseModel):
    """A review record for a SOP."""
    id: str
    reviewed_at: str
    reviewer: str
    findings: str
    actions: str
    status: Literal["completed", "pending", "overdue"]


class SOPKnowledge(BaseModel):
    """A Process SOP knowledge entry."""
    id: str
    title: str
    description: str
    category: str
    source_workflow: Optional[str] = None
    systems_involved: List[str]
    steps: List[SOPStep]
    best_practices: List[str]
    common_issues: List[str]
    review_history: List[SOPReviewRecord]
    created_at: str
    updated_at: str
    next_review_due: str
    status: Literal["active", "draft", "under-review", "deprecated"]
    owner: str
    tags: List[str]


class CreateSOPRequest(BaseModel):
    """Request to create a new SOP from a workflow."""
    title: str
    description: str
    category: str
    source_workflow: Optional[str] = None
    systems_involved: List[str]
    owner: str
    tags: List[str]


class MatchSOPRequest(BaseModel):
    """Request to find matching SOPs for a given text."""
    text: str = Field(..., min_length=1)
    max_results: int = 3


class MatchSOPResponse(BaseModel):
    """Response containing matching SOPs with scores."""
    matches: List[dict]


class SystemCapability(BaseModel):
    """A system capability definition."""
    id: str
    name: str
    description: str
    exposed_via: str
    input: str
    output: str
    tags: List[str]
    constraints: List[str]


class SystemKnowledge(BaseModel):
    """Knowledge about a connected system."""
    meta: dict
    capabilities: List[SystemCapability]
    endpoints: List[dict]
    documents: List[dict]
    rules: List[dict]


class StreamChunk(BaseModel):
    """A single chunk in a streaming response."""
    type: Literal["token", "workflow", "done", "error"]
    content: str
    data: Optional[dict] = None
