# OPR Backend API

OperAItions Process Register — AI-powered workflow orchestration backend service.

This FastAPI backend powers the OPR frontend's Workflow Studio Chat feature. It simulates a LangChain Deep Agent that analyzes business requirements, recommends optimal system workflows, manages Process SOP Knowledge, and provides real-time streaming chat responses.

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Start the server
uvicorn main:app --reload --port 8000

# 3. Open interactive docs
open http://localhost:8000/docs
```

The API will be available at `http://localhost:8000`.

---

## Project Structure

```
backend/
├── main.py              # FastAPI entry point, CORS, router registration
├── models.py            # Pydantic request/response schemas
├── requirements.txt     # Python dependencies
├── README.md            # This file
├── routers/
│   ├── chat.py          # Chat API (POST /api/chat, /api/chat/stream)
│   ├── workflow.py      # Workflow analysis (POST /api/analyze)
│   ├── sop.py           # SOP management (CRUD + matching)
│   └── systems.py       # System knowledge catalog
└── services/
    └── agent.py         # LangChain Deep Agent simulation
```

---

## API Endpoints

### Chat API

| Endpoint | Method | Description | Frontend Usage |
|----------|--------|-------------|----------------|
| `/api/chat` | `POST` | Send message, get complete AI response | Workflow Studio right-panel input |
| `/api/chat/stream` | `POST` | Send message, get SSE stream (typing effect) | Real-time chat with token-by-token display |

**POST /api/chat** — Request body:
```json
{
  "conversation_id": "conv-001",
  "messages": [
    { "id": "m1", "role": "user", "content": "Daily trade reconciliation", "type": "text", "timestamp": "2026-06-15T09:00:00Z" }
  ],
  "mode": "text"
}
```

**POST /api/chat/stream** — Returns `text/event-stream` with chunks:
- `type: "token"` — Individual words for typing animation
- `type: "workflow"` — Complete workflow data with recommendations
- `type: "done"` — Stream complete

**How frontend connects:** The `src/api/chat.ts` module provides `sendChat()` for full responses and `streamChat()` for SSE streaming. The Workflow Studio's input panel calls `analyzeWorkflow()` (which internally hits `/api/analyze`) when the user clicks "Analyze".

---

### Workflow Analysis API

| Endpoint | Method | Description | Frontend Usage |
|----------|--------|-------------|----------------|
| `/api/analyze` | `POST` | Analyze requirement, return workflow recommendations | "Analyze" button in Workflow Studio |

**POST /api/analyze** — Request body:
```json
{
  "text": "Daily trade reconciliation across multiple systems",
  "mode": "text",
  "constraints": ["Must use existing systems"]
}
```

**Response:**
```json
{
  "conversation_id": "conv-abc123",
  "summary": "Trade reconciliation workflow requiring multi-system orchestration...",
  "recommendations": [
    {
      "id": "rec-1",
      "name": "QTrack",
      "confidence": 98,
      "reason": "Trade file ingestion via email",
      "apis": ["Receive Incoming Email", "Send Notification"],
      "matched_capabilities": ["Email Processing"]
    }
  ],
  "workflow": [
    { "id": "step-1", "system": "QTrack", "action": "receiveEmail", "description": "Receive trade files" }
  ],
  "overall_confidence": 96
}
```

**How frontend connects:** `src/api/workflow.ts` exports `analyzeWorkflow()`. The frontend sends the user's requirement text and renders the returned `recommendations` as expandable system cards and the `workflow` as a canvas visualization.

---

### SOP Management API

| Endpoint | Method | Description | Frontend Usage |
|----------|--------|-------------|----------------|
| `/api/sops` | `GET` | List all SOP knowledge entries | Knowledge page "Process SOP" layer |
| `/api/sops/{id}` | `GET` | Get single SOP details | SOP detail drill-down |
| `/api/sops` | `POST` | Create new SOP | "Save as SOP" dialog |
| `/api/sops/match` | `POST` | Find matching SOPs for text query | Real-time SOP suggestion in input panel |
| `/api/workflows/save` | `POST` | Save workflow as SOP (convenience endpoint) | "Save as SOP Knowledge" button in chat |

**POST /api/sops/match** — Request body:
```json
{
  "text": "trade reconciliation",
  "max_results": 3
}
```

**Response:**
```json
{
  "matches": [
    {
      "sop": { /* full SOPKnowledge object */ },
      "score": 4,
      "matched_systems": ["QTrack"]
    }
  ]
}
```

**Scoring Algorithm:**
- Title match: 3 pts | Category match: 2 pts | Tag match: 2 pts
- Description match: 1 pt | System name match: 1 pt

**How frontend connects:** `src/api/sop.ts` exports `matchSOPs()`. The Workflow Studio's input panel calls this in real-time (when >=5 chars typed) to show "Matching SOPs" suggestions below the text area.

---

### System Knowledge API

| Endpoint | Method | Description | Frontend Usage |
|----------|--------|-------------|----------------|
| `/api/systems` | `GET` | List all systems with capabilities | Knowledge page system list + Canvas sidebar |
| `/api/systems/{id}` | `GET` | Get single system details | Canvas node detail panel |

**Response (GET /api/systems):**
```json
[
  {
    "id": "qtrack",
    "name": "QTrack",
    "capabilities": ["Receive Incoming Email", "Send Reply Email", "Auto Draft Email", "Summarize Email", "Translate Email"],
    "color": "#6366F1",
    "description": "Email processing and prioritization system"
  }
]
```

**How frontend connects:** `src/api/systems.ts` exports `listSystems()` and `getSystem()`. The Canvas sidebar uses `listSystems()` to populate the "Available Systems" drag panel. The node detail panel uses `getSystem()` to show role descriptions.

---

### Health Check

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | `GET` | Root — service info + docs link |
| `/api/health` | `GET` | Detailed health status with agent state |

---

## LangChain Deep Agent Architecture

The `WorkflowAgent` class in `services/agent.py` simulates a LangChain-based AI agent:

```
User Input
    |
    v
Intent Detection (keyword-based matching)
    |
    v
Capability Query (SYSTEM_DB lookup)
    |
    v
Workflow Generation (template-based orchestration)
    |
    v
Response Assembly (structured ChatMessage/AnalyzeResponse)
```

### Intent Detection
The agent detects intent from keywords in the user's text:

| Keywords | Intent | Systems Recommended |
|----------|--------|-------------------|
| "reconcile", "trade", "match", "position" | Trade Reconciliation | QTrack → GoldenEye → SWB → SIRE |
| "invoice", "payment", "bill", "vendor" | Invoice Processing | QTrack → SWB → Transformer → OPAS |
| "monitor", "status", "alert", "check" | Payment Monitoring | OPAS → SIRE |
| "report", "summary", "consolidate" | Report Generation | GoldenEye → Transformer → SWB |

### Production Migration
To replace the simulated agent with a real LangChain agent:

1. **Install LangChain:**
   ```bash
   pip install langchain langgraph langchain-openai
   ```

2. **Replace `WorkflowAgent` methods:**
   - `chat()` → LangGraph agent with memory
   - `analyze()` → Structured output chain with capability retrieval
   - `match_sops()` → Vector similarity search (ChromaDB/Pinecone)
   - `stream_chat()` → LangChain streaming with astream_events

3. **Add vector store:**
   ```python
   from langchain_chroma import Chroma
   from langchain_openai import OpenAIEmbeddings
   
   vectorstore = Chroma(
       collection_name="capabilities",
       embedding_function=OpenAIEmbeddings(),
   )
   ```

---

## Data Models

### System Database (`SYSTEM_DB`)
6 registered systems with capabilities, colors, and descriptions. See `services/agent.py` for full schema.

### SOP Database (`SOP_DB`)
3 pre-loaded SOPs (in-memory, resets on restart):
1. **Daily Trade Reconciliation Workflow** — QTrack → GoldenEye → SWB → SIRE
2. **Invoice Processing Pipeline** — QTrack → SWB → Transformer → OPAS
3. **Payment Status Monitoring** — OPAS → SIRE

### Conversation State
Conversations are stateless — the frontend maintains message history and sends the full `messages[]` array with each request. The backend only processes the last message in context.

---

## CORS Configuration

The backend allows requests from these origins:
- `http://localhost:5173` — Vite dev server
- `http://localhost:4173` — Vite preview
- `http://localhost:3000` — Common React dev port

To add production origins, edit `main.py`:
```python
allow_origins=[
    "http://localhost:5173",
    "https://your-production-domain.com",
]
```

---

## Frontend Integration

The frontend API client lives in `/app/src/api/`:

```
src/api/
├── config.ts     # API_BASE_URL, endpoint constants
├── client.ts     # HTTP client (fetch wrapper + SSE streaming)
├── types.ts      # TypeScript types (mirror of Pydantic models)
├── chat.ts       # Chat API functions
├── workflow.ts   # Workflow analysis functions
├── sop.ts        # SOP management functions
├── systems.ts    # System knowledge functions
└── index.ts      # Barrel export
```

### Environment Setup

Create `.env` in `/app/`:
```env
VITE_API_BASE_URL=http://localhost:8000
```

### Example Usage

```tsx
import { sendChat, matchSOPs, analyzeWorkflow } from '@/api';

// Send requirement and get AI analysis
const result = await analyzeWorkflow({
  text: 'Daily trade reconciliation',
  mode: 'text',
});

// Get real-time SOP suggestions as user types
const { matches } = await matchSOPs(inputText, 3);

// Stream chat for typing effect
for await (const chunk of streamChat({ conversation_id, messages, mode: 'text' })) {
  if (chunk.type === 'token') setText(prev => prev + chunk.content);
  if (chunk.type === 'workflow') setWorkflow(chunk.data!.workflow);
}
```

---

## Development

```bash
# Run with auto-reload
uvicorn main:app --reload --port 8000

# Run tests (when added)
pytest

# Lint
ruff check .

# Format
ruff format .
```

---

## License

Internal use only — OperAItions Process Register (OPR)
