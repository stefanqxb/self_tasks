"""OPR Backend — FastAPI application entry point.

This is the main FastAPI application that serves the Workflow Studio
Chat backend, including:
- Chat API with streaming support
- Workflow requirement analysis
- SOP management (CRUD + matching)
- System knowledge retrieval

## Quick Start
```bash
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

The API will be available at http://localhost:8000
Interactive docs at http://localhost:8000/docs
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.routers import chat, workflow, sop, systems

app = FastAPI(
    title="OPR Backend API",
    description="OperAItions Process Register — AI-powered workflow orchestration backend",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ─── CORS ──────────────────────────────────────────────────────────────────
# Allow the React frontend (Vite dev server on :5173 or production build)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",   # Vite dev server
        "http://localhost:4173",   # Vite preview
        "http://localhost:3000",   # Common React dev port
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Routers ───────────────────────────────────────────────────────────────
app.include_router(chat.router)
app.include_router(workflow.router)
app.include_router(sop.router)
app.include_router(systems.router)


@app.get("/")
async def root():
    """Health check endpoint."""
    return {
        "service": "OPR Backend API",
        "version": "1.0.0",
        "status": "healthy",
        "docs": "/docs",
    }


@app.get("/api/health")
async def health():
    """Detailed health check with agent status."""
    return {
        "status": "healthy",
        "agent": "WorkflowAgent initialized",
        "sops_loaded": 3,
        "systems_registered": 6,
    }
