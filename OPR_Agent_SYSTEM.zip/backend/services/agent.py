"""LangChain Deep Agent service for workflow analysis.

This module simulates a LangChain-based AI agent that:
1. Processes user requirements
2. Analyzes them against available system capabilities
3. Recommends optimal workflow orchestrations
4. Generates structured workflow definitions

In production, this would connect to a real LangChain agent
with vector store retrieval for capability matching.
"""
import json
import uuid
from typing import List, Dict, Any, AsyncGenerator
import asyncio

from backend.models import (
    ChatMessage, SystemRecommendation, SOPKnowledge, SOPStep
)


# ─── System Capability Database (mock) ────────────────────────────────────

SYSTEM_DB = {
    "QTrack": {
        "capabilities": [
            "Receive Incoming Email", "Send Reply Email", "Auto Draft Email",
            "Summarize Email", "Translate Email", "Send Notification"
        ],
        "color": "#6366F1",
        "description": "Email processing and prioritization system"
    },
    "GoldenEye": {
        "capabilities": [
            "Load Positions", "Validate Positions", "Generate Position Report"
        ],
        "color": "#F97316",
        "description": "Trade lifecycle and position management"
    },
    "SWB": {
        "capabilities": [
            "Extract Data from PDF", "Extract Invoice Data",
            "Extract Settlement Details", "OCR Document Processing"
        ],
        "color": "#F59E0B",
        "description": "Document extraction and entity recognition"
    },
    "SIRE": {
        "capabilities": [
            "Reconcile Batch", "Check Exceptions", "Generate Break Report",
            "Validate Referential Integrity"
        ],
        "color": "#8B5CF6",
        "description": "Reconciliation and break management"
    },
    "OPAS": {
        "capabilities": [
            "Query Payment Status", "Submit Payment", "Retry Failed Payment",
            "Check Settlement Status"
        ],
        "color": "#0EA5E9",
        "description": "Payment and settlement tracking"
    },
    "Transformer": {
        "capabilities": [
            "Flow Recommendation", "Flow Listing", "Flow Summary",
            "USD Payment Threshold Screening", "JPY Position Netting",
            "Transform Excel", "Transform PDF"
        ],
        "color": "#14B8A6",
        "description": "Data transformation and flow orchestration"
    },
}

# ─── SOP Database (mock, in-memory) ───────────────────────────────────────

SOP_DB: List[SOPKnowledge] = []


def init_sop_db():
    """Initialize the SOP database with sample entries."""
    global SOP_DB
    SOP_DB = [
        SOPKnowledge(
            id="sop-001",
            title="Daily Trade Reconciliation Workflow",
            description="Standard operating procedure for daily trade reconciliation across QTrack, GoldenEye, SWB, and SIRE systems.",
            category="Reconciliation",
            source_workflow="Daily Trade Reconciliation",
            systems_involved=["QTrack", "GoldenEye", "SWB", "SIRE"],
            steps=[
                SOPStep(order=1, title="Retrieve Trade Files", description="Pull trade data from upstream systems via QTrack", system="QTrack", action="receiveEmail", expected_output="Trade file attachment received", notes="Check for missing files before 9:00 AM"),
                SOPStep(order=2, title="Load to GoldenEye", description="Import trade records into GoldenEye", system="GoldenEye", action="importPositions", expected_output="Positions loaded with status VALID", notes="Validate date format"),
                SOPStep(order=3, title="SWB Document Extraction", description="Extract settlement details from SWB", system="SWB", action="extractSettlement", expected_output="Structured settlement data", notes="Handle PDF and XML formats"),
                SOPStep(order=4, title="SIRE Reconciliation", description="Run automated reconciliation at SIRE", system="SIRE", action="reconcileBatch", expected_output="Break report with match rate > 95%", notes="Escalate if match rate < 90%"),
                SOPStep(order=5, title="QTrack Notification", description="Send completion notification via QTrack", system="QTrack", action="sendNotification", expected_output="Email sent to operations team", notes="Include break summary"),
            ],
            best_practices=["Always run pre-validation on trade files", "Monitor SWB extraction queue depth", "Schedule during off-peak hours"],
            common_issues=["Date format mismatch", "Large batch may timeout", "QTrack email delivery delay"],
            review_history=[],
            created_at="2026-01-10",
            updated_at="2026-04-15",
            next_review_due="2026-07-15",
            status="active",
            owner="Operations Team",
            tags=["trade", "reconciliation", "daily", "critical"]
        ),
        SOPKnowledge(
            id="sop-002",
            title="Invoice Processing Pipeline",
            description="End-to-end SOP for processing vendor invoices through QTrack, SWB, Transformer, and OPAS.",
            category="Payment Processing",
            source_workflow="Invoice Processing Pipeline",
            systems_involved=["QTrack", "SWB", "Transformer", "OPAS"],
            steps=[
                SOPStep(order=1, title="Invoice Receipt", description="Receive vendor invoices via QTrack", system="QTrack", action="receiveInvoice", expected_output="Invoice email with PDF attachment", notes="Auto-prioritize by vendor SLA"),
                SOPStep(order=2, title="SWB Data Extraction", description="Extract invoice data from PDF", system="SWB", action="extractInvoice", expected_output="JSON with invoice fields", notes="Validate against vendor master data"),
                SOPStep(order=3, title="Transformer Formatting", description="Transform extracted data to OPAS format", system="Transformer", action="transformToPayment", expected_output="OPAS-compatible payment payload", notes="Map currency codes"),
                SOPStep(order=4, title="OPAS Payment Submission", description="Submit payment batch to OPAS", system="OPAS", action="submitPayment", expected_output="Payment batch accepted", notes="Verify payment limits"),
                SOPStep(order=5, title="QTrack Confirmation", description="Send payment confirmation via QTrack", system="QTrack", action="sendReplyEmail", expected_output="Confirmation email delivered", notes="Attach payment reference"),
            ],
            best_practices=["Pre-validate vendor against approved list", "Use Transformer templates", "Enable dual-approval for >$50K"],
            common_issues=["Handwritten invoices fail OCR", "Currency mismatch", "Duplicate payment detection"],
            review_history=[],
            created_at="2026-02-20",
            updated_at="2026-05-01",
            next_review_due="2026-08-01",
            status="active",
            owner="Finance Team",
            tags=["invoice", "payment", "vendor", "pipeline"]
        ),
        SOPKnowledge(
            id="sop-003",
            title="Payment Status Monitoring",
            description="SOP for monitoring payment settlement status across OPAS and SIRE.",
            category="Monitoring",
            source_workflow="Payment Status Monitoring",
            systems_involved=["OPAS", "SIRE"],
            steps=[
                SOPStep(order=1, title="OPAS Status Query", description="Query payment batch status from OPAS", system="OPAS", action="queryStatus", expected_output="Status: SETTLED or PENDING", notes="Use webhook for real-time updates"),
                SOPStep(order=2, title="SIRE Exception Check", description="Check for settlement breaks in SIRE", system="SIRE", action="checkExceptions", expected_output="Exception count (0 = all clear)", notes="Alert if exceptions > 5 in 1 hour"),
                SOPStep(order=3, title="Auto-Retry Logic", description="Retry failed payments with exponential backoff", system="OPAS", action="retryFailed", expected_output="Retry scheduled", notes="Max retry interval: 30 minutes"),
            ],
            best_practices=["Configure OPAS webhook", "Set SIRE alert threshold", "Document manual interventions"],
            common_issues=["OPAS API rate limit", "SIRE lag in reflecting data"],
            review_history=[],
            created_at="2026-03-01",
            updated_at="2026-03-01",
            next_review_due="2026-06-01",
            status="under-review",
            owner="Payment Ops",
            tags=["payment", "monitoring", "status", "alerting"]
        ),
    ]


# ─── Agent Service ────────────────────────────────────────────────────────

class WorkflowAgent:
    """Simulates a LangChain Deep Agent for workflow analysis.
    
    In production, this would use:
    - LangChain/LangGraph for agent orchestration
    - Vector store (ChromaDB/Pinecone) for capability retrieval
    - LLM (GPT-4/Claude) for reasoning and generation
    """

    def __init__(self):
        init_sop_db()

    async def chat(self, messages: List[ChatMessage]) -> ChatMessage:
        """Process a chat message and return AI response.
        
        Simulates an AI agent that:
        1. Understands the user's requirement
        2. Analyzes available system capabilities
        3. Generates appropriate workflow recommendations
        """
        await asyncio.sleep(0.5)  # Simulate processing latency
        
        last_msg = messages[-1]
        content_lower = last_msg.content.lower()
        
        # Detect intent
        if any(kw in content_lower for kw in ["reconcil", "trade", "match"]):
            return self._generate_trade_recon_response(last_msg)
        elif any(kw in content_lower for kw in ["invoice", "payment", "bill"]):
            return self._generate_invoice_response(last_msg)
        elif any(kw in content_lower for kw in ["monitor", "status", "alert"]):
            return self._generate_monitoring_response(last_msg)
        elif any(kw in content_lower for kw in ["report", "position", "monthly"]):
            return self._generate_report_response(last_msg)
        else:
            return self._generate_generic_response(last_msg)

    async def stream_chat(self, messages: List[ChatMessage]) -> AsyncGenerator[str, None]:
        """Stream chat response as SSE events.
        
        Yields JSON-encoded StreamChunk objects for real-time
        frontend display (typing effect + workflow data).
        """
        last_msg = messages[-1]
        content_lower = last_msg.content.lower()
        
        # Determine response type
        if any(kw in content_lower for kw in ["reconcil", "trade", "match"]):
            response = self._generate_trade_recon_response(last_msg)
        elif any(kw in content_lower for kw in ["invoice", "payment", "bill"]):
            response = self._generate_invoice_response(last_msg)
        elif any(kw in content_lower for kw in ["monitor", "status", "alert"]):
            response = self._generate_monitoring_response(last_msg)
        elif any(kw in content_lower for kw in ["report", "position", "monthly"]):
            response = self._generate_report_response(last_msg)
        else:
            response = self._generate_generic_response(last_msg)
        
        # Stream text content token by token
        words = response.content.split(" ")
        for word in words:
            chunk = json.dumps({
                "type": "token",
                "content": word + " ",
                "data": None
            })
            yield f"data: {chunk}\n\n"
            await asyncio.sleep(0.03)  # Typing speed
        
        # Stream workflow data if present
        if response.recommendations:
            chunk = json.dumps({
                "type": "workflow",
                "content": "",
                "data": {
                    "recommendations": [r.model_dump() for r in response.recommendations],
                    "workflow": response.workflow,
                    "confidence": response.confidence
                }
            })
            yield f"data: {chunk}\n\n"
        
        # Done
        yield f"data: {json.dumps({'type': 'done', 'content': '', 'data': None})}\n\n"

    def analyze(self, text: str, mode: str = "text") -> dict:
        """Analyze a requirement and return workflow recommendations.
        
        This is the core LangChain agent logic that would:
        1. Parse the requirement using NLP
        2. Query vector store for matching capabilities
        3. Score system combinations
        4. Generate optimal workflow
        """
        text_lower = text.lower()
        
        if any(kw in text_lower for kw in ["reconcil", "trade", "match", "position"]):
            return self._analyze_trade_recon(text, mode)
        elif any(kw in text_lower for kw in ["invoice", "payment", "bill", "vendor"]):
            return self._analyze_invoice(text, mode)
        elif any(kw in text_lower for kw in ["monitor", "status", "alert", "check"]):
            return self._analyze_monitoring(text, mode)
        elif any(kw in text_lower for kw in ["report", "summary", "consolidat"]):
            return self._analyze_report(text, mode)
        else:
            return self._analyze_generic(text, mode)

    def match_sops(self, text: str, max_results: int = 3) -> List[dict]:
        """Find matching SOPs based on text similarity.
        
        Scoring:
        - Title match: 3 pts
        - Category match: 2 pts
        - Tag match: 2 pts
        - Description match: 1 pt
        - System match: 1 pt
        """
        query = text.lower()
        scored = []
        
        for sop in SOP_DB:
            score = 0
            if query in sop.title.lower():
                score += 3
            if query in sop.category.lower():
                score += 2
            if any(query in t.lower() for t in sop.tags):
                score += 2
            if query in sop.description.lower():
                score += 1
            if any(query in s.lower() for s in sop.systems_involved):
                score += 1
            
            if score > 0:
                scored.append({
                    "sop": sop.model_dump(),
                    "score": score,
                    "matched_systems": [s for s in sop.systems_involved if query in s.lower()]
                })
        
        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:max_results]

    # ─── Internal Response Generators ──────────────────────────────────────

    def _generate_trade_recon_response(self, msg: ChatMessage) -> ChatMessage:
        """Generate response for trade reconciliation queries."""
        return ChatMessage(
            id=f"ai-{uuid.uuid4().hex[:8]}",
            role="ai",
            content=(
                "I've analyzed your trade reconciliation requirement. Based on the OPR system catalog, "
                "I recommend a 4-system pipeline: QTrack → GoldenEye → SWB → SIRE.\n\n"
                "**Pipeline Flow:**\n"
                "1. **QTrack** receives trade files via email notifications\n"
                "2. **GoldenEye** loads and validates position data\n"
                "3. **SWB** extracts settlement details from confirmation documents\n"
                "4. **SIRE** runs automated reconciliation and generates break reports\n\n"
                "**Key Capabilities Used:**\n"
                "- QTrack: Receive Incoming Email, Send Notification\n"
                "- GoldenEye: Load Positions, Validate Positions\n"
                "- SWB: Extract Settlement Details, OCR Processing\n"
                "- SIRE: Reconcile Batch, Generate Break Report\n\n"
                "**Confidence: 96%** — This is a well-established pattern in the system catalog.\n\n"
                "Would you like me to refine this workflow or explore alternative approaches?"
            ),
            type="workflow",
            timestamp=datetime.now().isoformat(),
            confidence=96,
            recommendations=[
                SystemRecommendation(
                    id="rec-1", name="QTrack", confidence=98,
                    reason="Trade file ingestion via email — primary entry point",
                    apis=["Receive Incoming Email", "Send Notification"],
                    matched_capabilities=["Email Processing"]
                ),
                SystemRecommendation(
                    id="rec-2", name="GoldenEye", confidence=95,
                    reason="Position loading and validation before reconciliation",
                    apis=["Load Positions", "Validate Positions"],
                    matched_capabilities=["Position Management"]
                ),
                SystemRecommendation(
                    id="rec-3", name="SWB", confidence=94,
                    reason="Settlement detail extraction from trade confirmations",
                    apis=["Extract Settlement Details"],
                    matched_capabilities=["Document Extraction"]
                ),
                SystemRecommendation(
                    id="rec-4", name="SIRE", confidence=97,
                    reason="Core reconciliation engine — matches trades vs settlements",
                    apis=["Reconcile Batch", "Generate Break Report"],
                    matched_capabilities=["Reconciliation"]
                ),
            ],
            workflow=[
                {"id": "step-1", "system": "QTrack", "action": "receiveEmail", "description": "Receive trade files"},
                {"id": "step-2", "system": "GoldenEye", "action": "importPositions", "description": "Load and validate positions"},
                {"id": "step-3", "system": "SWB", "action": "extractSettlement", "description": "Extract settlement details"},
                {"id": "step-4", "system": "SIRE", "action": "reconcileBatch", "description": "Run reconciliation"},
            ]
        )

    def _generate_invoice_response(self, msg: ChatMessage) -> ChatMessage:
        """Generate response for invoice processing queries."""
        return ChatMessage(
            id=f"ai-{uuid.uuid4().hex[:8]}",
            role="ai",
            content=(
                "I've designed an invoice processing pipeline using QTrack → SWB → Transformer → OPAS.\n\n"
                "**Pipeline Flow:**\n"
                "1. **QTrack** receives vendor invoices via email ingestion\n"
                "2. **SWB** extracts invoice data (header, line items, totals) from PDF\n"
                "3. **Transformer** formats extracted data to OPAS payment format\n"
                "4. **OPAS** submits payment batch and tracks settlement\n\n"
                "**Confidence: 94%**\n\n"
                "Key considerations: vendor pre-validation, currency mapping, and dual-approval for amounts >$50K."
            ),
            type="workflow",
            timestamp=datetime.now().isoformat(),
            confidence=94,
            recommendations=[
                SystemRecommendation(id="rec-1", name="QTrack", confidence=97, reason="Invoice receipt via email", apis=["Receive Incoming Email"], matched_capabilities=["Email Processing"]),
                SystemRecommendation(id="rec-2", name="SWB", confidence=95, reason="PDF data extraction", apis=["Extract Invoice Data"], matched_capabilities=["Document Extraction"]),
                SystemRecommendation(id="rec-3", name="Transformer", confidence=92, reason="Format transformation", apis=["Transform Excel", "Transform PDF"], matched_capabilities=["Data Transformation"]),
                SystemRecommendation(id="rec-4", name="OPAS", confidence=96, reason="Payment submission and tracking", apis=["Submit Payment", "Query Payment Status"], matched_capabilities=["Payment Processing"]),
            ],
            workflow=[
                {"id": "step-1", "system": "QTrack", "action": "receiveInvoice", "description": "Receive invoices"},
                {"id": "step-2", "system": "SWB", "action": "extractInvoice", "description": "Extract invoice data"},
                {"id": "step-3", "system": "Transformer", "action": "transformToPayment", "description": "Format for OPAS"},
                {"id": "step-4", "system": "OPAS", "action": "submitPayment", "description": "Submit payment"},
            ]
        )

    def _generate_monitoring_response(self, msg: ChatMessage) -> ChatMessage:
        """Generate response for monitoring queries."""
        return ChatMessage(
            id=f"ai-{uuid.uuid4().hex[:8]}",
            role="ai",
            content="I recommend a monitoring workflow using OPAS → SIRE for payment status tracking with automated retry logic and alerting.",
            type="workflow",
            timestamp=datetime.now().isoformat(),
            confidence=91,
            recommendations=[
                SystemRecommendation(id="rec-1", name="OPAS", confidence=94, reason="Payment status queries", apis=["Query Payment Status", "Retry Failed Payment"], matched_capabilities=["Payment Tracking"]),
                SystemRecommendation(id="rec-2", name="SIRE", confidence=88, reason="Exception detection", apis=["Check Exceptions"], matched_capabilities=["Break Management"]),
            ],
            workflow=[
                {"id": "step-1", "system": "OPAS", "action": "queryStatus", "description": "Query payment status"},
                {"id": "step-2", "system": "SIRE", "action": "checkExceptions", "description": "Check exceptions"},
                {"id": "step-3", "system": "OPAS", "action": "retryFailed", "description": "Retry failed payments"},
            ]
        )

    def _generate_report_response(self, msg: ChatMessage) -> ChatMessage:
        """Generate response for report generation queries."""
        return ChatMessage(
            id=f"ai-{uuid.uuid4().hex[:8]}",
            role="ai",
            content="For position reporting, I recommend GoldenEye → Transformer → SWB pipeline to consolidate, format, and distribute reports.",
            type="workflow",
            timestamp=datetime.now().isoformat(),
            confidence=89,
            recommendations=[
                SystemRecommendation(id="rec-1", name="GoldenEye", confidence=93, reason="Position data aggregation", apis=["Generate Position Report"], matched_capabilities=["Position Management"]),
                SystemRecommendation(id="rec-2", name="Transformer", confidence=87, reason="Report formatting", apis=["Flow Summary"], matched_capabilities=["Data Transformation"]),
                SystemRecommendation(id="rec-3", name="SWB", confidence=85, reason="Document generation", apis=["Transform PDF"], matched_capabilities=["Document Processing"]),
            ],
            workflow=[
                {"id": "step-1", "system": "GoldenEye", "action": "generateReport", "description": "Aggregate positions"},
                {"id": "step-2", "system": "Transformer", "action": "formatReport", "description": "Format report"},
                {"id": "step-3", "system": "SWB", "action": "generatePDF", "description": "Generate PDF"},
            ]
        )

    def _generate_generic_response(self, msg: ChatMessage) -> ChatMessage:
        """Generate generic response for unrecognized queries."""
        return ChatMessage(
            id=f"ai-{uuid.uuid4().hex[:8]}",
            role="ai",
            content=(
                f"I've received your request: \"{msg.content}\".\n\n"
                "To provide the most accurate workflow recommendation, could you clarify:\n"
                "- What type of business process is this? (e.g., reconciliation, payment, reporting)\n"
                "- What data sources are involved? (e.g., emails, Excel files, APIs)\n"
                "- Are there any specific systems you prefer or need to avoid?\n\n"
                "Alternatively, I can use the Transformer Flow Recommendation engine to analyze your requirement "
                "and suggest the optimal system orchestration."
            ),
            type="text",
            timestamp=datetime.now().isoformat(),
            confidence=0,
            recommendations=None
        )

    # ─── Analysis Generators ──────────────────────────────────────────────

    def _analyze_trade_recon(self, text: str, mode: str) -> dict:
        """Generate full analysis for trade reconciliation."""
        return {
            "conversation_id": f"conv-{uuid.uuid4().hex[:6]}",
            "summary": "Trade reconciliation workflow requiring multi-system orchestration for daily position matching.",
            "recommendations": [
                {"id": "rec-1", "name": "QTrack", "confidence": 98, "reason": "Trade file ingestion", "apis": ["Receive Incoming Email"], "matched_capabilities": ["Email Processing"]},
                {"id": "rec-2", "name": "GoldenEye", "confidence": 95, "reason": "Position validation", "apis": ["Load Positions", "Validate Positions"], "matched_capabilities": ["Position Management"]},
                {"id": "rec-3", "name": "SWB", "confidence": 94, "reason": "Settlement extraction", "apis": ["Extract Settlement Details"], "matched_capabilities": ["Document Extraction"]},
                {"id": "rec-4", "name": "SIRE", "confidence": 97, "reason": "Reconciliation engine", "apis": ["Reconcile Batch"], "matched_capabilities": ["Reconciliation"]},
            ],
            "workflow": [
                {"id": "step-1", "system": "QTrack", "action": "receiveEmail", "description": "Receive trade files"},
                {"id": "step-2", "system": "GoldenEye", "action": "importPositions", "description": "Load positions"},
                {"id": "step-3", "system": "SWB", "action": "extractSettlement", "description": "Extract settlement"},
                {"id": "step-4", "system": "SIRE", "action": "reconcileBatch", "description": "Run reconciliation"},
            ],
            "overall_confidence": 96
        }

    def _analyze_invoice(self, text: str, mode: str) -> dict:
        """Generate full analysis for invoice processing."""
        return {
            "conversation_id": f"conv-{uuid.uuid4().hex[:6]}",
            "summary": "Invoice processing pipeline from receipt to payment settlement.",
            "recommendations": [
                {"id": "rec-1", "name": "QTrack", "confidence": 97, "reason": "Invoice receipt", "apis": ["Receive Incoming Email"], "matched_capabilities": ["Email Processing"]},
                {"id": "rec-2", "name": "SWB", "confidence": 95, "reason": "Data extraction", "apis": ["Extract Invoice Data"], "matched_capabilities": ["Document Extraction"]},
                {"id": "rec-3", "name": "Transformer", "confidence": 92, "reason": "Format transformation", "apis": ["Transform Excel"], "matched_capabilities": ["Data Transformation"]},
                {"id": "rec-4", "name": "OPAS", "confidence": 96, "reason": "Payment processing", "apis": ["Submit Payment"], "matched_capabilities": ["Payment Processing"]},
            ],
            "workflow": [
                {"id": "step-1", "system": "QTrack", "action": "receiveInvoice", "description": "Receive invoices"},
                {"id": "step-2", "system": "SWB", "action": "extractInvoice", "description": "Extract data"},
                {"id": "step-3", "system": "Transformer", "action": "transformToPayment", "description": "Format data"},
                {"id": "step-4", "system": "OPAS", "action": "submitPayment", "description": "Submit payment"},
            ],
            "overall_confidence": 94
        }

    def _analyze_monitoring(self, text: str, mode: str) -> dict:
        """Generate full analysis for payment monitoring."""
        return {
            "conversation_id": f"conv-{uuid.uuid4().hex[:6]}",
            "summary": "Real-time payment monitoring with automated retry and exception handling.",
            "recommendations": [
                {"id": "rec-1", "name": "OPAS", "confidence": 94, "reason": "Status queries", "apis": ["Query Payment Status", "Retry Failed Payment"], "matched_capabilities": ["Payment Tracking"]},
                {"id": "rec-2", "name": "SIRE", "confidence": 88, "reason": "Exception detection", "apis": ["Check Exceptions"], "matched_capabilities": ["Break Management"]},
            ],
            "workflow": [
                {"id": "step-1", "system": "OPAS", "action": "queryStatus", "description": "Query status"},
                {"id": "step-2", "system": "SIRE", "action": "checkExceptions", "description": "Check exceptions"},
            ],
            "overall_confidence": 91
        }

    def _analyze_report(self, text: str, mode: str) -> dict:
        """Generate full analysis for report generation."""
        return {
            "conversation_id": f"conv-{uuid.uuid4().hex[:6]}",
            "summary": "Position report consolidation and distribution pipeline.",
            "recommendations": [
                {"id": "rec-1", "name": "GoldenEye", "confidence": 93, "reason": "Data aggregation", "apis": ["Generate Position Report"], "matched_capabilities": ["Position Management"]},
                {"id": "rec-2", "name": "Transformer", "confidence": 87, "reason": "Report formatting", "apis": ["Flow Summary"], "matched_capabilities": ["Data Transformation"]},
            ],
            "workflow": [
                {"id": "step-1", "system": "GoldenEye", "action": "generateReport", "description": "Aggregate data"},
                {"id": "step-2", "system": "Transformer", "action": "formatReport", "description": "Format output"},
            ],
            "overall_confidence": 89
        }

    def _analyze_generic(self, text: str, mode: str) -> dict:
        """Generate generic analysis for unrecognized requirements."""
        return {
            "conversation_id": f"conv-{uuid.uuid4().hex[:6]}",
            "summary": f"Requirement received: '{text[:100]}...'. More context needed for precise recommendation.",
            "recommendations": [],
            "workflow": [],
            "overall_confidence": 0
        }


# ─── Singleton Instance ───────────────────────────────────────────────────

agent = WorkflowAgent()
