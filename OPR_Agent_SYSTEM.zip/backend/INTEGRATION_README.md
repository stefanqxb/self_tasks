# OPR 前后端集成指南

本文档详细介绍前端如何调用后端 API，以及前后端之间的数据流转方式。

---

## 项目结构

### 前端 (`/mnt/agents/output/app/`)

```
src/api/
├── config.ts      # API 地址配置
├── client.ts      # HTTP 底层封装（fetch + SSE）
├── types.ts       # 类型定义（与后端 Pydantic 模型对应）
├── chat.ts        # 聊天 API
├── workflow.ts    # 工作流分析 API
├── sop.ts         # SOP 管理 API
├── systems.ts     # 系统知识 API
└── index.ts       # 统一导出
```

### 后端 (`/mnt/agents/output/backend/`)

```
├── main.py              # FastAPI 入口 + CORS + 路由注册
├── models.py            # Pydantic 请求/响应模型
├── requirements.txt     # Python 依赖
├── routers/
│   ├── chat.py          # Chat API（POST /api/chat + /api/chat/stream）
│   ├── workflow.py      # 工作流分析（POST /api/analyze）
│   ├── sop.py           # SOP 管理（CRUD + matching）
│   └── systems.py       # 系统知识目录
└── services/
    └── agent.py         # LangChain Deep Agent 模拟
```

---

## 1. 配置层：`config.ts`

```typescript
// 后端地址，默认 localhost:8000，可通过 .env 覆盖
export const API_BASE_URL = 
  import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000';
```

前端启动时设置环境变量：
```bash
# app/.env
VITE_API_BASE_URL=http://localhost:8000
```

---

## 2. HTTP 底层：`client.ts`

封装了三种请求方式：

| 函数 | 用途 | 调用后端 |
|------|------|---------|
| `get<T>(path)` | GET 请求 | `fetch(`${BASE}${path}`)` |
| `post<T>(path, body)` | POST 请求 | `fetch` + `JSON.stringify(body)` |
| `streamPost(path, body)` | SSE 流式请求 | `fetch` + `ReadableStream` 逐字读取 |

### 流式读取（Chat 打字效果）

```typescript
// 使用 AsyncGenerator 逐块读取 SSE 数据
for await (const chunk of streamPost('/api/chat/stream', request)) {
  // chunk = "data: {type:'token', content:'Hello'}"
  const data = JSON.parse(chunk);
}
```

### 错误处理

统一抛出 `APIError`，包含 `status` + `detail` + `message`：

```typescript
try {
  const result = await analyzeWorkflow({ text: '...' });
} catch (err) {
  if (err instanceof APIError) {
    console.error(`API ${err.status}: ${err.detail}`);
  }
}
```

---

## 3. 类型定义：`types.ts`

TypeScript 接口与后端 Pydantic 模型一一对应：

| 后端模型 | 前端接口 | 用途 |
|---------|---------|------|
| `ChatMessage` | `ChatMessage` | 聊天消息 |
| `SystemRecommendation` | `SystemRecommendation` | 系统推荐 |
| `AnalyzeResponse` | `AnalyzeResponse` | 分析结果 |
| `SOPKnowledge` | `SOPKnowledge` | SOP 知识 |
| `SystemInfo` | `SystemInfo` | 系统信息 |

---

## 4. 业务 API 层

### 4.1 Chat API（`chat.ts`）

```typescript
// 完整响应（一次性返回）
const response = await sendChat({
  conversation_id: 'conv-001',
  messages: [...],     // 完整对话历史
  mode: 'text',        // text | document | email
});
// → { message: ChatMessage, conversation_id: string }

// 流式响应（打字效果，逐字返回）
for await (const chunk of streamChat(request)) {
  if (chunk.type === 'token') setText(prev => prev + chunk.content);
  if (chunk.type === 'workflow') setWorkflow(chunk.data!.workflow);
  if (chunk.type === 'done') setLoading(false);
}
```

**对应后端端点**：
- `POST /api/chat` — `sendChat()`
- `POST /api/chat/stream` — `streamChat()`（SSE）

---

### 4.2 Workflow API（`workflow.ts`）

```typescript
// 分析需求，获取推荐工作流
const result = await analyzeWorkflow({
  text: 'Daily trade reconciliation',
  mode: 'text',
});
// → { summary, recommendations, workflow, overall_confidence }

// 保存工作流为 SOP
const sop = await saveWorkflowAsSOP({
  title: 'Trade Recon SOP',
  description: '...',
  systems_involved: ['QTrack', 'SIRE'],
  owner: 'Ops Team',
  tags: ['trade'],
});
```

**对应后端端点**：
- `POST /api/analyze` — `analyzeWorkflow()`
- `POST /api/workflows/save` — `saveWorkflowAsSOP()`

---

### 4.3 SOP API（`sop.ts`）

```typescript
// 获取所有 SOP（Knowledge 页面加载）
const sops = await listSOPs();

// 获取单个 SOP
const sop = await getSOP('sop-001');

// 创建新 SOP
const newSOP = await createSOP({ title, description, ... });

// 实时匹配 SOP（用户输入时调用）
const { matches } = await matchSOPs('trade reconciliation', 3);
// → [{ sop: SOPKnowledge, score: 4, matched_systems: ['QTrack'] }]
```

**对应后端端点**：
- `GET /api/sops` — `listSOPs()`
- `GET /api/sops/{id}` — `getSOP(id)`
- `POST /api/sops` — `createSOP()`
- `POST /api/sops/match` — `matchSOPs()`（实时匹配）

---

### 4.4 Systems API（`systems.ts`）

```typescript
// 获取所有系统列表（Canvas 侧边栏、Knowledge 页面）
const systems = await listSystems();
// → [{ id: 'qtrack', name: 'QTrack', capabilities: [...], color: '#6366F1' }]

// 获取单个系统详情（Canvas 节点详情面板）
const system = await getSystem('qtrack');
```

**对应后端端点**：
- `GET /api/systems` — `listSystems()`
- `GET /api/systems/{id}` — `getSystem(id)`

---

## 5. 组件中如何使用

```tsx
// 1. 导入需要的 API 函数
import { sendChat, matchSOPs, analyzeWorkflow } from '@/api';

// 2. 在组件中调用（async/await 或 useEffect）
async function handleAnalyze() {
  try {
    // 发送需求分析请求
    const result = await analyzeWorkflow({ 
      text: 'Daily trade reconciliation',
      mode: 'text',
    });
    
    // 使用返回数据更新 UI
    setRecommendations(result.recommendations);
    setWorkflow(result.workflow);
  } catch (err) {
    if (err instanceof APIError) {
      console.error(`API ${err.status}: ${err.detail}`);
    }
  }
}

// 3. 实时 SOP 匹配（输入时触发）
async function handleInputChange(text: string) {
  if (text.length >= 5) {
    const { matches } = await matchSOPs(text, 3);
    setMatchingSOPs(matches);
  }
}
```

---

## 6. 完整调用链路

```
用户输入需求
    ↓
组件调用 API 函数（chat.ts / workflow.ts / sop.ts）
    ↓
API 函数调用 client.ts（get/post/streamPost）
    ↓
client.ts 使用 fetch() 发送 HTTP 请求
    ↓
后端 FastAPI Router（routers/chat.py 等）
    ↓
LangChain Agent（services/agent.py）
    ↓
返回 JSON → client.ts 解析 → 组件更新 UI
```

---

## 7. 启动方式

### 启动后端

```bash
cd /mnt/agents/output/backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

后端 API 文档：http://localhost:8000/docs

### 启动前端

```bash
cd /mnt/agents/output/app
npm run dev
```

配置环境变量（`app/.env`）：
```env
VITE_API_BASE_URL=http://localhost:8000
```

---

## 8. 端点速查表

| 前端函数 | 方法 | 后端端点 | 说明 |
|---------|------|---------|------|
| `sendChat()` | POST | `/api/chat` | 发送消息，获取完整响应 |
| `streamChat()` | POST | `/api/chat/stream` | SSE 流式响应（打字效果） |
| `analyzeWorkflow()` | POST | `/api/analyze` | 分析需求，返回推荐工作流 |
| `saveWorkflowAsSOP()` | POST | `/api/workflows/save` | 保存工作流为 SOP |
| `listSOPs()` | GET | `/api/sops` | 列出所有 SOP |
| `getSOP(id)` | GET | `/api/sops/{id}` | 获取单个 SOP |
| `createSOP()` | POST | `/api/sops` | 创建新 SOP |
| `matchSOPs()` | POST | `/api/sops/match` | 实时匹配 SOP |
| `listSystems()` | GET | `/api/systems` | 列出所有系统 |
| `getSystem(id)` | GET | `/api/systems/{id}` | 获取单个系统 |

---

## 9. 当前集成状态

| 状态 | 说明 |
|------|------|
| **API 层代码** | 已完成（`src/api/` 8 个文件） |
| **后端代码** | 已完成（`backend/` 11 个文件） |
| **前后端连接** | 待激活 — 前端组件仍使用 mock 数据 |

### 接入后端的步骤

1. 在 `Requirements.tsx` 等组件中导入 API 函数：
   ```tsx
   import { analyzeWorkflow, matchSOPs } from '@/api';
   ```

2. 替换 mock 数据调用为真实 API 调用

3. 删除 `MOCK_CONVERSATIONS`、`MOCK_RESPONSES` 等 mock 数据

4. 使用 `try/catch` + `APIError` 处理后端错误
