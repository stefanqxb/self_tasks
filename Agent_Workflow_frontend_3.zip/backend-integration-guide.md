# NexusFlow 前端 — 后端接入完整指南

## 一、整体架构

```
┌─────────────────────────────────────────────────────────────┐
│                       前端 (NexusFlow)                       │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────────┐   │
│  │  React 19   │  │  Zustand     │  │  React Query     │   │
│  │  React Flow │  │  (状态管理)   │  │  (数据获取/缓存)  │   │
│  └─────────────┘  └──────────────┘  └──────────────────┘   │
│           │                │                  │             │
│           └────────────────┴──────────────────┘             │
│                           │                                 │
│                    ┌──────────────┐                        │
│                    │  API Client  │                        │
│                    │  (axios/fetch)│                       │
│                    └──────────────┘                        │
└───────────────────────────┬─────────────────────────────────┘
                            │ HTTP / WebSocket
┌───────────────────────────┼─────────────────────────────────┐
│  后端 (你的 Workflow      │  Backend)                        │
│  ┌─────────────┐  ┌──────┴───────┐  ┌──────────────────┐   │
│  │  REST API   │  │  WebSocket   │  │  AI Service      │   │
│  │  (CRUD)     │  │  (实时推送)   │  │  (LLM/GPT)      │   │
│  └─────────────┘  └──────────────┘  └──────────────────┘   │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────────┐   │
│  │ Node/Flow   │  │ File Storage │  │  Knowledge Graph │   │
│  │ Database    │  │ (S3/OSS)     │  │  (Neo4j/Vector)  │   │
│  └─────────────┘  └──────────────┘  └──────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## 二、API 客户端封装

### 2.1 基础配置

**安装依赖：**
```bash
npm install axios
```

**`src/lib/api.ts`** — API 客户端：

```typescript
import axios, { type AxiosInstance, type AxiosRequestConfig } from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api/v1';

// 创建 axios 实例
const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// 请求拦截器：自动附加 token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('auth_token');
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// 响应拦截器：统一错误处理
apiClient.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response?.status === 401) {
      // Token 过期，跳转登录
      localStorage.removeItem('auth_token');
      window.location.href = '/#/login';
    }
    return Promise.reject(error.response?.data?.message || error.message);
  }
);

export default apiClient;

// 通用请求封装
export async function get<T>(url: string, config?: AxiosRequestConfig): Promise<T> {
  return apiClient.get(url, config) as Promise<T>;
}

export async function post<T>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T> {
  return apiClient.post(url, data, config) as Promise<T>;
}

export async function put<T>(url: string, data?: unknown, config?: AxiosRequestConfig): Promise<T> {
  return apiClient.put(url, data, config) as Promise<T>;
}

export async function del<T>(url: string, config?: AxiosRequestConfig): Promise<T> {
  return apiClient.delete(url, config) as Promise<T>;
}

export async function upload<T>(url: string, formData: FormData, onProgress?: (percent: number) => void): Promise<T> {
  return apiClient.post(url, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: (progressEvent) => {
      if (onProgress && progressEvent.total) {
        onProgress(Math.round((progressEvent.loaded * 100) / progressEvent.total));
      }
    },
  }) as Promise<T>;
}
```

---

## 三、核心功能 API 对接

### 3.1 🔶 功能一：上传/导入 Node 和 Flow

#### 3.1.1 从外部系统导入 Node（Node Library 页面）

**API 定义：**
```typescript
// src/types/api.ts

// ===== 外部系统连接 =====
export interface ExternalSystem {
  id: string;
  name: 'zapier' | 'make' | 'n8n' | 'custom';
  displayName: string;
  connected: boolean;
  lastSync?: string;
}

export interface ConnectSystemRequest {
  systemType: string;
  apiKey?: string;
  baseUrl?: string;
  oauthToken?: string;
}

export interface ImportNodesRequest {
  systemId: string;
  selectedNodeIds: string[];
  conflictStrategy: 'skip' | 'overwrite' | 'rename';
}

export interface ImportNodesResponse {
  success: boolean;
  imported: number;
  skipped: number;
  failed: number;
  nodes: NodeDefinition[];
  errors?: string[];
}

// ===== 上传自定义 Node =====
export interface UploadNodeRequest {
  name: string;
  description: string;
  nodeType: 'trigger' | 'action' | 'logic' | 'data' | 'output';
  icon: string;
  parameters: NodeParameter[];
  sourceSystem?: string;
  definitionJson?: Record<string, unknown>;
}

export interface UploadNodeFileResponse {
  success: boolean;
  node: NodeDefinition;
  message: string;
}
```

**API Service（`src/services/nodeService.ts`）：**
```typescript
import { get, post, upload } from '@/lib/api';
import type {
  ExternalSystem,
  ConnectSystemRequest,
  ImportNodesRequest,
  ImportNodesResponse,
  UploadNodeFileResponse,
  NodeDefinition,
} from '@/types/api';

// 获取已连接的外部系统列表
export async function getConnectedSystems(): Promise<ExternalSystem[]> {
  return get<ExternalSystem[]>('/systems');
}

// 连接外部系统（Step 2: 输入 API Key 后调用）
export async function connectSystem(data: ConnectSystemRequest): Promise<ExternalSystem> {
  return post<ExternalSystem>('/systems/connect', data);
}

// 测试连接
export async function testSystemConnection(systemId: string): Promise<{ success: boolean; message: string }> {
  return post(`/systems/${systemId}/test`);
}

// 获取外部系统的 Node 列表（Step 3: 选择 Node）
export async function getExternalNodes(systemId: string, search?: string): Promise<NodeDefinition[]> {
  return get<NodeDefinition[]>(`/systems/${systemId}/nodes`, {
    params: { search },
  });
}

// 导入选中的 Node（Step 4: 确认导入）
export async function importNodes(data: ImportNodesRequest): Promise<ImportNodesResponse> {
  return post<ImportNodesResponse>('/nodes/import', data);
}

// 上传 JSON/YAML Node 定义文件
export async function uploadNodeFile(
  file: File,
  metadata: Omit<UploadNodeRequest, 'definitionJson'>,
  onProgress?: (percent: number) => void
): Promise<UploadNodeFileResponse> {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('metadata', JSON.stringify(metadata));
  return upload<UploadNodeFileResponse>('/nodes/upload', formData, onProgress);
}

// 手动创建自定义 Node
export async function createCustomNode(data: UploadNodeRequest): Promise<NodeDefinition> {
  return post<NodeDefinition>('/nodes', data);
}
```

**在 NodeLibrary.tsx 中对接：**
```typescript
// 导入向导 - Step 1: 选择系统
const handleSelectSystem = async (systemType: string) => {
  setImportStep(2);
  setSelectedSystem(systemType);
};

// Step 2: 连接认证
const handleConnect = async (apiKey: string) => {
  try {
    const system = await connectSystem({
      systemType: selectedSystem,
      apiKey,
    });
    // 测试连接
    const test = await testSystemConnection(system.id);
    if (test.success) {
      toast.success('连接成功！');
      setImportStep(3);
      // 加载该系统的 Node 列表
      const nodes = await getExternalNodes(system.id);
      setExternalNodes(nodes);
    }
  } catch (error) {
    toast.error(`连接失败: ${error}`);
  }
};

// Step 4: 确认导入
const handleConfirmImport = async (selectedIds: string[]) => {
  try {
    const result = await importNodes({
      systemId: selectedSystemId,
      selectedNodeIds: selectedIds,
      conflictStrategy: 'rename', // skip | overwrite | rename
    });
    toast.success(`成功导入 ${result.imported} 个节点`);
    // 刷新 Node 列表
    queryClient.invalidateQueries({ queryKey: ['nodes'] });
  } catch (error) {
    toast.error(`导入失败: ${error}`);
  }
};

// 文件上传（拖拽上传）
const handleFileUpload = async (file: File) => {
  const result = await uploadNodeFile(
    file,
    {
      name: file.name.replace(/\.[^/.]+$/, ''),
      description: '上传的自定义节点',
      nodeType: 'action',
      icon: 'Settings',
      parameters: [],
    },
    (percent) => setUploadProgress(percent)
  );
  toast.success(`节点 "${result.node.name}" 上传成功！`);
};
```

#### 3.1.2 上传/导入 Workflow

```typescript
// src/services/workflowService.ts

// 上传 Workflow 文件（JSON/YAML）
export async function uploadWorkflowFile(
  file: File,
  name: string,
  folderId?: string
): Promise<{ workflowId: string; message: string }> {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('name', name);
  if (folderId) formData.append('folderId', folderId);
  return upload('/workflows/import', formData);
}

// 导出 Workflow
export async function exportWorkflow(workflowId: string, format: 'json' | 'yaml'): Promise<Blob> {
  const response = await apiClient.get(`/workflows/${workflowId}/export?format=${format}`, {
    responseType: 'blob',
  });
  return response.data as Blob;
}
```

---

### 3.2 🔶 功能二：AI 生成/修改 Workflow

#### 3.2.1 方案 A：SSE 流式输出（推荐）

后端逐步返回生成结果，前端实时展示节点创建过程。

**API 定义：**
```typescript
// AI 生成 Workflow 请求
export interface AIGenerateRequest {
  prompt: string;                    // 用户自然语言需求
  existingWorkflowId?: string;       // 如为修改模式，传入已有 workflow ID
  conversationId?: string;           // 对话线程 ID（多轮对话）
  contextNodes?: string[];           // 用户已有的 Node 类型（用于上下文）
  complexity?: 'simple' | 'medium' | 'complex';
}

// SSE 事件类型
export type AIStreamEvent =
  | { type: 'thinking'; content: string }           // AI 正在思考
  | { type: 'node'; node: AIGeneratedNode }         // 生成一个节点
  | { type: 'edge'; edge: AIGeneratedEdge }         // 生成一条连接
  | { type: 'message'; content: string }            // AI 回复文本
  | { type: 'complete'; workflowId: string }        // 生成完成
  | { type: 'error'; message: string };             // 生成出错

export interface AIGeneratedNode {
  tempId: string;
  label: string;
  type: 'trigger' | 'action' | 'logic' | 'data' | 'output';
  icon: string;
  x: number;
  y: number;
  parameters?: NodeParameter[];
  description?: string;
}

export interface AIGeneratedEdge {
  source: string;       // tempId of source node
  target: string;       // tempId of target node
  animated?: boolean;
}
```

**Service（`src/services/aiService.ts`）：**
```typescript
// SSE 流式生成 Workflow
export function streamAIGenerate(
  request: AIGenerateRequest,
  onEvent: (event: AIStreamEvent) => void,
  onError?: (error: string) => void
): () => void {
  const abortController = new AbortController();

  const startStream = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/ai/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('auth_token') || ''}`,
        },
        body: JSON.stringify(request),
        signal: abortController.signal,
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      if (!reader) return;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const event = JSON.parse(line.slice(6)) as AIStreamEvent;
              onEvent(event);
            } catch {
              // 忽略解析失败的行
            }
          }
        }
      }
    } catch (error: any) {
      if (error.name !== 'AbortError') {
        onError?.(error.message);
      }
    }
  };

  startStream();

  // 返回取消函数
  return () => abortController.abort();
}
```

**在 AIAssistant.tsx / Canvas 的 AIChatPanel 中对接：**
```typescript
// 当前正在接收的流
const abortRef = useRef<(() => void) | null>(null);
const [isStreaming, setIsStreaming] = useState(false);
const [streamingNodes, setStreamingNodes] = useState<AIGeneratedNode[]>([]);

// 发送消息并启动 SSE 流
const handleSendMessage = async (prompt: string) => {
  // 添加用户消息
  addMessage({ role: 'user', content: prompt });
  setIsStreaming(true);
  setStreamingNodes([]);

  // 启动 SSE 流
  const cancel = streamAIGenerate(
    {
      prompt,
      conversationId: currentConversationId,
      complexity: 'medium',
    },
    // 处理每个事件
    (event) => {
      switch (event.type) {
        case 'thinking':
          // 显示 "AI 正在思考..."
          setThinkingText(event.content);
          break;

        case 'node':
          // 收集生成的节点
          setStreamingNodes((prev) => [...prev, event.node]);
          break;

        case 'edge':
          // 收集生成的连接
          setStreamingEdges((prev) => [...prev, event.edge]);
          break;

        case 'message':
          // AI 回复文本
          addMessage({ role: 'ai', content: event.content });
          break;

        case 'complete':
          // 生成完成，展示预览
          setIsStreaming(false);
          setWorkflowPreview({
            nodes: streamingNodes,
            edges: streamingEdges,
            workflowId: event.workflowId,
          });
          toast.success('Workflow 生成完成！');
          break;

        case 'error':
          setIsStreaming(false);
          toast.error(`生成失败: ${event.message}`);
          break;
      }
    },
    (error) => {
      setIsStreaming(false);
      toast.error(error);
    }
  );

  abortRef.current = cancel;
};

// 取消生成
const handleCancel = () => {
  abortRef.current?.();
  setIsStreaming(false);
};

// "应用到画布" 按钮
const handleApplyToCanvas = () => {
  // 将 streamingNodes/streamingEdges 传递给 Canvas 页面
  navigate('/canvas', {
    state: {
      aiWorkflow: {
        nodes: streamingNodes,
        edges: streamingEdges,
      },
    },
  });
};
```

#### 3.2.2 方案 B：WebSocket 实时通信（复杂场景）

适合多人协作编辑 Workflow。

```typescript
// src/services/websocket.ts
export class WorkflowWebSocket {
  private ws: WebSocket | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private listeners: Map<string, Set<(data: any) => void>> = new Map();

  connect(workflowId: string) {
    const token = localStorage.getItem('auth_token');
    this.ws = new WebSocket(
      `wss://your-api.com/ws/workflows/${workflowId}?token=${token}`
    );

    this.ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      const handlers = this.listeners.get(message.type) || new Set();
      handlers.forEach((h) => h(message.data));
    };

    this.ws.onclose = () => {
      // 自动重连
      this.reconnectTimer = setTimeout(() => this.connect(workflowId), 3000);
    };
  }

  on(event: string, handler: (data: any) => void) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(handler);
  }

  off(event: string, handler: (data: any) => void) {
    this.listeners.get(event)?.delete(handler);
  }

  send(type: string, data: any) {
    this.ws?.send(JSON.stringify({ type, data }));
  }

  disconnect() {
    this.reconnectTimer && clearTimeout(this.reconnectTimer);
    this.ws?.close();
  }
}
```

---

### 3.3 🔶 功能三：智能推荐 Node/Flow

```typescript
// src/services/recommendService.ts

// 基于当前画布内容推荐下一个节点
export async function getNodeRecommendations(
  context: {
    currentNodeIds: string[];
    lastNodeType?: string;
    workflowDescription?: string;
    cursorPosition?: { x: number; y: number };
  }
): Promise<NodeRecommendation[]> {
  return post<NodeRecommendation[]>('/recommendations/nodes', context);
}

// 基于用户行为推荐 Workflow 模板
export async function getWorkflowRecommendations(): Promise<WorkflowRecommendation[]> {
  return get<WorkflowRecommendation[]>('/recommendations/workflows');
}

// 搜索时自动补全推荐
export async function getSearchSuggestions(query: string): Promise<string[]> {
  return get<string[]>('/recommendations/suggestions', {
    params: { q: query },
  });
}

// ============ 在 Canvas.tsx 中对接 ============

// 当用户添加节点后，获取推荐
const handleRecommendNextNodes = async (lastNodeId: string) => {
  const recommendations = await getNodeRecommendations({
    currentNodeIds: nodes.map((n) => n.id),
    lastNodeType: nodes.find((n) => n.id === lastNodeId)?.data?.nodeType,
  });

  // 在画布上显示推荐浮层
  setRecommendedNodes(recommendations.map((r) => ({
    ...r,
    x: lastNodeX + 250,
    y: lastNodeY + (Math.random() - 0.5) * 200,
  })));
};
```

---

### 3.4 🔶 功能四：知识总结与优化建议

```typescript
// src/services/knowledgeService.ts

// 获取知识中心概览
export async function getKnowledgeOverview(): Promise<KnowledgeOverview> {
  return get<KnowledgeOverview>('/knowledge/overview');
}

// 获取优化建议列表
export async function getOptimizationSuggestions(
  filters?: { severity?: 'high' | 'medium' | 'low'; category?: string }
): Promise<OptimizationSuggestion[]> {
  return get<OptimizationSuggestion[]>('/knowledge/suggestions', {
    params: filters,
  });
}

// 获取 Workflow 摘要
export async function getWorkflowSummary(workflowId: string): Promise<WorkflowSummary> {
  return get<WorkflowSummary>(`/knowledge/workflows/${workflowId}/summary`);
}

// 获取知识图谱数据
export async function getKnowledgeGraph(): Promise<KnowledgeGraphData> {
  return get<KnowledgeGraphData>('/knowledge/graph');
}

// 获取节点分析
export async function getNodeAnalysis(): Promise<NodeAnalysis[]> {
  return get<NodeAnalysis[]>('/knowledge/node-analysis');
}

// 应用优化建议
export async function applyOptimization(suggestionId: string): Promise<{
  success: boolean;
  appliedChanges: string[];
  backupId: string;   // 用于回滚
}> {
  return post(`/knowledge/suggestions/${suggestionId}/apply`);
}

// 回滚优化
export async function rollbackOptimization(suggestionId: string): Promise<void> {
  return post(`/knowledge/suggestions/${suggestionId}/rollback`);
}

// ============ 在 KnowledgeHub.tsx 中对接 ============

const { data: overview } = useQuery({
  queryKey: ['knowledge-overview'],
  queryFn: getKnowledgeOverview,
  refetchInterval: 30000, // 30秒自动刷新
});

const { data: suggestions } = useQuery({
  queryKey: ['suggestions'],
  queryFn: () => getOptimizationSuggestions({ severity: filterSeverity }),
});

const handleApplyOptimization = async (suggestionId: string) => {
  const result = await applyOptimization(suggestionId);
  toast.success(`已应用优化，备份ID: ${result.backupId}`);
  // 刷新数据
  queryClient.invalidateQueries({ queryKey: ['suggestions'] });
};
```

---

## 四、推荐技术栈与后端架构

### 4.1 后端技术选型参考

| 组件 | 推荐方案 | 说明 |
|------|---------|------|
| **API 框架** | FastAPI (Python) / Express (Node) / Gin (Go) | RESTful API |
| **AI 服务** | OpenAI API / Claude / 自部署 LLM | 自然语言理解 + Workflow 生成 |
| **数据库** | PostgreSQL + Redis | 元数据存储 + 缓存 |
| **图数据库** | Neo4j / 向量数据库 (Pinecone/Milvus) | Node 关系图谱 |
| **消息队列** | Redis Streams / RabbitMQ | 异步任务处理 |
| **文件存储** | S3 / OSS / MinIO | Node/Workflow 定义文件 |
| **实时通信** | WebSocket / SSE | AI 流式输出 + 协作编辑 |

### 4.2 核心数据库表结构（参考）

```sql
-- Nodes 表
CREATE TABLE nodes (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    node_type VARCHAR(50),  -- trigger/action/logic/data/output
    icon VARCHAR(100),
    source_system VARCHAR(100),  -- zapier/make/n8n/custom
    system_node_id VARCHAR(255), -- 外部系统的原始 ID
    definition_json JSONB,       -- 完整节点定义
    parameters JSONB,
    created_by UUID,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- Workflows 表
CREATE TABLE workflows (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50),      -- draft/active/archived
    folder_id UUID,
    nodes_data JSONB,        -- React Flow nodes
    edges_data JSONB,        -- React Flow edges
    version INT DEFAULT 1,
    created_by UUID,
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- AI Conversations 表
CREATE TABLE ai_conversations (
    id UUID PRIMARY KEY,
    workflow_id UUID,
    messages JSONB,          -- 对话历史
    generated_workflow JSONB, -- 生成的工作流
    created_at TIMESTAMP
);

-- Knowledge Graph 表
CREATE TABLE node_relationships (
    id UUID PRIMARY KEY,
    source_node_id UUID,
    target_node_id UUID,
    relationship_type VARCHAR(100),  -- used_with/similar_to/depends_on
    weight FLOAT,
    ai_discovered BOOLEAN DEFAULT false
);

-- Optimization Suggestions 表
CREATE TABLE optimization_suggestions (
    id UUID PRIMARY KEY,
    type VARCHAR(100),       -- merge/remove/reorder/rename
    severity VARCHAR(20),    -- high/medium/low
    title TEXT,
    description TEXT,
    affected_nodes UUID[],
    applied_at TIMESTAMP,
    applied_by UUID,
    backup_data JSONB        -- 回滚所需数据
);
```

---

## 五、完整对接示例：AI 生成 Workflow 端到端

### 5.1 前端调用链

```
用户输入需求 → AIChatPanel.handleSendMessage()
                    ↓
            aiService.streamAIGenerate() —— SSE 流
                    ↓
            后端接收 prompt → 调用 LLM
                    ↓
            LLM 返回结构化 Workflow JSON
                    ↓
            后端逐条发送 SSE 事件 (node/edge/message)
                    ↓
            前端接收 → 实时更新 streamingNodes
                    ↓
            生成完成 → 显示预览 + "Apply to Canvas" 按钮
                    ↓
            用户点击 → 跳转到 Canvas 页面
                    ↓
            Canvas 读取 route state 中的 aiWorkflow
                    ↓
            渲染到 React Flow 画布上
```

### 5.2 后端处理流程（Python FastAPI 示例）

```python
# backend/api/ai.py
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
import json
import asyncio

router = APIRouter()

@router.post("/ai/generate")
async def ai_generate_workflow(request: AIGenerateRequest):
    async def event_stream():
        # 1. 调用 LLM 分析用户需求
        yield f"data: {json.dumps({'type': 'thinking', 'content': '正在分析您的需求...'})}\n\n"
        await asyncio.sleep(0.5)

        # 2. 生成 Workflow 结构（LLM 返回 JSON）
        workflow_json = await llm_service.generate_workflow(request.prompt)

        # 3. 逐个节点发送
        for node in workflow_json["nodes"]:
            yield f"data: {json.dumps({'type': 'node', 'node': node})}\n\n"
            await asyncio.sleep(0.3)  # 模拟创建动画间隔

        # 4. 逐条连接发送
        for edge in workflow_json["edges"]:
            yield f"data: {json.dumps({'type': 'edge', 'edge': edge})}\n\n"
            await asyncio.sleep(0.2)

        # 5. 发送 AI 说明文字
        yield f"data: {json.dumps({'type': 'message', 'content': workflow_json['explanation']})}\n\n"

        # 6. 保存到数据库
        workflow_id = await db.save_workflow(workflow_json)

        # 7. 完成事件
        yield f"data: {json.dumps({'type': 'complete', 'workflowId': str(workflow_id)})}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"}
    )
```

### 5.3 LLM Prompt 模板

```python
SYSTEM_PROMPT = """你是一个 Workflow 生成专家。根据用户的需求，生成一个结构化工作流。

你必须返回以下 JSON 格式：
{
  "nodes": [
    {
      "tempId": "node-1",
      "label": "节点名称",
      "type": "trigger|action|logic|data|output",
      "icon": "Lucide图标名称",
      "x": 100,
      "y": 200,
      "parameters": [{"key": "...", "label": "...", "value": "..."}],
      "description": "节点功能说明"
    }
  ],
  "edges": [
    {"source": "node-1", "target": "node-2", "animated": true}
  ],
  "explanation": "对工作流的整体说明"
}

规则：
1. 第一个节点必须是 trigger 类型
2. 节点间需要有合理的逻辑连接
3. 如果用户提到了具体工具/服务，使用对应的 icon 和参数
4. 坐标应按从左到右排列，间距 x=250, y 交错
"""
```

---

## 六、环境变量配置

**`.env` 文件：**
```bash
# API 配置
VITE_API_BASE_URL=http://localhost:8000/api/v1
VITE_WS_URL=wss://localhost:8000/ws

# AI 服务（如前端直接调用 AI API）
VITE_AI_API_KEY=your-openai-key
VITE_AI_MODEL=gpt-4

# 功能开关
VITE_ENABLE_AI_ASSISTANT=true
VITE_ENABLE_REALTIME_COLLAB=true
VITE_ENABLE_KNOWLEDGE_HUB=true
```

---

## 七、快速开始清单

1. ✅ 复制 `api.ts` 到你的项目
2. ✅ 复制 `types/api.ts` 类型定义
3. ✅ 创建 `services/` 目录下的 service 文件
4. ✅ 安装 `axios` 和 `@tanstack/react-query`
5. ✅ 在 `.env` 中配置你的后端地址
6. ✅ 在每个页面的组件中调用对应的 service
7. ✅ 后端按照上面的接口定义实现对应端点

---

## 八、推荐的 React Query 集成

```typescript
// src/lib/queryClient.ts
import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,  // 5 分钟缓存
      retry: 2,
      refetchOnWindowFocus: false,
    },
  },
});

// main.tsx
import { QueryClientProvider } from '@tanstack/react-query';
<QueryClientProvider client={queryClient}>
  <App />
</QueryClientProvider>
```

以上就是完整的后端接入指南！有任何问题随时问我。
