import React, { Suspense } from 'react'
import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'

const Home = React.lazy(() => import('./pages/Home'))
const Canvas = React.lazy(() => import('./pages/Canvas'))
const NodeLibrary = React.lazy(() => import('./pages/NodeLibrary'))
const Workflows = React.lazy(() => import('./pages/Workflows'))
const AIAssistant = React.lazy(() => import('./pages/AIAssistant'))
const KnowledgeHub = React.lazy(() => import('./pages/KnowledgeHub'))
const Settings = React.lazy(() => import('./pages/Settings'))
const Profile = React.lazy(() => import('./pages/Profile'))

export default function App() {
  return (
    <Layout>
      <Suspense fallback={<div className="flex items-center justify-center h-full text-muted-gray">Loading...</div>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/canvas" element={<Canvas />} />
          <Route path="/node-library" element={<NodeLibrary />} />
          <Route path="/workflows" element={<Workflows />} />
          <Route path="/ai-assistant" element={<AIAssistant />} />
          <Route path="/knowledge-hub" element={<KnowledgeHub />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </Suspense>
    </Layout>
  )
}
