import type { OrchestrationStep } from '@/types/orchestration';
import { TARGET_SYSTEMS } from './systemCapabilities';

/**
 * Sub-flow generator for multi-level workflow canvas.
 * Creates child steps when user double-clicks a group node.
 */
export function generateSubFlow(_parentLabel: string, systemId: string, functionId: string): OrchestrationStep[] {
  const sys = TARGET_SYSTEMS.find(s => s.id === systemId);
  const func = sys?.functions.find(f => f.id === functionId);
  if (!sys || !func) return [];

  // Generate 2-4 sub-steps based on the function's category
  const subs: OrchestrationStep[] = [];

  if (func.category === 'Extraction' || func.category === 'OCR') {
    subs.push(
      { id: 'sub-0', label: 'Receive Document', description: 'Accept incoming document', systemId: 'docuwise-doc', functionId: 'f301', systemName: 'DocuWise', functionName: 'Receive', confidence: 90, params: {} },
      { id: 'sub-1', label: 'Pre-process Image', description: 'Deskew, denoise, enhance', systemId: 'docuwise-doc', functionId: 'f301', systemName: 'DocuWise', functionName: 'Pre-process', confidence: 85, params: {} },
      { id: 'sub-2', label: func.name, description: func.description, systemId, functionId, systemName: sys.name, functionName: func.name, confidence: 95, params: {} },
      { id: 'sub-3', label: 'Validate Output', description: 'Check extraction quality', systemId: 'docuwise-doc', functionId: 'f304', systemName: 'DocuWise', functionName: 'Validate', confidence: 88, params: {} },
    );
  } else if (func.category === 'Payment' || func.category === 'Invoicing') {
    subs.push(
      { id: 'sub-0', label: 'Validate Input', description: 'Check amount and currency', systemId, functionId, systemName: sys.name, functionName: 'Validate', confidence: 92, params: {} },
      { id: 'sub-1', label: 'Fraud Check', description: 'Risk assessment', systemId, functionId, systemName: sys.name, functionName: 'Fraud Check', confidence: 90, params: {} },
      { id: 'sub-2', label: func.name, description: func.description, systemId, functionId, systemName: sys.name, functionName: func.name, confidence: 96, params: {} },
      { id: 'sub-3', label: 'Send Receipt', description: 'Notify customer', systemId: 'slack-comm', functionId: 'f401', systemName: 'Slack', functionName: 'Notify', confidence: 85, params: {} },
    );
  } else {
    subs.push(
      { id: 'sub-0', label: 'Prepare Input', description: 'Gather and format input data', systemId, functionId, systemName: sys.name, functionName: 'Prepare', confidence: 88, params: {} },
      { id: 'sub-1', label: 'Execute Logic', description: `Run ${func.name}`, systemId, functionId, systemName: sys.name, functionName: func.name, confidence: 92, params: {} },
      { id: 'sub-2', label: 'Verify Result', description: 'Check execution output', systemId, functionId, systemName: sys.name, functionName: 'Verify', confidence: 86, params: {} },
    );
  }

  return subs;
}
