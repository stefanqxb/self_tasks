import type { TargetSystem, SystemFunction } from '@/types/orchestration';

/** ─── 5 Candidate Target Systems with Capability Matrices ─────────── */

export const TARGET_SYSTEMS: TargetSystem[] = [
  {
    id: 'sap-erp',
    name: 'SAP ERP',
    icon: 'Database',
    color: '#0F52BA',
    description: 'Enterprise resource planning system. Handles financial data, procurement, inventory, HR records, and compliance reporting.',
    category: 'ERP',
    apiVersion: 'v2024.1',
    status: 'available',
    functions: [
      { id: 'f101', name: 'Create Purchase Order', description: 'Generate a new procurement purchase order with vendor, items, quantities, and pricing.', category: 'Procurement', keywords: ['purchase','order','procurement','buy','vendor','supplier','PO'], parameters: [{key:'vendor_id',label:'Vendor ID',type:'string',required:true},{key:'items',label:'Items JSON',type:'json',required:true},{key:'currency',label:'Currency',type:'string',required:false}], confidence: 92 },
      { id: 'f102', name: 'Post Financial Journal', description: 'Post a journal entry to the general ledger for accounting transactions.', category: 'Finance', keywords: ['journal','ledger','accounting','financial','post','GL','entry','debit','credit'], parameters: [{key:'company_code',label:'Company Code',type:'string',required:true},{key:'posting_date',label:'Posting Date',type:'date',required:true},{key:'line_items',label:'Line Items',type:'json',required:true}], confidence: 95 },
      { id: 'f103', name: 'Query Inventory Stock', description: 'Check current inventory levels for materials across storage locations.', category: 'Inventory', keywords: ['inventory','stock','material','warehouse','storage','level','quantity','on-hand'], parameters: [{key:'material_id',label:'Material ID',type:'string',required:true},{key:'plant',label:'Plant Code',type:'string',required:false}], confidence: 88 },
      { id: 'f104', name: 'Generate Financial Report', description: 'Produce balance sheet, P&L, or cash flow report for a given fiscal period.', category: 'Finance', keywords: ['report','financial','balance','profit','loss','P&L','cash flow','statement','fiscal'], parameters: [{key:'report_type',label:'Report Type',type:'string',required:true},{key:'fiscal_period',label:'Fiscal Period',type:'string',required:true},{key:'company_code',label:'Company Code',type:'string',required:true}], confidence: 90 },
      { id: 'f105', name: 'Approve Workflow Item', description: 'Approve or reject a pending workflow item in the approval chain.', category: 'Workflow', keywords: ['approve','reject','workflow','approval','item','decision','authorize'], parameters: [{key:'workflow_id',label:'Workflow ID',type:'string',required:true},{key:'decision',label:'Decision',type:'string',required:true},{key:'comment',label:'Comment',type:'string',required:false}], confidence: 87 },
      { id: 'f106', name: 'Sync Vendor Master', description: 'Create or update vendor master data records.', category: 'Master Data', keywords: ['vendor','master','supplier','create','update','sync','maintain'], parameters: [{key:'vendor_data',label:'Vendor Data JSON',type:'json',required:true},{key:'action',label:'Action',type:'string',required:true}], confidence: 82 },
      { id: 'f107', name: 'Run Payroll Calculation', description: 'Execute payroll run for employees including deductions and contributions.', category: 'HR', keywords: ['payroll','salary','wage','employee','payment','run','calculate'], parameters: [{key:'payroll_area',label:'Payroll Area',type:'string',required:true},{key:'period',label:'Period',type:'string',required:true}], confidence: 93 },
      { id: 'f108', name: 'Export Compliance Data', description: 'Export audit-ready compliance data for regulatory submissions.', category: 'Compliance', keywords: ['compliance','audit','regulatory','export','GDPR','SOX','tax','legal'], parameters: [{key:'regulation_type',label:'Regulation Type',type:'string',required:true},{key:'date_range',label:'Date Range',type:'string',required:true}], confidence: 85 },
      { id: 'f109', name: 'Create Goods Receipt', description: 'Record goods receipt against a purchase order when shipment arrives.', category: 'Procurement', keywords: ['goods','receipt','GR','receive','shipment','delivery','arrive','warehouse'], parameters: [{key:'po_number',label:'PO Number',type:'string',required:true},{key:'materials',label:'Materials Received',type:'json',required:true}], confidence: 89 },
      { id: 'f110', name: 'Query Cost Center', description: 'Retrieve cost center details, budgets, and actual spending.', category: 'Finance', keywords: ['cost','center','budget','spend','actual','plan','controlling'], parameters: [{key:'cost_center_id',label:'Cost Center ID',type:'string',required:true},{key:'fiscal_year',label:'Fiscal Year',type:'string',required:false}], confidence: 84 },
    ],
  },
  {
    id: 'salesforce-crm',
    name: 'Salesforce CRM',
    icon: 'Users',
    color: '#0176D3',
    description: 'Customer relationship management platform. Manages leads, opportunities, accounts, contacts, campaigns, and service cases.',
    category: 'CRM',
    apiVersion: 'v60.0',
    status: 'available',
    functions: [
      { id: 'f201', name: 'Create Lead', description: 'Create a new sales lead with contact information, source, and qualification data.', category: 'Sales', keywords: ['lead','create','prospect','opportunity','sales','contact','new'], parameters: [{key:'lead_data',label:'Lead Data JSON',type:'json',required:true},{key:'owner_id',label:'Owner ID',type:'string',required:false}], confidence: 94 },
      { id: 'f202', name: 'Update Opportunity Stage', description: 'Move an opportunity to the next or previous stage in the sales pipeline.', category: 'Sales', keywords: ['opportunity','stage','pipeline','move','advance','close','win','lose','CRM'], parameters: [{key:'opp_id',label:'Opportunity ID',type:'string',required:true},{key:'stage',label:'New Stage',type:'string',required:true},{key:'close_date',label:'Close Date',type:'date',required:false}], confidence: 93 },
      { id: 'f203', name: 'Send Email Campaign', description: 'Trigger a marketing email campaign to a segmented list of contacts.', category: 'Marketing', keywords: ['email','campaign','marketing','send','blast','newsletter','promotion','reach'], parameters: [{key:'campaign_id',label:'Campaign ID',type:'string',required:true},{key:'segment_id',label:'Segment ID',type:'string',required:false}], confidence: 91 },
      { id: 'f204', name: 'Create Service Case', description: 'Open a customer support case with issue description and priority.', category: 'Service', keywords: ['case','ticket','support','service','issue','problem','help','customer'], parameters: [{key:'account_id',label:'Account ID',type:'string',required:true},{key:'subject',label:'Subject',type:'string',required:true},{key:'priority',label:'Priority',type:'string',required:true},{key:'description',label:'Description',type:'string',required:false}], confidence: 90 },
      { id: 'f205', name: 'Sync Contact Record', description: 'Create or update a contact record with latest interaction data.', category: 'Master Data', keywords: ['contact','sync','update','person','customer','prospect','record'], parameters: [{key:'contact_data',label:'Contact Data JSON',type:'json',required:true}], confidence: 88 },
      { id: 'f206', name: 'Generate Sales Forecast', description: 'Produce a sales forecast report based on pipeline data and historical trends.', category: 'Analytics', keywords: ['forecast','predict','sales','revenue','pipeline','projection','quota','trend'], parameters: [{key:'period',label:'Forecast Period',type:'string',required:true},{key:'territory',label:'Territory',type:'string',required:false}], confidence: 87 },
      { id: 'f207', name: 'Assign Task to User', description: 'Create and assign a task or activity to a specific user or queue.', category: 'Productivity', keywords: ['task','assign','activity','todo','delegate','user','queue','work'], parameters: [{key:'subject',label:'Subject',type:'string',required:true},{key:'owner_id',label:'Owner ID',type:'string',required:true},{key:'due_date',label:'Due Date',type:'date',required:false}], confidence: 85 },
      { id: 'f208', name: 'Convert Lead to Account', description: 'Convert a qualified lead into an account, contact, and opportunity.', category: 'Sales', keywords: ['convert','lead','account','opportunity','qualify','transform','upgrade'], parameters: [{key:'lead_id',label:'Lead ID',type:'string',required:true},{key:'account_data',label:'Account Data',type:'json',required:false}], confidence: 92 },
      { id: 'f209', name: 'Log Customer Interaction', description: 'Record a call, meeting, or email interaction against a customer record.', category: 'Activity', keywords: ['log','interaction','call','meeting','email','activity','touchpoint','engagement'], parameters: [{key:'record_id',label:'Record ID',type:'string',required:true},{key:'interaction_type',label:'Type',type:'string',required:true},{key:'notes',label:'Notes',type:'string',required:false}], confidence: 89 },
      { id: 'f210', name: 'Query Account Health Score', description: 'Retrieve the health and engagement score for a customer account.', category: 'Analytics', keywords: ['health','score','account','engagement','churn','risk','retention','NPS'], parameters: [{key:'account_id',label:'Account ID',type:'string',required:true}], confidence: 83 },
    ],
  },
  {
    id: 'docuwise-doc',
    name: 'DocuWise',
    icon: 'FileText',
    color: '#F59E0B',
    description: 'Intelligent document processing platform. OCR, classification, data extraction, validation, and document generation.',
    category: 'Document',
    apiVersion: 'v3.2',
    status: 'available',
    functions: [
      { id: 'f301', name: 'OCR Extract Text', description: 'Extract text content from scanned documents, PDFs, or images using OCR.', category: 'OCR', keywords: ['OCR','extract','text','scan','PDF','image','read','recognize','document'], parameters: [{key:'document_url',label:'Document URL',type:'string',required:true},{key:'language',label:'Language',type:'string',required:false}], confidence: 96 },
      { id: 'f302', name: 'Classify Document', description: 'Automatically classify a document into a predefined category (invoice, contract, receipt, etc.).', category: 'Classification', keywords: ['classify','category','type','identify','document','sort','label','auto-classify'], parameters: [{key:'document_url',label:'Document URL',type:'string',required:true},{key:'model_id',label:'Model ID',type:'string',required:false}], confidence: 94 },
      { id: 'f303', name: 'Extract Invoice Data', description: 'Extract structured fields from invoices: vendor, amounts, line items, dates, PO numbers.', category: 'Extraction', keywords: ['invoice','extract','vendor','amount','line item','total','tax','payment','bill'], parameters: [{key:'document_url',label:'Document URL',type:'string',required:true},{key:'template_id',label:'Template ID',type:'string',required:false}], confidence: 95 },
      { id: 'f304', name: 'Validate Document Data', description: 'Validate extracted data against business rules and master data.', category: 'Validation', keywords: ['validate','check','verify','rule','compliance','data quality','error','correct'], parameters: [{key:'extracted_data',label:'Extracted Data JSON',type:'json',required:true},{key:'rule_set',label:'Rule Set ID',type:'string',required:true}], confidence: 91 },
      { id: 'f305', name: 'Generate PDF Document', description: 'Generate a formatted PDF document from a template with merged data fields.', category: 'Generation', keywords: ['generate','PDF','document','template','create','output','print','form'], parameters: [{key:'template_id',label:'Template ID',type:'string',required:true},{key:'data',label:'Merge Data JSON',type:'json',required:true}], confidence: 89 },
      { id: 'f306', name: 'Compare Documents', description: 'Compare two versions of a document to identify changes and differences.', category: 'Comparison', keywords: ['compare','diff','version','change','delta','redline','contract','review'], parameters: [{key:'doc_a_url',label:'Document A URL',type:'string',required:true},{key:'doc_b_url',label:'Document B URL',type:'string',required:true}], confidence: 86 },
      { id: 'f307', name: 'Digitize Form', description: 'Convert a paper form into a digital structured form with field recognition.', category: 'OCR', keywords: ['digitize','form','field','recognize','paper','convert','digital','structure'], parameters: [{key:'form_image_url',label:'Form Image URL',type:'string',required:true}], confidence: 88 },
      { id: 'f308', name: 'Archive Document', description: 'Store a document in the long-term archive with metadata and retention policy.', category: 'Storage', keywords: ['archive','store','save','retention','long-term','document','repository','compliance'], parameters: [{key:'document_url',label:'Document URL',type:'string',required:true},{key:'metadata',label:'Metadata JSON',type:'json',required:true},{key:'retention_years',label:'Retention Years',type:'number',required:false}], confidence: 90 },
      { id: 'f309', name: 'Extract Contract Terms', description: 'Extract key terms, clauses, dates, and parties from a legal contract document.', category: 'Extraction', keywords: ['contract','terms','clause','legal','party','agreement','extract','obligation','renewal'], parameters: [{key:'document_url',label:'Document URL',type:'string',required:true}], confidence: 87 },
      { id: 'f310', name: 'Detect Fraud Pattern', description: 'Analyze document patterns to detect potential fraud, forgery, or anomalies.', category: 'Security', keywords: ['fraud','detect','forgery','anomaly','security','risk','fake','verify','authenticate'], parameters: [{key:'document_url',label:'Document URL',type:'string',required:true},{key:'sensitivity',label:'Sensitivity Level',type:'string',required:false}], confidence: 84 },
    ],
  },
  {
    id: 'slack-comm',
    name: 'Slack Connect',
    icon: 'MessageSquare',
    color: '#4A154B',
    description: 'Team communication and collaboration hub. Channels, direct messages, notifications, and workflow integrations.',
    category: 'Communication',
    apiVersion: 'v2.0',
    status: 'available',
    functions: [
      { id: 'f401', name: 'Send Channel Message', description: 'Post a message to a specific Slack channel with optional blocks and attachments.', category: 'Messaging', keywords: ['send','message','channel','post','notify','alert','announce','slack'], parameters: [{key:'channel_id',label:'Channel ID',type:'string',required:true},{key:'text',label:'Message Text',type:'string',required:true},{key:'blocks',label:'Blocks JSON',type:'json',required:false}], confidence: 95 },
      { id: 'f402', name: 'Send Direct Message', description: 'Send a direct message to a specific user.', category: 'Messaging', keywords: ['DM','direct','message','user','private','personal','notify','alert'], parameters: [{key:'user_id',label:'User ID',type:'string',required:true},{key:'text',label:'Message Text',type:'string',required:true}], confidence: 94 },
      { id: 'f403', name: 'Create Channel', description: 'Create a new public or private channel for a project or topic.', category: 'Channel', keywords: ['create','channel','new','group','project','topic','team','workspace'], parameters: [{key:'name',label:'Channel Name',type:'string',required:true},{key:'is_private',label:'Private',type:'boolean',required:false}], confidence: 88 },
      { id: 'f404', name: 'Schedule Message', description: 'Schedule a message to be sent at a future date and time.', category: 'Messaging', keywords: ['schedule','delay','timed','future','reminder','post','queue'], parameters: [{key:'channel_id',label:'Channel ID',type:'string',required:true},{key:'text',label:'Message Text',type:'string',required:true},{key:'post_at',label:'Post At (Unix)',type:'number',required:true}], confidence: 90 },
      { id: 'f405', name: 'Upload File', description: 'Upload a file to a channel or direct message thread.', category: 'File', keywords: ['upload','file','attachment','document','share','image','PDF'], parameters: [{key:'file_url',label:'File URL',type:'string',required:true},{key:'channel_id',label:'Channel ID',type:'string',required:true},{key:'title',label:'Title',type:'string',required:false}], confidence: 89 },
      { id: 'f406', name: 'Create Workflow Step', description: 'Add an interactive workflow step to a message for approvals or forms.', category: 'Workflow', keywords: ['workflow','step','interactive','button','form','approval','shortcut','action'], parameters: [{key:'trigger_id',label:'Trigger ID',type:'string',required:true},{key:'callback_id',label:'Callback ID',type:'string',required:true}], confidence: 85 },
      { id: 'f407', name: 'Pin Message', description: 'Pin an important message to a channel for easy reference.', category: 'Organization', keywords: ['pin','bookmark','important','reference','highlight','save'], parameters: [{key:'channel_id',label:'Channel ID',type:'string',required:true},{key:'message_ts',label:'Message Timestamp',type:'string',required:true}], confidence: 82 },
      { id: 'f408', name: 'Invite Users to Channel', description: 'Invite one or more users to join a channel.', category: 'Channel', keywords: ['invite','add','user','member','join','channel','participate'], parameters: [{key:'channel_id',label:'Channel ID',type:'string',required:true},{key:'user_ids',label:'User IDs',type:'string',required:true}], confidence: 87 },
    ],
  },
  {
    id: 'stripe-pay',
    name: 'Stripe Payments',
    icon: 'CreditCard',
    color: '#635BFF',
    description: 'Payment processing platform. Charges, refunds, subscriptions, invoicing, and financial reconciliation.',
    category: 'Custom',
    apiVersion: 'v2024-06',
    status: 'available',
    functions: [
      { id: 'f501', name: 'Create Charge', description: 'Process a one-time payment charge against a customer payment method.', category: 'Payment', keywords: ['charge','payment','process','transaction','pay','collect','debit','sale'], parameters: [{key:'amount',label:'Amount (cents)',type:'number',required:true},{key:'currency',label:'Currency',type:'string',required:true},{key:'customer_id',label:'Customer ID',type:'string',required:true}], confidence: 96 },
      { id: 'f502', name: 'Create Subscription', description: 'Set up a recurring subscription with billing cycles and pricing tiers.', category: 'Subscription', keywords: ['subscribe','recurring','billing','plan','tier','membership','renewal'], parameters: [{key:'customer_id',label:'Customer ID',type:'string',required:true},{key:'price_id',label:'Price ID',type:'string',required:true}], confidence: 94 },
      { id: 'f503', name: 'Issue Refund', description: 'Process a full or partial refund for a previous charge.', category: 'Refund', keywords: ['refund','return','money','back','partial','full','reverse','credit'], parameters: [{key:'charge_id',label:'Charge ID',type:'string',required:true},{key:'amount',label:'Amount (cents)',type:'number',required:false},{key:'reason',label:'Reason',type:'string',required:false}], confidence: 93 },
      { id: 'f504', name: 'Generate Invoice', description: 'Create and send a finalized invoice to a customer for payment.', category: 'Invoicing', keywords: ['invoice','bill','send','customer','payment','request','due','outstanding'], parameters: [{key:'customer_id',label:'Customer ID',type:'string',required:true},{key:'collection_method',label:'Collection Method',type:'string',required:false}], confidence: 91 },
      { id: 'f505', name: 'Create Customer', description: 'Create a new customer record with contact and billing information.', category: 'Customer', keywords: ['customer','create','new','contact','billing','profile','account'], parameters: [{key:'email',label:'Email',type:'string',required:true},{key:'name',label:'Name',type:'string',required:false},{key:'metadata',label:'Metadata JSON',type:'json',required:false}], confidence: 90 },
      { id: 'f506', name: 'Query Payment Intent', description: 'Check the status and details of a payment intent.', category: 'Payment', keywords: ['payment','intent','status','query','check','3D secure','confirm'], parameters: [{key:'payment_intent_id',label:'Payment Intent ID',type:'string',required:true}], confidence: 88 },
      { id: 'f507', name: 'Reconcile Transactions', description: 'Match and reconcile payment transactions against bank statements.', category: 'Finance', keywords: ['reconcile','match','bank','statement','transaction','settlement','payout','discrepancy'], parameters: [{key:'date_range',label:'Date Range',type:'string',required:true},{key:'payout_id',label:'Payout ID',type:'string',required:false}], confidence: 86 },
      { id: 'f508', name: 'Handle Dispute', description: 'Respond to a chargeback dispute with evidence and explanation.', category: 'Dispute', keywords: ['dispute','chargeback','evidence','respond','fraud','claim','defend'], parameters: [{key:'dispute_id',label:'Dispute ID',type:'string',required:true},{key:'evidence',label:'Evidence JSON',type:'json',required:false}], confidence: 89 },
      { id: 'f509', name: 'Apply Coupon', description: 'Apply a discount coupon or promotion code to a subscription or charge.', category: 'Promotion', keywords: ['coupon','discount','promo','code','voucher','offer','reduction','save'], parameters: [{key:'coupon_id',label:'Coupon ID',type:'string',required:true},{key:'customer_id',label:'Customer ID',type:'string',required:true}], confidence: 87 },
      { id: 'f510', name: 'Generate Revenue Report', description: 'Produce a revenue, MRR, or churn analytics report.', category: 'Analytics', keywords: ['revenue','MRR','churn','report','analytics','metric','ARR','growth'], parameters: [{key:'report_type',label:'Report Type',type:'string',required:true},{key:'period',label:'Period',type:'string',required:true}], confidence: 84 },
    ],
  },
];

/** System color map for consistent coloring across the app */
export const SYSTEM_COLORS: Record<string, string> = {
  'SAP ERP': '#0F52BA',
  'Salesforce CRM': '#0176D3',
  'DocuWise': '#F59E0B',
  'Slack Connect': '#4A154B',
  'Stripe Payments': '#635BFF',
};

/** Get a system color by system name */
export function getSystemColor(systemName: string): string {
  return SYSTEM_COLORS[systemName] || '#94A3B8';
}

/** Get a system by its ID */
export function getSystem(id: string): TargetSystem | undefined {
  return TARGET_SYSTEMS.find(s => s.id === id);
}

/** Search functions across all systems by keyword */
export function searchFunctions(keyword: string): Array<{ system: TargetSystem; func: SystemFunction }> {
  const kw = keyword.toLowerCase();
  const results: Array<{ system: TargetSystem; func: SystemFunction }> = [];
  for (const sys of TARGET_SYSTEMS) {
    for (const func of sys.functions) {
      const match = func.name.toLowerCase().includes(kw) ||
        func.description.toLowerCase().includes(kw) ||
        func.keywords.some(k => k.includes(kw));
      if (match) results.push({ system: sys, func });
    }
  }
  return results.sort((a, b) => b.func.confidence - a.func.confidence);
}
