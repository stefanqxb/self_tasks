import { create } from 'zustand';
import type { Node, Edge } from '@xyflow/react';

interface WorkflowNodeData extends Record<string, unknown> {
  label: string;
  nodeType: 'transformer' | 'swb' | 'customization' | 'trigger';
  description?: string;
  icon?: string;
  parameters?: Array<{ key: string; label: string; value: string; required?: boolean }>;
}

export interface PendingWorkflow {
  nodes: Node<WorkflowNodeData>[];
  edges: Edge[];
  name: string;
  description: string;
}

interface WorkflowStore {
  pendingWorkflow: PendingWorkflow | null;
  setPendingWorkflow: (workflow: PendingWorkflow | null) => void;
  clearPendingWorkflow: () => void;
}

export const useWorkflowStore = create<WorkflowStore>((set) => ({
  pendingWorkflow: null,
  setPendingWorkflow: (workflow) => set({ pendingWorkflow: workflow }),
  clearPendingWorkflow: () => set({ pendingWorkflow: null }),
}));
