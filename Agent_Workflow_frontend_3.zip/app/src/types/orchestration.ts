/**
 * Orchestration Types
 * Type definitions for intelligent workflow orchestration system.
 */

/** A capability/function that a target system can perform */
export interface SystemFunction {
  id: string;
  name: string;
  description: string;
  category: string;
  parameters: { key: string; label: string; type: string; required: boolean }[];
  keywords: string[];
  confidence: number; // 0-100, how well this function matches general use cases
}

/** A candidate target system with its capabilities */
export interface TargetSystem {
  id: string;
  name: string;
  icon: string; // lucide icon name
  color: string;
  description: string;
  category: 'ERP' | 'CRM' | 'Document' | 'Communication' | 'Custom';
  functions: SystemFunction[];
  apiVersion: string;
  status: 'available' | 'limited' | 'deprecated';
}

/** A step in the orchestrated workflow */
export interface OrchestrationStep {
  id: string;
  label: string;
  description: string;
  systemId: string;
  functionId: string;
  systemName: string;
  functionName: string;
  confidence: number;
  params: Record<string, string>;
  fallback?: 'system' | 'custom'; // if no system match, use custom node
  subSteps?: OrchestrationStep[]; // multi-level: sub-flow
}

/** Result of analyzing a user requirement */
export interface OrchestrationResult {
  originalRequest: string;
  interpretedGoal: string;
  steps: OrchestrationStep[];
  unmetRequirements: string[];
  totalConfidence: number;
  systemsUsed: string[];
  customNodesNeeded: number;
}
