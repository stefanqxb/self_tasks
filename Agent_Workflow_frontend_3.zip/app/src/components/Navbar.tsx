import { Link } from 'react-router-dom'
import { Search, Bell } from 'lucide-react'

export default function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-[100] h-[52px] bg-white border-b border-border-light flex items-center justify-between px-4 shadow-sm">
      {/* Left: Logo + Breadcrumb */}
      <div className="flex items-center gap-3">
        <Link to="/" className="flex items-center gap-2">
          <img src="/logo-icon.png" alt="NexusFlow" className="w-5 h-5 object-contain" />
          <span className="text-base font-bold text-dark-text tracking-tight">NexusFlow</span>
        </Link>
        <span className="text-muted-gray text-sm">/</span>
        <span className="text-muted-gray text-sm">Dashboard</span>
      </div>

      {/* Right: Search, Notifications, Avatar */}
      <div className="flex items-center gap-2">
        <button className="w-9 h-9 rounded-md flex items-center justify-center text-muted-gray hover:bg-surface-light hover:text-dark-text transition-all duration-150">
          <Search size={20} />
        </button>
        <button className="w-9 h-9 rounded-md flex items-center justify-center text-muted-gray hover:bg-surface-light hover:text-dark-text transition-all duration-150 relative">
          <Bell size={20} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-error-red rounded-full" />
        </button>
        <Link
          to="/profile"
          className="w-8 h-8 rounded-full border-2 border-border-light overflow-hidden hover:border-brand-blue transition-all duration-150"
        >
          <img src="/ai-avatar.png" alt="User" className="w-full h-full object-cover" />
        </Link>
      </div>
    </nav>
  )
}
