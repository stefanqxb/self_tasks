import { useState } from 'react';
import { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import { ChevronDown, ChevronUp, Box, Cpu, Database, FileText, CreditCard, MessageSquare, Layers } from 'lucide-react';
import type { NodeProps } from '@xyflow/react';

interface GroupNodeData {
  label: string;
  description: string;
  systemName: string;
  systemColor: string;
  confidence: number;
  expanded?: boolean;
  subStepCount?: number;
  onToggle?: (id: string) => void;
  nodeId: string;
}

const SYSTEM_ICONS: Record<string, typeof Box> = {
  'SAP ERP': Database,
  'Salesforce CRM': Layers,
  'DocuWise': FileText,
  'Slack Connect': MessageSquare,
  'Stripe Payments': CreditCard,
};

function GroupNodeComponent(props: NodeProps) {
  const { data: rawData, selected } = props;
  const data = rawData as unknown as GroupNodeData;
  const [isHovered, setIsHovered] = useState(false);
  const expanded = data.expanded ?? false;
  const Icon = SYSTEM_ICONS[data.systemName] || Cpu;

  return (
    <div
      className="relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Main group card */}
      <div
        className={`rounded-xl border-2 px-4 py-3 min-w-[180px] transition-all duration-300 ${
          selected ? 'ring-2 ring-blue-400 ring-offset-2' : ''
        }`}
        style={{
          backgroundColor: `${data.systemColor}08`,
          borderColor: expanded ? data.systemColor : `${data.systemColor}40`,
          boxShadow: isHovered ? `0 8px 30px ${data.systemColor}15` : `0 2px 8px ${data.systemColor}08`,
        }}
      >
        {/* Header */}
        <div className="flex items-center gap-2">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
            style={{ backgroundColor: `${data.systemColor}15` }}
          >
            <Icon size={16} style={{ color: data.systemColor }} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-slate-800 truncate">{data.label}</div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-medium text-slate-400">{data.systemName}</span>
              {/* Confidence badge */}
              <span
                className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold"
                style={{
                  backgroundColor: data.confidence >= 85 ? '#10B98115' : data.confidence >= 60 ? '#F59E0B15' : '#EF444415',
                  color: data.confidence >= 85 ? '#059669' : data.confidence >= 60 ? '#D97706' : '#DC2626',
                }}
              >
                {data.confidence}%
              </span>
            </div>
          </div>
          {/* Expand/collapse button */}
          {data.subStepCount && data.subStepCount > 0 && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                data.onToggle?.(data.nodeId);
              }}
              className="w-7 h-7 rounded-md flex items-center justify-center hover:bg-slate-100 transition-colors shrink-0"
            >
              {expanded ? (
                <ChevronUp size={15} className="text-slate-500" />
              ) : (
                <ChevronDown size={15} className="text-slate-500" />
              )}
            </button>
          )}
        </div>

        {/* Description (shown when expanded or hovered) */}
        {(expanded || isHovered) && data.description && (
          <div className="mt-2 pt-2 border-t border-slate-100">
            <p className="text-[11px] text-slate-500 leading-relaxed">{data.description}</p>
          </div>
        )}

        {/* Sub-steps preview (shown when collapsed but has substeps) */}
        {!expanded && data.subStepCount && data.subStepCount > 0 && (
          <div className="mt-2 flex items-center gap-1">
            <div className="flex-1 h-1 rounded-full bg-slate-100 overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{
                  width: '100%',
                  background: `linear-gradient(90deg, ${data.systemColor}40, ${data.systemColor})`,
                }}
              />
            </div>
            <span className="text-[10px] text-slate-400 ml-1">{data.subStepCount} sub-steps</span>
          </div>
        )}
      </div>

      {/* Handles */}
      <Handle
        type="target"
        position={Position.Left}
        className="!w-3 !h-3 !bg-slate-300 !border-2 !border-white"
        style={{ left: -6 }}
      />
      <Handle
        type="source"
        position={Position.Right}
        className="!w-3 !h-3 !bg-slate-300 !border-2 !border-white"
        style={{ right: -6 }}
      />
      <Handle
        type="source"
        position={Position.Bottom}
        id="expand"
        className="!w-2 !h-2 !bg-blue-400 !border-2 !border-white"
        style={{ bottom: -5 }}
      />
    </div>
  );
}

export const GroupNode = memo(GroupNodeComponent);
