import { memo, useState, useCallback } from 'react';
import { Handle, Position } from '@xyflow/react';
import type { NodeProps } from '@xyflow/react';
import {
  Clock,
  Database,
  Filter,
  Mail,
  Timer,
  Shuffle,
  Zap,
  Settings,
  FileText,
  BarChart3,
  MessageSquare,
  Bot,
} from 'lucide-react';
import { motion } from 'framer-motion';
import type { CustomNodeData } from './types';
import { NODE_TYPE_COLORS } from './types';

const ICON_MAP: Record<string, React.ComponentType<{ size?: number; className?: string }>> = {
  Clock,
  Database,
  Filter,
  Mail,
  Timer,
  Shuffle,
  Zap,
  Settings,
  FileText,
  BarChart3,
  MessageSquare,
  Bot,
};

function getNodeIcon(iconName: string) {
  return ICON_MAP[iconName] || Settings;
}

const CustomNode = memo(function CustomNode(props: NodeProps) {
  const { data: rawData, selected, id } = props;
  const data = rawData as CustomNodeData;
  const { label, nodeType, icon, parameters, aiGenerated, isNew } = data;
  const color = NODE_TYPE_COLORS[nodeType];
  const IconComponent = getNodeIcon(icon);
  const [hoveredParam, setHoveredParam] = useState<string | null>(null);
  const [showGlow, setShowGlow] = useState(isNew ?? false);

  const handleAnimationComplete = useCallback(() => {
    setShowGlow(false);
  }, []);

  return (
    <motion.div
      initial={isNew ? { scale: 0, opacity: 0 } : false}
      animate={{ scale: 1, opacity: 1 }}
      transition={
        isNew
          ? { type: 'spring', stiffness: 260, damping: 20, duration: 0.3 }
          : undefined
      }
      onAnimationComplete={isNew ? handleAnimationComplete : undefined}
      className="group relative"
      style={{ minWidth: 180, maxWidth: 240 }}
      data-id={id}
    >
      {/* AI-generated golden glow pulse */}
      {aiGenerated && (
        <div
          className="absolute -inset-[3px] rounded-lg animate-ai-node-pulse pointer-events-none"
          style={{
            background: 'transparent',
            boxShadow: '0 0 12px rgba(245,158,11,0.4)',
          }}
        />
      )}
      {/* New node golden glow */}
      {showGlow && (
        <motion.div
          initial={{ opacity: 0.8 }}
          animate={{ opacity: 0 }}
          transition={{ duration: 2, ease: 'easeOut' }}
          className="absolute -inset-[4px] rounded-lg pointer-events-none"
          style={{
            boxShadow: '0 0 20px rgba(245,158,11,0.6), 0 0 40px rgba(245,158,11,0.3)',
          }}
        />
      )}

      {/* AI badge */}
      {aiGenerated && (
        <div
          className="absolute -top-2 -right-2 z-10 flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold tracking-wide pointer-events-none"
          style={{
            background: 'rgba(245,158,11,0.15)',
            color: '#F59E0B',
            border: '1px solid rgba(245,158,11,0.3)',
          }}
        >
          <Bot size={10} />
          AI
        </div>
      )}

      {/* Main node card */}
      <div
        className="rounded-lg overflow-hidden transition-all duration-200"
        style={{
          background: 'rgba(255, 255, 255, 0.98)',
          borderWidth: selected ? 2 : 1,
          borderColor: selected ? '#2B7FFF' : aiGenerated ? 'rgba(245,158,11,0.3)' : 'rgba(0,0,0,0.1)',
          boxShadow: selected
            ? '0 0 12px rgba(43,127,255,0.3)'
            : aiGenerated
              ? '0 0 8px rgba(245,158,11,0.2)'
              : 'none',
        }}
        onMouseEnter={(e) => {
          const el = e.currentTarget;
          el.style.borderColor = selected ? '#2B7FFF' : 'rgba(0,0,0,0.2)';
          if (!selected) {
            el.style.boxShadow = '0 0 12px rgba(43,127,255,0.3)';
          }
        }}
        onMouseLeave={(e) => {
          const el = e.currentTarget;
          el.style.borderColor = selected ? '#2B7FFF' : aiGenerated ? 'rgba(245,158,11,0.3)' : 'rgba(0,0,0,0.1)';
          el.style.boxShadow = selected
            ? '0 0 12px rgba(43,127,255,0.3)'
            : aiGenerated
              ? '0 0 8px rgba(245,158,11,0.2)'
              : 'none';
        }}
      >
        {/* Type-colored left border */}
        <div
          className="absolute left-0 top-0 bottom-0 w-[3px] rounded-l-lg"
          style={{ background: color }}
        />

        {/* Header */}
        <div className="flex items-center gap-2 px-3 py-2 pl-4 border-b border-black/[0.06]">
          <span style={{ color }}><IconComponent size={16} /></span>
          <span
            className="text-[13px] font-semibold text-dark-text truncate"
            title={label}
          >
            {label}
          </span>
        </div>

        {/* Parameters */}
        {parameters && parameters.length > 0 && (
          <div className="px-3 py-2 pl-4 space-y-1">
            {parameters.slice(0, 3).map((param) => (
              <div
                key={param.key}
                className="flex items-center justify-between gap-2"
                onMouseEnter={() => setHoveredParam(param.key)}
                onMouseLeave={() => setHoveredParam(null)}
              >
                <span className="text-[11px] font-medium text-muted-gray truncate">
                  {param.label}
                </span>
                <span
                  className="text-[11px] truncate max-w-[100px] transition-colors duration-100"
                  style={{
                    color: hoveredParam === param.key ? '#E2E8F0' : '#94A3B8',
                  }}
                  title={param.value}
                >
                  {param.value.length > 14
                    ? param.value.substring(0, 14) + '...'
                    : param.value}
                </span>
              </div>
            ))}
            {parameters.length > 3 && (
              <span className="text-[10px] text-muted-gray">
                +{parameters.length - 3} more
              </span>
            )}
          </div>
        )}
      </div>

      {/* Input handle */}
      <Handle
        type="target"
        position={Position.Left}
        style={{
          width: 12,
          height: 12,
          background: '#2B7FFF',
          border: '2px solid #F8FAFC',
          left: -7,
        }}
      />

      {/* Output handle */}
      <Handle
        type="source"
        position={Position.Right}
        style={{
          width: 12,
          height: 12,
          background: '#2B7FFF',
          border: '2px solid #F8FAFC',
          right: -7,
        }}
      />
    </motion.div>
  );
});

export default CustomNode;
