import type { NodeType, NodeParameter, CustomNodeType, CustomEdgeType } from './types';

const triggerParams: NodeParameter[] = [
  { key: 'schedule', label: 'Schedule', value: 'Every 15 minutes', type: 'select', options: ['Every 5 minutes', 'Every 15 minutes', 'Every hour', 'Daily'] },
  { key: 'timezone', label: 'Timezone', value: 'UTC' },
];

const crmParams: NodeParameter[] = [
  { key: 'source', label: 'Source', value: 'Salesforce', type: 'select', options: ['Salesforce', 'HubSpot', 'Zoho'] },
  { key: 'query', label: 'Query', value: 'SELECT * FROM customers WHERE status = \'active\'' },
];

const filterParams: NodeParameter[] = [
  { key: 'condition', label: 'Condition', value: 'value > 10000', type: 'text' },
  { key: 'field', label: 'Field', value: 'lifetime_value' },
];

const transformParams: NodeParameter[] = [
  { key: 'mapping', label: 'Field Mapping', value: '{ name: customer_name, email: contact_email }' },
  { key: 'format', label: 'Output Format', value: 'JSON', type: 'select', options: ['JSON', 'CSV', 'XML'] },
];

const emailParams: NodeParameter[] = [
  { key: 'template', label: 'Template', value: 'welcome_email_v2' },
  { key: 'subject', label: 'Subject', value: 'Welcome to our premium service!' },
];

const delayParams: NodeParameter[] = [
  { key: 'delay', label: 'Delay', value: '24', type: 'number' },
  { key: 'unit', label: 'Unit', value: 'hours', type: 'select', options: ['minutes', 'hours', 'days'] },
];

export const initialNodes: CustomNodeType[] = [
  {
    id: '1',
    type: 'custom',
    position: { x: 100, y: 200 },
    data: {
      label: 'Webhook Trigger',
      nodeType: 'customization' as NodeType,
      icon: 'Zap',
      description: 'Receives incoming webhook calls to start workflow',
      parameters: triggerParams,
      aiGenerated: false,
    },
  },
  {
    id: '2',
    type: 'custom',
    position: { x: 380, y: 200 },
    data: {
      label: 'Merge Rows',
      nodeType: 'transformer' as NodeType,
      icon: 'Combine',
      description: 'Combine multiple data rows by key with aggregation',
      parameters: crmParams,
      aiGenerated: false,
    },
  },
  {
    id: '3',
    type: 'custom',
    position: { x: 660, y: 200 },
    data: {
      label: 'Filter Rows',
      nodeType: 'transformer' as NodeType,
      icon: 'Filter',
      description: 'Filters rows by column conditions',
      parameters: filterParams,
      aiGenerated: false,
    },
  },
  {
    id: '4',
    type: 'custom',
    position: { x: 660, y: 420 },
    data: {
      label: 'API Request',
      nodeType: 'swb' as NodeType,
      icon: 'Globe',
      description: 'Makes REST API call with retry logic',
      parameters: delayParams,
      aiGenerated: false,
    },
  },
  {
    id: '5',
    type: 'custom',
    position: { x: 940, y: 200 },
    data: {
      label: 'Column Mapping',
      nodeType: 'transformer' as NodeType,
      icon: 'Shuffle',
      description: 'Maps and renames columns',
      parameters: transformParams,
      aiGenerated: false,
    },
  },
  {
    id: '6',
    type: 'custom',
    position: { x: 1220, y: 200 },
    data: {
      label: 'Send Email',
      nodeType: 'customization' as NodeType,
      icon: 'Mail',
      description: 'Sends personalized email via SMTP',
      parameters: emailParams,
      aiGenerated: false,
    },
  },
];

export const initialEdges: CustomEdgeType[] = [
  {
    id: 'e1-2',
    source: '1',
    target: '2',
    type: 'custom',
    data: { animated: true },
  },
  {
    id: 'e2-3',
    source: '2',
    target: '3',
    type: 'custom',
    data: { animated: true },
  },
  {
    id: 'e3-4',
    source: '3',
    target: '4',
    sourceHandle: 'bottom',
    targetHandle: 'top',
    type: 'custom',
    data: { animated: false },
  },
  {
    id: 'e3-5',
    source: '3',
    target: '5',
    type: 'custom',
    data: { animated: true },
  },
  {
    id: 'e4-5',
    source: '4',
    target: '5',
    type: 'custom',
    data: { animated: false },
  },
  {
    id: 'e5-6',
    source: '5',
    target: '6',
    type: 'custom',
    data: { animated: true },
  },
];

export const mockAIWorkflowResponse = {
  nodes: [
    {
      id: 'ai-1',
      label: 'Webhook',
      type: 'customization' as NodeType,
      x: 100,
      y: 200,
    },
    {
      id: 'ai-2',
      label: 'Filter Rows',
      type: 'transformer' as NodeType,
      x: 380,
      y: 200,
    },
    {
      id: 'ai-3',
      label: 'LLM Prompt',
      type: 'swb' as NodeType,
      x: 660,
      y: 200,
    },
    {
      id: 'ai-4',
      label: 'Send Email',
      type: 'customization' as NodeType,
      x: 940,
      y: 200,
    },
  ],
  edges: [
    { source: 'ai-1', target: 'ai-2' },
    { source: 'ai-2', target: 'ai-3' },
    { source: 'ai-3', target: 'ai-4' },
  ],
};

export const initialChatMessages = [
  {
    id: 'sys-1',
    role: 'system' as const,
    content: 'AI Assistant is ready to help you build workflows.',
    timestamp: new Date(Date.now() - 1000 * 60 * 5),
  },
  {
    id: 'msg-1',
    role: 'user' as const,
    content: 'Create a workflow that fetches customer data from a CRM, filters for high-value customers, and sends them a personalized email',
    timestamp: new Date(Date.now() - 1000 * 60 * 4),
  },
  {
    id: 'msg-2',
    role: 'ai' as const,
    content: 'I\'ve created a workflow with 6 connected nodes:\n1. Webhook Trigger — receives incoming webhook\n2. Merge Rows — combines related records by customer ID\n3. Filter Rows — filters by value > $10,000\n4. API Request — calls enrichment API\n5. Column Mapping — renames and formats columns\n6. Send Email — sends personalized message\n\nClick "Apply to Canvas" to add it, or tell me to modify any part.',
    timestamp: new Date(Date.now() - 1000 * 60 * 3),
    workflowPreview: mockAIWorkflowResponse,
  },
];
