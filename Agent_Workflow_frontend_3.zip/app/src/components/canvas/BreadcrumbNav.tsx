import { ChevronRight, Home } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface BreadcrumbItem {
  id: string;
  label: string;
  level: number;
}

interface BreadcrumbNavProps {
  items: BreadcrumbItem[];
  onNavigate: (item: BreadcrumbItem) => void;
}

export function BreadcrumbNav({ items, onNavigate }: BreadcrumbNavProps) {
  return (
    <div className="flex items-center gap-1 px-4 py-2 bg-white/80 backdrop-blur-sm border-b border-slate-200">
      {items.length <= 1 ? (
        <span className="flex items-center gap-1 text-xs text-slate-500">
          <Home size={12} />
          <span className="font-medium">Main Flow</span>
        </span>
      ) : (
        <>
          <button
            onClick={() => onNavigate(items[0])}
            className="flex items-center gap-1 text-xs text-slate-500 hover:text-blue-600 transition-colors"
          >
            <Home size={12} />
            <span className="font-medium">Main Flow</span>
          </button>
          {items.slice(1).map((item, i) => (
            <div key={item.id} className="flex items-center gap-1">
              <ChevronRight size={12} className="text-slate-300" />
              <button
                onClick={() => onNavigate(item)}
                className={cn(
                  'text-xs transition-colors font-medium',
                  i === items.slice(1).length - 1
                    ? 'text-blue-600'
                    : 'text-slate-500 hover:text-blue-600'
                )}
              >
                {item.label}
              </button>
            </div>
          ))}
        </>
      )}
    </div>
  );
}
