import type { Node, Edge } from '@xyflow/react';

export type NodeType = 'transformer' | 'swb' | 'customization';

export interface NodeParameter {
  key: string;
  label: string;
  value: string;
  type?: 'text' | 'number' | 'select' | 'boolean';
  options?: string[];
  required?: boolean;
}

export interface CustomNodeData extends Record<string, unknown> {
  label: string;
  description?: string;
  nodeType: NodeType;
  icon: string;
  parameters?: NodeParameter[];
  aiGenerated?: boolean;
  isNew?: boolean;
}

export interface CustomEdgeData extends Record<string, unknown> {
  animated?: boolean;
  onDelete?: (id: string) => void;
}

export type CustomNodeType = Node<CustomNodeData, 'custom'>;
export type CustomEdgeType = Edge<CustomEdgeData>;

export interface NodeTemplate {
  type: NodeType;
  label: string;
  description: string;
  icon: string;
  defaultParameters?: NodeParameter[];
}

export interface NodeCategoryDef {
  name: string;
  type: NodeType;
  color: string;
  nodes: NodeTemplate[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'ai' | 'system';
  content: string;
  timestamp: Date;
  workflowPreview?: {
    nodes: Array<{ id: string; label: string; type: NodeType; x: number; y: number }>;
    edges: Array<{ source: string; target: string }>;
  };
}

export const NODE_TYPE_COLORS: Record<NodeType, string> = {
  transformer: '#10B981',
  swb: '#2B7FFF',
  customization: '#F59E0B',
};

export const NODE_TYPE_LABELS: Record<NodeType, string> = {
  transformer: 'Transformer',
  swb: 'SWB',
  customization: 'Customization',
};
