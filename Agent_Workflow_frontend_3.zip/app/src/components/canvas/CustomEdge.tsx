import { memo, useState, useCallback } from 'react';
import { BaseEdge, EdgeLabelRenderer, getBezierPath } from '@xyflow/react';
import type { EdgeProps } from '@xyflow/react';
import { X } from 'lucide-react';
import type { CustomEdgeData } from './types';

const CustomEdge = memo(function CustomEdge(props: EdgeProps) {
  const {
    id,
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    style = {},
    selected,
    data: rawData,
  } = props;
  const data = rawData as unknown as CustomEdgeData | undefined;
  const [isHovered, setIsHovered] = useState(false);
  const animated = data?.animated ?? false;
  const onDelete = data?.onDelete;

  const [edgePath, labelX, labelY] = getBezierPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
  });

  const handleDelete = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      onDelete?.(id);
    },
    [id, onDelete]
  );

  return (
    <>
      <BaseEdge
        path={edgePath}
        style={{
          ...style,
          stroke: selected ? '#2B7FFF' : '#4A9DFF',
          strokeWidth: isHovered || selected ? 3 : 2,
          strokeDasharray: animated ? '8 4' : 'none',
          animation: animated ? 'dash-flow 1s linear infinite' : 'none',
          transition: 'stroke-width 150ms ease',
          cursor: 'pointer',
        }}
        className="custom-edge-path"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      />
      <style>{`
        @keyframes dash-flow {
          to {
            stroke-dashoffset: -24;
          }
        }
      `}</style>

      {/* Hover / selected delete button */}
      <EdgeLabelRenderer>
        {(isHovered || selected) && (
          <div
            className="nodrag nopan pointer-events-auto"
            style={{
              position: 'absolute',
              transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
              zIndex: 1000,
            }}
          >
            <button
              onClick={handleDelete}
              className="flex items-center justify-center w-5 h-5 rounded-full bg-white border border-error-red shadow-sm text-error-red hover:bg-error-red hover:text-dark-text transition-all duration-150 cursor-pointer"
              title="Delete connection"
            >
              <X size={10} />
            </button>
          </div>
        )}
      </EdgeLabelRenderer>
    </>
  );
});

export default CustomEdge;
