import { useState, useEffect } from 'react'
import { Play, AlertCircle } from 'lucide-react'

export default function Footer() {
  const [zoom] = useState(100)
  const [coords, setCoords] = useState({ x: 0, y: 0 })
  const [nodeCount] = useState(24)
  const [connectionCount] = useState(36)
  const [lastSaved, setLastSaved] = useState('2m ago')
  const [status] = useState<'idle' | 'running' | 'error'>('running')

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setCoords({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener('mousemove', handleMouseMove)

    const interval = setInterval(() => {
      const now = new Date()
      setLastSaved(`${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`)
    }, 60000)

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      clearInterval(interval)
    }
  }, [])

  return (
    <footer className="fixed bottom-0 left-0 right-0 z-[100] h-[28px] bg-white border-t border-border-light flex items-center justify-between px-4 text-xs text-muted-gray">
      {/* Left: Zoom + Coordinates */}
      <div className="flex items-center gap-4">
        <span>{zoom}%</span>
        <span>x: {coords.x}, y: {coords.y}</span>
      </div>

      {/* Center: Status */}
      <div className="flex items-center gap-2">
        {status === 'idle' && (
          <>
            <span className="w-2 h-2 rounded-full bg-muted-gray" />
            <span>Idle</span>
          </>
        )}
        {status === 'running' && (
          <>
            <Play size={10} className="text-success-green animate-green-pulse" />
            <span className="text-success-green">Running</span>
          </>
        )}
        {status === 'error' && (
          <>
            <AlertCircle size={10} className="text-error-red" />
            <span className="text-error-red">Error</span>
          </>
        )}
      </div>

      {/* Right: Node count, Connection count, Last saved */}
      <div className="flex items-center gap-4">
        <span>{nodeCount} nodes</span>
        <span>{connectionCount} connections</span>
        <span>Last saved {lastSaved}</span>
      </div>
    </footer>
  )
}
