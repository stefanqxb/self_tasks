import type { ReactNode } from 'react'
import Navbar from './Navbar'
import Sidebar from './Sidebar'
import Footer from './Footer'

interface LayoutProps {
  children: ReactNode
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="h-screen w-screen overflow-hidden bg-surface-light">
      <Navbar />
      <Sidebar />
      <main className="ml-[56px] bg-surface-light" style={{ height: 'calc(100vh - 52px - 28px)' }}>
        {children}
      </main>
      <Footer />
    </div>
  )
}
