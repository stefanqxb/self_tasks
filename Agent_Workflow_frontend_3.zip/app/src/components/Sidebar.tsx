import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import {
  LayoutDashboard,
  PenTool,
  Box,
  GitBranch,
  Sparkles,
  BookOpen,
  Settings,
  HelpCircle,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'

const navItems = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/canvas', icon: PenTool, label: 'Canvas' },
  { path: '/node-library', icon: Box, label: 'Node Library' },
  { path: '/workflows', icon: GitBranch, label: 'Workflows' },
  { path: '/ai-assistant', icon: Sparkles, label: 'AI Assistant' },
  { path: '/knowledge-hub', icon: BookOpen, label: 'Knowledge Hub' },
]

export default function Sidebar() {
  const [expanded, setExpanded] = useState(false)
  const location = useLocation()

  return (
    <aside
      className="fixed left-0 top-[52px] bottom-[28px] z-[90] bg-white border-r border-border-light flex flex-col transition-all duration-300 shadow-[2px_0_8px_rgba(0,0,0,0.06)]"
      style={{ width: expanded ? 220 : 56 }}
    >
      {/* Main nav items */}
      <div className="flex flex-col gap-1 p-2 flex-1">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = location.pathname === item.path
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`
                flex items-center gap-3 h-11 rounded-md px-2 transition-all duration-200
                ${
                  isActive
                    ? 'bg-brand-blue/10 text-brand-blue border-l-[3px] border-brand-blue'
                    : 'text-muted-gray hover:bg-surface-light hover:text-dark-text border-l-[3px] border-transparent'
                }
              `}
              style={{ paddingLeft: expanded ? 12 : undefined }}
              title={!expanded ? item.label : undefined}
            >
              <Icon size={20} className="flex-shrink-0" />
              {expanded && (
                <span className="text-sm font-medium whitespace-nowrap transition-opacity duration-200">
                  {item.label}
                </span>
              )}
            </Link>
          )
        })}
      </div>

      {/* Bottom section */}
      <div className="flex flex-col gap-1 p-2 border-t border-border-light">
        <Link
          to="/settings"
          className={`
            flex items-center gap-3 h-11 rounded-md px-2 transition-all duration-200
            ${
              location.pathname === '/settings'
                ? 'bg-brand-blue/10 text-brand-blue border-l-[3px] border-brand-blue'
                : 'text-muted-gray hover:bg-surface-light hover:text-dark-text border-l-[3px] border-transparent'
            }
          `}
          title={!expanded ? 'Settings' : undefined}
        >
          <Settings size={20} className="flex-shrink-0" />
          {expanded && <span className="text-sm font-medium whitespace-nowrap">Settings</span>}
        </Link>
        <button
          className="flex items-center gap-3 h-11 rounded-md px-2 text-muted-gray hover:bg-surface-light hover:text-dark-text transition-all duration-200 border-l-[3px] border-transparent"
          title={!expanded ? 'Help' : undefined}
        >
          <HelpCircle size={20} className="flex-shrink-0" />
          {expanded && <span className="text-sm font-medium whitespace-nowrap">Help</span>}
        </button>
      </div>

      {/* Expand/collapse toggle */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="absolute -right-3 top-4 w-6 h-6 bg-white border border-border-light rounded-full flex items-center justify-center text-muted-gray hover:text-dark-text transition-all duration-200 shadow-sm z-10"
      >
        {expanded ? <ChevronLeft size={12} /> : <ChevronRight size={12} />}
      </button>
    </aside>
  )
}
