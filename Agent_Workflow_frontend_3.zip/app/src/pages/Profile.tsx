export default function Profile() {
  return (
    <div className="p-8 bg-surface-light h-full">
      <h1 className="text-2xl font-bold text-dark-text mb-4">Profile</h1>
      <p className="text-muted-dark">View and manage your profile.</p>
    </div>
  )
}
