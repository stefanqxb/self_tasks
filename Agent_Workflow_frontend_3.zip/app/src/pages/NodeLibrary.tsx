import { useState, useMemo, useCallback, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search, Upload, Plus, LayoutGrid, List, Heart, X,
  Check, ChevronRight, ChevronLeft as ChevronLeftIcon,
  Briefcase, Star, Table, Cpu, Settings2, Edit3,
  Save, RotateCcw, FileJson, PenTool, Trash2, AlertCircle,
  Loader2,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/** Python Agent API base URL */
const AGENT_API_URL = import.meta.env.VITE_AGENT_URL || 'http://localhost:8000'

// ─── Types ───────────────────────────────────────────────────────────────────

type NodeCategory = 'Transformer' | 'SWB' | 'Customization'

interface NodeParam {
  name: string
  type: string
  required: boolean
  default?: string
}

interface NodeItem {
  id: string
  name: string
  description: string
  type: NodeCategory
  source: string
  tags: string[]
  usageCount: number
  parameters: NodeParam[]
  connections: { input: string[]; output: string[] }
  workflows: string[]
  recommended?: boolean
}

// ─── Constants ───────────────────────────────────────────────────────────────

const CATEGORIES = ['All', 'Transformer', 'SWB', 'Customization'] as const
const SOURCES = ['All Sources', 'Built-in', 'Imported', 'Custom', 'Zapier', 'Make', 'n8n']
const SORT_OPTIONS = ['Most Used', 'Recently Added', 'Alphabetical', 'Type']

const TYPE_COLORS: Record<string, { bg: string; text: string; border: string; icon: string }> = {
  Transformer: { bg: 'bg-emerald-50', text: 'text-emerald-600', border: 'border-emerald-200', icon: 'bg-emerald-100' },
  SWB: { bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-blue-200', icon: 'bg-blue-100' },
  Customization: { bg: 'bg-amber-50', text: 'text-amber-600', border: 'border-amber-200', icon: 'bg-amber-100' },
}

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number]

// ─── API Helpers ─────────────────────────────────────────────────────────────

async function apiListNodes(): Promise<NodeItem[]> {
  const resp = await fetch(`${AGENT_API_URL}/api/nodes`)
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`)
  return resp.json()
}

async function apiCreateNode(node: NodeItem): Promise<void> {
  const resp = await fetch(`${AGENT_API_URL}/api/nodes`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(node),
  })
  if (!resp.ok) throw new Error(`HTTP ${resp.status}: ${await resp.text()}`)
}

async function apiUpdateNode(node: NodeItem): Promise<void> {
  const resp = await fetch(`${AGENT_API_URL}/api/nodes/${node.id}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(node),
  })
  if (!resp.ok) throw new Error(`HTTP ${resp.status}: ${await resp.text()}`)
}

async function apiDeleteNode(id: string): Promise<void> {
  const resp = await fetch(`${AGENT_API_URL}/api/nodes/${id}`, { method: 'DELETE' })
  if (!resp.ok) throw new Error(`HTTP ${resp.status}: ${await resp.text()}`)
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function NodeLibrary() {
  const [nodes, setNodes] = useState<NodeItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [activeSource, setActiveSource] = useState('All Sources')
  const [sortBy, setSortBy] = useState('Most Used')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [selectedNode, setSelectedNode] = useState<NodeItem | null>(null)
  const [addNodeOpen, setAddNodeOpen] = useState(false)
  const [favorites, setFavorites] = useState<Set<string>>(new Set())

  const searchTimeout = useRef<ReturnType<typeof setTimeout> | null>(null)
  const [debouncedQuery, setDebouncedQuery] = useState('')

  // Load nodes from backend on mount
  useEffect(() => {
    apiListNodes()
      .then(data => { setNodes(data); setLoading(false) })
      .catch(err => { setError(err.message); setLoading(false) })
  }, [])

  const handleSearch = (value: string) => {
    setSearchQuery(value)
    if (searchTimeout.current) clearTimeout(searchTimeout.current)
    searchTimeout.current = setTimeout(() => setDebouncedQuery(value), 300)
  }

  // Save edited node -> backend
  const handleSaveNode = useCallback(async (updated: NodeItem) => {
    try {
      await apiUpdateNode(updated)
      setNodes(prev => prev.map(n => n.id === updated.id ? updated : n))
    } catch (err) {
      alert(`Failed to save: ${err instanceof Error ? err.message : 'unknown error'}`)
    }
  }, [])

  // Delete node -> backend
  const handleDeleteNode = useCallback(async (id: string) => {
    try {
      await apiDeleteNode(id)
      setNodes(prev => prev.filter(n => n.id !== id))
      setSelectedNode(null)
    } catch (err) {
      alert(`Failed to delete: ${err instanceof Error ? err.message : 'unknown error'}`)
    }
  }, [])

  // Add new node -> backend
  const handleAddNode = useCallback(async (newNode: NodeItem) => {
    try {
      await apiCreateNode(newNode)
      setNodes(prev => [...prev, newNode])
    } catch (err) {
      alert(`Failed to create: ${err instanceof Error ? err.message : 'unknown error'}`)
    }
  }, [])

  const filteredNodes = useMemo(() => {
    let filtered = nodes.filter((node) => {
      const matchesSearch = debouncedQuery === '' ||
        node.name.toLowerCase().includes(debouncedQuery.toLowerCase()) ||
        node.description.toLowerCase().includes(debouncedQuery.toLowerCase()) ||
        node.tags.some(t => t.toLowerCase().includes(debouncedQuery.toLowerCase()))
      const matchesCategory = activeCategory === 'All' || node.type === activeCategory
      const matchesSource = activeSource === 'All Sources' || node.source === activeSource ||
        (activeSource === 'Imported' && ['Zapier', 'Make', 'n8n'].includes(node.source))
      return matchesSearch && matchesCategory && matchesSource
    })
    switch (sortBy) {
      case 'Most Used': filtered.sort((a, b) => b.usageCount - a.usageCount); break
      case 'Alphabetical': filtered.sort((a, b) => a.name.localeCompare(b.name)); break
      case 'Type': filtered.sort((a, b) => a.type.localeCompare(b.type)); break
      case 'Recently Added': filtered.sort((a, b) => b.id.localeCompare(a.id)); break
    }
    return filtered
  }, [debouncedQuery, activeCategory, activeSource, sortBy, nodes])

  const toggleFavorite = useCallback((id: string) => {
    setFavorites(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }, [])

  if (loading) return (
    <div className="h-full flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-3">
        <Loader2 size={28} className="text-blue-600 animate-spin" />
        <p className="text-sm text-slate-500">Loading nodes from backend...</p>
      </div>
    </div>
  )

  if (error) return (
    <div className="h-full flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-3 text-center">
        <AlertCircle size={28} className="text-red-500" />
        <p className="text-sm text-red-600 font-medium">Failed to load nodes</p>
        <p className="text-xs text-slate-400">{error}</p>
        <p className="text-xs text-slate-400">Make sure the Python agent is running:<br/><code className="bg-slate-100 px-1 rounded">python -m uvicorn main:app --port 8000</code></p>
        <button onClick={() => window.location.reload()} className="h-8 px-4 rounded-lg text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700">Retry</button>
      </div>
    </div>
  )

  return (
    <div className="h-full overflow-y-auto bg-slate-50 p-6 lg:p-8">
      {/* ─── Page Header ─── */}
      <motion.div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-6" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, ease: EASE }}>
        <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
          <span>Dashboard</span><span>/</span><span className="text-blue-600 font-medium">Node Library</span>
        </div>
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-[28px] font-bold text-slate-900 leading-tight">Node Library</h1>
            <p className="text-sm text-slate-500 mt-1">{nodes.length} nodes across {CATEGORIES.length - 1} categories &middot; stored in <code className="bg-slate-100 px-1 rounded text-xs">node_lib/</code></p>
          </div>
          <button onClick={() => setAddNodeOpen(true)}
            className="h-10 px-5 rounded-lg text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:scale-[0.98] transition-all flex items-center gap-2 shadow-sm">
            <Plus size={17} /> Add Node
          </button>
        </div>
      </motion.div>

      {/* ─── Filters ─── */}
      <motion.div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 mb-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3, delay: 0.15 }}>
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative w-[320px]">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input type="text" value={searchQuery} onChange={(e) => handleSearch(e.target.value)}
              placeholder="Search nodes..."
              className="w-full h-10 pl-10 pr-4 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 transition-all" />
            {searchQuery && <button onClick={() => handleSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"><X size={14} /></button>}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {CATEGORIES.map((cat) => (
              <button key={cat} onClick={() => setActiveCategory(cat)}
                className={cn('h-8 px-3 rounded-full text-xs font-medium transition-all border',
                  activeCategory === cat ? 'bg-blue-600 text-white border-transparent' : 'bg-white border-slate-200 text-slate-600 hover:bg-blue-50 hover:border-blue-200')}>
                {cat} <span className={cn('text-[10px]', activeCategory === cat ? 'text-white/70' : 'text-slate-400')}>({cat === 'All' ? nodes.length : nodes.filter(n => n.type === cat as NodeCategory).length})</span>
              </button>
            ))}
          </div>
          <div className="ml-auto flex items-center gap-3">
            <select value={activeSource} onChange={(e) => setActiveSource(e.target.value)}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:border-blue-500 cursor-pointer">
              {SOURCES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:border-blue-500 cursor-pointer">
              {SORT_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden">
              <button onClick={() => setViewMode('grid')} className={cn('w-9 h-9 flex items-center justify-center transition-all', viewMode === 'grid' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:text-slate-800')}><LayoutGrid size={18} /></button>
              <button onClick={() => setViewMode('list')} className={cn('w-9 h-9 flex items-center justify-center transition-all', viewMode === 'list' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:text-slate-800')}><List size={18} /></button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ─── Grid View ─── */}
      <AnimatePresence mode="wait">
        {viewMode === 'grid' && filteredNodes.length > 0 && (
          <motion.div key="grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
            {filteredNodes.map((node, i) => {
              const colors = TYPE_COLORS[node.type] || TYPE_COLORS.Transformer
              const isFav = favorites.has(node.id)
              return (
                <motion.div key={node.id} custom={i}
                  initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay: i * 0.05, ease: EASE }}
                  whileHover={{ y: -3, transition: { duration: 0.2 } }}
                  onClick={() => setSelectedNode(node)}
                  className={cn('bg-white rounded-xl shadow-sm border border-slate-200 p-4 cursor-pointer hover:shadow-lg transition-all relative',
                    node.recommended && 'ring-1 ring-amber-300/50')}>
                  {node.recommended && <div className="absolute -top-2 -left-2 flex items-center gap-1 bg-amber-50 text-amber-600 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-amber-200"><Star size={10} className="fill-amber-500" /> Recommended</div>}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={cn('w-9 h-9 rounded-full flex items-center justify-center', colors.icon)}><NodeTypeIcon type={node.type} size={18} className={colors.text} /></div>
                      <h3 className="text-[15px] font-semibold text-slate-800 leading-tight">{node.name}</h3>
                    </div>
                    <span className="text-[10px] font-medium text-slate-400 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100">{node.source}</span>
                  </div>
                  <p className="text-[13px] text-slate-500 leading-relaxed mb-3 line-clamp-2">{node.description}</p>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {node.tags.map(tag => <span key={tag} className={cn('text-[11px] font-semibold px-2 py-0.5 rounded-full', colors.bg, colors.text)}>{tag}</span>)}
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                    <span className="flex items-center gap-1.5 text-[11px] text-slate-400"><Briefcase size={12} /> {node.usageCount} workflows</span>
                    <div className="flex items-center gap-1">
                      <button onClick={(e) => { e.stopPropagation(); setSelectedNode(node) }} className="w-8 h-8 flex items-center justify-center rounded-md text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors" title="Edit"><Edit3 size={15} /></button>
                      <button onClick={(e) => { e.stopPropagation(); toggleFavorite(node.id) }} className={cn('w-8 h-8 flex items-center justify-center rounded-md transition-colors', isFav ? 'text-red-500' : 'text-slate-400 hover:text-red-500 hover:bg-red-50')}><Heart size={15} className={isFav ? 'fill-red-500' : ''} /></button>
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </motion.div>
        )}

        {/* ─── List View ─── */}
        {viewMode === 'list' && filteredNodes.length > 0 && (
          <motion.div key="list" className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
            {filteredNodes.map((node, i) => {
              const colors = TYPE_COLORS[node.type] || TYPE_COLORS.Transformer
              const isFav = favorites.has(node.id)
              return (
                <motion.div key={node.id} custom={i}
                  initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.25, delay: i * 0.03, ease: EASE }}
                  onClick={() => setSelectedNode(node)}
                  className="flex items-center gap-4 px-4 h-16 border-b border-slate-100 last:border-b-0 cursor-pointer hover:bg-blue-50/30 transition-colors">
                  <div className={cn('w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0', colors.icon)}><NodeTypeIcon type={node.type} size={14} className={colors.text} /></div>
                  <div className="w-32 flex-shrink-0"><span className="text-sm font-semibold text-slate-800">{node.name}</span></div>
                  <div className="flex-1 min-w-0"><span className="text-xs text-slate-500 truncate block">{node.description}</span></div>
                  <div className="flex items-center gap-1 flex-shrink-0">{node.tags.slice(0, 2).map(tag => <span key={tag} className={cn('text-[10px] font-semibold px-2 py-0.5 rounded-full', colors.bg, colors.text)}>{tag}</span>)}</div>
                  <span className="text-[11px] text-slate-400 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100 flex-shrink-0">{node.source}</span>
                  <span className="text-[11px] text-slate-400 flex items-center gap-1 flex-shrink-0 w-20"><Briefcase size={11} /> {node.usageCount}</span>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button onClick={(e) => { e.stopPropagation(); setSelectedNode(node) }} className="w-8 h-8 flex items-center justify-center rounded-md text-slate-400 hover:text-blue-600 transition-colors" title="Edit"><Edit3 size={15} /></button>
                    <button onClick={(e) => { e.stopPropagation(); toggleFavorite(node.id) }} className={cn('w-8 h-8 flex items-center justify-center rounded-md transition-colors', isFav ? 'text-red-500' : 'text-slate-400 hover:text-red-500')}><Heart size={15} className={isFav ? 'fill-red-500' : ''} /></button>
                  </div>
                </motion.div>
              )
            })}
          </motion.div>
        )}

        {/* Empty */}
        {filteredNodes.length === 0 && (
          <motion.div key="empty" className="flex flex-col items-center justify-center py-16" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <div className="w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center mb-4"><Search size={40} className="text-slate-300" /></div>
            <h3 className="text-lg font-semibold text-slate-500 mb-1">No nodes found</h3>
            <p className="text-sm text-slate-400 mb-4">Try adjusting filters or add a new node.</p>
            <button onClick={() => { handleSearch(''); setActiveCategory('All'); setActiveSource('All Sources') }}
              className="h-9 px-4 rounded-lg text-sm font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 transition-colors">Clear Filters</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Modals ─── */}
      <AnimatePresence>
        {addNodeOpen && <AddNodeModal onClose={() => setAddNodeOpen(false)} onAdd={handleAddNode} />}
        {selectedNode && (
          <NodeDetailDrawer
            node={selectedNode}
            onClose={() => setSelectedNode(null)}
            onSave={handleSaveNode}
            onDelete={handleDeleteNode}
          />
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── Node Type Icon ──────────────────────────────────────────────────────────

function NodeTypeIcon({ type, size = 16, className = '' }: { type: string; size?: number; className?: string }) {
  switch (type) {
    case 'Transformer': return <Table size={size} className={className} />
    case 'SWB': return <Cpu size={size} className={className} />
    case 'Customization': return <Settings2 size={size} className={className} />
    default: return <BoxIcon size={size} className={className} />
  }
}

function BoxIcon({ size = 16, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" /><path d="m3.3 7 8.7 5 8.7-5" /><path d="M12 22V12" />
    </svg>
  )
}

// ─── Node Detail Drawer (View + Edit Mode) ──────────────────────────────────

function NodeDetailDrawer({ node, onClose, onSave, onDelete }: {
  node: NodeItem; onClose: () => void; onSave: (n: NodeItem) => Promise<void>; onDelete: (id: string) => Promise<void>
}) {
  const [isEditing, setIsEditing] = useState(false)
  const [editForm, setEditForm] = useState<NodeItem>({ ...node })
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [saving, setSaving] = useState(false)

  const colors = TYPE_COLORS[node.type] || TYPE_COLORS.Transformer

  const handleSave = async () => {
    setSaving(true)
    await onSave(editForm)
    setSaving(false)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditForm({ ...node })
    setIsEditing(false)
  }

  const addParam = () => {
    setEditForm(prev => ({
      ...prev,
      parameters: [...prev.parameters, { name: '', type: 'string', required: false }],
    }))
  }

  const removeParam = (idx: number) => {
    setEditForm(prev => ({ ...prev, parameters: prev.parameters.filter((_, i) => i !== idx) }))
  }

  const updateParam = (idx: number, field: keyof NodeParam, value: string | boolean) => {
    setEditForm(prev => ({
      ...prev,
      parameters: prev.parameters.map((p, i) => i === idx ? { ...p, [field]: value } : p),
    }))
  }

  const addTag = () => {
    const tag = prompt('Enter new tag:')
    if (tag && !editForm.tags.includes(tag)) {
      setEditForm(prev => ({ ...prev, tags: [...prev.tags, tag] }))
    }
  }

  const removeTag = (tag: string) => {
    setEditForm(prev => ({ ...prev, tags: prev.tags.filter(t => t !== tag) }))
  }

  return (
    <motion.div className="fixed inset-0 z-[200]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <motion.div className="absolute right-0 top-0 bottom-0 w-[480px] bg-white shadow-2xl border-l border-slate-200 overflow-y-auto"
        initial={{ x: 480 }} animate={{ x: 0 }} exit={{ x: 480 }} transition={{ duration: 0.3, ease: EASE }}>

        {/* Header */}
        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={cn('w-9 h-9 rounded-full flex items-center justify-center', colors.icon)}><NodeTypeIcon type={node.type} size={18} className={colors.text} /></div>
            <div>
              <h2 className="text-base font-semibold text-slate-900">{isEditing ? 'Edit Node' : node.name}</h2>
              <p className="text-[11px] text-slate-400">{node.type} &middot; {node.source} &middot; File: <code className="text-[10px] bg-slate-100 px-1 rounded">{node.id}.json</code></p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isEditing ? (
              <>
                <button onClick={handleSave} disabled={saving} className="h-8 px-3 rounded-md text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-colors flex items-center gap-1.5 disabled:opacity-50">
                  {saving ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />} {saving ? 'Saving...' : 'Save'}
                </button>
                <button onClick={handleCancel} className="h-8 px-3 rounded-md text-xs font-medium text-slate-600 border border-slate-200 hover:bg-slate-50 transition-colors flex items-center gap-1.5"><RotateCcw size={13} /> Cancel</button>
              </>
            ) : (
              <>
                <button onClick={() => setIsEditing(true)} className="h-8 px-3 rounded-md text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 transition-colors flex items-center gap-1.5"><Edit3 size={13} /> Edit</button>
                <button onClick={() => setShowDeleteConfirm(true)} className="h-8 px-3 rounded-md text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 transition-colors flex items-center gap-1.5"><Trash2 size={13} /> Delete</button>
              </>
            )}
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"><X size={18} /></button>
          </div>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-5">
          {/* Name */}
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Name</label>
            {isEditing ? (
              <input value={editForm.name} onChange={e => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500 transition-all" />
            ) : <p className="text-sm text-slate-800 font-medium">{node.name}</p>}
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Description</label>
            {isEditing ? (
              <textarea value={editForm.description} onChange={e => setEditForm(prev => ({ ...prev, description: e.target.value }))}
                rows={3} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500 transition-all resize-none" />
            ) : <p className="text-sm text-slate-600 leading-relaxed">{node.description}</p>}
          </div>

          {/* Type & Source */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Type</label>
              {isEditing ? (
                <select value={editForm.type} onChange={e => setEditForm(prev => ({ ...prev, type: e.target.value as NodeCategory }))}
                  className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500 cursor-pointer">
                  {(['Transformer', 'SWB', 'Customization'] as const).map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              ) : <span className={cn('inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold', colors.bg, colors.text)}>{node.type}</span>}
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Source</label>
              {isEditing ? (
                <input value={editForm.source} onChange={e => setEditForm(prev => ({ ...prev, source: e.target.value }))}
                  className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500" />
              ) : <span className="text-sm text-slate-600">{node.source}</span>}
            </div>
          </div>

          {/* Tags */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Tags</label>
              {isEditing && <button onClick={addTag} className="text-[11px] text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"><Plus size={11} /> Add Tag</button>}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {(isEditing ? editForm.tags : node.tags).map(tag => (
                <span key={tag} className={cn('inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium', colors.bg, colors.text)}>
                  {tag}
                  {isEditing && <button onClick={() => removeTag(tag)} className="hover:text-red-500 transition-colors"><X size={10} /></button>}
                </span>
              ))}
            </div>
          </div>

          {/* Connections */}
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Connections</label>
            <div className="flex items-center gap-4 bg-slate-50 rounded-lg p-3 border border-slate-100">
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400">Input:</span>
                {isEditing ? (
                  <input value={editForm.connections.input.join(', ')} onChange={e => setEditForm(prev => ({ ...prev, connections: { ...prev.connections, input: e.target.value.split(',').map(s => s.trim()).filter(Boolean) } }))}
                    className="w-24 h-7 px-2 border border-slate-200 rounded text-xs text-slate-700 focus:outline-none focus:border-blue-500" placeholder="data, trigger" />
                ) : <span className="text-xs text-slate-700 font-medium">{node.connections.input.join(', ') || 'None'}</span>}
              </div>
              <ChevronRight size={14} className="text-slate-300" />
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400">Output:</span>
                {isEditing ? (
                  <input value={editForm.connections.output.join(', ')} onChange={e => setEditForm(prev => ({ ...prev, connections: { ...prev.connections, output: e.target.value.split(',').map(s => s.trim()).filter(Boolean) } }))}
                    className="w-24 h-7 px-2 border border-slate-200 rounded text-xs text-slate-700 focus:outline-none focus:border-blue-500" placeholder="data, action" />
                ) : <span className="text-xs text-slate-700 font-medium">{node.connections.output.join(', ') || 'None'}</span>}
              </div>
            </div>
          </div>

          {/* Parameters */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Parameters</label>
              {isEditing && <button onClick={addParam} className="text-[11px] text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"><Plus size={11} /> Add Parameter</button>}
            </div>
            <div className="space-y-2">
              {(isEditing ? editForm.parameters : node.parameters).map((param, idx) => (
                <div key={idx} className="bg-slate-50 rounded-lg p-3 border border-slate-100">
                  {isEditing ? (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <input value={param.name} onChange={e => updateParam(idx, 'name', e.target.value)}
                          className="flex-1 h-8 px-2 border border-slate-200 rounded text-xs text-slate-700 focus:outline-none focus:border-blue-500" placeholder="Param name" />
                        <select value={param.type} onChange={e => updateParam(idx, 'type', e.target.value)}
                          className="h-8 px-2 border border-slate-200 rounded text-xs text-slate-700 focus:outline-none focus:border-blue-500 cursor-pointer w-24">
                          {['string', 'number', 'boolean', 'select', 'array', 'object', 'json'].map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                        <label className="flex items-center gap-1 text-[11px] text-slate-500 cursor-pointer">
                          <input type="checkbox" checked={param.required} onChange={e => updateParam(idx, 'required', e.target.checked)} className="w-3 h-3 rounded" /> Required
                        </label>
                        <button onClick={() => removeParam(idx)} className="w-6 h-6 flex items-center justify-center rounded text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors"><Trash2 size={12} /></button>
                      </div>
                      <input value={param.default || ''} onChange={e => updateParam(idx, 'default', e.target.value)}
                        className="w-full h-7 px-2 border border-slate-200 rounded text-xs text-slate-500 focus:outline-none focus:border-blue-500" placeholder="Default value (optional)" />
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-slate-800">{param.name}</span>
                        <span className="text-[10px] font-mono text-slate-400 bg-white px-1.5 py-0.5 rounded border border-slate-200">{param.type}</span>
                        {param.required && <span className="text-[10px] font-semibold text-red-500 bg-red-50 px-1.5 py-0.5 rounded-full border border-red-200">required</span>}
                      </div>
                      {param.default !== undefined && <span className="text-[11px] text-slate-400 font-mono">default: {param.default}</span>}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Workflows */}
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Used in Workflows ({node.workflows.length})</label>
            <div className="flex flex-wrap gap-1.5">
              {node.workflows.map(wf => <span key={wf} className="text-[11px] px-2.5 py-1 rounded-full bg-blue-50 text-blue-600 border border-blue-100 font-medium">{wf}</span>)}
            </div>
          </div>
        </div>

        {/* Delete Confirmation */}
        <AnimatePresence>
          {showDeleteConfirm && (
            <motion.div className="absolute inset-0 z-20 flex items-center justify-center bg-black/20 backdrop-blur-sm"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <motion.div className="bg-white rounded-xl shadow-xl border border-slate-200 p-6 mx-4 w-[360px]"
                initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center"><AlertCircle size={20} className="text-red-500" /></div>
                  <h3 className="text-base font-semibold text-slate-900">Delete Node?</h3>
                </div>
                <p className="text-sm text-slate-500 mb-5">Are you sure you want to delete <strong className="text-slate-800">{node.name}</strong>? This will remove <code className="bg-slate-100 px-1 rounded">{node.id}.json</code> from the backend.</p>
                <div className="flex items-center gap-2">
                  <button onClick={() => { onDelete(node.id); setShowDeleteConfirm(false) }}
                    className="flex-1 h-9 rounded-lg text-sm font-semibold text-white bg-red-500 hover:bg-red-600 transition-colors">Delete</button>
                  <button onClick={() => setShowDeleteConfirm(false)}
                    className="flex-1 h-9 rounded-lg text-sm font-medium text-slate-600 border border-slate-200 hover:bg-slate-50 transition-colors">Cancel</button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  )
}

// ─── Add Node Modal ──────────────────────────────────────────────────────────

function AddNodeModal({ onClose, onAdd }: { onClose: () => void; onAdd: (n: NodeItem) => Promise<void> }) {
  const [mode, setMode] = useState<'choose' | 'manual' | 'upload'>('choose')
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadDone, setUploadDone] = useState(false)
  const [creating, setCreating] = useState(false)

  // Manual form state
  const [form, setForm] = useState({
    name: '', description: '', type: 'Transformer' as NodeCategory, source: 'Custom', tags: '',
    paramName: '', paramType: 'string', paramRequired: false, paramDefault: '',
    parameters: [] as NodeParam[],
  })

  const addParamToForm = () => {
    if (!form.paramName.trim()) return
    setForm(prev => ({
      ...prev,
      parameters: [...prev.parameters, { name: prev.paramName, type: prev.paramType, required: prev.paramRequired, default: prev.paramDefault || undefined }],
      paramName: '', paramType: 'string', paramRequired: false, paramDefault: '',
    }))
  }

  const removeFormParam = (idx: number) => {
    setForm(prev => ({ ...prev, parameters: prev.parameters.filter((_, i) => i !== idx) }))
  }

  const handleCreate = async () => {
    if (!form.name.trim() || !form.description.trim()) return
    const id = form.name.toLowerCase().trim().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')
    const newNode: NodeItem = {
      id,
      name: form.name.trim(),
      description: form.description.trim(),
      type: form.type,
      source: form.source,
      tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
      usageCount: 0,
      parameters: form.parameters,
      connections: { input: ['data'], output: ['data'] },
      workflows: [],
    }
    setCreating(true)
    await onAdd(newNode)
    setCreating(false)
    onClose()
  }

  const handleUpload = () => {
    let p = 0
    const interval = setInterval(() => { p += 5; setUploadProgress(p); if (p >= 100) { clearInterval(interval); setUploadDone(true) } }, 100)
  }

  const colors = TYPE_COLORS[form.type] || TYPE_COLORS.Transformer

  return (
    <motion.div className="fixed inset-0 z-[200] flex items-center justify-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <motion.div className="relative bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-[560px] mx-4 overflow-hidden"
        initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }} transition={{ duration: 0.25, ease: EASE }}>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="text-lg font-semibold text-slate-900">
            {mode === 'choose' && 'Add New Node'}
            {mode === 'manual' && 'Create Node Manually'}
            {mode === 'upload' && 'Upload Node Spec'}
          </h2>
          <button onClick={mode === 'choose' ? onClose : () => setMode('choose')} className="w-8 h-8 flex items-center justify-center rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors">
            {mode === 'choose' ? <X size={18} /> : <ChevronLeftIcon size={18} />}
          </button>
        </div>

        {/* Body */}
        <div className="p-6 max-h-[520px] overflow-y-auto">
          <AnimatePresence mode="wait">

            {/* ── Mode Chooser ── */}
            {mode === 'choose' && (
              <motion.div key="choose" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-3">
                <button onClick={() => setMode('manual')}
                  className="w-full flex items-center gap-4 p-5 rounded-xl border-2 border-slate-200 hover:border-blue-400 hover:bg-blue-50/30 transition-all text-left group">
                  <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center shrink-0"><PenTool size={22} className="text-blue-600" /></div>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900 group-hover:text-blue-700 transition-colors">Create Manually</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Fill in node name, description, parameters, and configuration</p>
                  </div>
                  <ChevronRight size={18} className="text-slate-300 ml-auto group-hover:text-blue-400 transition-colors" />
                </button>
                <button onClick={() => setMode('upload')}
                  className="w-full flex items-center gap-4 p-5 rounded-xl border-2 border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/30 transition-all text-left group">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0"><FileJson size={22} className="text-emerald-600" /></div>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900 group-hover:text-emerald-700 transition-colors">Upload Node Spec</h3>
                    <p className="text-xs text-slate-500 mt-0.5">Upload a JSON spec file or paste JSON definition</p>
                  </div>
                  <ChevronRight size={18} className="text-slate-300 ml-auto group-hover:text-emerald-400 transition-colors" />
                </button>
                <div className="pt-2">
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    <strong className="text-slate-600">Tip:</strong> Nodes are stored as individual JSON files in <code className="bg-slate-100 px-1 rounded">node_lib/&#123;category&#125;/</code> on the backend.
                  </p>
                </div>
              </motion.div>
            )}

            {/* ── Manual Entry Form ── */}
            {mode === 'manual' && (
              <motion.div key="manual" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
                {/* Name */}
                <div>
                  <label className="text-xs font-semibold text-slate-600 mb-1 block">Node Name <span className="text-red-500">*</span></label>
                  <input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                    placeholder="e.g. My Custom Node" className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-300 focus:outline-none focus:border-blue-500 transition-all" />
                </div>
                {/* Description */}
                <div>
                  <label className="text-xs font-semibold text-slate-600 mb-1 block">Description <span className="text-red-500">*</span></label>
                  <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                    rows={2} placeholder="What does this node do?" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-300 focus:outline-none focus:border-blue-500 transition-all resize-none" />
                </div>
                {/* Type & Tags */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 mb-1 block">Category</label>
                    <select value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value as NodeCategory }))}
                      className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500 cursor-pointer">
                      {(['Transformer', 'SWB', 'Customization'] as const).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 mb-1 block">Tags (comma-separated)</label>
                    <input value={form.tags} onChange={e => setForm(p => ({ ...p, tags: e.target.value }))}
                      placeholder="API, Custom, Transform" className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-300 focus:outline-none focus:border-blue-500" />
                  </div>
                </div>

                {/* Live Preview Badge */}
                <div className={cn('rounded-lg p-3 border flex items-center gap-3', colors.bg, colors.border)}>
                  <div className={cn('w-8 h-8 rounded-full flex items-center justify-center', colors.icon)}><NodeTypeIcon type={form.type} size={16} className={colors.text} /></div>
                  <div>
                    <div className="text-sm font-semibold text-slate-800">{form.name || 'Untitled Node'}</div>
                    <div className="text-[11px] text-slate-400">{form.type} &middot; Custom &middot; {form.parameters.length} params</div>
                  </div>
                </div>

                {/* Parameters */}
                <div>
                  <label className="text-xs font-semibold text-slate-600 mb-2 block">Parameters</label>
                  {form.parameters.length > 0 && (
                    <div className="space-y-2 mb-3">
                      {form.parameters.map((p, i) => (
                        <div key={i} className="flex items-center gap-2 bg-slate-50 rounded-lg px-3 py-2 border border-slate-100">
                          <span className="text-xs font-medium text-slate-700 flex-1">{p.name}</span>
                          <span className="text-[10px] font-mono text-slate-400 bg-white px-1.5 py-0.5 rounded border border-slate-200">{p.type}</span>
                          {p.required && <span className="text-[10px] font-semibold text-red-500 bg-red-50 px-1.5 rounded-full">required</span>}
                          <button onClick={() => removeFormParam(i)} className="w-5 h-5 flex items-center justify-center rounded text-slate-400 hover:text-red-500"><X size={12} /></button>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <input value={form.paramName} onChange={e => setForm(p => ({ ...p, paramName: e.target.value }))}
                      onKeyDown={e => e.key === 'Enter' && addParamToForm()}
                      placeholder="Parameter name" className="flex-1 h-9 px-3 border border-slate-200 rounded-lg text-xs text-slate-700 placeholder:text-slate-300 focus:outline-none focus:border-blue-500" />
                    <select value={form.paramType} onChange={e => setForm(p => ({ ...p, paramType: e.target.value }))}
                      className="h-9 px-2 border border-slate-200 rounded-lg text-xs text-slate-700 cursor-pointer w-24">
                      {['string', 'number', 'boolean', 'select', 'array', 'object', 'json'].map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                    <label className="flex items-center gap-1 text-[11px] text-slate-500 cursor-pointer shrink-0">
                      <input type="checkbox" checked={form.paramRequired} onChange={e => setForm(p => ({ ...p, paramRequired: e.target.checked }))} className="w-3.5 h-3.5 rounded" /> Req
                    </label>
                    <button onClick={addParamToForm}
                      className="h-9 px-3 rounded-lg text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 transition-colors shrink-0">Add</button>
                  </div>
                </div>

                {/* Create Button */}
                <button onClick={handleCreate} disabled={!form.name.trim() || !form.description.trim() || creating}
                  className="w-full h-11 rounded-xl text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2">
                  {creating ? <Loader2 size={16} className="animate-spin" /> : <Plus size={16} />} {creating ? 'Creating...' : 'Create Node'}
                </button>
              </motion.div>
            )}

            {/* ── Upload Spec ── */}
            {mode === 'upload' && (
              <motion.div key="upload" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
                {!uploadDone ? (
                  <>
                    <div className="border-2 border-dashed border-slate-200 rounded-xl p-8 text-center hover:border-emerald-400 hover:bg-emerald-50/20 transition-all cursor-pointer"
                      onClick={handleUpload}>
                      <div className="w-14 h-14 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-3"><Upload size={24} className="text-emerald-600" /></div>
                      <p className="text-sm font-semibold text-slate-700 mb-1">Click to upload or drag & drop</p>
                      <p className="text-xs text-slate-400">JSON spec file (.json)</p>
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-600 mb-1 block">Or paste JSON directly</label>
                      <textarea rows={6} placeholder='{"name": "MyNode", "description": "...", "type": "Transformer", "parameters": [...]}'
                        className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-mono text-slate-700 placeholder:text-slate-300 focus:outline-none focus:border-emerald-500 transition-all resize-none" />
                    </div>
                    {uploadProgress > 0 && (
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs text-slate-500"><span>Uploading...</span><span>{uploadProgress}%</span></div>
                        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden"><div className="h-full bg-emerald-500 rounded-full transition-all" style={{ width: `${uploadProgress}%` }} /></div>
                      </div>
                    )}
                    <button onClick={handleUpload} className="w-full h-10 rounded-xl text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2">
                      <FileJson size={16} /> Parse & Create Node
                    </button>
                  </>
                ) : (
                  <motion.div className="text-center py-8" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
                    <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4"><Check size={28} className="text-emerald-600" /></div>
                    <h3 className="text-base font-semibold text-slate-900 mb-1">Node Spec Parsed!</h3>
                    <p className="text-sm text-slate-500 mb-4">Your node has been created and added to the library.</p>
                    <button onClick={onClose} className="h-9 px-6 rounded-lg text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors">Done</button>
                  </motion.div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </motion.div>
  )
}
