import { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Lightbulb, FileText, Sparkles, BarChart3,
  Send, Loader2, GitBranch, Box, TrendingUp,
  TrendingDown, Minus, Timer, Activity, Search,
  Zap, ArrowRight, AlertTriangle,
  ChevronDown, ChevronUp, RefreshCw,
  Layers, Star, Cpu, Database,
  Settings2, Table2,
  Eye, MessageSquare, X, Target, Wand2,
  Users, CreditCard,
} from 'lucide-react';
import {
  ReactFlow, Background, type Node, type Edge,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { cn } from '@/lib/utils';
import { useWorkflowStore } from '@/store/workflowStore';
import { TARGET_SYSTEMS, searchFunctions } from '@/data/systemCapabilities';
import type { TargetSystem } from '@/types/orchestration';

/* ─── Easing ────────────────────────────────────────────────────── */
const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number];

/* ─── Types ─────────────────────────────────────────────────────── */
type TabId = 'recommend' | 'summary' | 'insights' | 'embed' | 'systems';

interface WorkflowItem {
  id: string;
  name: string;
  description: string;
  category: 'Transformer' | 'SWB' | 'Customization';
  nodes: number;
  connections: number;
  status: 'Running' | 'Idle' | 'Error';
  lastRun: string;
  complexity: number;
  efficiency: number;
  usedIn: number;
}

interface NodeItem {
  id: string;
  name: string;
  type: string;
  category: 'Transformer' | 'SWB' | 'Customization';
  usedIn: number;
  execTime: string;
  successRate: number;
  health: 'healthy' | 'warning' | 'critical';
}

interface InsightCard {
  label: string;
  value: string;
  color: string;
  icon: typeof Layers;
  trend: string;
  trendUp: boolean | null;
}

interface Recommendation {
  id: string;
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  category: string;
  confidence: number;
  affectedCount: number;
  timeSaved: string;
}

interface OptimizationLogEntry {
  id: string;
  title: string;
  description: string;
  date: string;
  status: 'applied' | 'partial' | 'reverted';
  metrics: string;
}

/* ─── Mock Data ─────────────────────────────────────────────────── */
const WORKFLOWS: WorkflowItem[] = [
  // Transformer (4)
  { id: '1', name: 'CSV Data Pipeline', description: 'Filter Rows → Column Mapping → Sort Data → Aggregate → OutputCSV', category: 'Transformer', nodes: 5, connections: 4, status: 'Running', lastRun: '2h ago', complexity: 42, efficiency: 88, usedIn: 12 },
  { id: '2', name: 'Customer Data Merge', description: 'Join Tables → Merge Rows → Drop Columns → Sort Data', category: 'Transformer', nodes: 4, connections: 3, status: 'Idle', lastRun: '5h ago', complexity: 35, efficiency: 92, usedIn: 8 },
  { id: '3', name: 'Sales Report Generator', description: 'Excel → Aggregate → Merge Rows → Sort Data → OutputPDF', category: 'Transformer', nodes: 5, connections: 4, status: 'Running', lastRun: '1d ago', complexity: 38, efficiency: 85, usedIn: 6 },
  { id: '4', name: 'Document Ingestion', description: 'PDF → OCR Extract → Filter Rows → Column Mapping → OutputCSV', category: 'Transformer', nodes: 5, connections: 4, status: 'Idle', lastRun: '3d ago', complexity: 40, efficiency: 83, usedIn: 5 },
  // SWB (3)
  { id: '5', name: 'Invoice OCR Processor', description: 'API Request → OCR Extract → Document Parser → Email to PDF', category: 'SWB', nodes: 4, connections: 3, status: 'Running', lastRun: '3h ago', complexity: 45, efficiency: 78, usedIn: 10 },
  { id: '6', name: 'Content Generator', description: 'API Request → Data Validator → LLM Prompt → Email to PDF', category: 'SWB', nodes: 4, connections: 3, status: 'Idle', lastRun: '1d ago', complexity: 52, efficiency: 82, usedIn: 7 },
  { id: '7', name: 'Image Recognition Flow', description: 'API Request → Image Recognizer → OCR Extract → Document Parser', category: 'SWB', nodes: 4, connections: 3, status: 'Error', lastRun: '2d ago', complexity: 48, efficiency: 65, usedIn: 5 },
  // Customization (2)
  { id: '8', name: 'Customer Onboarding', description: 'Webhook → Merge Rows → Filter Rows → LLM Prompt → Send Email', category: 'Customization', nodes: 5, connections: 4, status: 'Idle', lastRun: '2d ago', complexity: 55, efficiency: 90, usedIn: 15 },
  { id: '9', name: 'Daily Report Automation', description: 'Database Query → Aggregate → OCR Extract → Report Generator → Send Email', category: 'Customization', nodes: 5, connections: 4, status: 'Idle', lastRun: '3d ago', complexity: 50, efficiency: 87, usedIn: 9 },
];

const NODES: NodeItem[] = [
  // Transformer (11)
  { id: 'n1', name: 'Filter Rows', type: 'Logic', category: 'Transformer', usedIn: 12, execTime: '0.3s', successRate: 99.1, health: 'healthy' },
  { id: 'n2', name: 'Column Mapping', type: 'Transform', category: 'Transformer', usedIn: 9, execTime: '0.2s', successRate: 98.5, health: 'healthy' },
  { id: 'n3', name: 'Drop Columns', type: 'Transform', category: 'Transformer', usedIn: 8, execTime: '0.1s', successRate: 99.8, health: 'healthy' },
  { id: 'n4', name: 'Sort Data', type: 'Logic', category: 'Transformer', usedIn: 10, execTime: '0.5s', successRate: 97.2, health: 'healthy' },
  { id: 'n5', name: 'Aggregate', type: 'Transform', category: 'Transformer', usedIn: 7, execTime: '1.2s', successRate: 96.5, health: 'healthy' },
  { id: 'n6', name: 'Join Tables', type: 'Transform', category: 'Transformer', usedIn: 6, execTime: '2.1s', successRate: 94.8, health: 'warning' },
  { id: 'n8', name: 'Merge Rows', type: 'Transform', category: 'Transformer', usedIn: 4, execTime: '0.8s', successRate: 93.1, health: 'warning' },
  { id: 'n25', name: 'Excel', type: 'Input', category: 'Transformer', usedIn: 8, execTime: '1.2s', successRate: 97.5, health: 'healthy' },
  { id: 'n26', name: 'PDF', type: 'Input', category: 'Transformer', usedIn: 5, execTime: '2.3s', successRate: 94.0, health: 'healthy' },
  { id: 'n27', name: 'OutputCSV', type: 'Output', category: 'Transformer', usedIn: 11, execTime: '0.6s', successRate: 98.8, health: 'healthy' },
  { id: 'n28', name: 'OutputPDF', type: 'Output', category: 'Transformer', usedIn: 7, execTime: '2.8s', successRate: 95.5, health: 'healthy' },
  // SWB (7 — Text Extractor merged into OCR Extract)
  { id: 'n9', name: 'OCR Extract', type: 'AI', category: 'SWB', usedIn: 15, execTime: '3.2s', successRate: 92.0, health: 'warning' },
  { id: 'n10', name: 'LLM Prompt', type: 'AI', category: 'SWB', usedIn: 6, execTime: '4.2s', successRate: 88.5, health: 'warning' },
  { id: 'n11', name: 'Email to PDF', type: 'Convert', category: 'SWB', usedIn: 5, execTime: '1.5s', successRate: 96.0, health: 'healthy' },
  { id: 'n12', name: 'API Request', type: 'Action', category: 'SWB', usedIn: 14, execTime: '0.8s', successRate: 94.3, health: 'healthy' },
  { id: 'n13', name: 'Data Validator', type: 'Logic', category: 'SWB', usedIn: 9, execTime: '0.3s', successRate: 98.9, health: 'healthy' },
  { id: 'n15', name: 'Image Recognizer', type: 'AI', category: 'SWB', usedIn: 5, execTime: '3.2s', successRate: 89.4, health: 'critical' },
  { id: 'n16', name: 'Document Parser', type: 'AI', category: 'SWB', usedIn: 6, execTime: '2.5s', successRate: 93.8, health: 'healthy' },
  // Customization (6 — Slack Notify and File Upload removed)
  { id: 'n17', name: 'Send Email', type: 'Output', category: 'Customization', usedIn: 18, execTime: '1.2s', successRate: 97.5, health: 'healthy' },
  { id: 'n19', name: 'Webhook', type: 'Trigger', category: 'Customization', usedIn: 10, execTime: '0.1s', successRate: 99.5, health: 'healthy' },
  { id: 'n20', name: 'Database Query', type: 'Data', category: 'Customization', usedIn: 11, execTime: '1.5s', successRate: 96.2, health: 'healthy' },
  { id: 'n22', name: 'CSV Export', type: 'Output', category: 'Customization', usedIn: 9, execTime: '0.8s', successRate: 97.8, health: 'healthy' },
  { id: 'n23', name: 'Push Notification', type: 'Output', category: 'Customization', usedIn: 6, execTime: '0.3s', successRate: 95.5, health: 'healthy' },
  { id: 'n24', name: 'Report Generator', type: 'AI', category: 'Customization', usedIn: 5, execTime: '5.1s', successRate: 86.2, health: 'critical' },
];

const INSIGHTS: InsightCard[] = [
  { label: 'Total Workflows', value: '9', color: '#2B7FFF', icon: Layers, trend: '+2 this month', trendUp: true },
  { label: 'Active Nodes', value: '24', color: '#2B7FFF', icon: Box, trend: '8 categories', trendUp: true },
  { label: 'Avg Efficiency', value: '84%', color: '#10B981', icon: TrendingUp, trend: '+5% vs last week', trendUp: true },
  { label: 'AI Insights', value: '12', color: '#F59E0B', icon: Lightbulb, trend: '3 high priority', trendUp: null },
];

const RECOMMENDATIONS: Recommendation[] = [
  { id: 'r1', title: 'Parallelize Invoice OCR Processor', description: '3 sequential nodes in "Invoice OCR Processor" can run in parallel. Estimated 60% execution time reduction.', priority: 'high', category: 'Optimize', confidence: 94, affectedCount: 1, timeSaved: '~2.1s/run' },
  { id: 'r2', title: 'Add retry logic to API calls', description: 'Image Recognition Flow has 12% failure rate on external API calls. Adding retry logic with exponential backoff would reduce to <2%.', priority: 'high', category: 'Add', confidence: 91, affectedCount: 3, timeSaved: '~15min/day' },
  { id: 'r3', title: 'Merge duplicate email configs', description: '5 workflows use similar email sending configurations. Consolidating to shared template improves maintainability.', priority: 'medium', category: 'Consolidate', confidence: 87, affectedCount: 5, timeSaved: '~10min/week' },
  { id: 'r4', title: 'Replace Report Generator v1', description: 'Report Generator has 86% success rate and 5.1s execution time. Upgrading to v2 would improve to 96% and 2.3s.', priority: 'medium', category: 'Upgrade', confidence: 89, affectedCount: 2, timeSaved: '~2.8s/run' },
  { id: 'r5', title: 'Standardize naming conventions', description: 'Inconsistent node naming across Customization workflows makes discovery harder. Standardizing improves team collaboration.', priority: 'low', category: 'Standardize', confidence: 82, affectedCount: 6, timeSaved: '~5min/week' },
  { id: 'r6', title: 'Cache OCR Extract results', description: 'OCR Extract processes identical documents repeatedly. Adding a cache layer would reduce API calls by 40%.', priority: 'medium', category: 'Optimize', confidence: 85, affectedCount: 4, timeSaved: '~1.4s/run' },
];

const OPT_LOG: OptimizationLogEntry[] = [
  { id: 'o1', title: 'Added retry logic to API Request nodes', description: 'Implemented exponential backoff retry for 3 API Request nodes in SWB workflows. Failure rate dropped from 12% to 1.8%.', date: 'Today, 10:30 AM', status: 'applied', metrics: '-10.2% failure rate' },
  { id: 'o2', title: 'Optimized Invoice OCR Processor parallelism', description: 'Restructured 3 sequential steps in Invoice OCR Processor to run in parallel. Execution time reduced from 4.5s to 1.8s.', date: 'Yesterday, 3:15 PM', status: 'applied', metrics: '-2.7s per run' },
  { id: 'o3', title: 'Upgraded Report Generator to v2', description: 'Migrated Report Generator from v1 to v2. Success rate improved from 86% to 96%, execution time halved.', date: '3 days ago', status: 'partial', metrics: '+10% success, -2.8s' },
  { id: 'o4', title: 'Cached OCR Extract results', description: 'Added Redis cache for OCR Extract. Duplicate document processing eliminated, API calls reduced by 40%.', date: '1 week ago', status: 'applied', metrics: '-40% API calls' },
];

/* ─── Tabs Config ───────────────────────────────────────────────── */
const TABS: { id: TabId; label: string; icon: typeof Lightbulb; description: string }[] = [
  { id: 'recommend', label: 'AI Recommendations', icon: Sparkles, description: 'Describe your needs and get AI-recommended workflows' },
  { id: 'summary', label: 'Flow Summary', icon: FileText, description: 'Overview of all workflows and their performance' },
  { id: 'insights', label: 'AI Insights', icon: Lightbulb, description: 'Smart optimization suggestions from AI analysis' },
  { id: 'embed', label: 'Embed Analysis', icon: BarChart3, description: 'Deep-dive analysis per category with optimization' },
  { id: 'systems', label: 'Systems', icon: Database, description: 'Browse 5 target systems and their capabilities' },
];

/* ─── Helpers ───────────────────────────────────────────────────── */
const categoryMeta: Record<string, { color: string; bg: string; border: string; icon: typeof Table2 }> = {
  Transformer: { color: '#10B981', bg: 'bg-emerald-50', border: 'border-emerald-200', icon: Table2 },
  SWB: { color: '#2B7FFF', bg: 'bg-blue-50', border: 'border-blue-200', icon: Cpu },
  Customization: { color: '#F59E0B', bg: 'bg-amber-50', border: 'border-amber-200', icon: Settings2 },
};

function HealthBadge({ health }: { health: string }) {
  const config: Record<string, string> = {
    healthy: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    warning: 'bg-amber-50 text-amber-700 border-amber-200',
    critical: 'bg-red-50 text-red-700 border-red-200',
  };
  const labels: Record<string, string> = { healthy: 'Healthy', warning: 'Warning', critical: 'Critical' };
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border', config[health] || config.healthy)}>
      {labels[health] || health}
    </span>
  );
}

function PriorityBadge({ priority }: { priority: string }) {
  const c: Record<string, string> = {
    high: 'bg-red-50 text-red-600 border-red-200',
    medium: 'bg-amber-50 text-amber-600 border-amber-200',
    low: 'bg-blue-50 text-blue-600 border-blue-200',
  };
  return (
    <span className={cn('inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border', c[priority] || c.low)}>
      {priority.charAt(0).toUpperCase() + priority.slice(1)}
    </span>
  );
}

/* ─── CountUp ───────────────────────────────────────────────────── */
function CountUp({ target, duration = 800 }: { target: string; duration?: number }) {
  const [display, setDisplay] = useState('0');
  const numericValue = parseFloat(target.replace(/[^0-9.]/g, ''));
  const prefix = target.match(/^[^0-9]*/)?.[0] || '';
  const suffix = target.match(/[^0-9.]*$/)?.[0] || '';
  useEffect(() => {
    const start = performance.now();
    const animate = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = numericValue * eased;
      setDisplay(prefix + (Number.isInteger(numericValue) ? Math.round(current) : current.toFixed(1)) + suffix);
      if (progress < 1) requestAnimationFrame(animate);
    };
    requestAnimationFrame(animate);
  }, [numericValue, prefix, suffix, duration]);
  return <span>{display}</span>;
}

/* ══════════════════════════════════════════════════════════════════
   TAB 1: AI RECOMMENDATIONS
   ══════════════════════════════════════════════════════════════════ */

/* ─── Workflow node layout data for preview / canvas ───────────── */
/** Node-to-system color mapping for consistent coloring */
const NODE_SYSTEM_COLORS: Record<string, string> = {
  // Transformer nodes → SAP ERP (deep blue)
  'Filter Rows': '#0F52BA', 'Column Mapping': '#0F52BA', 'Drop Columns': '#0F52BA',
  'Sort Data': '#0F52BA', 'Aggregate': '#0F52BA', 'Join Tables': '#0F52BA',
  'Merge Rows': '#0F52BA', 'Excel': '#0F52BA', 'PDF': '#0F52BA',
  'OutputCSV': '#0F52BA', 'OutputPDF': '#0F52BA',
  // SWB nodes → Salesforce CRM (blue)
  'OCR Extract': '#0176D3', 'LLM Prompt': '#0176D3', 'Email to PDF': '#0176D3',
  'API Request': '#0176D3', 'Data Validator': '#0176D3', 'Image Recognizer': '#0176D3',
  'Document Parser': '#0176D3',
  // Customization nodes → Stripe Payments (purple)
  'Send Email': '#635BFF', 'Webhook': '#635BFF', 'Database Query': '#635BFF',
  'CSV Export': '#635BFF', 'Push Notification': '#635BFF', 'Report Generator': '#635BFF',
};

const WORKFLOW_PREVIEW_DATA: Record<string, { steps: string[]; nodeType: string }> = {
  'CSV Data Pipeline': {
    steps: ['Filter Rows', 'Column Mapping', 'Sort Data', 'Aggregate', 'OutputCSV'],
    nodeType: 'transformer',
  },
  'Customer Data Merge': {
    steps: ['Join Tables', 'Merge Rows', 'Drop Columns', 'Sort Data'],
    nodeType: 'transformer',
  },
  'Sales Report Generator': {
    steps: ['Excel', 'Aggregate', 'Merge Rows', 'Sort Data', 'OutputPDF'],
    nodeType: 'transformer',
  },
  'Document Ingestion': {
    steps: ['PDF', 'Filter Rows', 'Column Mapping', 'Merge Rows', 'OutputCSV'],
    nodeType: 'transformer',
  },
  'Invoice OCR Processor': {
    steps: ['API Request', 'OCR Extract', 'Document Parser', 'Email to PDF'],
    nodeType: 'swb',
  },
  'Content Generator': {
    steps: ['API Request', 'Data Validator', 'LLM Prompt', 'Email to PDF'],
    nodeType: 'swb',
  },
  'Image Recognition Flow': {
    steps: ['API Request', 'Image Recognizer', 'OCR Extract', 'Document Parser'],
    nodeType: 'swb',
  },
  'Customer Onboarding': {
    steps: ['Webhook', 'Merge Rows', 'Filter Rows', 'LLM Prompt', 'Send Email'],
    nodeType: 'customization',
  },
  'Daily Report Automation': {
    steps: ['Database Query', 'Aggregate', 'OCR Extract', 'Report Generator', 'Send Email'],
    nodeType: 'customization',
  },
};

function buildPreviewNodes(name: string): { nodes: Node[]; edges: Edge[] } {
  const data = WORKFLOW_PREVIEW_DATA[name];
  if (!data) return { nodes: [], edges: [] };
  const defaultColors: Record<string, string> = {
    transformer: '#0F52BA',
    swb: '#0176D3',
    customization: '#635BFF',
  };
  const defaultColor = defaultColors[data.nodeType] || '#94A3B8';
  const nodes: Node[] = data.steps.map((step, i) => {
    const color = NODE_SYSTEM_COLORS[step] || defaultColor;
    return {
      id: `s-${i}`,
      type: 'default',
      position: { x: 100 + i * 160, y: 100 },
      data: { label: step, systemColor: color },
      style: {
        background: color,
        color: '#fff',
        borderRadius: 9999,
        padding: '8px 16px',
        fontSize: 12,
        fontWeight: 600,
        border: `2px solid ${color}`,
        boxShadow: `0 4px 12px ${color}30`,
        minWidth: 120,
        textAlign: 'center' as const,
      },
    };
  });
  const edges: Edge[] = data.steps.slice(0, -1).map((_, i) => ({
    id: `e-${i}`,
    source: `s-${i}`,
    target: `s-${i + 1}`,
    style: { stroke: defaultColor, strokeWidth: 2 },
  }));
  return { nodes, edges };
}

/* ─── Preview Modal ─────────────────────────────────────────────── */
function PreviewModal({ workflow, isOpen, onClose }: { workflow: WorkflowItem | null; isOpen: boolean; onClose: () => void }) {
  if (!isOpen || !workflow) return null;
  const preview = buildPreviewNodes(workflow.name);
  const meta = categoryMeta[workflow.category];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="modal-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/40 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            key="modal-content"
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.35, ease: EASE }}
            onClick={(e) => e.stopPropagation()}
            className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-[800px] max-h-[80vh] overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${meta?.color}12` }}>
                  <meta.icon size={18} style={{ color: meta?.color }} />
                </div>
                <div>
                  <h3 className="text-base font-semibold text-slate-900">{workflow.name}</h3>
                  <p className="text-xs text-slate-500">Workflow Preview · {workflow.nodes} nodes · {workflow.connections} connections</p>
                </div>
              </div>
              <button onClick={onClose} className="w-8 h-8 rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors">
                <X size={18} />
              </button>
            </div>

            {/* Preview Area */}
            <div className="flex-1 overflow-hidden bg-slate-50" style={{ height: 320 }}>
              <ReactFlow
                nodes={preview.nodes}
                edges={preview.edges}
                fitView
                fitViewOptions={{ padding: 0.3 }}
                nodesDraggable={false}
                nodesConnectable={false}
                elementsSelectable={false}
                zoomOnScroll={false}
                zoomOnPinch={false}
                panOnDrag={false}
                proOptions={{ hideAttribution: true }}
              >
                <Background gap={20} size={1} color="rgba(0,0,0,0.05)" />
              </ReactFlow>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-6 py-4 border-t border-slate-100 bg-white">
              <div className="flex items-center gap-4 text-xs text-slate-500">
                <span className="flex items-center gap-1"><Activity size={12} /> Efficiency: <strong className="text-slate-700">{workflow.efficiency}%</strong></span>
                <span className="flex items-center gap-1"><Timer size={12} /> Last run: <strong className="text-slate-700">{workflow.lastRun}</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <button onClick={onClose} className="h-9 px-4 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200">
                  Close
                </button>
                <ApplyToCanvasButton workflow={workflow} />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ─── Apply to Canvas Button ────────────────────────────────────── */
function ApplyToCanvasButton({ workflow, onClick }: { workflow: WorkflowItem; onClick?: () => void }) {
  const navigate = useNavigate();
  const setPendingWorkflow = useWorkflowStore((s) => s.setPendingWorkflow);

  const handleApply = () => {
    const preview = buildPreviewNodes(workflow.name);
    if (preview.nodes.length === 0) return;

    const typedNodes = preview.nodes.map((n) => ({
      ...n,
      data: {
        label: String(n.data.label || ''),
        nodeType: (WORKFLOW_PREVIEW_DATA[workflow.name]?.nodeType || 'transformer') as 'transformer' | 'swb' | 'customization' | 'trigger',
        description: `${String(n.data.label || '')} node in ${workflow.name}`,
        systemColor: String((n.data as any)?.systemColor || ''),
        parameters: [
          { key: 'config', label: 'Configuration', value: 'default', required: false },
        ],
      },
    }));

    setPendingWorkflow({
      nodes: typedNodes,
      edges: preview.edges,
      name: workflow.name,
      description: workflow.description,
    });
    onClick?.();
    navigate('/canvas');
  };

  return (
    <button
      onClick={handleApply}
      className="h-9 px-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
    >
      <ArrowRight size={13} /> Apply to Canvas
    </button>
  );
}

/* ─── Main AI Recommend Tab ────────────────────────────────────── */
function AIRecommendTab() {
  const [query, setQuery] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState<typeof WORKFLOWS>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [previewWf, setPreviewWf] = useState<WorkflowItem | null>(null);

  const handleSearch = () => {
    if (!query.trim()) return;
    setIsAnalyzing(true);
    setHasSearched(true);
    setResults([]);
    setTimeout(() => {
      const q = query.toLowerCase();
      const scored = WORKFLOWS.map(wf => {
        let score = 0;
        if (wf.name.toLowerCase().includes(q)) score += 3;
        if (wf.description.toLowerCase().includes(q)) score += 2;
        if (wf.category.toLowerCase().includes(q)) score += 1;
        const qWords = q.split(/\s+/);
        qWords.forEach(word => {
          if (wf.description.toLowerCase().includes(word)) score += 0.5;
        });
        return { wf, score };
      }).filter(s => s.score > 0).sort((a, b) => b.score - a.score).map(s => s.wf);
      setResults(scored);
      setIsAnalyzing(false);
    }, 1500);
  };

  const suggestedPrompts = [
    'I need to process CSV files and filter data',
    'Automate invoice generation with OCR',
    'Send emails when new customers sign up',
    'Create a daily report from database',
  ];

  return (
    <div className="space-y-6">
      {/* Preview Modal */}
      <PreviewModal workflow={previewWf} isOpen={!!previewWf} onClose={() => setPreviewWf(null)} />

      {/* Demand Input */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, ease: EASE }}
        className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
            <Target size={20} className="text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900">What do you want to build?</h3>
            <p className="text-sm text-slate-500">Describe your workflow needs in natural language</p>
          </div>
        </div>
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="e.g., I need a workflow to process invoices automatically..."
              className="w-full h-12 pl-4 pr-4 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 transition-all"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={!query.trim() || isAnalyzing}
            className="h-12 px-6 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-lg transition-colors flex items-center gap-2"
          >
            {isAnalyzing ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
            {isAnalyzing ? 'Analyzing...' : 'Get Recommendations'}
          </button>
        </div>
        {/* Suggested prompts */}
        <div className="flex flex-wrap gap-2 mt-4">
          {suggestedPrompts.map((p) => (
            <button
              key={p}
              onClick={() => { setQuery(p); }}
              className="h-8 px-3 rounded-full text-xs font-medium bg-slate-50 border border-slate-200 text-slate-600 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600 transition-all"
            >
              {p}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Results */}
      <AnimatePresence mode="wait">
        {isAnalyzing && (
          <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center justify-center py-16">
            <div className="w-16 h-16 rounded-full bg-blue-50 flex items-center justify-center mb-4">
              <Sparkles size={28} className="text-blue-500 animate-pulse" />
            </div>
            <p className="text-sm font-medium text-slate-700 mb-1">Analyzing your requirements...</p>
            <p className="text-xs text-slate-500">Matching against 9 existing workflows and 24 nodes</p>
          </motion.div>
        )}

        {!isAnalyzing && hasSearched && results.length > 0 && (
          <motion.div key="results" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.4, ease: EASE }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-slate-900">
                <Star size={16} className="inline text-amber-500 mr-1.5 -mt-0.5" />
                Top {results.length} matching workflows
              </h3>
              <span className="text-xs text-slate-500">Sorted by relevance</span>
            </div>
            <div className="space-y-3">
              {results.map((wf, i) => {
                const meta = categoryMeta[wf.category];
                const Icon = meta?.icon || Layers;
                const matchScore = Math.max(70, 95 - i * 8);
                return (
                  <motion.div
                    key={wf.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.35, delay: i * 0.08, ease: EASE }}
                    className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 hover:shadow-md hover:border-blue-200 transition-all"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${meta?.color}12` }}>
                        <Icon size={22} style={{ color: meta?.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="text-[15px] font-semibold text-slate-900">{wf.name}</h4>
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border" style={{ backgroundColor: `${meta?.color}10`, color: meta?.color, borderColor: `${meta?.color}25` }}>
                            {wf.category}
                          </span>
                          <span className="ml-auto flex items-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            <Zap size={11} />
                            {matchScore}% match
                          </span>
                        </div>
                        <p className="text-sm text-slate-500 leading-relaxed mb-3">{wf.description}</p>
                        <div className="flex items-center gap-4 text-xs text-slate-500">
                          <span className="flex items-center gap-1"><GitBranch size={12} /> {wf.nodes} nodes · {wf.connections} connections</span>
                          <span className="flex items-center gap-1"><Activity size={12} /> {wf.efficiency}% efficiency</span>
                          <span className="flex items-center gap-1"><Timer size={12} /> Last run {wf.lastRun}</span>
                        </div>
                        <div className="flex items-center gap-2 mt-3">
                          <ApplyToCanvasButton workflow={wf} />
                          <button
                            onClick={() => setPreviewWf(wf)}
                            className="h-8 px-3 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5"
                          >
                            <Eye size={12} /> Preview
                          </button>
                          <button className="h-8 px-3 text-slate-500 hover:text-blue-600 text-xs font-medium rounded-md hover:bg-blue-50 transition-colors flex items-center gap-1.5">
                            <Sparkles size={12} /> Ask AI to modify
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}

        {!isAnalyzing && hasSearched && results.length === 0 && (
          <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center py-16">
            <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-4">
              <Search size={28} className="text-slate-400" />
            </div>
            <p className="text-sm font-medium text-slate-700 mb-1">No exact matches found</p>
            <p className="text-xs text-slate-500 mb-4 max-w-md text-center">
              Try a different description, or use AI Assistant to create a new workflow from scratch.
            </p>
            <button onClick={() => window.location.hash = '/ai-assistant'} className="h-9 px-4 bg-blue-50 text-blue-600 text-sm font-semibold rounded-md hover:bg-blue-100 transition-colors">
              Create New Workflow with AI
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   TAB 2: FLOW SUMMARY
   ══════════════════════════════════════════════════════════════════ */
function FlowSummaryTab() {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const filtered = activeCategory === 'all'
    ? WORKFLOWS
    : WORKFLOWS.filter(w => w.category === activeCategory);

  const categories = ['all', 'Transformer', 'SWB', 'Customization'];

  return (
    <div className="space-y-6">
      {/* Insights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {INSIGHTS.map((insight, i) => {
          const Icon = insight.icon;
          return (
            <motion.div key={insight.label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: i * 0.08, ease: EASE }}
              className="bg-white rounded-xl shadow-sm border border-slate-200 p-5 border-t-[3px]" style={{ borderTopColor: insight.color }}>
              <div className="flex items-start justify-between mb-3">
                <Icon size={28} style={{ color: insight.color }} />
                <div className="flex items-center gap-1">
                  {insight.trendUp === true && <TrendingUp size={14} className="text-emerald-500" />}
                  {insight.trendUp === false && <TrendingDown size={14} className="text-red-500" />}
                  {insight.trendUp === null && <Minus size={14} className="text-slate-400" />}
                </div>
              </div>
              <div className="text-[26px] font-bold text-slate-900 leading-tight mb-1"><CountUp target={insight.value} /></div>
              <div className="text-[13px] text-slate-500 mb-1">{insight.label}</div>
              <div className="text-[11px] font-medium" style={{ color: insight.color }}>{insight.trend}</div>
            </motion.div>
          );
        })}
      </div>

      {/* AI Summary */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4, ease: EASE }}
        className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold text-slate-900">Workflow Ecosystem Summary</h3>
          <button className="h-8 px-3 text-slate-500 hover:text-blue-600 text-xs font-medium rounded-md hover:bg-blue-50 transition-colors flex items-center gap-1.5">
            <RefreshCw size={13} /> Refresh
          </button>
        </div>
        <p className="text-sm text-slate-600 leading-relaxed">
          Your ecosystem has <strong>9 workflows</strong> across 3 categories (4 Transformer + 3 SWB + 2 Customization).
          Transformer workflows show highest efficiency (avg 87%) with consistent performance across data pipelines.
          SWB workflows have the most room for improvement due to external API dependencies — Image Recognition Flow needs attention.
          Customization workflows are most frequently used (24 total invocations) with strong adoption.
          Overall system health is <span className="text-emerald-600 font-semibold">Good</span> with 1 workflow requiring attention.
        </p>
      </motion.div>

      {/* Category Filter */}
      <div className="flex items-center gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={cn(
              'h-9 px-4 rounded-full text-sm font-medium transition-all flex items-center gap-1.5',
              activeCategory === cat
                ? 'bg-blue-600 text-white'
                : 'bg-slate-50 border border-slate-200 text-slate-600 hover:bg-blue-50 hover:border-blue-200'
            )}
          >
            {cat !== 'all' && categoryMeta[cat] && (
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: categoryMeta[cat].color }} />
            )}
            {cat === 'all' ? 'All Workflows' : cat}
            <span className={cn('text-[11px]', activeCategory === cat ? 'text-white/70' : 'text-slate-400')}>
              ({cat === 'all' ? WORKFLOWS.length : WORKFLOWS.filter(w => w.category === cat).length})
            </span>
          </button>
        ))}
      </div>

      {/* Workflow Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((wf, i) => {
          const meta = categoryMeta[wf.category];
          return (
            <motion.div key={wf.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay: i * 0.06, ease: EASE }}
              className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-all">
              <div className="p-5">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: wf.status === 'Running' ? '#10B981' : wf.status === 'Error' ? '#EF4444' : '#94A3B8' }} />
                  <h4 className="text-[15px] font-semibold text-slate-900 flex-1">{wf.name}</h4>
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold border" style={{ backgroundColor: `${meta?.color}10`, color: meta?.color, borderColor: `${meta?.color}20` }}>
                    {wf.category}
                  </span>
                </div>
                <p className="text-sm text-slate-500 leading-relaxed mb-4 line-clamp-2">{wf.description}</p>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-2 mb-4">
                  <div className="bg-slate-50 rounded-lg p-2.5 text-center">
                    <div className="text-[11px] text-slate-400 mb-0.5">Nodes</div>
                    <div className="text-base font-bold text-slate-800">{wf.nodes}</div>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-2.5 text-center">
                    <div className="text-[11px] text-slate-400 mb-0.5">Efficiency</div>
                    <div className="text-base font-bold" style={{ color: wf.efficiency >= 90 ? '#10B981' : wf.efficiency >= 75 ? '#F59E0B' : '#EF4444' }}>{wf.efficiency}%</div>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-2.5 text-center">
                    <div className="text-[11px] text-slate-400 mb-0.5">Used</div>
                    <div className="text-base font-bold text-slate-800">{wf.usedIn}x</div>
                  </div>
                </div>

                {/* Complexity bar */}
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-xs text-slate-400 w-16">Complexity</span>
                  <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(wf.complexity, 100)}%`, background: wf.complexity > 50 ? '#F59E0B' : '#10B981' }} />
                  </div>
                  <span className="text-xs font-medium text-slate-600 w-8 text-right">{wf.complexity}</span>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <span className="flex items-center gap-1"><Timer size={11} /> {wf.lastRun}</span>
                  <span className="flex items-center gap-1"><GitBranch size={11} /> {wf.connections} conn</span>
                </div>
              </div>

              {/* Expand */}
              <div className="border-t border-slate-100">
                <button onClick={() => setExpandedId(expandedId === wf.id ? null : wf.id)}
                  className="w-full flex items-center justify-center gap-1.5 py-2.5 text-xs text-slate-400 hover:text-slate-700 hover:bg-slate-50 transition-colors">
                  {expandedId === wf.id ? <>Less <ChevronUp size={13} /></> : <>More Details <ChevronDown size={13} /></>}
                </button>
                <AnimatePresence>
                  {expandedId === wf.id && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
                      <div className="px-5 pb-4 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Status</span>
                          <span className={cn('font-medium', wf.status === 'Running' ? 'text-emerald-600' : wf.status === 'Error' ? 'text-red-500' : 'text-slate-500')}>{wf.status}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Optimization potential</span>
                          <span className="font-medium text-amber-600">{100 - wf.efficiency}%</span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   TAB 3: AI INSIGHTS
   ══════════════════════════════════════════════════════════════════ */
function AIInsightsTab() {
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const filtered = filterPriority === 'all'
    ? RECOMMENDATIONS
    : RECOMMENDATIONS.filter(r => r.priority === filterPriority);

  return (
    <div className="space-y-6">
      {/* High Priority Alert */}
      {RECOMMENDATIONS.filter(r => r.priority === 'high').length > 0 && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, ease: EASE }}
          className="bg-amber-50 border border-amber-200 rounded-xl p-5 flex items-center gap-4">
          <AlertTriangle size={22} className="text-amber-600 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-amber-800">
              {RECOMMENDATIONS.filter(r => r.priority === 'high').length} high-priority optimizations available
            </p>
            <p className="text-xs text-amber-600">Applying these could improve overall efficiency by ~18%</p>
          </div>
          <button className="h-8 px-4 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-md transition-colors shrink-0">
            Apply All
          </button>
        </motion.div>
      )}

      {/* Filter */}
      <div className="flex items-center gap-2">
        {['all', 'high', 'medium', 'low'].map((p) => (
          <button key={p} onClick={() => setFilterPriority(p)}
            className={cn(
              'h-8 px-3 rounded-full text-xs font-medium transition-all border',
              filterPriority === p
                ? p === 'high' ? 'bg-red-50 border-red-200 text-red-600' : p === 'medium' ? 'bg-amber-50 border-amber-200 text-amber-600' : p === 'low' ? 'bg-blue-50 border-blue-200 text-blue-600' : 'bg-blue-600 border-blue-600 text-white'
                : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
            )}>
            {p === 'all' ? 'All' : p.charAt(0).toUpperCase() + p.slice(1)}
            <span className="ml-1 opacity-60">({p === 'all' ? RECOMMENDATIONS.length : RECOMMENDATIONS.filter(r => r.priority === p).length})</span>
          </button>
        ))}
      </div>

      {/* Recommendation Cards */}
      <div className="space-y-3">
        {filtered.map((rec, i) => {
          const borderColors: Record<string, string> = { high: '#EF4444', medium: '#F59E0B', low: '#2B7FFF' };
          return (
            <motion.div key={rec.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay: i * 0.06, ease: EASE }}
              className="bg-white rounded-xl shadow-sm border border-slate-200 border-l-[4px] p-5" style={{ borderLeftColor: borderColors[rec.priority] }}>
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <PriorityBadge priority={rec.priority} />
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-600 border border-slate-200">{rec.category}</span>
                <span className="ml-auto flex items-center gap-1 text-[11px] text-slate-500">
                  <Sparkles size={11} className="text-amber-500" />
                  AI Confidence: {rec.confidence}%
                </span>
              </div>
              <h4 className="text-[15px] font-semibold text-slate-900 mb-1.5">{rec.title}</h4>
              <p className="text-sm text-slate-600 leading-relaxed mb-3">{rec.description}</p>
              <div className="flex items-center gap-3 mb-3 text-xs text-slate-500">
                <span>Affects <strong className="text-slate-700">{rec.affectedCount}</strong> {rec.affectedCount === 1 ? 'workflow' : 'workflows'}</span>
                <span className="text-emerald-600 font-medium">{rec.timeSaved}</span>
              </div>
              <div className="flex items-center gap-2">
                <button className="h-8 px-3 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-md transition-colors">Apply</button>
                <button className="h-8 px-3 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-medium rounded-md transition-colors">Details</button>
                <button className="h-8 px-3 text-slate-400 hover:text-slate-600 text-xs font-medium rounded-md hover:bg-slate-50 transition-colors ml-auto">Dismiss</button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Optimization Log */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4, delay: 0.3, ease: EASE }} className="pt-4">
        <h3 className="text-base font-semibold text-slate-900 mb-4">Recent Optimizations</h3>
        <div className="relative pl-6">
          <div className="absolute left-[7px] top-0 bottom-0 w-px bg-slate-200" />
          {OPT_LOG.map((entry, i) => {
            const statusColors: Record<string, { dot: string; text: string }> = {
              applied: { dot: 'bg-emerald-500', text: 'text-emerald-600' },
              partial: { dot: 'bg-amber-500', text: 'text-amber-600' },
              reverted: { dot: 'bg-red-500', text: 'text-red-500' },
            };
            const sc = statusColors[entry.status];
            return (
              <motion.div key={entry.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: i * 0.06, ease: EASE }} className="relative pb-6 last:pb-0">
                <div className={cn('absolute left-[-21px] top-1 w-4 h-4 rounded-full border-2 border-white', sc.dot)} />
                <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 ml-3">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs text-slate-400">{entry.date}</span>
                    <span className={cn('text-[11px] font-semibold', sc.text)}>{entry.status.charAt(0).toUpperCase() + entry.status.slice(1)}</span>
                  </div>
                  <h4 className="text-sm font-semibold text-slate-900 mb-1">{entry.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed mb-2">{entry.description}</p>
                  <span className="text-[11px] font-medium text-slate-500 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100">{entry.metrics}</span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   TAB 4: EMBED ANALYSIS
   ══════════════════════════════════════════════════════════════════ */
function EmbedAnalysisTab() {
  const [selectedCategory, setSelectedCategory] = useState<'Transformer' | 'SWB' | 'Customization'>('Transformer');
  const [analysisMode, setAnalysisMode] = useState<'workflows' | 'nodes'>('nodes');

  const catNodes = NODES.filter(n => n.category === selectedCategory);
  const catWorkflows = WORKFLOWS.filter(w => w.category === selectedCategory);

  const avgSuccess = Math.round(catNodes.reduce((s, n) => s + n.successRate, 0) / catNodes.length);
  const avgExec = (catNodes.reduce((s, n) => s + parseFloat(n.execTime), 0) / catNodes.length).toFixed(1);
  const warningCount = catNodes.filter(n => n.health === 'warning').length;
  const criticalCount = catNodes.filter(n => n.health === 'critical').length;
  const healthScore = Math.round(catNodes.reduce((s, n) => s + (n.health === 'healthy' ? 100 : n.health === 'warning' ? 60 : 20), 0) / catNodes.length);

  const meta = categoryMeta[selectedCategory];

  return (
    <div className="space-y-6">
      {/* Category Selector */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, ease: EASE }}
        className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <h3 className="text-sm font-semibold text-slate-900 mb-3">Select Category to Analyze</h3>
        <div className="flex items-center gap-3">
          {(['Transformer', 'SWB', 'Customization'] as const).map((cat) => {
            const cm = categoryMeta[cat];
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={cn(
                  'flex-1 h-16 rounded-xl border-2 transition-all flex items-center gap-3 px-4',
                  isActive ? 'border-blue-500 bg-blue-50/50' : 'border-slate-200 hover:border-slate-300 bg-white'
                )}
              >
                <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${cm.color}15` }}>
                  <cm.icon size={18} style={{ color: cm.color }} />
                </div>
                <div className="text-left">
                  <div className="text-sm font-semibold" style={{ color: isActive ? cm.color : '#1e293b' }}>{cat}</div>
                  <div className="text-[11px] text-slate-400">{NODES.filter(n => n.category === cat).length} nodes · {WORKFLOWS.filter(w => w.category === cat).length} workflows</div>
                </div>
              </button>
            );
          })}
        </div>
      </motion.div>

      {/* Health Overview */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.08, ease: EASE }}
        className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${meta.color}15` }}>
              <Activity size={20} style={{ color: meta.color }} />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-900">{selectedCategory} Health Overview</h3>
              <p className="text-xs text-slate-500">AI-generated analysis based on usage patterns</p>
            </div>
          </div>
          {/* Mode Toggle */}
          <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden">
            <button onClick={() => setAnalysisMode('nodes')} className={cn('h-8 px-3 text-xs font-medium transition-all', analysisMode === 'nodes' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:bg-slate-50')}>Nodes</button>
            <button onClick={() => setAnalysisMode('workflows')} className={cn('h-8 px-3 text-xs font-medium transition-all', analysisMode === 'workflows' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:bg-slate-50')}>Workflows</button>
          </div>
        </div>

        {/* Score Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          <div className="bg-slate-50 rounded-xl p-4 text-center">
            <div className="text-[11px] text-slate-400 mb-1">Health Score</div>
            <div className={cn('text-2xl font-bold', healthScore >= 90 ? 'text-emerald-600' : healthScore >= 70 ? 'text-amber-600' : 'text-red-500')}>{healthScore}%</div>
          </div>
          <div className="bg-slate-50 rounded-xl p-4 text-center">
            <div className="text-[11px] text-slate-400 mb-1">Avg Success Rate</div>
            <div className="text-2xl font-bold text-slate-800">{avgSuccess}%</div>
          </div>
          <div className="bg-slate-50 rounded-xl p-4 text-center">
            <div className="text-[11px] text-slate-400 mb-1">Avg Exec Time</div>
            <div className="text-2xl font-bold text-slate-800">{avgExec}s</div>
          </div>
          <div className="bg-slate-50 rounded-xl p-4 text-center">
            <div className="text-[11px] text-slate-400 mb-1">Issues</div>
            <div className={cn('text-2xl font-bold', warningCount + criticalCount > 0 ? 'text-amber-600' : 'text-emerald-600')}>
              {warningCount + criticalCount}
            </div>
          </div>
        </div>

        {/* AI Analysis Summary */}
        <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-4 mb-4">
          <div className="flex items-start gap-2">
            <Sparkles size={16} className="text-blue-500 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-medium text-blue-800 mb-0.5">AI Analysis</p>
              <p className="text-xs text-blue-600 leading-relaxed">
                {selectedCategory === 'Transformer' && 'Transformer nodes show strong performance with 97%+ success rates. Consider adding a caching layer to Join Tables to reduce 2.1s execution time. Merge Rows could benefit from batch processing optimization.'}
                {selectedCategory === 'SWB' && 'SWB nodes have the most room for improvement. Image Recognizer (89.4% success) and OCR Extract (91.2%) need fallback mechanisms. LLM Prompt averaging 4.2s — consider implementing response streaming.'}
                {selectedCategory === 'Customization' && 'Customization nodes are healthy overall. Report Generator has critical performance (5.1s, 86.2% success) — upgrade recommended. Send Email is your most reliable node with 97.5% success rate.'}
              </p>
            </div>
          </div>
        </div>

        {/* Issue alerts */}
        {(warningCount > 0 || criticalCount > 0) && (
          <div className="flex flex-wrap gap-2">
            {criticalCount > 0 && (
              <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold bg-red-50 text-red-600 border border-red-200">
                <AlertTriangle size={12} /> {criticalCount} Critical
              </span>
            )}
            {warningCount > 0 && (
              <span className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold bg-amber-50 text-amber-600 border border-amber-200">
                <AlertTriangle size={12} /> {warningCount} Warning
              </span>
            )}
          </div>
        )}
      </motion.div>

      {/* Detailed Table */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.15, ease: EASE }}
        className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-base font-semibold text-slate-900">
            {analysisMode === 'nodes' ? 'Node Details' : 'Workflow Details'} — {selectedCategory}
          </h3>
          <span className="text-xs text-slate-400">{analysisMode === 'nodes' ? catNodes.length : catWorkflows.length} items</span>
        </div>

        {analysisMode === 'nodes' ? (
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/50">
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Node</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Type</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Used In</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Exec Time</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Success</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Health</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Action</th>
              </tr>
            </thead>
            <tbody>
              {catNodes.map((node, i) => (
                <motion.tr key={node.id} initial={{ x: -6, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 0.2, delay: i * 0.03, ease: EASE }}
                  className="border-b border-slate-50 hover:bg-blue-50/30 transition-colors">
                  <td className="px-5 py-3 text-sm font-medium text-slate-800">{node.name}</td>
                  <td className="px-5 py-3 text-xs text-slate-500">{node.type}</td>
                  <td className="px-5 py-3 text-xs text-slate-500">{node.usedIn} workflows</td>
                  <td className="px-5 py-3 text-xs text-slate-600 font-mono">{node.execTime}</td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full bg-emerald-500" style={{ width: `${node.successRate}%` }} />
                      </div>
                      <span className="text-xs text-slate-600">{node.successRate}%</span>
                    </div>
                  </td>
                  <td className="px-5 py-3"><HealthBadge health={node.health} /></td>
                  <td className="px-5 py-3">
                    <button className="h-7 px-2.5 text-xs font-medium text-blue-600 hover:bg-blue-50 rounded-md transition-colors flex items-center gap-1">
                      <Wand2 size={11} /> Optimize
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50/50">
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Workflow</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Nodes</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Efficiency</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Complexity</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Status</th>
                <th className="text-left px-5 py-3 text-[11px] font-semibold text-slate-400 uppercase">Action</th>
              </tr>
            </thead>
            <tbody>
              {catWorkflows.map((wf, i) => (
                <motion.tr key={wf.id} initial={{ x: -6, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 0.2, delay: i * 0.03, ease: EASE }}
                  className="border-b border-slate-50 hover:bg-blue-50/30 transition-colors">
                  <td className="px-5 py-3">
                    <div className="text-sm font-medium text-slate-800">{wf.name}</div>
                    <div className="text-xs text-slate-400">{wf.description.slice(0, 50)}...</div>
                  </td>
                  <td className="px-5 py-3 text-xs text-slate-500">{wf.nodes}</td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${wf.efficiency}%`, background: wf.efficiency >= 90 ? '#10B981' : wf.efficiency >= 75 ? '#F59E0B' : '#EF4444' }} />
                      </div>
                      <span className="text-xs text-slate-600">{wf.efficiency}%</span>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-xs text-slate-500">{wf.complexity}/100</td>
                  <td className="px-5 py-3">
                    <span className={cn('inline-flex items-center gap-1 text-[11px] font-semibold',
                      wf.status === 'Running' ? 'text-emerald-600' : wf.status === 'Error' ? 'text-red-500' : 'text-slate-500')}>
                      <span className={cn('w-1.5 h-1.5 rounded-full', wf.status === 'Running' ? 'bg-emerald-500' : wf.status === 'Error' ? 'bg-red-500' : 'bg-slate-400')} />
                      {wf.status}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <button className="h-7 px-2.5 text-xs font-medium text-blue-600 hover:bg-blue-50 rounded-md transition-colors flex items-center gap-1">
                      <Wand2 size={11} /> Optimize
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        )}
      </motion.div>

      {/* Optimization Suggestions per Category */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, delay: 0.2, ease: EASE }}
        className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <h3 className="text-base font-semibold text-slate-900 mb-3">Optimization Suggestions for {selectedCategory}</h3>
        <div className="space-y-2">
          {selectedCategory === 'Transformer' && [
            { t: 'Add caching to Join Tables', d: '2.1s avg execution — Redis cache could reduce to 0.4s for repeated joins', impact: 'High' },
            { t: 'Batch process Merge Rows', d: 'Currently row-by-row — batching could improve throughput 3x', impact: 'Medium' },
            { t: 'Add data validation to Merge Rows', d: '15% of failures are due to malformed input data', impact: 'Medium' },
          ].map((s, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 hover:bg-blue-50/30 transition-colors">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center shrink-0"><TrendingUp size={15} className="text-emerald-600" /></div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-slate-800">{s.t}</div>
                <div className="text-xs text-slate-500">{s.d}</div>
              </div>
              <span className={cn('text-[11px] font-semibold px-2 py-0.5 rounded-full border', s.impact === 'High' ? 'bg-red-50 text-red-600 border-red-200' : 'bg-amber-50 text-amber-600 border-amber-200')}>{s.impact}</span>
              <button className="h-7 px-2.5 text-xs font-medium text-blue-600 hover:bg-blue-50 rounded-md transition-colors">Apply</button>
            </div>
          ))}
          {selectedCategory === 'SWB' && [
            { t: 'Add fallback to Image Recognizer', d: '89.4% success rate — implement secondary model for failed requests', impact: 'High' },
            { t: 'Stream LLM Prompt responses', d: '4.2s avg — streaming would improve perceived performance by 70%', impact: 'High' },
            { t: 'Batch OCR Extract requests', d: 'Process multiple documents in parallel to reduce total time', impact: 'Medium' },
          ].map((s, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 hover:bg-blue-50/30 transition-colors">
              <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center shrink-0"><TrendingUp size={15} className="text-blue-600" /></div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-slate-800">{s.t}</div>
                <div className="text-xs text-slate-500">{s.d}</div>
              </div>
              <span className={cn('text-[11px] font-semibold px-2 py-0.5 rounded-full border', s.impact === 'High' ? 'bg-red-50 text-red-600 border-red-200' : 'bg-amber-50 text-amber-600 border-amber-200')}>{s.impact}</span>
              <button className="h-7 px-2.5 text-xs font-medium text-blue-600 hover:bg-blue-50 rounded-md transition-colors">Apply</button>
            </div>
          ))}
          {selectedCategory === 'Customization' && [
            { t: 'Upgrade Report Generator to v2', d: '5.1s → 2.3s, 86% → 96% success — significant improvement available', impact: 'High' },
            { t: 'Add Send Email template library', d: '6 workflows use email — shared templates would improve consistency', impact: 'Medium' },
            { t: 'Implement webhook circuit breaker', d: 'Prevent cascading failures when downstream services are down', impact: 'Medium' },
          ].map((s, i) => (
            <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 hover:bg-blue-50/30 transition-colors">
              <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center shrink-0"><TrendingUp size={15} className="text-amber-600" /></div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-slate-800">{s.t}</div>
                <div className="text-xs text-slate-500">{s.d}</div>
              </div>
              <span className={cn('text-[11px] font-semibold px-2 py-0.5 rounded-full border', s.impact === 'High' ? 'bg-red-50 text-red-600 border-red-200' : 'bg-amber-50 text-amber-600 border-amber-200')}>{s.impact}</span>
              <button className="h-7 px-2.5 text-xs font-medium text-blue-600 hover:bg-blue-50 rounded-md transition-colors">Apply</button>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   TAB 5: SYSTEMS KNOWLEDGE BASE
   ══════════════════════════════════════════════════════════════════ */
const SYSTEM_ICONS: Record<string, typeof Database> = {
  'SAP ERP': Database,
  'Salesforce CRM': Users,
  'DocuWise': FileText,
  'Slack Connect': MessageSquare,
  'Stripe Payments': CreditCard,
};

function SystemsTab() {
  const [selectedSystem, setSelectedSystem] = useState<TargetSystem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = ['all', ...Array.from(new Set(TARGET_SYSTEMS.map(s => s.category)))];

  const filteredSystems = TARGET_SYSTEMS.filter(s => {
    const matchesCategory = activeCategory === 'all' || s.category === activeCategory;
    const q = searchQuery.toLowerCase();
    const matchesSearch = !q || s.name.toLowerCase().includes(q) || s.functions.some(f => f.name.toLowerCase().includes(q) || f.keywords.some(k => k.includes(q)));
    return matchesCategory && matchesSearch;
  });

  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return [];
    return searchFunctions(searchQuery).slice(0, 10);
  }, [searchQuery]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, ease: EASE }}
        className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center">
            <Database size={20} className="text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-900">Target System Knowledge Base</h3>
            <p className="text-sm text-slate-500">5 connected systems · {TARGET_SYSTEMS.reduce((s, sys) => s + sys.functions.length, 0)} functions available</p>
          </div>
        </div>
        {/* Search */}
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search systems, functions, or keywords..."
            className="w-full h-10 pl-9 pr-4 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 transition-all"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
              <X size={14} />
            </button>
          )}
        </div>
      </motion.div>

      {/* Search Results */}
      {searchQuery.trim() && searchResults.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-xl shadow-sm border border-blue-200 p-4">
          <h4 className="text-sm font-semibold text-slate-900 mb-3">
            <Zap size={14} className="inline text-amber-500 mr-1" />
            {searchResults.length} matching functions
          </h4>
          <div className="space-y-2">
            {searchResults.map((r, i) => {
              const Icon = SYSTEM_ICONS[r.system.name] || Database;
              return (
                <div key={`${r.system.id}-${r.func.id}-${i}`} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 hover:bg-blue-50/50 transition-colors cursor-pointer" onClick={() => setSelectedSystem(r.system)}>
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${r.system.color}12` }}>
                    <Icon size={15} style={{ color: r.system.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-800">{r.func.name}</div>
                    <div className="text-[11px] text-slate-400">{r.system.name} · {r.func.category}</div>
                  </div>
                  <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: `${r.system.color}10`, color: r.system.color }}>
                    {r.func.confidence}%
                  </span>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* Category Filter */}
      <div className="flex items-center gap-2">
        {categories.map(cat => (
          <button key={cat} onClick={() => setActiveCategory(cat)}
            className={cn('h-8 px-3 rounded-full text-xs font-medium transition-all border',
              activeCategory === cat ? 'bg-blue-600 border-blue-600 text-white' : 'bg-white border-slate-200 text-slate-600 hover:bg-blue-50 hover:border-blue-200')}>
            {cat === 'all' ? 'All Systems' : cat}
          </button>
        ))}
      </div>

      {/* System Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filteredSystems.map((sys, i) => {
          const Icon = SYSTEM_ICONS[sys.name] || Database;
          const isSelected = selectedSystem?.id === sys.id;
          return (
            <motion.div key={sys.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, delay: i * 0.06, ease: EASE }}
              className={cn('bg-white rounded-xl shadow-sm border transition-all cursor-pointer overflow-hidden',
                isSelected ? 'border-blue-400 ring-1 ring-blue-400' : 'border-slate-200 hover:border-blue-200 hover:shadow-md')}
              onClick={() => setSelectedSystem(isSelected ? null : sys)}>
              {/* System Header */}
              <div className="p-5">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${sys.color}12` }}>
                    <Icon size={20} style={{ color: sys.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-[15px] font-semibold text-slate-900">{sys.name}</h4>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-400">{sys.category} · API {sys.apiVersion}</span>
                      <span className={cn('text-[10px] px-1.5 py-0.5 rounded-full font-semibold border',
                        sys.status === 'available' ? 'bg-emerald-50 text-emerald-600 border-emerald-200' : 'bg-amber-50 text-amber-600 border-amber-200')}>
                        {sys.status}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-semibold text-slate-500 bg-slate-50 px-2 py-1 rounded-full border border-slate-100">{sys.functions.length} funcs</span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">{sys.description}</p>
              </div>

              {/* Expandable Function List */}
              {isSelected && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} className="overflow-hidden">
                  <div className="border-t border-slate-100 px-5 py-4">
                    <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">Available Functions</h5>
                    <div className="space-y-2 max-h-[400px] overflow-y-auto">
                      {sys.functions.map((func, fi) => (
                        <motion.div key={func.id} initial={{ x: -8, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ duration: 0.2, delay: fi * 0.04, ease: EASE }}
                          className="p-3 rounded-lg bg-slate-50 border border-slate-100 hover:bg-blue-50/30 transition-colors">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm font-medium text-slate-800">{func.name}</span>
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ backgroundColor: `${sys.color}10`, color: sys.color }}>
                              {func.confidence}%
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 leading-relaxed mb-2">{func.description}</p>
                          {/* Keywords */}
                          <div className="flex flex-wrap gap-1 mb-2">
                            {func.keywords.slice(0, 5).map(kw => (
                              <span key={kw} className="text-[10px] px-1.5 py-0.5 rounded-full bg-white text-slate-500 border border-slate-200">{kw}</span>
                            ))}
                          </div>
                          {/* Parameters */}
                          {func.parameters.length > 0 && (
                            <div className="mt-2 pt-2 border-t border-slate-100">
                              <span className="text-[10px] font-semibold text-slate-400 uppercase">Parameters</span>
                              <div className="mt-1 flex flex-wrap gap-1">
                                {func.parameters.map(p => (
                                  <span key={p.key} className={cn('text-[10px] px-1.5 py-0.5 rounded font-mono',
                                    p.required ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-slate-100 text-slate-500 border border-slate-200')}>
                                    {p.label}{p.required ? '*' : ''}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════
   MAIN PAGE
   ══════════════════════════════════════════════════════════════════ */
export default function KnowledgeHub() {
  const [activeTab, setActiveTab] = useState<TabId>('recommend');
  const activeConfig = TABS.find(t => t.id === activeTab)!;

  return (
    <div className="h-full overflow-y-auto bg-slate-50">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-8 py-8">

        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4, ease: EASE }} className="mb-6">
          <p className="text-xs text-slate-400 mb-1 font-medium">Dashboard / Knowledge Hub</p>
          <h1 className="text-[28px] font-bold text-slate-900 mb-1 leading-tight">Knowledge Hub</h1>
          <p className="text-sm text-slate-500">{activeConfig.description}</p>
        </motion.div>

        {/* Tabs */}
        <div className="border-b border-slate-200 mb-6">
          <div className="flex gap-0 overflow-x-auto">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    'relative flex items-center gap-2 h-12 px-5 text-sm font-medium whitespace-nowrap transition-colors duration-200',
                    isActive ? 'text-blue-600' : 'text-slate-500 hover:text-slate-800'
                  )}>
                  <Icon size={17} />
                  {tab.label}
                  {isActive && <motion.div layoutId="khTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" transition={{ duration: 0.2, ease: EASE }} />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          <motion.div key={activeTab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.3, ease: EASE }}>
            {activeTab === 'recommend' && <AIRecommendTab />}
            {activeTab === 'summary' && <FlowSummaryTab />}
            {activeTab === 'insights' && <AIInsightsTab />}
            {activeTab === 'embed' && <EmbedAnalysisTab />}
            {activeTab === 'systems' && <SystemsTab />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
