import { useState, useCallback, useMemo, useEffect } from 'react';
import {
  ReactFlow,
  Background,
  BackgroundVariant,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  useReactFlow,
  ReactFlowProvider,
  Panel,
  addEdge,
  type Connection,
  type Node,
  type NodeTypes,
  type EdgeTypes,
  ConnectionLineType,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Plus, Box, Map, Settings, Minus, Maximize, MousePointer, Hand, GitBranch, Sparkles,
  X, Database, Zap, Trash2,
} from 'lucide-react';
import { GroupNode } from '@/components/canvas/GroupNode';
import { BreadcrumbNav } from '@/components/canvas/BreadcrumbNav';
import type { BreadcrumbItem } from '@/components/canvas/BreadcrumbNav';
import { generateSubFlow } from '@/data/orchestrationEngine';
import { getSystemColor } from '@/data/systemCapabilities';
import { initialNodes, initialEdges } from '@/components/canvas/mockData';
import { NODE_TYPE_COLORS } from '@/components/canvas/types';
import type { CustomNodeType, NodeType, NodeParameter } from '@/components/canvas/types';
import CustomNodeComponent from '@/components/canvas/CustomNode';
import CustomEdgeComponent from '@/components/canvas/CustomEdge';
import { cn } from '@/lib/utils';
import { useWorkflowStore } from '@/store/workflowStore';

const NODE_TYPE_ICONS: Record<NodeType, React.ComponentType<{ size?: number }>> = {
  transformer: Database,
  swb: Zap,
  customization: Sparkles,
};

function nodeColor(n: Node): string {
  const data = (n as unknown as CustomNodeType).data;
  // Priority: systemColor > nodeType color > fallback
  if (data?.systemColor) return data.systemColor as string;
  if (data?.systemName) return getSystemColor(data.systemName as string);
  if (data?.nodeType) return NODE_TYPE_COLORS[data.nodeType];
  return '#94A3B8';
}

/* ─── Node Detail Panel ─────────────────────────────────────────── */
function NodeDetailPanel({
  node,
  onClose,
  onDelete,
}: {
  node: Node | null;
  onClose: () => void;
  onDelete: (id: string) => void;
}) {
  if (!node) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-6 text-center">
        <div className="w-16 h-16 rounded-xl flex items-center justify-center mb-4 bg-blue-50">
          <MousePointer size={28} className="text-blue-500" />
        </div>
        <h3 className="text-slate-800 text-sm font-semibold mb-2">Select a Node</h3>
        <p className="text-xs text-slate-500">Click on any node in the canvas to view its details and configuration</p>
      </div>
    );
  }

  const data = (node as unknown as CustomNodeType).data;
  const color = NODE_TYPE_COLORS[data.nodeType];
  const TypeIcon = NODE_TYPE_ICONS[data.nodeType] || Settings;

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-200">
        <div className="flex items-center gap-2 min-w-0">
          <span style={{ color }}><TypeIcon size={18} /></span>
          <h3 className="text-slate-800 text-sm font-semibold truncate">{data.label}</h3>
        </div>
        <button onClick={onClose} className="w-7 h-7 rounded-md flex items-center justify-center transition-colors text-slate-500 hover:text-slate-800 hover:bg-slate-100 shrink-0 ml-2">
          <X size={16} />
        </button>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5">
        {/* Node ID & Type */}
        <div className="rounded-lg p-3 space-y-2.5 bg-slate-50 border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Node ID</span>
            <span className="text-xs font-mono text-slate-700">{node.id}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Type</span>
            <span className="text-xs font-medium px-2 py-0.5 rounded-full capitalize" style={{ color, background: `${color}15`, border: `1px solid ${color}30` }}>
              {data.nodeType}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Position</span>
            <span className="text-xs font-mono text-slate-600">x: {Math.round(node.position.x)}, y: {Math.round(node.position.y)}</span>
          </div>
        </div>

        {/* Description */}
        {data.description && (
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider mb-2 text-slate-500">Description</h4>
            <p className="text-sm leading-relaxed text-slate-700">{data.description}</p>
          </div>
        )}

        {/* Parameters Configuration */}
        <div>
          <h4 className="text-xs font-semibold uppercase tracking-wider mb-2 text-slate-500">Configuration</h4>
          {data.parameters && data.parameters.length > 0 ? (
            <div className="rounded-lg overflow-hidden bg-slate-50 border border-slate-200">
              {data.parameters.map((param: NodeParameter) => (
                <div key={param.key} className="p-3 border-b border-slate-100 last:border-b-0">
                  {/* Label row */}
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xs font-semibold text-slate-800">{param.label}</span>
                    {param.required && <span className="text-[10px] px-1.5 py-0.5 rounded-full text-red-600 bg-red-50 border border-red-200 font-medium">required</span>}
                    <span className="text-[10px] text-slate-400 ml-auto">{param.key}</span>
                  </div>
                  {/* Value - full width, wrap enabled */}
                  <div className="text-xs font-mono px-3 py-2 rounded-md text-slate-700 bg-white border border-slate-200 break-all whitespace-pre-wrap leading-relaxed w-full">
                    {param.value || '-'}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs italic text-slate-400">No configurable parameters</p>
          )}
        </div>

        {/* Actions */}
        <div className="pt-2 space-y-2">
          <h4 className="text-xs font-semibold uppercase tracking-wider mb-2 text-slate-500">Actions</h4>
          <button
            onClick={() => onDelete(node.id)}
            className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium transition-all duration-150 text-red-600 bg-red-50 border border-red-200 hover:bg-red-100"
          >
            <Trash2 size={14} />
            Delete Node
          </button>
        </div>
      </div>
    </div>
  );
}

/* ─── Canvas Toolbar ────────────────────────────────────────────── */
function CanvasToolbar({ onAddNode, onToggleMinimap, showMinimap }: { onAddNode: () => void; onToggleMinimap: () => void; showMinimap: boolean }) {
  const [hoveredTool, setHoveredTool] = useState<string | null>(null);
  const navigate = useNavigate();
  const tools = [
    { id: 'add', icon: Plus, label: 'Add Node', action: onAddNode },
    { id: 'library', icon: Box, label: 'Node Library', action: () => navigate('/node-library') },
  ];
  const bottomTools = [
    { id: 'minimap', icon: Map, label: 'Minimap', action: onToggleMinimap, active: showMinimap },
    { id: 'settings', icon: Settings, label: 'Settings', action: () => {} },
  ];
  return (
    <div className="relative z-[50] flex flex-col items-center py-2 gap-1 flex-shrink-0 h-full" style={{ width: 56, background: '#FFFFFF', borderRight: '1px solid rgba(0,0,0,0.08)' }}>
      <div className="flex flex-col gap-1">
        {tools.map((t) => (
          <div key={t.id} className="relative">
            <button onClick={t.action} onMouseEnter={() => setHoveredTool(t.id)} onMouseLeave={() => setHoveredTool(null)}
              className="w-11 h-11 rounded-md flex items-center justify-center transition-all duration-150"
              style={{ background: t.id === 'add' ? 'rgba(43,127,255,0.12)' : 'transparent', color: t.id === 'add' ? '#2B7FFF' : '#94A3B8' }}>
              <t.icon size={20} />
            </button>
            {hoveredTool === t.id && (
              <div className="absolute left-full top-1/2 -translate-y-1/2 ml-2 px-2 py-1 rounded-md text-xs font-medium text-slate-800 whitespace-nowrap z-[120] bg-white border border-slate-200 shadow-lg">{t.label}</div>
            )}
          </div>
        ))}
      </div>
      <div className="flex-1" />
      <div className="flex flex-col gap-1">
        {bottomTools.map((t) => (
          <div key={t.id} className="relative">
            <button onClick={t.action} onMouseEnter={() => setHoveredTool(t.id)} onMouseLeave={() => setHoveredTool(null)}
              className="w-11 h-11 rounded-md flex items-center justify-center transition-all duration-150"
              style={{ background: t.active ? 'rgba(43,127,255,0.12)' : 'transparent', color: t.active ? '#2B7FFF' : '#94A3B8' }}>
              <t.icon size={20} />
            </button>
            {hoveredTool === t.id && (
              <div className="absolute left-full top-1/2 -translate-y-1/2 ml-2 px-2 py-1 rounded-md text-xs font-medium text-slate-800 whitespace-nowrap z-[120] bg-white border border-slate-200 shadow-lg">{t.label}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─── Flow Canvas ───────────────────────────────────────────────── */
function FlowCanvas() {
  const pendingWorkflow = useWorkflowStore((s) => s.pendingWorkflow);
  const clearPendingWorkflow = useWorkflowStore((s) => s.clearPendingWorkflow);
  const startNodes = pendingWorkflow?.nodes ?? [];
  const startEdges = pendingWorkflow?.edges ?? [];
  const [nodes, setNodes, onNodesChange] = useNodesState(startNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(startEdges);

  // Clear pending workflow after first render
  useEffect(() => {
    if (pendingWorkflow) {
      clearPendingWorkflow();
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const [showMinimap, setShowMinimap] = useState(true);
  const [showRightPanel, setShowRightPanel] = useState(true);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [activeMode, setActiveMode] = useState<'select' | 'pan' | 'connect'>('select');
  const { zoomIn, zoomOut, fitView } = useReactFlow();

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge({ ...params, type: 'custom' }, eds)),
    [setEdges]
  );

  const handleNodeClick = useCallback((_event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
  }, []);

  const handlePaneClick = useCallback(() => {
    setSelectedNode(null);
  }, []);

  const handleDeleteNode = useCallback((id: string) => {
    setNodes((prev) => prev.filter((n) => n.id !== id));
    setEdges((prev) => prev.filter((e) => e.source !== id && e.target !== id));
    setSelectedNode(null);
  }, [setNodes, setEdges]);

  /* ─── Multi-Level Flow State ──────────────────────────────────── */
  const [breadcrumb, setBreadcrumb] = useState<BreadcrumbItem[]>([{ id: 'root', label: 'Main Flow', level: 0 }]);
  const [currentLevel, setCurrentLevel] = useState(0);

  // Build node types with group
  const nodeTypes: NodeTypes = useMemo(() => ({
    custom: CustomNodeComponent as unknown as NodeTypes[string],
    group: GroupNode as unknown as NodeTypes[string],
  }), []);
  const edgeTypes: EdgeTypes = useMemo(() => ({ custom: CustomEdgeComponent as unknown as EdgeTypes[string] }), []);

  // Handle double-click on group node to drill into sub-flow
  const handleNodeDoubleClick = useCallback((_event: React.MouseEvent, node: Node) => {
    if (node.type === 'group' && node.data) {
      const subCount = (node.data.subStepCount as number) ?? 0;
      if (subCount > 0 && node.data.systemId && node.data.functionId) {
        const subs = generateSubFlow(node.data.label as string, node.data.systemId as string, node.data.functionId as string);
        if (subs.length > 0) {
          const levelId = `level-${currentLevel + 1}-${node.id}`;
          const newItem: BreadcrumbItem = { id: levelId, label: node.data.label as string, level: currentLevel + 1 };
          setBreadcrumb(prev => [...prev, newItem]);
          setCurrentLevel(prev => prev + 1);

          // Convert sub-steps to nodes/edges for the sub-flow view
          const subNodes = subs.map((s, i) => ({
            id: s.id,
            type: 'custom' as const,
            position: { x: 150 + i * 200, y: 200 },
            data: {
              label: s.label,
              description: s.description,
              nodeType: 'swb' as const,
              parameters: [{ key: 'system', label: 'System', value: s.systemName, required: false }],
            },
          }));
          const subEdges = subs.slice(0, -1).map((s, i) => ({
            id: `se-${i}`,
            source: s.id,
            target: subs[i + 1].id,
            type: 'custom' as const,
          }));
          setNodes(subNodes as any);
          setEdges(subEdges);
          setSelectedNode(null);
          setTimeout(() => fitView({ padding: 0.2 }), 50);
        }
      }
    }
  }, [currentLevel, fitView, setEdges, setNodes]);

  // Navigate via breadcrumb
  const handleBreadcrumbNavigate = useCallback((item: BreadcrumbItem) => {
    const targetLevel = item.level;
    setCurrentLevel(targetLevel);
    setBreadcrumb(prev => prev.slice(0, targetLevel + 1));
    setSelectedNode(null);

    if (targetLevel === 0) {
      // Return to root
      const rootNodes = pendingWorkflow?.nodes ?? initialNodes;
      const rootEdges = pendingWorkflow?.edges ?? initialEdges;
      setNodes(rootNodes);
      setEdges(rootEdges);
      setTimeout(() => fitView({ padding: 0.2 }), 50);
    }
  }, [fitView, pendingWorkflow, setEdges, setNodes]);

  return (
    <div className="flex w-full h-full" style={{ background: '#F8FAFC' }}>
      <CanvasToolbar onAddNode={() => {}} onToggleMinimap={() => setShowMinimap((v) => !v)} showMinimap={showMinimap} />

      {/* React Flow Canvas */}
      <div className="flex-1 relative flex flex-col" style={{ minHeight: 0 }}>
        {/* Breadcrumb Navigation */}
        <BreadcrumbNav items={breadcrumb} onNavigate={handleBreadcrumbNavigate} />

        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onNodeClick={handleNodeClick}
          onNodeDoubleClick={handleNodeDoubleClick}
          onPaneClick={handlePaneClick}
          nodeTypes={nodeTypes}
          edgeTypes={edgeTypes}
          minZoom={0.25}
          maxZoom={4}
          defaultEdgeOptions={{ type: 'custom' }}
          snapToGrid
          snapGrid={[10, 10]}
          connectionLineStyle={{ stroke: '#4A9DFF', strokeWidth: 2 }}
          connectionLineType={ConnectionLineType.SmoothStep}
          proOptions={{ hideAttribution: true }}
          style={{ background: '#F8FAFC' }}
        >
          <Background variant={BackgroundVariant.Dots} gap={20} size={1} color="rgba(0,0,0,0.04)" />

          <Panel position="top-center">
            <div className="flex items-center gap-1 px-2 py-1.5 rounded-xl bg-white/95 backdrop-blur-md border border-slate-200 shadow-sm">
              <button className="w-9 h-9 rounded-md flex items-center justify-center text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-all" onClick={() => zoomOut()}><Minus size={18} /></button>
              <button className="w-9 h-9 rounded-md flex items-center justify-center text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-all" onClick={() => zoomIn()}><Plus size={18} /></button>
              <button className="w-9 h-9 rounded-md flex items-center justify-center text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-all" onClick={() => fitView()}><Maximize size={18} /></button>
              <div className="w-px h-5 mx-1 bg-slate-200" />
              <button className={cn('w-9 h-9 rounded-md flex items-center justify-center transition-all', activeMode === 'select' ? 'text-blue-600 bg-blue-50' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-50')} onClick={() => setActiveMode('select')}><MousePointer size={18} /></button>
              <button className={cn('w-9 h-9 rounded-md flex items-center justify-center transition-all', activeMode === 'pan' ? 'text-blue-600 bg-blue-50' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-50')} onClick={() => setActiveMode('pan')}><Hand size={18} /></button>
              <button className={cn('w-9 h-9 rounded-md flex items-center justify-center transition-all', activeMode === 'connect' ? 'text-blue-600 bg-blue-50' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-50')} onClick={() => setActiveMode('connect')}><GitBranch size={18} /></button>
              <div className="w-px h-5 mx-1 bg-slate-200" />
              <button className="w-9 h-9 rounded-md flex items-center justify-center text-amber-500 hover:text-amber-600 hover:bg-amber-50 transition-all"><Sparkles size={18} /></button>
            </div>
          </Panel>

          {showMinimap && (
            <Panel position="bottom-left">
              <MiniMap
                nodeColor={nodeColor}
                maskColor="rgba(148,163,184,0.4)"
                maskStrokeColor="rgba(100,116,139,0.5)"
                maskStrokeWidth={1}
                nodeBorderRadius={6}
                nodeStrokeWidth={0}
                pannable
                zoomable
                className="rounded-lg border border-slate-200 bg-white/95"
                style={{ width: 200, height: 150 }}
              />
            </Panel>
          )}
          <Controls className="flex flex-col gap-1 bg-transparent border-none shadow-none" showZoom showFitView position="bottom-right" />
        </ReactFlow>
      </div>

      {/* Right Panel - Node Details */}
      <AnimatePresence>
        {showRightPanel && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 340, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="relative z-[60] flex-shrink-0 overflow-hidden"
            style={{ background: '#FFFFFF', borderLeft: '1px solid #E2E8F0' }}
          >
            <NodeDetailPanel
              node={selectedNode}
              onClose={() => setSelectedNode(null)}
              onDelete={handleDeleteNode}
            />
            <button onClick={() => setShowRightPanel(false)}
              className="absolute left-0 top-1/2 -translate-x-full -translate-y-1/2 w-4 h-16 rounded-l-md flex items-center justify-center bg-slate-200 hover:bg-slate-300 transition-colors">
              <div className="w-0.5 h-6 rounded-full bg-slate-500" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {!showRightPanel && (
        <button onClick={() => setShowRightPanel(true)}
          className="absolute right-4 top-4 z-[50] w-9 h-9 rounded-md flex items-center justify-center bg-white border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 transition-colors shadow-sm">
          <Settings size={18} />
        </button>
      )}
    </div>
  );
}

export default function Canvas() {
  return (
    <ReactFlowProvider>
      <FlowCanvas />
    </ReactFlowProvider>
  );
}
