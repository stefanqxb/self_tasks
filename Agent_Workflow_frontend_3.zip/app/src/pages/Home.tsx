import { useState, useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import {
  GitBranch,
  Box,
  Play,
  Sparkles,
  Zap,
  Database,
  Plus,
  PenTool,
  PlusSquare,
  Upload,
  Search,
  BookOpen,
} from 'lucide-react'
import { motion } from 'framer-motion'

/* ──────────────────────────────────────────────
   Animation helpers
   ────────────────────────────────────────────── */
const fadeSlideUp = (delay = 0) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5, delay, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] },
})

const staggerContainer = (stagger = 0.1, delay = 0) => ({
  initial: {},
  animate: { transition: { staggerChildren: stagger, delayChildren: delay } },
})

const fadeSlideUpChild = {
  initial: { opacity: 0, y: 20 },
  animate: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] },
  },
}

/* ──────────────────────────────────────────────
   Section 1: Hero Banner
   ────────────────────────────────────────────── */
function FloatingParticles() {
  const particles = Array.from({ length: 16 }, (_, i) => ({
    id: i,
    size: 2 + Math.random() * 2,
    x: 60 + Math.random() * 35,
    y: 10 + Math.random() * 80,
    duration: 4 + Math.random() * 2,
    delay: Math.random() * 4,
  }))

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full bg-brand-blue/20 animate-float"
          style={{
            width: p.size,
            height: p.size,
            left: `${p.x}%`,
            top: `${p.y}%`,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
          }}
        />
      ))}
    </div>
  )
}

function HeroSection() {
  const greeting = 'Good morning, Alex'
  const subtitle = 'You have 3 workflows running and 2 AI suggestions waiting. Library: 24 nodes (11 Transformer + 7 SWB + 6 Customization).'

  return (
    <section className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#1a56c4] to-[#2B7FFF] px-6 py-5 h-[140px]">
      <FloatingParticles />
      <div className="relative z-10">
        <motion.h1 {...fadeSlideUp(0.1)} className="text-[28px] font-bold text-white leading-tight tracking-tight">
          {greeting}
        </motion.h1>
        <motion.p {...fadeSlideUp(0.2)} className="text-sm text-light-gray mt-1">
          {subtitle}
        </motion.p>
        <motion.div {...staggerContainer(0.1, 0.4)} className="flex items-center gap-2 mt-4">
          <motion.div {...fadeSlideUpChild}>
            <Link
              to="/workflows"
              className="inline-flex items-center gap-1.5 h-8 px-3 bg-brand-blue text-white text-sm font-semibold rounded-md hover:bg-brand-blue-hover transition-colors duration-150"
            >
              <Plus size={14} />
              Create Workflow
            </Link>
          </motion.div>
          <motion.div {...fadeSlideUpChild}>
            <Link
              to="/canvas"
              className="inline-flex items-center gap-1.5 h-8 px-3 bg-white/[0.08] text-light-gray text-sm font-semibold rounded-md border border-white/[0.1] hover:bg-white/[0.12] transition-colors duration-150"
            >
              <PenTool size={14} />
              Open Canvas
            </Link>
          </motion.div>
          <motion.div {...fadeSlideUpChild}>
            <Link
              to="/ai-assistant"
              className="inline-flex items-center gap-1.5 h-8 px-3 text-warning-amber text-sm font-semibold rounded-md hover:bg-white/[0.06] transition-colors duration-150"
            >
              <Sparkles size={14} />
              Ask AI Assistant
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

/* ──────────────────────────────────────────────
   Section 2: Stats Row
   ────────────────────────────────────────────── */
interface StatCardProps {
  icon: typeof GitBranch
  color: string
  bgColor: string
  value: string
  label: string
}

function StatCard({ icon: Icon, color, bgColor, value, label }: StatCardProps) {
  const [count, setCount] = useState(0)
  const numericValue = parseInt(value.replace(/,/g, ''))
  const ref = useRef<HTMLDivElement>(null)
  const [triggered, setTriggered] = useState(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !triggered) {
          setTriggered(true)
        }
      },
      { threshold: 0.2 }
    )
    observer.observe(el)
    return () => observer.disconnect()
  }, [triggered])

  useEffect(() => {
    if (!triggered) return
    const duration = 800
    const start = performance.now()
    const step = (now: number) => {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setCount(Math.round(eased * numericValue))
      if (progress < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [triggered, numericValue])

  return (
    <motion.div
      {...fadeSlideUp(0)}
      className="bg-white rounded-lg shadow-sm px-4 py-4 flex items-center gap-4 h-[100px] hover:-translate-y-0.5 hover:shadow-md transition-all duration-200 cursor-default"
    >
      <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: bgColor }}>
        <Icon size={20} style={{ color }} />
      </div>
      <div>
        <div ref={ref} className="text-2xl font-bold text-dark-text">
          {count.toLocaleString()}
        </div>
        <div className="text-xs text-muted-dark mt-0.5">{label}</div>
      </div>
    </motion.div>
  )
}

function StatsRow() {
  const stats: StatCardProps[] = [
    { icon: GitBranch, color: '#2B7FFF', bgColor: 'rgba(43,127,255,0.12)', value: '24', label: 'Total Workflows' },
    { icon: Box, color: '#2B7FFF', bgColor: 'rgba(43,127,255,0.12)', value: '24', label: 'Nodes in Library' },
    { icon: Play, color: '#10B981', bgColor: 'rgba(16,185,129,0.12)', value: '3', label: 'Currently Running' },
    { icon: Sparkles, color: '#F59E0B', bgColor: 'rgba(245,158,11,0.12)', value: '7', label: 'AI Suggestions' },
  ]

  return (
    <motion.section
      {...staggerContainer(0.08, 0)}
      className="grid grid-cols-4 gap-4 mt-6"
    >
      {stats.map((s, i) => (
        <motion.div key={s.label} {...fadeSlideUp(i * 0.08)}>
          <StatCard {...s} />
        </motion.div>
      ))}
    </motion.section>
  )
}

/* ──────────────────────────────────────────────
   Section 3: Main Content Grid
   ────────────────────────────────────────────── */

const workflows = [
  { name: 'Customer Onboarding', desc: 'Automated email sequence + CRM update', status: 'running', time: '2h ago' },
  { name: 'Data Pipeline v2', desc: 'ETL process for analytics dashboard', status: 'idle', time: '5h ago' },
  { name: 'Social Media Scheduler', desc: 'Auto-post + engagement tracking', status: 'running', time: '1d ago' },
  { name: 'Invoice Generator', desc: 'PDF generation + email delivery', status: 'error', time: '2d ago' },
  { name: 'User Survey Flow', desc: 'Form collection + response analysis', status: 'idle', time: '3d ago' },
]

const StatusBadge = ({ status }: { status: string }) => {
  if (status === 'running') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-success-green/10 text-success-green">
        <span className="w-1.5 h-1.5 rounded-full bg-success-green animate-green-pulse" />
        Running
      </span>
    )
  }
  if (status === 'error') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-error-red/10 text-error-red">
        <span className="w-1.5 h-1.5 rounded-full bg-error-red" />
        Error
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-muted-gray/10 text-muted-dark">
      <span className="w-1.5 h-1.5 rounded-full bg-muted-gray" />
      Idle
    </span>
  )
}

function RecentWorkflows() {
  return (
    <motion.div {...fadeSlideUp(0)} className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-dark-text">Recent Workflows</h2>
        <Link to="/workflows" className="text-xs font-medium text-brand-blue hover:underline">
          View All
        </Link>
      </div>
      <div>
        {workflows.map((wf, i) => (
          <motion.div
            key={wf.name}
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: i * 0.06, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] }}
            className="flex items-center justify-between py-3 border-b border-border-light last:border-0 hover:bg-brand-blue/[0.04] hover:cursor-pointer rounded-md px-2 -mx-2 transition-colors duration-150"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-full bg-brand-blue/10 flex items-center justify-center flex-shrink-0">
                <GitBranch size={14} className="text-brand-blue" />
              </div>
              <div className="min-w-0">
                <div className="text-[15px] font-semibold text-dark-text truncate">{wf.name}</div>
                <div className="text-[13px] text-muted-dark truncate">{wf.desc}</div>
              </div>
            </div>
            <div className="flex items-center gap-3 flex-shrink-0">
              <StatusBadge status={wf.status} />
              <span className="text-xs text-muted-dark whitespace-nowrap">{wf.time}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

const aiSuggestions = [
  { icon: 'merge', title: 'Merge Duplicate Nodes', desc: '3 similar data transform nodes detected. Merging could reduce complexity by 15%.' },
  { icon: 'optimize', title: 'Optimize Invoice Flow', desc: 'Your Invoice Generator has a redundant approval step. Removing it would save ~2s per run.' },
  { icon: 'new', title: 'New Node Available', desc: "A 'Sentiment Analysis' node matching your existing flows is now available." },
]

function AISuggestions() {
  return (
    <motion.div {...fadeSlideUp(0.1)} className="rounded-lg shadow-sm p-6 relative overflow-hidden" style={{ background: 'linear-gradient(to bottom, #FFFDF5, #FFFFFF)' }}>
      {/* Top accent bar */}
      <div className="absolute top-0 left-0 right-0 h-[3px] rounded-t-lg" style={{ background: 'linear-gradient(to right, #F59E0B, #2B7FFF)' }} />

      <div className="flex items-center gap-2 mb-4">
        <Sparkles size={20} className="text-warning-amber" />
        <h2 className="text-lg font-semibold text-dark-text">AI Insights</h2>
        <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-warning-amber/10 text-warning-amber">AI</span>
      </div>

      <div>
        {aiSuggestions.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: i * 0.1, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] }}
            className="p-3 rounded-md mb-3 last:mb-0 border border-warning-amber/15 hover:border-warning-amber/30 hover:shadow-sm transition-all duration-150 cursor-pointer"
            style={{ background: 'rgba(245,158,11,0.05)' }}
          >
            <div className="flex items-center gap-2 mb-1">
              <Sparkles size={18} className="text-warning-amber flex-shrink-0" />
              <span className="text-[15px] font-semibold text-dark-text">{s.title}</span>
            </div>
            <p className="text-[13px] text-muted-dark leading-relaxed mb-1">{s.desc}</p>
            <span className="text-xs font-medium text-brand-blue hover:underline cursor-pointer">Review &rarr;</span>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

function MainContentGrid() {
  return (
    <section className="grid gap-6 mt-6" style={{ gridTemplateColumns: '60% 40%' }}>
      <RecentWorkflows />
      <AISuggestions />
    </section>
  )
}

/* ──────────────────────────────────────────────
   Section 4: Activity Feed + Quick Actions
   ────────────────────────────────────────────── */

const activities = [
  { color: '#2B7FFF', text: "Created 'Customer Onboarding' workflow", time: '2h ago' },
  { color: '#10B981', text: "'Social Media Scheduler' completed successfully", time: '3h ago' },
  { color: '#F59E0B', text: "AI modified 'Data Pipeline v2' — added filter node", time: '5h ago' },
  { color: '#10B981', text: "'Invoice Generator' started running", time: '6h ago' },
  { color: '#EF4444', text: "Deleted 'Test Workflow'", time: '1d ago' },
  { color: '#2B7FFF', text: 'Imported 7 SWB nodes from external API', time: '1d ago' },
]

function ActivityFeed() {
  return (
    <motion.div {...fadeSlideUp(0)} className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-dark-text">Recent Activity</h2>
        <div className="relative">
          <select className="text-xs text-muted-dark bg-transparent border border-border-light rounded-md px-2 py-1 cursor-pointer hover:border-border-subtle transition-colors">
            <option>All</option>
            <option>Create</option>
            <option>Run</option>
            <option>Edit</option>
            <option>Delete</option>
          </select>
        </div>
      </div>
      <div>
        {activities.map((a, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: i * 0.05, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] }}
            className="flex items-start gap-3 py-2 hover:bg-black/[0.02] rounded-md px-2 -mx-2 transition-colors duration-100"
          >
            {/* Timeline dot + line */}
            <div className="flex flex-col items-center self-stretch">
              <div className="w-2 h-2 rounded-full flex-shrink-0 mt-1.5" style={{ backgroundColor: a.color }} />
              {i < activities.length - 1 && (
                <div className="w-px flex-1 min-h-[20px] bg-black/[0.06] mt-1" />
              )}
            </div>
            <div className="min-w-0">
              <div className="text-sm text-dark-text">{a.text}</div>
              <div className="text-xs text-muted-dark mt-0.5">{a.time}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

const quickActions = [
  { icon: PlusSquare, label: 'New Workflow', sublabel: 'Start from scratch', to: '/canvas' },
  { icon: Upload, label: 'Import Nodes', sublabel: 'From external system', to: '/node-library' },
  { icon: Sparkles, label: 'AI Generate', sublabel: 'Describe your flow', to: '/ai-assistant' },
  { icon: Search, label: 'Browse Library', sublabel: '24 nodes available', to: '/node-library' },
  { icon: BookOpen, label: 'View Insights', sublabel: 'Optimization ideas', to: '/knowledge-hub' },
  { icon: Play, label: 'Run Workflow', sublabel: 'Execute latest version', to: '/workflows' },
]

function QuickActions() {
  return (
    <motion.div {...fadeSlideUp(0)} className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold text-dark-text mb-4">Quick Actions</h2>
      <div className="grid grid-cols-3 gap-3">
        {quickActions.map((a, i) => (
          <motion.div
            key={a.label}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.25, delay: i * 0.06, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] }}
          >
            <Link
              to={a.to}
              className="flex flex-col items-center text-center p-4 rounded-md border border-brand-blue/10 hover:bg-brand-blue/[0.08] hover:border-brand-blue/20 hover:-translate-y-0.5 transition-all duration-200"
              style={{ background: 'rgba(43,127,255,0.04)' }}
            >
              <a.icon size={28} className="text-brand-blue mb-2" />
              <span className="text-[15px] font-semibold text-dark-text">{a.label}</span>
              <span className="text-xs text-muted-dark mt-0.5">{a.sublabel}</span>
            </Link>
          </motion.div>
        ))}
      </div>
    </motion.div>
  )
}

function ActivitySection() {
  return (
    <section className="grid grid-cols-2 gap-6 mt-6">
      <ActivityFeed />
      <QuickActions />
    </section>
  )
}

/* ──────────────────────────────────────────────
   Section 5: Node Category Overview
   ────────────────────────────────────────────── */

const categories = [
  { name: 'Transformer', icon: Database, color: '#10B981', count: 11, usage: 82 },
  { name: 'SWB', icon: Zap, color: '#2B7FFF', count: 7, usage: 91 },
  { name: 'Customization', icon: Sparkles, color: '#F59E0B', count: 6, usage: 76 },
]

function NodeCategoryOverview() {
  return (
    <motion.section {...fadeSlideUp(0)} className="bg-white rounded-lg shadow-sm p-6 mt-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-dark-text">Node Library Overview</h2>
        <Link to="/node-library" className="text-xs font-medium text-brand-blue hover:underline">
          Open Library &rarr;
        </Link>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-2" style={{ scrollbarWidth: 'none' }}>
        {categories.map((cat, i) => (
          <motion.div
            key={cat.name}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: i * 0.07, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] }}
            className="min-w-[180px] p-4 rounded-md border border-border-light text-center hover:-translate-y-0.5 hover:shadow-md transition-all duration-200 cursor-default"
          >
            <div
              className="w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center"
              style={{ backgroundColor: `${cat.color}12` }}
            >
              <cat.icon size={24} style={{ color: cat.color }} />
            </div>
            <div className="text-[15px] font-semibold text-dark-text">{cat.name}</div>
            <div className="text-xs text-muted-dark mt-1">{cat.count} nodes</div>
            <div className="mt-2 h-1 bg-border-light rounded-full overflow-hidden">
              <motion.div
                className="h-full rounded-full"
                style={{ backgroundColor: cat.color }}
                initial={{ width: 0 }}
                animate={{ width: `${cat.usage}%` }}
                transition={{ duration: 0.6, delay: 0.2 + i * 0.07, ease: [0.25, 0.1, 0.25, 1] as [number, number, number, number] }}
              />
            </div>
            <div className="text-[11px] text-muted-dark mt-1">{cat.usage}% used</div>
          </motion.div>
        ))}
      </div>
    </motion.section>
  )
}

/* ──────────────────────────────────────────────
   Section 6: Footer CTA
   ────────────────────────────────────────────── */
function FooterCTA() {
  return (
    <motion.section
      {...fadeSlideUp(0)}
      className="mt-12 mb-8 rounded-2xl p-12 text-center"
      style={{ background: 'linear-gradient(to right, #2B7FFF, #4A9DFF)' }}
    >
      <h2 className="text-[22px] font-bold text-white mb-2">
        Ready to build something powerful?
      </h2>
      <p className="text-sm text-white/80 mb-6">
        Describe your workflow in natural language and let AI build it for you.
      </p>
      <Link
        to="/ai-assistant"
        className="inline-flex items-center gap-2 h-11 px-6 bg-white text-brand-blue font-semibold rounded-md hover:bg-white/90 hover:scale-[1.02] transition-all duration-200 animate-pulse-glow"
      >
        <Sparkles size={18} />
        Start with AI
      </Link>
    </motion.section>
  )
}

/* ──────────────────────────────────────────────
   Main Home Page
   ────────────────────────────────────────────── */
export default function Home() {
  return (
    <div className="max-w-[1400px] mx-auto px-8 py-8">
      <HeroSection />
      <StatsRow />
      <MainContentGrid />
      <ActivitySection />
      <NodeCategoryOverview />
      <FooterCTA />
    </div>
  )
}
