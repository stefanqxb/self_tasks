export default function Settings() {
  return (
    <div className="p-8 bg-surface-light h-full">
      <h1 className="text-2xl font-bold text-dark-text mb-4">Settings</h1>
      <p className="text-muted-dark">Configure your preferences and connections.</p>
    </div>
  )
}
