import { useState, useMemo, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search, LayoutGrid, List, Play, PenTool, MoreHorizontal,
  X, Folder, CheckCircle2, AlertCircle, PauseCircle, Clock,
  Loader2, Save, Trash2,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/** Python Agent API base URL */
const AGENT_API_URL = import.meta.env.VITE_AGENT_URL || 'http://localhost:8000'

// ─── Types ───────────────────────────────────────────────────────────────────

interface WorkflowItem {
  id: string
  name: string
  description: string
  status: 'Running' | 'Idle' | 'Error' | 'Paused' | 'Draft'
  nodes: number
  connections: number
  tags: string[]
  lastEdited: string
  folder: string
  thumbnailColor: string
  nodeRefs: string[]
}

// ─── API Helpers ─────────────────────────────────────────────────────────────

async function apiListWorkflows(): Promise<WorkflowItem[]> {
  const resp = await fetch(`${AGENT_API_URL}/api/workflows`)
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`)
  return resp.json()
}

async function apiUpdateWorkflow(wf: WorkflowItem): Promise<void> {
  const resp = await fetch(`${AGENT_API_URL}/api/workflows/${wf.id}`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(wf),
  })
  if (!resp.ok) throw new Error(`HTTP ${resp.status}: ${await resp.text()}`)
}

async function apiDeleteWorkflow(id: string): Promise<void> {
  const resp = await fetch(`${AGENT_API_URL}/api/workflows/${id}`, { method: 'DELETE' })
  if (!resp.ok) throw new Error(`HTTP ${resp.status}: ${await resp.text()}`)
}

// ─── Constants ───────────────────────────────────────────────────────────────

const STATUS_OPTIONS = ['All Status', 'Active', 'Running', 'Idle', 'Paused', 'Error', 'Draft']
const SORT_OPTIONS = ['Last Modified', 'Name A-Z', 'Status']

const STATUS_CONFIG: Record<string, { dot: string; labelColor: string; bgColor: string }> = {
  Running: { dot: 'bg-emerald-500', labelColor: 'text-emerald-600', bgColor: 'bg-emerald-50' },
  Idle:    { dot: 'bg-slate-400', labelColor: 'text-slate-500', bgColor: 'bg-slate-50' },
  Error:   { dot: 'bg-red-500', labelColor: 'text-red-500', bgColor: 'bg-red-50' },
  Paused:  { dot: 'bg-amber-500', labelColor: 'text-amber-600', bgColor: 'bg-amber-50' },
  Draft:   { dot: 'bg-slate-500', labelColor: 'text-slate-500', bgColor: 'bg-slate-50' },
}

const FOLDER_CATEGORIES = ['Transformer', 'SWB', 'Customization']

const EASE = [0.16, 1, 0.3, 1] as [number, number, number, number]

// ─── Component ───────────────────────────────────────────────────────────────

export default function Workflows() {
  const [workflows, setWorkflows] = useState<WorkflowItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [activeFolder, setActiveFolder] = useState('all')
  const [activeStatus, setActiveStatus] = useState('All Status')
  const [sortBy, setSortBy] = useState('Last Modified')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set())
  const [editingWorkflow, setEditingWorkflow] = useState<WorkflowItem | null>(null)

  // Load workflows from backend
  useEffect(() => {
    apiListWorkflows()
      .then(data => { setWorkflows(data); setLoading(false) })
      .catch(err => { setError(err.message); setLoading(false) })
  }, [])

  const folders = useMemo(() => [
    { id: 'all', name: 'All Workflows', count: workflows.length },
    ...FOLDER_CATEGORIES.map(cat => ({
      id: cat, name: cat, count: workflows.filter(w => w.folder === cat).length
    }))
  ], [workflows])

  const filteredWorkflows = useMemo(() => {
    let filtered = workflows.filter((wf) => {
      const q = searchQuery.toLowerCase()
      const matchesSearch = q === '' ||
        wf.name.toLowerCase().includes(q) ||
        wf.description.toLowerCase().includes(q) ||
        wf.tags.some(t => t.toLowerCase().includes(q))

      const matchesStatus = activeStatus === 'All Status' ||
        (activeStatus === 'Active' && (wf.status === 'Running' || wf.status === 'Idle')) ||
        wf.status === activeStatus

      const matchesFolder = activeFolder === 'all' || wf.folder === activeFolder

      return matchesSearch && matchesStatus && matchesFolder
    })

    switch (sortBy) {
      case 'Name A-Z': filtered.sort((a, b) => a.name.localeCompare(b.name)); break
      case 'Status':   filtered.sort((a, b) => a.status.localeCompare(b.status)); break
    }
    return filtered
  }, [searchQuery, activeFolder, activeStatus, sortBy, workflows])

  const toggleSelection = (id: string) => {
    setSelectedItems(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  // Save edited workflow -> backend (does NOT close drawer - let user see success)
  const handleSaveWorkflow = useCallback(async (updated: WorkflowItem) => {
    await apiUpdateWorkflow(updated)
    setWorkflows(prev => prev.map(w => w.id === updated.id ? updated : w))
    // NOTE: We intentionally do NOT call setEditingWorkflow(null) here.
    // The drawer stays open so the user can see the "Saved!" confirmation.
  }, [])

  // Delete workflow -> backend
  const handleDeleteWorkflow = useCallback(async (id: string) => {
    await apiDeleteWorkflow(id)
    setWorkflows(prev => prev.filter(w => w.id !== id))
    setEditingWorkflow(null)
  }, [])

  // Status toggle helper
  const getNextStatus = (current: string): string => {
    const cycle = ['Draft', 'Idle', 'Running', 'Paused', 'Error']
    const idx = cycle.indexOf(current)
    return cycle[(idx + 1) % cycle.length]
  }

  if (loading) return (
    <div className="h-full flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-3">
        <Loader2 size={28} className="text-blue-600 animate-spin" />
        <p className="text-sm text-slate-500">Loading workflows from backend...</p>
      </div>
    </div>
  )

  if (error) return (
    <div className="h-full flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-3 text-center">
        <AlertCircle size={28} className="text-red-500" />
        <p className="text-sm text-red-600 font-medium">Failed to load workflows</p>
        <p className="text-xs text-slate-400">{error}</p>
        <p className="text-xs text-slate-400">Make sure the Python agent is running:<br/><code className="bg-slate-100 px-1 rounded">python -m uvicorn main:app --port 8000</code></p>
        <button onClick={() => window.location.reload()} className="h-8 px-4 rounded-lg text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700">Retry</button>
      </div>
    </div>
  )

  return (
    <div className="h-full overflow-y-auto bg-slate-50 p-6 lg:p-8">
      {/* ─── Page Header ─── */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
          <span>Dashboard</span><span>/</span><span className="text-blue-600 font-medium">Workflows</span>
        </div>
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-[28px] font-bold text-slate-900 leading-tight">Workflow Manager</h1>
            <p className="text-sm text-slate-500 mt-1">Manage and organize your {workflows.length} workflows &middot; stored in <code className="bg-slate-100 px-1 rounded text-xs">workflow_lib/</code></p>
          </div>
        </div>
      </div>

      {/* ─── Toolbar & Filters ─── */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 mb-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative w-[360px]">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search workflows by name, description, or tags..."
              className="w-full h-10 pl-10 pr-4 bg-white border border-slate-200 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 transition-all" />
            {searchQuery && <button onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"><X size={14} /></button>}
          </div>
          <div className="flex items-center gap-2">
            <select value={activeStatus} onChange={(e) => setActiveStatus(e.target.value)}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:border-blue-500 cursor-pointer">
              {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}
              className="h-9 px-3 bg-white border border-slate-200 rounded-lg text-sm text-slate-700 focus:outline-none focus:border-blue-500 cursor-pointer">
              {SORT_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="ml-auto flex items-center border border-slate-200 rounded-lg overflow-hidden">
            <button onClick={() => setViewMode('grid')} className={cn('w-9 h-9 flex items-center justify-center transition-all', viewMode === 'grid' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:text-slate-800')}><LayoutGrid size={18} /></button>
            <button onClick={() => setViewMode('list')} className={cn('w-9 h-9 flex items-center justify-center transition-all', viewMode === 'list' ? 'bg-blue-50 text-blue-600' : 'text-slate-500 hover:text-slate-800')}><List size={18} /></button>
          </div>
        </div>
      </div>

      {/* ─── Folder Navigation ─── */}
      <div className="flex items-center gap-2 mb-4 overflow-x-auto no-scrollbar">
        {folders.map((folder) => (
          <button key={folder.id} onClick={() => setActiveFolder(folder.id)}
            className={cn('h-9 px-3.5 rounded-full text-sm font-medium transition-all flex items-center gap-1.5 flex-shrink-0',
              activeFolder === folder.id
                ? 'bg-blue-600 text-white'
                : 'bg-blue-50 border border-blue-200 text-slate-600 hover:bg-blue-100')}>
            {folder.id !== 'all' && <Folder size={14} className={activeFolder === folder.id ? 'text-white' : 'text-blue-600'} />}
            <span>{folder.name}</span>
            <span className={cn('text-[11px]', activeFolder === folder.id ? 'text-white/70' : 'text-slate-400')}>({folder.count})</span>
          </button>
        ))}
      </div>

      {/* ─── Workflow Grid View ─── */}
      <AnimatePresence mode="wait">
        {viewMode === 'grid' && filteredWorkflows.length > 0 && (
          <motion.div key="grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
            {filteredWorkflows.map((wf, i) => {
              const sc = STATUS_CONFIG[wf.status] || STATUS_CONFIG.Idle
              const isSel = selectedItems.has(wf.id)
              return (
                <motion.div key={wf.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, delay: i * 0.06 }} whileHover={{ y: -3 }}
                  className={cn('bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden cursor-pointer hover:shadow-md hover:border-blue-300 relative transition-all duration-200', isSel && 'ring-2 ring-blue-600')}>
                  {/* Thumbnail */}
                  <div className="relative h-[120px] overflow-hidden group" style={{ backgroundColor: `${wf.thumbnailColor}08` }}>
                    <svg className="w-full h-full" viewBox="0 0 200 120">
                      <defs><pattern id={`g${wf.id}`} width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke={`${wf.thumbnailColor}10`} strokeWidth="0.5" /></pattern></defs>
                      <rect width="200" height="120" fill={`url(#g${wf.id})`} />
                      <g opacity="0.3">
                        {wf.nodeRefs.slice(0, Math.min(wf.nodes - 1, 3)).map((_, j) => (
                          <path key={j} d={`M ${44 + j * 30} ${42 + (j % 2) * 26} Q ${62 + j * 30} ${32 + (j % 2) * 20} ${76 + j * 30} ${28 + (j % 2) * 20}`} fill="none" stroke={wf.thumbnailColor} strokeWidth="1.5" />
                        ))}
                      </g>
                      {[{ x: 20, y: 30 }, { x: 80, y: 20 }, { x: 80, y: 60 }, { x: 140, y: 40 }].slice(0, Math.min(wf.nodes, 4)).map((p, j) => (
                        <g key={j}><rect x={p.x} y={p.y} width="24" height="14" rx="3" fill={wf.thumbnailColor} opacity="0.15" stroke={wf.thumbnailColor} strokeWidth="1" /></g>
                      ))}
                    </svg>
                    {/* Status dot */}
                    <div className={cn('absolute top-3 right-3 w-3 h-3 rounded-full border-2 border-white shadow-sm', sc.dot, wf.status === 'Running' && 'animate-pulse')} />
                    {/* Checkbox */}
                    <div onClick={(e) => { e.stopPropagation(); toggleSelection(wf.id) }} className="absolute top-3 left-3">
                      <div className={cn('w-4 h-4 rounded border-2 flex items-center justify-center transition-all cursor-pointer', isSel ? 'bg-blue-600 border-blue-600' : 'border-white/60 bg-black/10 hover:border-white/80')}>
                        {isSel && <CheckCircle2 size={12} className="text-white" />}
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-4">
                    <h3 className="text-[15px] font-semibold text-slate-900 truncate mb-1">{wf.name}</h3>
                    <p className="text-[13px] text-slate-500 leading-relaxed mb-3 line-clamp-2">{wf.description}</p>
                    <div className="flex flex-wrap gap-1 mb-3">
                      {wf.tags.map(tag => (
                        <span key={tag} className="text-[11px] font-medium text-slate-500 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-200">{tag}</span>
                      ))}
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>{wf.nodes} nodes &middot; {wf.connections} conn</span>
                      <span>Edited {wf.lastEdited}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 px-4 py-2.5 border-t border-slate-100">
                    <button onClick={() => {
                      // Toggle status cycle
                      const nextStatus = getNextStatus(wf.status) as WorkflowItem['status']
                      handleSaveWorkflow({ ...wf, status: nextStatus, lastEdited: 'Just now' })
                    }} className="flex-1 h-8 flex items-center justify-center gap-1.5 rounded-md text-xs font-medium text-slate-600 hover:bg-slate-50 transition-colors">
                      <Play size={13} className="text-emerald-500" /> {wf.status === 'Running' ? 'Stop' : 'Run'}
                    </button>
                    <button onClick={() => setEditingWorkflow(wf)} className="flex-1 h-8 flex items-center justify-center gap-1.5 rounded-md text-xs font-medium text-slate-600 hover:bg-blue-50 hover:text-blue-600 transition-colors">
                      <PenTool size={13} /> Edit
                    </button>
                    <button className="w-8 h-8 flex items-center justify-center rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-50 transition-colors">
                      <MoreHorizontal size={16} />
                    </button>
                  </div>
                </motion.div>
              )
            })}
          </motion.div>
        )}

        {/* ─── List View ─── */}
        {viewMode === 'list' && filteredWorkflows.length > 0 && (
          <motion.div key="list" className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
            {/* Header */}
            <div className="flex items-center gap-4 px-4 py-2.5 bg-slate-50/50 border-b border-slate-200 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              <div className="w-4 flex-shrink-0" /><div className="w-3 flex-shrink-0" /><div className="w-12 flex-shrink-0" />
              <div className="flex-1 min-w-0">Name</div>
              <div className="w-48 flex-shrink-0 hidden lg:block">Description</div>
              <div className="w-32 flex-shrink-0 hidden md:flex">Tags</div>
              <div className="w-16 flex-shrink-0 text-center">Nodes</div>
              <div className="w-20 flex-shrink-0 text-right hidden lg:block">Modified</div>
              <div className="w-24 flex-shrink-0 text-right">Actions</div>
            </div>
            {filteredWorkflows.map((wf) => {
              const sc = STATUS_CONFIG[wf.status] || STATUS_CONFIG.Idle
              const isSel = selectedItems.has(wf.id)
              return (
                <div key={wf.id} className="flex items-center gap-4 px-4 h-[72px] border-b border-slate-100 last:border-b-0 hover:bg-blue-50/30 transition-colors">
                  <div className="w-4 flex-shrink-0" onClick={() => toggleSelection(wf.id)}>
                    <div className={cn('w-4 h-4 rounded border-2 flex items-center justify-center transition-all cursor-pointer', isSel ? 'bg-blue-600 border-blue-600' : 'border-slate-300 hover:border-slate-400')}>
                      {isSel && <CheckCircle2 size={12} className="text-white" />}
                    </div>
                  </div>
                  <div className={cn('w-3 h-3 rounded-full flex-shrink-0', sc.dot, wf.status === 'Running' && 'animate-pulse')} />
                  <div className="w-12 flex-shrink-0">
                    <div className="w-12 h-9 rounded-md border border-slate-200 flex items-center justify-center" style={{ backgroundColor: `${wf.thumbnailColor}10` }}>
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: wf.thumbnailColor }} />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-sm font-semibold text-slate-900 truncate block">{wf.name}</span>
                    <span className={cn('inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-full mt-0.5', sc.bgColor, sc.labelColor)}>
                      {wf.status === 'Running' && <Loader2 size={10} className="animate-spin" />}
                      {wf.status === 'Idle' && <CheckCircle2 size={10} />}
                      {wf.status === 'Error' && <AlertCircle size={10} />}
                      {wf.status === 'Paused' && <PauseCircle size={10} />}
                      {wf.status === 'Draft' && <Clock size={10} />}
                      {wf.status}
                    </span>
                  </div>
                  <div className="w-48 flex-shrink-0 hidden lg:block"><span className="text-xs text-slate-500 truncate block">{wf.description}</span></div>
                  <div className="w-32 flex-shrink-0 hidden md:flex items-center gap-1 flex-wrap">
                    {wf.tags.map(tag => <span key={tag} className="text-[10px] font-medium text-slate-500 bg-slate-50 px-1.5 py-0.5 rounded-full border border-slate-200">{tag}</span>)}
                  </div>
                  <div className="w-16 flex-shrink-0 text-center text-xs text-slate-500">{wf.nodes}</div>
                  <div className="w-20 flex-shrink-0 text-right text-[11px] text-slate-400 hidden lg:block">{wf.lastEdited}</div>
                  <div className="w-24 flex-shrink-0 flex items-center justify-end gap-1">
                    <button onClick={() => {
                      const nextStatus = getNextStatus(wf.status) as WorkflowItem['status']
                      handleSaveWorkflow({ ...wf, status: nextStatus, lastEdited: 'Just now' })
                    }} className="w-8 h-8 flex items-center justify-center rounded-md text-emerald-500 hover:bg-emerald-50 transition-colors" title="Toggle Run"><Play size={15} /></button>
                    <button onClick={() => setEditingWorkflow(wf)} className="w-8 h-8 flex items-center justify-center rounded-md text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors" title="Edit"><PenTool size={15} /></button>
                    <button className="w-8 h-8 flex items-center justify-center rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-50 transition-colors" title="More"><MoreHorizontal size={15} /></button>
                  </div>
                </div>
              )
            })}
          </motion.div>
        )}

        {/* ─── Empty State ─── */}
        {filteredWorkflows.length === 0 && (
          <motion.div key="empty" className="flex flex-col items-center justify-center py-16" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.4 }}>
            <div className="w-24 h-24 rounded-full bg-slate-100 flex items-center justify-center mb-4 border border-slate-200"><Search size={40} className="text-slate-300" /></div>
            <h3 className="text-lg font-semibold text-slate-500 mb-1">No Workflows Found</h3>
            <p className="text-sm text-slate-400 mb-4">Try adjusting your search or filters.</p>
            <button onClick={() => { setSearchQuery(''); setActiveFolder('all'); setActiveStatus('All Status') }}
              className="h-9 px-4 rounded-lg text-sm font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 transition-colors">Clear Filters</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Edit Drawer ─── */}
      <AnimatePresence mode="wait">
        {editingWorkflow && (
          <WorkflowEditDrawer
            key={editingWorkflow.id}
            workflow={editingWorkflow}
            onClose={() => setEditingWorkflow(null)}
            onSave={handleSaveWorkflow}
            onDelete={handleDeleteWorkflow}
          />
        )}
      </AnimatePresence>
    </div>
  )
}

// ─── Workflow Edit Drawer ────────────────────────────────────────────────────

function WorkflowEditDrawer({ workflow, onClose, onSave, onDelete }: {
  workflow: WorkflowItem; onClose: () => void
  onSave: (w: WorkflowItem) => Promise<void>; onDelete: (id: string) => Promise<void>
}) {
  const [form, setForm] = useState<WorkflowItem>({ ...workflow })
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [saving, setSaving] = useState(false)
  const [saveError, setSaveError] = useState('')
  const [saveSuccess, setSaveSuccess] = useState(false)

  // Sync form when workflow prop changes
  useEffect(() => {
    setForm({ ...workflow })
    setSaveError('')
    setSaveSuccess(false)
  }, [workflow])

  const sc = STATUS_CONFIG[form.status] || STATUS_CONFIG.Idle

  const handleSave = async () => {
    setSaving(true)
    setSaveError('')
    setSaveSuccess(false)
    try {
      await onSave({ ...form, lastEdited: 'Just now' })
      setSaveSuccess(true)
      // Auto-close after 1.5s so user can see the confirmation
      setTimeout(() => onClose(), 1500)
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Save failed')
    } finally {
      setSaving(false)
    }
  }

  const addTag = () => {
    const tag = prompt('Enter new tag:')
    if (tag && !form.tags.includes(tag)) setForm(p => ({ ...p, tags: [...p.tags, tag] }))
  }

  const removeTag = (tag: string) => setForm(p => ({ ...p, tags: p.tags.filter(t => t !== tag) }))

  return (
    <motion.div className="fixed inset-0 z-[200]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}>
      <div className="absolute inset-0 bg-black/30" onClick={onClose} />
      <motion.div className="absolute right-0 top-0 bottom-0 w-[480px] bg-white shadow-2xl border-l border-slate-200 overflow-y-auto"
        initial={{ x: 480 }} animate={{ x: 0 }} exit={{ x: 480 }} transition={{ duration: 0.3, ease: EASE }}>

        {/* Header */}
        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-9 rounded-md border border-slate-200 flex items-center justify-center" style={{ backgroundColor: `${form.thumbnailColor}10` }}>
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: form.thumbnailColor }} />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-900">Edit Workflow</h2>
              <p className="text-[11px] text-slate-400">{form.folder} &middot; File: <code className="bg-slate-100 px-1 rounded">{form.id}.json</code></p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {saveSuccess && <span className="text-[11px] font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-200">Saved!</span>}
            {saveError && <span className="text-[11px] font-medium text-red-600 bg-red-50 px-2 py-1 rounded-md border border-red-200 max-w-[200px] truncate" title={saveError}>{saveError}</span>}
            <button onClick={handleSave} disabled={saving}
              className="h-8 px-3 rounded-md text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-colors flex items-center gap-1.5 disabled:opacity-50">
              {saving ? <Loader2 size={13} className="animate-spin" /> : <Save size={13} />} {saving ? 'Saving...' : 'Save'}
            </button>
            <button onClick={() => setShowDeleteConfirm(true)}
              className="h-8 px-3 rounded-md text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 transition-colors flex items-center gap-1.5"><Trash2 size={13} /> Delete</button>
            <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"><X size={18} /></button>
          </div>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-5">
          {/* Name */}
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Name</label>
            <input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
              className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500 transition-all" />
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Description</label>
            <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
              rows={3} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500 transition-all resize-none" />
            <p className="text-[11px] text-slate-400 mt-1">Node chain: {form.description}</p>
          </div>

          {/* Status & Folder */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Status</label>
              <select value={form.status} onChange={e => setForm(p => ({ ...p, status: e.target.value as WorkflowItem['status'] }))}
                className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500 cursor-pointer">
                {(['Draft', 'Idle', 'Running', 'Paused', 'Error'] as const).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <div className="flex items-center gap-2 mt-2">
                <span className={cn('inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full', sc.bgColor, sc.labelColor)}>
                  {form.status === 'Running' && <Loader2 size={10} className="animate-spin" />}
                  {form.status}
                </span>
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Folder</label>
              <select value={form.folder} onChange={e => {
                const newFolder = e.target.value
                const colorMap: Record<string, string> = { Transformer: '#0F52BA', SWB: '#0176D3', Customization: '#635BFF' }
                setForm(p => ({ ...p, folder: newFolder, thumbnailColor: colorMap[newFolder] || p.thumbnailColor }))
              }} className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500 cursor-pointer">
                {(['Transformer', 'SWB', 'Customization'] as const).map(f => <option key={f} value={f}>{f}</option>)}
              </select>
              <p className="text-[11px] text-slate-400 mt-1">Moving changes the file location</p>
            </div>
          </div>

          {/* Tags */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Tags</label>
              <button onClick={addTag} className="text-[11px] text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"><PlusIcon size={11} /> Add Tag</button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {form.tags.map(tag => (
                <span key={tag} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-50 text-slate-600 border border-slate-200">
                  {tag}<button onClick={() => removeTag(tag)} className="hover:text-red-500 transition-colors"><X size={10} /></button>
                </span>
              ))}
            </div>
          </div>

          {/* Nodes & Connections */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Node Count</label>
              <input type="number" value={form.nodes} onChange={e => setForm(p => ({ ...p, nodes: parseInt(e.target.value) || 0 }))}
                className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500" />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Connection Count</label>
              <input type="number" value={form.connections} onChange={e => setForm(p => ({ ...p, connections: parseInt(e.target.value) || 0 }))}
                className="w-full h-10 px-3 border border-slate-200 rounded-lg text-sm text-slate-900 focus:outline-none focus:border-blue-500" />
            </div>
          </div>

          {/* Referenced Nodes */}
          <div>
            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 block">Referenced Node IDs ({form.nodeRefs.length})</label>
            <div className="flex flex-wrap gap-1.5">
              {form.nodeRefs.map(ref => (
                <span key={ref} className="text-[11px] px-2.5 py-1 rounded-full bg-blue-50 text-blue-600 border border-blue-100 font-mono">{ref}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Delete Confirmation */}
        <AnimatePresence>
          {showDeleteConfirm && (
            <motion.div className="absolute inset-0 z-20 flex items-center justify-center bg-black/20 backdrop-blur-sm"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <motion.div className="bg-white rounded-xl shadow-xl border border-slate-200 p-6 mx-4 w-[360px]"
                initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center"><AlertCircle size={20} className="text-red-500" /></div>
                  <h3 className="text-base font-semibold text-slate-900">Delete Workflow?</h3>
                </div>
                <p className="text-sm text-slate-500 mb-5">Delete <strong className="text-slate-800">{form.name}</strong>? This removes <code className="bg-slate-100 px-1 rounded">{form.id}.json</code> from the backend.</p>
                <div className="flex items-center gap-2">
                  <button onClick={() => { onDelete(form.id); setShowDeleteConfirm(false) }}
                    className="flex-1 h-9 rounded-lg text-sm font-semibold text-white bg-red-500 hover:bg-red-600 transition-colors">Delete</button>
                  <button onClick={() => setShowDeleteConfirm(false)}
                    className="flex-1 h-9 rounded-lg text-sm font-medium text-slate-600 border border-slate-200 hover:bg-slate-50 transition-colors">Cancel</button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  )
}

function PlusIcon({ size = 16 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14" /><path d="M12 5v14" /></svg>
}
