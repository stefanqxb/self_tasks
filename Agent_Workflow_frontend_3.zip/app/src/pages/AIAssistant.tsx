import { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWorkflowStore } from '@/store/workflowStore';
import { getSystem, getSystemColor } from '@/data/systemCapabilities';
import type { OrchestrationResult } from '@/types/orchestration';
import {
  ChevronLeft, ChevronRight, Plus, MessageSquare, Trash2, Download,
  ArrowUp, PenTool, Code, Check, Sparkles, Wand2,
} from 'lucide-react';

/** Python Agent API base URL (configurable via env) */
const AGENT_API_URL = import.meta.env.VITE_AGENT_URL || 'http://localhost:8000';

interface ChatMessage { id: string; role: 'user' | 'ai' | 'system'; content: string; timestamp: string; }
interface Conversation {
  id: string; title: string; timestamp: string; messages: ChatMessage[];
  orchestration?: OrchestrationResult;
}

const INITIAL_CONVERSATIONS: Conversation[] = [
  { id: '1', title: 'Sales report pipeline', timestamp: '2h ago', messages: [
    { id: '1', role: 'user', content: 'I need to process sales data: read Excel files, aggregate by region, sort by revenue, and export as PDF report', timestamp: '2h ago' },
    { id: '2', role: 'ai', content: '**Interpreted Goal:** Sales Report Pipeline\n\n**Matched System Functions (87% overall confidence):**\n\n1. **Excel** (Transformer) \u2014 97% match\n2. **Aggregate** (Transformer) \u2014 92% match\n3. **Sort Data** (Transformer) \u2014 91% match\n4. **OutputPDF** (Transformer) \u2014 89% match\n\n**Systems Used:** Transformer\n\nAll steps matched Transformer nodes. Click "Apply to Canvas" to deploy.', timestamp: '2h ago' },
    { id: '3', role: 'user', content: 'Add a merge step to combine quarterly files before aggregating', timestamp: '1h ago' },
    { id: '4', role: 'ai', content: 'Updated pipeline:\n\n1. **Excel** \u2014 reads quarterly Excel files\n2. **Merge Rows** \u2014 combines Q1-Q4 data by region\n3. **Aggregate** \u2014 sums revenue per region\n4. **Sort Data** \u2014 descending by revenue\n5. **OutputPDF** \u2014 generates report\n\nAdded Merge Rows between Excel and Aggregate. Ready to apply.', timestamp: '1h ago' },
    { id: '5', role: 'user', content: 'Apply it', timestamp: '45m ago' },
    { id: '6', role: 'system', content: 'Workflow applied to canvas successfully! 5 Transformer nodes created.', timestamp: '45m ago' },
  ]},
  { id: '2', title: 'Invoice + analytics hybrid', timestamp: '1d ago', messages: [
    { id: '7', role: 'user', content: 'Build an invoice processing flow that reads PDF invoices via OCR, validates data, stores in database, and sends daily email reports', timestamp: '1d ago' },
    { id: '8', role: 'ai', content: '**Interpreted Goal:** Invoice Processing + Daily Reporting\n\n**Matched System Functions (84% overall confidence):**\n\n1. **PDF** (Transformer) \u2014 94% match\n2. **OCR Extract** (SWB) \u2014 96% match\n3. **Data Validator** (SWB) \u2014 93% match\n4. **Database Query** (Customization) \u2014 90% match\n5. **Send Email** (Customization) \u2014 92% match\n\n**Systems Used:** Transformer, SWB, Customization\n\nCross-category flow combining all 3 node types. Click "Apply to Canvas" to deploy.', timestamp: '1d ago' },
    { id: '9', role: 'user', content: 'Replace PDF reader with API fetch, invoices come from REST API now', timestamp: '20h ago' },
    { id: '10', role: 'ai', content: 'Updated hybrid flow:\n\n1. **API Request** (SWB) \u2014 fetches invoice JSON from REST API\n2. **OCR Extract** (SWB) \u2014 processes PDF attachments\n3. **Data Validator** (SWB) \u2014 validates invoice schema\n4. **Database Query** (Customization) \u2014 stores validated invoices\n5. **Send Email** (Customization) \u2014 sends daily summary\n\nReplaced PDF input with API Request. All nodes reference real library entries.', timestamp: '20h ago' },
  ]},
];



/** Map system name to node library category */
function getNodeCategory(systemName: string): string {
  const map: Record<string, string> = {
    'SAP ERP': 'Transformer',
    'Salesforce CRM': 'SWB',
    'DocuWise': 'SWB',
    'Slack Connect': 'Customization',
    'Stripe Payments': 'Customization',
  };
  return map[systemName] || 'Transformer';
}

export default function AIAssistant() {
  const navigate = useNavigate();
  const setPendingWorkflow = useWorkflowStore((s) => s.setPendingWorkflow);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS);
  const [activeConvId, setActiveConvId] = useState('1');
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeConv = conversations.find((c) => c.id === activeConvId);
  const messages = activeConv?.messages ?? [];
  const lastOrch = activeConv?.orchestration;

  // Build preview nodes from orchestration or fallback — use system colors
  const previewNodes = lastOrch && lastOrch.steps.length > 0
    ? lastOrch.steps.map((s, i) => ({
        id: String(i + 1), label: s.label, type: getNodeCategory(s.systemName),
        color: getSystemColor(s.systemName),
        x: 20 + i * 130,
      }))
    : [
        { id: '1', label: 'Trigger', type: 'Trigger', color: '#F97316', x: 20 },
        { id: '2', label: 'Process', type: 'Transformer', color: getSystemColor('SAP ERP'), x: 150 },
        { id: '3', label: 'Transform', type: 'SWB', color: getSystemColor('Salesforce CRM'), x: 280 },
        { id: '4', label: 'Output', type: 'Customization', color: getSystemColor('Stripe Payments'), x: 410 },
      ];

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, isTyping]);

  const handleNewChat = useCallback(() => {
    const newId = Date.now().toString();
    const newConv: Conversation = { id: newId, title: 'New Conversation', timestamp: 'Just now', messages: [] };
    setConversations((prev) => [newConv, ...prev]);
    setActiveConvId(newId);
    setInputValue('');
  }, []);

  const handleSwitchConv = useCallback((convId: string) => { setActiveConvId(convId); }, []);

  const handleDeleteConv = useCallback((convId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setConversations(prev => {
      const next = prev.filter(c => c.id !== convId);
      if (next.length === 0) {
        const emptyConv: Conversation = { id: Date.now().toString(), title: 'New Conversation', timestamp: 'Just now', messages: [] };
        setActiveConvId(emptyConv.id);
        return [emptyConv];
      }
      if (activeConvId === convId) setActiveConvId(next[0].id);
      return next;
    });
  }, [activeConvId]);

  const handleClearChat = useCallback(() => {
    setConversations(prev => prev.map(c =>
      c.id === activeConvId ? { ...c, messages: [], orchestration: undefined } : c
    ));
  }, [activeConvId]);

  /* ── Apply to Canvas ── */
  const handleApplyToCanvas = useCallback(() => {
    const orch = activeConv?.orchestration;
    if (!orch || orch.steps.length === 0) {
      const labels = ['Trigger', 'Process', 'Transform', 'Output'];
      const types = ['trigger', 'transformer', 'swb', 'customization'] as const;
      const xfNodes = labels.map((label, i) => ({
        id: `ai-${i}`, type: 'custom' as const,
        position: { x: 100 + i * 250, y: 200 },
        data: { label, nodeType: types[i], description: `${label} node`, parameters: [] },
      }));
      const xfEdges = labels.slice(0, -1).map((_, i) => ({
        id: `ae-${i}`, source: `ai-${i}`, target: `ai-${i + 1}`, type: 'custom' as const,
      }));
      setPendingWorkflow({ nodes: xfNodes, edges: xfEdges, name: activeConv?.title || 'AI Workflow', description: 'AI-generated workflow' });
      navigate('/canvas');
      return;
    }

    const nodeTypeMap: Record<string, 'trigger' | 'transformer' | 'swb' | 'customization'> = {
      'SAP ERP': 'transformer', 'Salesforce CRM': 'swb', 'DocuWise': 'swb',
      'Slack Connect': 'customization', 'Stripe Payments': 'customization',
    };

    const xfNodes = orch.steps.map((step, i) => {
      const sys = getSystem(step.systemId);
      const color = sys?.color || '#94A3B8';
      return {
        id: `orch-${i}`,
        type: step.fallback === 'custom' ? 'custom' : 'group' as const,
        position: { x: 100 + i * 280, y: 250 },
        data: {
          label: step.label, description: step.description,
          systemName: step.systemName, systemColor: color,
          nodeType: nodeTypeMap[step.systemName] || 'swb',
          confidence: step.confidence,
          systemId: step.systemId, functionId: step.functionId,
          subStepCount: step.fallback === 'custom' ? 0 : 4,
          parameters: [{ key: 'system', label: 'System', value: step.systemName, required: false }],
        },
      };
    });

    const xfEdges = orch.steps.slice(0, -1).map((_, i) => ({
      id: `oe-${i}`, source: `orch-${i}`, target: `orch-${i + 1}`, type: 'custom' as const,
    }));

    setPendingWorkflow({
      nodes: xfNodes, edges: xfEdges,
      name: orch.interpretedGoal,
      description: `AI-orchestrated workflow using: ${orch.systemsUsed.join(', ')} (${orch.totalConfidence}% confidence)`,
    });
    navigate('/canvas');
  }, [navigate, setPendingWorkflow, activeConv]);

  const handleSend = useCallback(async () => {
    const text = inputValue.trim();
    if (!text) return;
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: text, timestamp: 'Just now' };
    setConversations(prev => prev.map(c =>
      c.id === activeConvId ? { ...c, messages: [...c.messages, userMsg], title: c.messages.length === 0 ? text.slice(0, 40) : c.title } : c
    ));
    setInputValue('');
    setIsTyping(true);

    try {
      // Call Python Agent Service via HTTP API
      const resp = await fetch(`${AGENT_API_URL}/api/agent/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requirement: text }),
      });

      if (!resp.ok) {
        throw new Error(`Agent service returned ${resp.status}`);
      }

      const result = await resp.json();

      let aiContent: string;
      if (result.steps.length === 0) {
        aiContent = `I analyzed your request but couldn't find matching nodes in the library. I'll create a **custom workflow** for you instead.\n\n**Interpreted Goal:** ${result.interpretedGoal}\n\nNo existing nodes matched your requirements. Custom nodes will be used.`;
      } else {
        const stepList = result.steps.map((s: any, i: number) => `${i + 1}. **${s.nodeName}** (${s.systemName}) \u2014 ${Math.round(s.confidence)}% match \u2014 Node: \`${s.nodeId}\``).join('\n');
        const fallbackNote = result.fallbackMessage ? `\n\n\u26a0\ufe0f ${result.fallbackMessage}` : '';
        aiContent = `**Interpreted Goal:** ${result.interpretedGoal}\n\n**Matched Nodes from Node Library (${result.totalConfidence}% overall confidence):**\n\n${stepList}\n\n**Systems Used:** ${result.systemsUsed.join(', ')}${fallbackNote}\n\nAll nodes are from the Node Library (24 built-in nodes). Click "Apply to Canvas" to deploy.`;
      }

      // Convert Python agent result to frontend OrchestrationResult format
      const orchResult: OrchestrationResult = {
        originalRequest: result.originalRequest,
        interpretedGoal: result.interpretedGoal,
        steps: result.steps.map((s: any) => ({
          id: s.stepOrder.toString(),
          label: s.nodeName,
          description: s.description,
          systemId: s.systemId,
          functionId: s.nodeId,
          systemName: s.systemName,
          functionName: s.nodeName,
          confidence: Math.round(s.confidence),
          params: {},
        })),
        unmetRequirements: result.unmetRequirements || [],
        totalConfidence: result.totalConfidence,
        systemsUsed: result.systemsUsed,
        customNodesNeeded: result.fallbackMessage ? result.steps.length : 0,
      };

      const aiMsg: ChatMessage = { id: (Date.now() + 1).toString(), role: 'ai', content: aiContent, timestamp: 'Just now' };
      setIsTyping(false);
      setConversations(prev => prev.map(c =>
        c.id === activeConvId ? { ...c, messages: [...c.messages, aiMsg], orchestration: orchResult } : c
      ));
    } catch (err) {
      setIsTyping(false);
      const errorMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'ai',
        content: `**Error:** Unable to reach the Workflow Agent service.\n\n_Make sure the Python agent is running:\`python -m uvicorn main:app --port 8000\`_\n\n_Details: ${err instanceof Error ? err.message : 'Unknown error'}_`,
        timestamp: 'Just now',
      };
      setConversations(prev => prev.map(c =>
        c.id === activeConvId ? { ...c, messages: [...c.messages, errorMsg] } : c
      ));
    }
  }, [inputValue, activeConvId]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  return (
    <div className="flex h-full bg-slate-50">
      {/* Sidebar */}
      {sidebarOpen && (
        <aside className="w-[280px] flex flex-col shrink-0 h-full bg-white border-r border-slate-200">
          <div className="p-4 border-b border-slate-100">
            <h3 className="text-[15px] font-semibold text-slate-800 mb-3">Conversations</h3>
            <button onClick={handleNewChat} className="w-full h-9 flex items-center justify-center gap-2 rounded-lg text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 transition-colors">
              <Plus size={16} /> New Chat
            </button>
          </div>
          <div className="flex-1 overflow-y-auto">
            {conversations.map((conv) => (
              <button key={conv.id} onClick={() => handleSwitchConv(conv.id)}
                className={`w-full h-14 px-3 flex items-center gap-3 text-left border-b border-slate-50 transition-all group ${
                  activeConvId === conv.id ? 'bg-blue-50 border-l-[3px] border-l-blue-600' : 'border-l-[3px] border-l-transparent hover:bg-slate-50'
                }`}>
                <MessageSquare size={16} className="shrink-0 text-slate-400" />
                <div className="flex-1 min-w-0">
                  <p className="text-[13px] text-slate-700 truncate font-medium">{conv.title}</p>
                  <p className="text-[11px] text-slate-400">{conv.timestamp} &middot; {conv.messages.length} msgs</p>
                </div>
                <button onClick={(e) => handleDeleteConv(conv.id, e)}
                  className="w-6 h-6 flex items-center justify-center rounded text-slate-300 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-all"
                  title="Delete">
                  <Trash2 size={12} />
                </button>
              </button>
            ))}
          </div>
        </aside>
      )}

      {/* Main Chat */}
      <div className="flex-1 flex flex-col min-w-0 h-full">
        {/* Header */}
        <div className="h-14 border-b border-slate-200 bg-white px-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="w-8 h-8 rounded-md flex items-center justify-center text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition-colors">
              {sidebarOpen ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
            </button>
            <div>
              <h2 className="text-[15px] font-semibold text-slate-800">{activeConv?.title || 'New Conversation'}</h2>
              <p className="text-[11px] text-slate-400">{messages.length} messages</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={handleNewChat} className="w-8 h-8 rounded-md flex items-center justify-center text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors" title="New chat"><Plus size={16} /></button>
            <button onClick={handleClearChat} className="w-8 h-8 rounded-md flex items-center justify-center text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Clear chat"><Trash2 size={16} /></button>
            <button onClick={() => alert('Export feature coming soon!')} className="w-8 h-8 rounded-md flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors" title="Export"><Download size={16} /></button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <div className="w-16 h-16 rounded-2xl bg-blue-100 flex items-center justify-center mb-4">
                <Sparkles size={28} className="text-blue-600" />
              </div>
              <h3 className="text-[18px] font-semibold text-slate-800 mb-2">What workflow would you like to build?</h3>
              <p className="text-[14px] max-w-md text-slate-500">Describe your needs in natural language and I&apos;ll match them to system capabilities and generate a workflow.</p>
            </div>
          ) : (
            <div className="flex flex-col gap-3 max-w-4xl mx-auto">
              {messages.map((msg) => (
                <div key={msg.id} className={msg.role === 'user' ? 'flex justify-end' : msg.role === 'system' ? 'flex justify-center' : 'flex justify-start'}>
                  {msg.role === 'user' && (
                    <div className="max-w-[75%]">
                      <div className="px-4 py-3 rounded-2xl rounded-tr-sm text-sm leading-relaxed whitespace-pre-wrap text-white bg-blue-600">{msg.content}</div>
                      <span className="text-[11px] mt-1 block text-right text-slate-400">{msg.timestamp}</span>
                    </div>
                  )}
                  {msg.role === 'ai' && (
                    <div className="max-w-[85%] flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center shrink-0 mt-1">
                        <Wand2 size={16} className="text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap text-slate-800 shadow-sm">{msg.content}</div>
                        <div className="flex gap-2 mt-2">
                          <button onClick={handleApplyToCanvas} className="h-8 px-3 rounded-lg text-white text-[13px] font-semibold flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 transition-colors shadow-sm">
                            <PenTool size={14} /> Apply to Canvas
                          </button>
                          <button onClick={() => alert('Modify feature coming soon!')}
                            className="h-8 px-3 border border-slate-200 rounded-lg text-[13px] font-medium bg-white text-slate-700 hover:bg-slate-50 transition-colors">
                            Modify
                          </button>
                        </div>
                        <span className="text-[11px] mt-1 block text-slate-400">{msg.timestamp}</span>
                      </div>
                    </div>
                  )}
                  {msg.role === 'system' && (
                    <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 border border-emerald-200">
                      <Check size={14} className="text-emerald-600" />
                      <span className="text-[13px] font-medium text-emerald-700">{msg.content}</span>
                    </div>
                  )}
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-white border border-slate-200 shadow-sm">
                    <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center mr-1">
                      <Wand2 size={12} className="text-blue-600" />
                    </div>
                    <div className="flex gap-1">
                      {[0, 1, 2].map((i) => (
                        <div key={i} className="w-2 h-2 rounded-full bg-blue-500 animate-bounce" style={{ animationDelay: `${i * 0.15}s`, animationDuration: '0.8s' }} />
                      ))}
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input */}
        <div className="border-t border-slate-200 bg-white px-4 py-3 shrink-0">
          <div className="flex gap-2 max-w-4xl mx-auto">
            <textarea value={inputValue} onChange={(e) => setInputValue(e.target.value)} onKeyDown={handleKeyDown}
              placeholder="Describe the workflow you want to create..." rows={1}
              className="flex-1 min-h-[40px] max-h-[160px] px-4 py-2.5 border border-slate-200 rounded-xl text-sm resize-none focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/10 transition-all text-slate-800 bg-slate-50" />
            <button onClick={handleSend} disabled={!inputValue.trim() || isTyping}
              className="w-10 h-10 shrink-0 rounded-full flex items-center justify-center text-white transition-all self-end"
              style={{ background: inputValue.trim() && !isTyping ? '#2563EB' : '#CBD5E1' }}>
              <ArrowUp size={18} />
            </button>
          </div>
          <p className="text-[11px] mt-1.5 text-slate-400 text-center">Enter to send, Shift+Enter for new line</p>
        </div>
      </div>

      {/* Right Preview Panel */}
      <div className="w-[320px] shrink-0 border-l border-slate-200 bg-white flex flex-col overflow-hidden hidden lg:flex">
        <div className="h-12 border-b border-slate-100 px-4 flex items-center shrink-0">
          <span className="text-sm font-semibold text-slate-800">Workflow Preview</span>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {messages.some((m) => m.role === 'ai') ? (
            <div className="space-y-4">
              {/* Dynamic SVG diagram */}
              <div className="rounded-xl border border-slate-200 overflow-hidden p-3 bg-slate-50">
                <svg viewBox={`0 0 ${previewNodes.length * 130 + 20} 140`} className="w-full" style={{ minHeight: 100 }}>
                  {previewNodes.map((n, i) => (
                    <g key={n.id}>
                      <rect x={n.x} y={20} width={110} height={60} rx={8} fill="white" stroke={n.color} strokeWidth={1.5} />
                      <rect x={n.x} y={20} width={4} height={60} rx={2} fill={n.color} />
                      <text x={n.x + 57} y={48} textAnchor="middle" fill="#64748B" fontSize={9} fontFamily="system-ui">{n.type}</text>
                      <text x={n.x + 57} y={64} textAnchor="middle" fill="#1E293B" fontSize={10} fontWeight={600} fontFamily="system-ui">{n.label}</text>
                      {i < previewNodes.length - 1 && <line x1={n.x + 110} y1={50} x2={n.x + 140} y2={50} stroke="#94A3B8" strokeWidth={1.5} strokeDasharray="4 2" />}
                    </g>
                  ))}
                </svg>
              </div>
              {/* Node list */}
              <div className="space-y-1.5">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 mb-2">Nodes ({previewNodes.length})</p>
                {previewNodes.map((n, i) => (
                  <div key={i} className="flex items-center gap-2.5 py-1.5 px-3 rounded-lg bg-slate-50 border border-slate-100">
                    <span className="text-[11px] font-mono w-5 text-center text-slate-400">{i + 1}</span>
                    <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: n.color }} />
                    <span className="text-[13px] font-medium text-slate-700">{n.label}</span>
                  </div>
                ))}
              </div>
              {lastOrch && (
                <div className="bg-blue-50 rounded-lg p-3 border border-blue-100">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] text-blue-600 font-semibold">AI Confidence</span>
                    <span className="text-[11px] text-blue-700 font-bold">{lastOrch.totalConfidence}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-blue-100 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${lastOrch.totalConfidence}%` }} />
                  </div>
                </div>
              )}
              <button onClick={handleApplyToCanvas} className="w-full h-9 rounded-lg text-white text-sm font-semibold flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 transition-colors shadow-sm">
                <PenTool size={15} /> Apply to Canvas
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <div className="w-14 h-14 rounded-2xl bg-slate-100 flex items-center justify-center mb-3">
                <Code size={24} className="text-slate-300" />
              </div>
              <p className="text-sm font-semibold text-slate-500 mb-1">No Workflow Preview</p>
              <p className="text-xs text-slate-400">Start a conversation to see workflow previews</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
