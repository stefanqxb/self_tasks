# NexusFlow - Workflow Assistant

A modern, AI-powered workflow management platform built with React, TypeScript, and Tailwind CSS. NexusFlow enables users to visually design, manage, and optimize data processing workflows through an intuitive canvas-based interface with intelligent AI assistance.

## Features

### 8 Core Pages

| Page | Route | Description |
|------|-------|-------------|
| **Dashboard** | `/` | System overview with stats, recent workflows, AI insights, activity feed, and quick actions |
| **Canvas** | `/#/canvas` | Visual workflow designer with drag-and-drop nodes, connections, mini-map, and configuration panel |
| **Node Library** | `/#/node-library` | Browse 24 nodes across 3 categories (Transformer, SWB, Customization) with search and import |
| **Workflow Manager** | `/#/workflows` | Grid/list view of 9 workflows with folder navigation, status filtering, and search |
| **AI Assistant** | `/#/ai-assistant` | Full-screen AI chat for generating and modifying workflows with natural language |
| **Knowledge Hub** | `/#/knowledge-hub` | AI recommendations, flow summaries, optimization insights, and per-category embed analysis |
| **Settings** | `/#/settings` | Configuration and preferences management |
| **Profile** | `/#/profile` | User profile and activity overview |

### Key Capabilities

- **Visual Workflow Design** - Drag-and-drop canvas with 7 node types, custom edges, zoom/pan controls
- **AI Recommendations** - Describe your needs in natural language, get matched workflows with relevance scoring
- **Apply to Canvas** - One-click deployment of recommended workflows onto the visual canvas
- **Workflow Preview** - Modal popup with React Flow visualization before applying
- **Embed Analysis** - Per-category deep-dive: health scores, success rates, execution times, optimization suggestions
- **24 Built-in Nodes** - Organized into Transformer (8), SWB (8), and Customization (8) categories
- **9 Sample Workflows** - Realistic mock data demonstrating various use cases
- **Light Theme** - Clean, modern light color scheme throughout

## Tech Stack

| Technology | Version | Purpose |
|-----------|---------|---------|
| React | 19 | UI framework |
| TypeScript | 5.x | Type safety |
| Vite | 7.2.4 | Build tool & dev server |
| Tailwind CSS | 3.4.19 | Utility-first styling |
| shadcn/ui | latest | UI component primitives (40+ components) |
| React Flow (xyflow) | latest | Canvas-based node editor |
| Framer Motion | latest | Animations & transitions |
| Zustand | latest | Global state management |
| Lucide React | latest | Icon library |
| Wouter | latest | Lightweight routing |

## Project Structure

```
src/
|-- main.tsx                          # Entry point, HashRouter setup
|-- App.tsx                           # Root layout with routes
|-- index.css                         # Global styles, Tailwind imports, CSS variables
|
|-- pages/                            # 8 page-level components
|   |-- Home.tsx                      # Dashboard overview
|   |-- Canvas.tsx                    # Visual workflow designer
|   |   +-- NodeDetailPanel          # Right sidebar configuration panel
|   |   +-- CanvasToolbar            # Left toolbar (add node, library, minimap)
|   |-- NodeLibrary.tsx               # Node browser with 3-category view
|   |-- Workflows.tsx                 # Workflow manager (grid/list + filters)
|   |-- AIAssistant.tsx               # Full-screen AI chat interface
|   |-- KnowledgeHub.tsx              # 4-tab knowledge center
|   |   +-- AIRecommendTab           # Natural language workflow search
|   |   +-- FlowSummaryTab           # Workflow ecosystem overview
|   |   +-- AIInsightsTab            # Optimization recommendations
|   |   +-- EmbedAnalysisTab         # Per-category deep analysis
|   |-- Settings.tsx                  # App settings
|   |-- Profile.tsx                   # User profile
|
|-- components/                       # Reusable components
|   |-- Layout.tsx                    # App shell (navbar + sidebar + footer + main)
|   |-- Navbar.tsx                    # Top navigation bar
|   |-- Sidebar.tsx                   # Collapsible left sidebar navigation
|   |-- Footer.tsx                    # Bottom status bar
|   |
|   |-- canvas/                       # Canvas sub-components
|   |   |-- CustomNode.tsx            # Custom node renderer (7 types)
|   |   |-- CustomEdge.tsx            # Custom edge with delete button
|   |   |-- types.ts                  # Canvas type definitions
|   |   |-- mockData.ts               # Canvas initial data (6 nodes)
|   |
|   |-- ui/                           # shadcn/ui components (40+)
|       |-- button.tsx
|       |-- card.tsx
|       |-- dialog.tsx
|       |-- input.tsx
|       |-- ...                       # (see full list below)
|
|-- store/
|   |-- workflowStore.ts              # Zustand store for AI->Canvas workflow transfer
|
|-- hooks/
|   |-- use-mobile.ts                 # Responsive mobile detection
|
|-- lib/
|   |-- utils.ts                      # cn() helper (clsx + tailwind-merge)
|
|-- types/
|   |-- (shared TypeScript types)

public/                                 # Static assets
|-- logo-icon.png                       # App logo
|-- ai-avatar.png                       # User avatar
|-- empty-*.png                         # Empty state illustrations
```

### shadcn/ui Components Used

`accordion`, `alert-dialog`, `alert`, `aspect-ratio`, `avatar`, `badge`, `breadcrumb`, `button`, `button-group`, `calendar`, `card`, `carousel`, `chart`, `checkbox`, `collapsible`, `command`, `context-menu`, `dialog`, `drawer`, `dropdown-menu`, `field`, `form`, `hover-card`, `input`, `input-group`, `input-otp`, `item`, `kbd`, `label`, `menubar`, `navigation-menu`, `pagination`, `popover`, `progress`, `radio-group`, `resizable`, `scroll-area`, `select`, `separator`, `sheet`, `sidebar`, `skeleton`, `slider`, `sonner`, `spinner`, `switch`, `table`, `tabs`, `textarea`, `toggle`, `toggle-group`, `tooltip`

## Architecture

### State Management

**Zustand Store** (`src/store/workflowStore.ts`):
- `pendingWorkflow` - Stores workflow data for AI->Canvas transfer
- `setPendingWorkflow()` - Sets workflow from AI Assistant or Knowledge Hub
- `clearPendingWorkflow()` - Clears after Canvas consumes it

**Local State** (React `useState`):
- Each page manages its own UI state (filters, search queries, view modes)
- Canvas manages nodes, edges, viewport, and selected node locally

### Component Hierarchy

```
App.tsx (HashRouter)
  Layout.tsx
    Navbar.tsx
    Sidebar.tsx
    <main>
      <Route> -> Page Component
    </main>
    Footer.tsx
```

### Data Flow

```
User Input (KnowledgeHub/AIAssistant)
  -> setPendingWorkflow() [Zustand Store]
    -> Canvas reads on mount
      -> ReactFlow renders nodes/edges
```

### Canvas Architecture

```
Canvas.tsx
  ReactFlow (node-based editor)
    CustomNode.tsx (7 node type renderers)
    CustomEdge.tsx (edges with delete)
    Background (dot grid)
    MiniMap (overview navigation)
    Controls (zoom/pan)
  NodeDetailPanel.tsx (right sidebar config)
  CanvasToolbar.tsx (left tool buttons)
```

## Node Types

| Type | Color | Icon | Count |
|------|-------|------|-------|
| **trigger** | `#2B7FFF` | Zap | 1 |
| **transformer** | `#10B981` | Table2 | 3 |
| **swb** | `#2B7FFF` | Cpu | 1 |
| **customization** | `#F59E0B` | Settings2 | 1 |
| **output** | `#EC4899` | Mail | 1 |
| **input** | `#8B5CF6` | Upload | 1 |
| **default** | `#94A3B8` | Box | - |

## Workflow Categories

| Category | Nodes | Color | Description |
|----------|-------|-------|-------------|
| **Transformer** | 8 | Emerald | Data transformation: Filter, Sort, Aggregate, Join, Pivot, etc. |
| **SWB** | 8 | Blue | AI/ML services: OCR, LLM, API, Image Recognition, etc. |
| **Customization** | 8 | Amber | Integration: Email, Slack, Webhook, Database, etc. |

## Development

### Prerequisites

- Node.js 20+
- npm or yarn

### Setup

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

### Build Output

Production build outputs to `dist/`:
- `index.html` - Entry point
- `assets/` - JS/CSS chunks (code-split by route)
- `public/` files copied as-is

### Port

Dev server runs on `http://localhost:5173`

## Deployment

Static site deployment from `dist/` folder:

```bash
# Build
npm run build

# Deploy dist/ folder to any static host
# (Netlify, Vercel, GitHub Pages, etc.)
```

## Design Decisions

1. **Light Theme** - Clean, professional appearance with slate-based color palette
2. **HashRouter** - SPA routing without server configuration
3. **Code Splitting** - Each page is a lazy-loaded chunk for performance
4. **Zustand over Context** - Simpler state management for the workflow transfer pattern
5. **React Flow for Canvas** - Industry-standard library for node-based visual editors
6. **shadcn/ui** - Consistent, accessible component primitives
7. **Framer Motion** - Smooth page transitions and micro-interactions

## Browser Support

- Chrome/Edge 90+
- Firefox 90+
- Safari 15+

## License

MIT
