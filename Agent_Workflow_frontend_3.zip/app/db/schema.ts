import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
} from "drizzle-orm/mysql-core";

// Add your tables here. See docs/Database.md for schema examples and patterns.
