"""Workflow Store — file-system based CRUD for Workflow Manager.

Directory layout:
    workflow_lib/
    ├── transformer/
    │   ├── csv-data-pipeline.json
    │   └── ...
    ├── swb/
    │   ├── invoice-ocr-processor.json
    │   └── ...
    └── customization/
        ├── customer-onboarding.json
        └── ...
"""

import json
from pathlib import Path
from typing import Optional

WORKFLOW_LIB_DIR = Path(__file__).parent / "workflow_lib"
CATEGORY_DIRS = ["transformer", "swb", "customization"]


def _ensure_dirs() -> None:
    for cat in CATEGORY_DIRS:
        (WORKFLOW_LIB_DIR / cat).mkdir(parents=True, exist_ok=True)


def _category_dir(category: str) -> Path:
    cat = category.lower()
    if cat == "customization":
        return WORKFLOW_LIB_DIR / "customization"
    elif cat == "swb":
        return WORKFLOW_LIB_DIR / "swb"
    return WORKFLOW_LIB_DIR / "transformer"


# ─── CRUD ──────────────────────────────────────────────────────

def list_workflows() -> list[dict]:
    """Read all workflow JSON files from workflow_lib/ and return as a list."""
    _ensure_dirs()
    workflows = []
    for cat in CATEGORY_DIRS:
        cat_dir = WORKFLOW_LIB_DIR / cat
        if not cat_dir.exists():
            continue
        for f in sorted(cat_dir.glob("*.json")):
            try:
                with open(f, "r", encoding="utf-8") as fp:
                    wf = json.load(fp)
                workflows.append(wf)
            except (json.JSONDecodeError, OSError):
                continue
    return workflows


def get_workflow(wf_id: str) -> Optional[dict]:
    """Find a workflow by its id across all categories."""
    _ensure_dirs()
    for cat in CATEGORY_DIRS:
        f = WORKFLOW_LIB_DIR / cat / f"{wf_id}.json"
        if f.exists():
            with open(f, "r", encoding="utf-8") as fp:
                return json.load(fp)
    return None


def create_workflow(wf: dict) -> dict:
    """Create a new workflow JSON file. Returns the workflow with assigned id."""
    _ensure_dirs()
    wf_id = wf.get("id") or wf["name"].lower().strip().replace(" ", "-").replace("_", "-")
    wf["id"] = wf_id

    folder = wf.get("folder", "Transformer")
    cat_dir = _category_dir(folder)
    file_path = cat_dir / f"{wf_id}.json"

    if file_path.exists():
        raise FileExistsError(f"Workflow '{wf_id}' already exists in {cat_dir.name}")

    with open(file_path, "w", encoding="utf-8") as fp:
        json.dump(wf, fp, indent=2, ensure_ascii=False)

    return wf


def update_workflow(wf_id: str, updates: dict) -> dict:
    """Update an existing workflow. Returns the updated workflow."""
    _ensure_dirs()
    old_wf = get_workflow(wf_id)
    if not old_wf:
        raise FileNotFoundError(f"Workflow '{wf_id}' not found")

    updated = {**old_wf, **updates, "id": wf_id}

    # Handle folder change: move file if folder changed
    old_cat = _category_dir(old_wf.get("folder", "Transformer"))
    new_cat = _category_dir(updated.get("folder", "Transformer"))

    old_path = old_cat / f"{wf_id}.json"
    new_path = new_cat / f"{wf_id}.json"

    with open(new_path, "w", encoding="utf-8") as fp:
        json.dump(updated, fp, indent=2, ensure_ascii=False)

    if old_path != new_path and old_path.exists():
        old_path.unlink()

    return updated


def delete_workflow(wf_id: str) -> None:
    """Delete a workflow by id."""
    _ensure_dirs()
    for cat in CATEGORY_DIRS:
        f = WORKFLOW_LIB_DIR / cat / f"{wf_id}.json"
        if f.exists():
            f.unlink()
            return
    raise FileNotFoundError(f"Workflow '{wf_id}' not found")


def seed_default_workflows() -> int:
    """Seed default workflows if workflow_lib is empty. Returns count seeded."""
    _ensure_dirs()
    existing = list_workflows()
    if existing:
        return 0

    defaults = [
        # ── Transformer (4) ──
        {
            "id": "csv-data-pipeline",
            "name": "CSV Data Pipeline",
            "status": "Running",
            "description": "Filter Rows → Column Mapping → Sort Data → Aggregate → OutputCSV",
            "nodes": 5, "connections": 4,
            "tags": ["Transformer"], "lastEdited": "2h ago",
            "folder": "Transformer", "thumbnailColor": "#0F52BA",
            "nodeRefs": ["filter-rows", "column-mapping", "sort-data", "aggregate", "outputcsv"],
        },
        {
            "id": "customer-data-merge",
            "name": "Customer Data Merge",
            "status": "Idle",
            "description": "Join Tables → Merge Rows → Drop Columns → Sort Data",
            "nodes": 4, "connections": 3,
            "tags": ["Transformer"], "lastEdited": "5h ago",
            "folder": "Transformer", "thumbnailColor": "#0F52BA",
            "nodeRefs": ["join-tables", "merge-rows", "drop-columns", "sort-data"],
        },
        {
            "id": "sales-report-generator",
            "name": "Sales Report Generator",
            "status": "Running",
            "description": "Excel → Aggregate → Merge Rows → Sort Data → OutputPDF",
            "nodes": 5, "connections": 4,
            "tags": ["Transformer"], "lastEdited": "1d ago",
            "folder": "Transformer", "thumbnailColor": "#0F52BA",
            "nodeRefs": ["excel", "aggregate", "merge-rows", "sort-data", "outputpdf"],
        },
        {
            "id": "document-ingestion",
            "name": "Document Ingestion",
            "status": "Idle",
            "description": "PDF → Filter Rows → Column Mapping → Merge Rows → OutputCSV",
            "nodes": 5, "connections": 4,
            "tags": ["Transformer"], "lastEdited": "3d ago",
            "folder": "Transformer", "thumbnailColor": "#0F52BA",
            "nodeRefs": ["pdf", "filter-rows", "column-mapping", "merge-rows", "outputcsv"],
        },
        # ── SWB (3) ──
        {
            "id": "invoice-ocr-processor",
            "name": "Invoice OCR Processor",
            "status": "Running",
            "description": "API Request → OCR Extract → Document Parser → Email to PDF",
            "nodes": 4, "connections": 3,
            "tags": ["SWB"], "lastEdited": "3h ago",
            "folder": "SWB", "thumbnailColor": "#0176D3",
            "nodeRefs": ["api-request", "ocr-extract", "document-parser", "email-to-pdf"],
        },
        {
            "id": "content-generator",
            "name": "Content Generator",
            "status": "Idle",
            "description": "API Request → Data Validator → LLM Prompt → Email to PDF",
            "nodes": 4, "connections": 3,
            "tags": ["SWB"], "lastEdited": "1d ago",
            "folder": "SWB", "thumbnailColor": "#0176D3",
            "nodeRefs": ["api-request", "data-validator", "llm-prompt", "email-to-pdf"],
        },
        {
            "id": "image-recognition-flow",
            "name": "Image Recognition Flow",
            "status": "Error",
            "description": "API Request → Image Recognizer → OCR Extract → Document Parser",
            "nodes": 4, "connections": 3,
            "tags": ["SWB"], "lastEdited": "2d ago",
            "folder": "SWB", "thumbnailColor": "#0176D3",
            "nodeRefs": ["api-request", "image-recognizer", "ocr-extract", "document-parser"],
        },
        # ── Customization (2) ──
        {
            "id": "customer-onboarding",
            "name": "Customer Onboarding",
            "status": "Idle",
            "description": "Webhook → Merge Rows → Filter Rows → LLM Prompt → Send Email",
            "nodes": 5, "connections": 4,
            "tags": ["Customization"], "lastEdited": "2d ago",
            "folder": "Customization", "thumbnailColor": "#635BFF",
            "nodeRefs": ["webhook", "merge-rows", "filter-rows", "llm-prompt", "send-email"],
        },
        {
            "id": "daily-report-automation",
            "name": "Daily Report Automation",
            "status": "Paused",
            "description": "Database Query → Aggregate → OCR Extract → Report Generator → Send Email",
            "nodes": 5, "connections": 4,
            "tags": ["Customization"], "lastEdited": "3d ago",
            "folder": "Customization", "thumbnailColor": "#635BFF",
            "nodeRefs": ["database-query", "aggregate", "ocr-extract", "report-generator", "send-email"],
        },
    ]

    count = 0
    for wf in defaults:
        try:
            create_workflow(wf)
            count += 1
        except FileExistsError:
            pass
    return count
