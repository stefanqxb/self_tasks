"""Node Store — file-system based CRUD for Node Library.

Directory layout:
    node_lib/
    ├── transformer/
    │   ├── filter-rows.json
    │   └── ...
    ├── swb/
    │   ├── ocr-extract.json
    │   └── ...
    └── customization/
        ├── send-email.json
        └── ...

Each node is stored as a single JSON file named by its node_id.
Category must be one of: transformer, swb, customization.
"""

import json
import os
from pathlib import Path
from typing import Optional

# Base directory for node storage
NODE_LIB_DIR = Path(__file__).parent / "node_lib"
CATEGORY_DIRS = ["transformer", "swb", "customization"]


def _ensure_dirs() -> None:
    """Create category directories if they don't exist."""
    for cat in CATEGORY_DIRS:
        (NODE_LIB_DIR / cat).mkdir(parents=True, exist_ok=True)


def _sanitize_id(name: str) -> str:
    """Convert node name to a safe file id."""
    return name.lower().strip().replace(" ", "-").replace("_", "-")


def _category_dir(category: str) -> Path:
    """Map frontend category to directory name."""
    cat = category.lower()
    if cat == "customization":
        return NODE_LIB_DIR / "customization"
    elif cat == "swb":
        return NODE_LIB_DIR / "swb"
    return NODE_LIB_DIR / "transformer"


# ─── CRUD ──────────────────────────────────────────────────────

def list_nodes() -> list[dict]:
    """Read all node JSON files from node_lib/ and return as a list."""
    _ensure_dirs()
    nodes = []
    for cat in CATEGORY_DIRS:
        cat_dir = NODE_LIB_DIR / cat
        if not cat_dir.exists():
            continue
        for f in sorted(cat_dir.glob("*.json")):
            try:
                with open(f, "r", encoding="utf-8") as fp:
                    node = json.load(fp)
                nodes.append(node)
            except (json.JSONDecodeError, OSError):
                continue
    return nodes


def get_node(node_id: str) -> Optional[dict]:
    """Find a node by its id across all categories."""
    _ensure_dirs()
    for cat in CATEGORY_DIRS:
        f = NODE_LIB_DIR / cat / f"{node_id}.json"
        if f.exists():
            with open(f, "r", encoding="utf-8") as fp:
                return json.load(fp)
    return None


def create_node(node: dict) -> dict:
    """Create a new node JSON file. Returns the node with assigned id."""
    _ensure_dirs()
    node_id = node.get("id") or _sanitize_id(node.get("name", "untitled"))
    node["id"] = node_id

    category = node.get("type", "Transformer")
    cat_dir = _category_dir(category)
    file_path = cat_dir / f"{node_id}.json"

    # Prevent overwriting
    if file_path.exists():
        raise FileExistsError(f"Node '{node_id}' already exists in {cat_dir.name}")

    with open(file_path, "w", encoding="utf-8") as fp:
        json.dump(node, fp, indent=2, ensure_ascii=False)

    return node


def update_node(node_id: str, updates: dict) -> dict:
    """Update an existing node. Returns the updated node."""
    _ensure_dirs()
    old_node = get_node(node_id)
    if not old_node:
        raise FileNotFoundError(f"Node '{node_id}' not found")

    # Merge old + new
    updated = {**old_node, **updates, "id": node_id}

    # Handle category change: move file if type changed
    old_cat = _category_dir(old_node.get("type", "Transformer"))
    new_cat = _category_dir(updated.get("type", "Transformer"))

    old_path = old_cat / f"{node_id}.json"
    new_path = new_cat / f"{node_id}.json"

    with open(new_path, "w", encoding="utf-8") as fp:
        json.dump(updated, fp, indent=2, ensure_ascii=False)

    # Remove old file if category changed
    if old_path != new_path and old_path.exists():
        old_path.unlink()

    return updated


def delete_node(node_id: str) -> None:
    """Delete a node by id."""
    _ensure_dirs()
    for cat in CATEGORY_DIRS:
        f = NODE_LIB_DIR / cat / f"{node_id}.json"
        if f.exists():
            f.unlink()
            return
    raise FileNotFoundError(f"Node '{node_id}' not found")


def seed_default_nodes() -> int:
    """Seed default nodes if node_lib is empty. Returns count seeded."""
    _ensure_dirs()
    existing = list_nodes()
    if existing:
        return 0

    defaults = [
        # ── Transformer (11) ──
        {"id": "filter-rows", "name": "Filter Rows", "type": "Transformer", "source": "Built-in",
         "description": "Filter spreadsheet rows based on column conditions and logical expressions",
         "tags": ["Excel", "Filter", "Rows"], "usageCount": 52,
         "parameters": [{"name": "column", "type": "string", "required": True},
                        {"name": "operator", "type": "select", "required": True, "default": "equals"},
                        {"name": "value", "type": "string", "required": True},
                        {"name": "logic", "type": "select", "required": False, "default": "AND"}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Data Pipeline v2", "Report Generator"]},
        {"id": "column-mapping", "name": "Column Mapping", "type": "Transformer", "source": "Built-in",
         "description": "Map and rename columns from one schema to another",
         "tags": ["Excel", "Mapping", "Columns"], "usageCount": 47,
         "parameters": [{"name": "mappings", "type": "object", "required": True},
                        {"name": "strict", "type": "boolean", "required": False, "default": "false"}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Data Pipeline v2", "CRM Sync"]},
        {"id": "drop-columns", "name": "Drop Columns", "type": "Transformer", "source": "Built-in",
         "description": "Remove unnecessary columns from dataset",
         "tags": ["Excel", "Drop", "Columns"], "usageCount": 41,
         "parameters": [{"name": "columns", "type": "array", "required": True},
                        {"name": "inverse", "type": "boolean", "required": False, "default": "false"}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Data Pipeline v2", "Report Generator"]},
        {"id": "sort-data", "name": "Sort Data", "type": "Transformer", "source": "Built-in",
         "description": "Sort rows by one or multiple columns ascending or descending",
         "tags": ["Excel", "Sort", "Order"], "usageCount": 38,
         "parameters": [{"name": "sortBy", "type": "array", "required": True},
                        {"name": "order", "type": "select", "required": False, "default": "ascending"}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Report Generator", "Sales Dashboard"]},
        {"id": "aggregate", "name": "Aggregate", "type": "Transformer", "source": "Built-in",
         "description": "Group data and compute SUM, COUNT, AVG, MIN, MAX per group",
         "tags": ["Excel", "Aggregate", "GroupBy"], "usageCount": 35,
         "parameters": [{"name": "groupBy", "type": "array", "required": True},
                        {"name": "aggregations", "type": "object", "required": True}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Sales Dashboard", "Financial Report"]},
        {"id": "join-tables", "name": "Join Tables", "type": "Transformer", "source": "Built-in",
         "description": "Merge two datasets using inner, left, right, or full join",
         "tags": ["Excel", "Join", "Merge"], "usageCount": 33,
         "parameters": [{"name": "leftKey", "type": "string", "required": True},
                        {"name": "rightKey", "type": "string", "required": True},
                        {"name": "joinType", "type": "select", "required": True, "default": "inner"}],
         "connections": {"input": ["data", "data"], "output": ["data"]},
         "workflows": ["CRM Sync", "Customer 360"]},
        {"id": "merge-rows", "name": "Merge Rows", "type": "Transformer", "source": "Built-in",
         "description": "Combine multiple data rows into one by key, with aggregation options",
         "tags": ["Excel", "Merge", "Combine"], "usageCount": 44, "recommended": True,
         "parameters": [{"name": "mergeKey", "type": "string", "required": True},
                        {"name": "delimiter", "type": "string", "required": False, "default": ","},
                        {"name": "aggregation", "type": "select", "required": False, "default": "concat"}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Customer 360", "Order Fulfillment"]},
        {"id": "excel", "name": "Excel", "type": "Transformer", "source": "Built-in",
         "description": "Read and parse Excel (.xlsx/.xls) files as input data source",
         "tags": ["Input", "Excel", "Read"], "usageCount": 62,
         "parameters": [{"name": "filePath", "type": "string", "required": True},
                        {"name": "sheetName", "type": "string", "required": False, "default": "Sheet1"},
                        {"name": "headerRow", "type": "number", "required": False, "default": "1"}],
         "connections": {"input": [], "output": ["data"]},
         "workflows": ["Data Import", "Report Generator"]},
        {"id": "pdf", "name": "PDF", "type": "Transformer", "source": "Built-in",
         "description": "Read and extract tabular data from PDF files as input source",
         "tags": ["Input", "PDF", "Read"], "usageCount": 38,
         "parameters": [{"name": "filePath", "type": "string", "required": True},
                        {"name": "pageRange", "type": "string", "required": False, "default": "all"},
                        {"name": "extractTables", "type": "boolean", "required": False, "default": "true"}],
         "connections": {"input": [], "output": ["data"]},
         "workflows": ["Document Ingestion"]},
        {"id": "outputcsv", "name": "OutputCSV", "type": "Transformer", "source": "Built-in",
         "description": "Export processed data to CSV file with delimiter and encoding options",
         "tags": ["Output", "CSV", "Export"], "usageCount": 55, "recommended": True,
         "parameters": [{"name": "filePath", "type": "string", "required": True},
                        {"name": "delimiter", "type": "select", "required": False, "default": ","},
                        {"name": "encoding", "type": "select", "required": False, "default": "utf-8"},
                        {"name": "includeHeader", "type": "boolean", "required": False, "default": "true"}],
         "connections": {"input": ["data"], "output": []},
         "workflows": ["Data Export", "Sales Backup"]},
        {"id": "outputpdf", "name": "OutputPDF", "type": "Transformer", "source": "Built-in",
         "description": "Generate formatted PDF report from processed data with templates",
         "tags": ["Output", "PDF", "Report"], "usageCount": 41,
         "parameters": [{"name": "filePath", "type": "string", "required": True},
                        {"name": "template", "type": "string", "required": False},
                        {"name": "title", "type": "string", "required": False},
                        {"name": "orientation", "type": "select", "required": False, "default": "portrait"}],
         "connections": {"input": ["data"], "output": []},
         "workflows": ["Daily Report", "Executive Summary"]},

        # ── SWB (7) ──
        {"id": "ocr-extract", "name": "OCR Extract", "type": "SWB", "source": "Built-in",
         "description": "Extract text from images, scanned documents, PDFs, Word docs, and HTML using OCR",
         "tags": ["OCR", "Vision", "Text", "Extract", "Document"], "usageCount": 53,
         "parameters": [{"name": "documentUrl", "type": "string", "required": True},
                        {"name": "language", "type": "select", "required": False, "default": "eng"},
                        {"name": "format", "type": "select", "required": False, "default": "plain"}],
         "connections": {"input": ["trigger", "data"], "output": ["data"]},
         "workflows": ["Invoice Processor", "Receipt Scanner", "Contract Parser"]},
        {"id": "llm-prompt", "name": "LLM Prompt", "type": "SWB", "source": "Built-in",
         "description": "Send prompts to LLM and receive structured responses",
         "tags": ["LLM", "AI", "GPT"], "usageCount": 28,
         "parameters": [{"name": "prompt", "type": "string", "required": True},
                        {"name": "model", "type": "select", "required": False, "default": "gpt-4"},
                        {"name": "temperature", "type": "number", "required": False, "default": "0.7"}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Content Generator", "Survey Analyzer"]},
        {"id": "email-to-pdf", "name": "Email to PDF", "type": "SWB", "source": "Built-in",
         "description": "Convert email content and attachments to PDF format",
         "tags": ["PDF", "Email", "Convert"], "usageCount": 25,
         "parameters": [{"name": "emailId", "type": "string", "required": True},
                        {"name": "includeAttachments", "type": "boolean", "required": False, "default": "true"}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Document Archive"]},
        {"id": "api-request", "name": "API Request", "type": "SWB", "source": "Built-in",
         "description": "Make REST API calls with authentication and retry logic",
         "tags": ["API", "REST", "HTTP"], "usageCount": 56, "recommended": True,
         "parameters": [{"name": "url", "type": "string", "required": True},
                        {"name": "method", "type": "select", "required": True, "default": "GET"},
                        {"name": "headers", "type": "object", "required": False},
                        {"name": "auth", "type": "select", "required": False, "default": "none"}],
         "connections": {"input": ["trigger", "data"], "output": ["data"]},
         "workflows": ["CRM Sync", "Payment Gateway"]},
        {"id": "data-validator", "name": "Data Validator", "type": "SWB", "source": "Built-in",
         "description": "Validate data against schema, rules, and constraints",
         "tags": ["Validation", "Schema", "Quality"], "usageCount": 37,
         "parameters": [{"name": "schema", "type": "object", "required": True},
                        {"name": "strictMode", "type": "boolean", "required": False, "default": "true"}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Data Pipeline v2", "Lead Import"]},
        {"id": "image-recognizer", "name": "Image Recognizer", "type": "SWB", "source": "Built-in",
         "description": "Detect objects, labels, and faces in images using AI vision",
         "tags": ["Vision", "AI", "Image"], "usageCount": 19,
         "parameters": [{"name": "imageUrl", "type": "string", "required": True},
                        {"name": "detectType", "type": "select", "required": False, "default": "labels"}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Product Catalog", "Quality Inspector"]},
        {"id": "document-parser", "name": "Document Parser", "type": "SWB", "source": "Built-in",
         "description": "Parse structured documents like invoices, receipts, and forms",
         "tags": ["Parser", "Document", "AI"], "usageCount": 27,
         "parameters": [{"name": "documentType", "type": "select", "required": True, "default": "invoice"},
                        {"name": "documentUrl", "type": "string", "required": True}],
         "connections": {"input": ["data"], "output": ["data"]},
         "workflows": ["Invoice Processor", "Form Automation"]},

        # ── Customization (6) ──
        {"id": "send-email", "name": "Send Email", "type": "Customization", "source": "Built-in",
         "description": "Send emails via SMTP with template support and attachments",
         "tags": ["Email", "SMTP", "Notify"], "usageCount": 63,
         "parameters": [{"name": "to", "type": "string", "required": True},
                        {"name": "subject", "type": "string", "required": True},
                        {"name": "body", "type": "string", "required": True},
                        {"name": "template", "type": "select", "required": False}],
         "connections": {"input": ["action"], "output": []},
         "workflows": ["Customer Onboarding", "Daily Report"]},
        {"id": "webhook", "name": "Webhook", "type": "Customization", "source": "Built-in",
         "description": "Receive and process incoming HTTP webhook calls",
         "tags": ["Webhook", "HTTP", "Trigger"], "usageCount": 48,
         "parameters": [{"name": "path", "type": "string", "required": True},
                        {"name": "method", "type": "select", "required": True, "default": "POST"},
                        {"name": "authType", "type": "select", "required": False, "default": "none"}],
         "connections": {"input": [], "output": ["action"]},
         "workflows": ["Payment Gateway", "CRM Webhook"]},
        {"id": "database-query", "name": "Database Query", "type": "Customization", "source": "Built-in",
         "description": "Execute SQL queries on connected databases",
         "tags": ["SQL", "Database", "Query"], "usageCount": 39,
         "parameters": [{"name": "query", "type": "string", "required": True},
                        {"name": "connection", "type": "select", "required": True},
                        {"name": "params", "type": "array", "required": False}],
         "connections": {"input": ["trigger", "action"], "output": ["data"]},
         "workflows": ["Report Generator", "Customer 360"]},
        {"id": "csv-export", "name": "CSV Export", "type": "Customization", "source": "Built-in",
         "description": "Export data to CSV file with delimiter and encoding options",
         "tags": ["CSV", "Export", "File"], "usageCount": 34,
         "parameters": [{"name": "filename", "type": "string", "required": True},
                        {"name": "delimiter", "type": "select", "required": False, "default": ","},
                        {"name": "includeHeader", "type": "boolean", "required": False, "default": "true"}],
         "connections": {"input": ["data"], "output": []},
         "workflows": ["Data Export", "Sales Backup"]},
        {"id": "push-notification", "name": "Push Notification", "type": "Customization", "source": "Built-in",
         "description": "Send push notifications to mobile and web clients",
         "tags": ["Push", "Notify", "Mobile"], "usageCount": 18,
         "parameters": [{"name": "title", "type": "string", "required": True},
                        {"name": "body", "type": "string", "required": True},
                        {"name": "deviceTokens", "type": "array", "required": True}],
         "connections": {"input": ["action"], "output": []},
         "workflows": ["Alert System", "Order Tracker"]},
        {"id": "report-generator", "name": "Report Generator", "type": "Customization", "source": "Built-in",
         "description": "Generate PDF and HTML reports from templates and data",
         "tags": ["Report", "PDF", "Template"], "usageCount": 21, "recommended": True,
         "parameters": [{"name": "templateId", "type": "string", "required": True},
                        {"name": "dataSource", "type": "string", "required": True},
                        {"name": "format", "type": "select", "required": False, "default": "pdf"}],
         "connections": {"input": ["data"], "output": []},
         "workflows": ["Daily Report", "Financial Report"]},
    ]

    count = 0
    for node in defaults:
        try:
            create_node(node)
            count += 1
        except FileExistsError:
            pass
    return count
