"""Node Library data and System Capabilities for the Workflow Agent."""

# ── 5 Target Systems ──────────────────────────────────────────
SYSTEMS = [
    {
        "systemId": "sap-erp",
        "name": "SAP ERP",
        "color": "#0F52BA",
        "category": "ERP",
        "description": "Enterprise resource planning. Handles financial data, procurement, inventory, HR records.",
    },
    {
        "systemId": "salesforce-crm",
        "name": "Salesforce CRM",
        "color": "#0176D3",
        "category": "CRM",
        "description": "Customer relationship management. Leads, opportunities, accounts, contacts, campaigns.",
    },
    {
        "systemId": "docuwise-doc",
        "name": "DocuWise",
        "color": "#F59E0B",
        "category": "Document",
        "description": "Intelligent document processing. OCR, classification, extraction, validation.",
    },
    {
        "systemId": "slack-comm",
        "name": "Slack Connect",
        "color": "#4A154B",
        "category": "Communication",
        "description": "Team communication hub. Channels, direct messages, notifications.",
    },
    {
        "systemId": "stripe-pay",
        "name": "Stripe Payments",
        "color": "#635BFF",
        "category": "Custom",
        "description": "Payment processing. Charges, refunds, subscriptions, invoicing.",
    },
]

# ── Node Library (24 nodes) ───────────────────────────────────
NODES = [
    # Transformer (11) → SAP ERP
    {
        "nodeId": "filter-rows",
        "name": "Filter Rows",
        "type": "Transformer",
        "description": "Filter spreadsheet rows based on column conditions and logical expressions",
        "tags": "excel,filter,rows,data",
        "usageCount": 52,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "column-mapping",
        "name": "Column Mapping",
        "type": "Transformer",
        "description": "Map and rename columns from one schema to another",
        "tags": "excel,mapping,columns,transform",
        "usageCount": 47,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "drop-columns",
        "name": "Drop Columns",
        "type": "Transformer",
        "description": "Remove unnecessary columns from dataset",
        "tags": "excel,drop,columns,clean",
        "usageCount": 41,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "sort-data",
        "name": "Sort Data",
        "type": "Transformer",
        "description": "Sort rows by one or multiple columns ascending or descending",
        "tags": "excel,sort,order,arrange",
        "usageCount": 38,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "aggregate",
        "name": "Aggregate",
        "type": "Transformer",
        "description": "Group data and compute SUM, COUNT, AVG, MIN, MAX per group",
        "tags": "excel,aggregate,groupby,sum,count",
        "usageCount": 35,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "join-tables",
        "name": "Join Tables",
        "type": "Transformer",
        "description": "Merge two datasets using inner, left, right, or full join",
        "tags": "excel,join,merge,combine",
        "usageCount": 33,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "merge-rows",
        "name": "Merge Rows",
        "type": "Transformer",
        "description": "Combine multiple data rows into one by key, with aggregation options",
        "tags": "excel,merge,combine,rows",
        "usageCount": 44,
        "recommended": True,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "excel-input",
        "name": "Excel",
        "type": "Transformer",
        "description": "Read and parse Excel (.xlsx/.xls) files as input data source",
        "tags": "input,excel,read,parse,xlsx",
        "usageCount": 62,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "pdf-input",
        "name": "PDF",
        "type": "Transformer",
        "description": "Read and extract tabular data from PDF files as input source",
        "tags": "input,pdf,read,extract",
        "usageCount": 38,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "output-csv",
        "name": "OutputCSV",
        "type": "Transformer",
        "description": "Export processed data to CSV file with delimiter and encoding options",
        "tags": "output,csv,export,save",
        "usageCount": 55,
        "recommended": True,
        "systemId": "sap-erp",
    },
    {
        "nodeId": "output-pdf",
        "name": "OutputPDF",
        "type": "Transformer",
        "description": "Generate formatted PDF report from processed data with templates",
        "tags": "output,pdf,report,generate",
        "usageCount": 41,
        "systemId": "sap-erp",
    },
    # SWB (7) → Salesforce CRM
    {
        "nodeId": "ocr-extract",
        "name": "OCR Extract",
        "type": "SWB",
        "description": "Extract text from images, scanned documents, PDFs, Word docs, and HTML using OCR",
        "tags": "ocr,vision,text,extract,document,read",
        "usageCount": 53,
        "systemId": "salesforce-crm",
    },
    {
        "nodeId": "llm-prompt",
        "name": "LLM Prompt",
        "type": "SWB",
        "description": "Send prompts to LLM and receive structured responses",
        "tags": "llm,ai,gpt,prompt,generate",
        "usageCount": 28,
        "systemId": "salesforce-crm",
    },
    {
        "nodeId": "email-to-pdf",
        "name": "Email to PDF",
        "type": "SWB",
        "description": "Convert email content and attachments to PDF format",
        "tags": "pdf,email,convert,attachment",
        "usageCount": 25,
        "systemId": "salesforce-crm",
    },
    {
        "nodeId": "api-request",
        "name": "API Request",
        "type": "SWB",
        "description": "Make REST API calls with authentication and retry logic",
        "tags": "api,rest,http,call,fetch",
        "usageCount": 56,
        "recommended": True,
        "systemId": "salesforce-crm",
    },
    {
        "nodeId": "data-validator",
        "name": "Data Validator",
        "type": "SWB",
        "description": "Validate data against schema, rules, and constraints",
        "tags": "validation,schema,quality,check",
        "usageCount": 37,
        "systemId": "salesforce-crm",
    },
    {
        "nodeId": "image-recognizer",
        "name": "Image Recognizer",
        "type": "SWB",
        "description": "Detect objects, labels, and faces in images using AI vision",
        "tags": "vision,ai,image,recognize,detect",
        "usageCount": 19,
        "systemId": "salesforce-crm",
    },
    {
        "nodeId": "document-parser",
        "name": "Document Parser",
        "type": "SWB",
        "description": "Parse structured documents like invoices, receipts, and forms",
        "tags": "parser,document,ai,invoice,form",
        "usageCount": 27,
        "systemId": "salesforce-crm",
    },
    # Customization (6) → Stripe Payments
    {
        "nodeId": "send-email",
        "name": "Send Email",
        "type": "Customization",
        "description": "Send emails via SMTP with template support and attachments",
        "tags": "email,smtp,notify,send",
        "usageCount": 63,
        "systemId": "stripe-pay",
    },
    {
        "nodeId": "webhook",
        "name": "Webhook",
        "type": "Customization",
        "description": "Receive and process incoming HTTP webhook calls",
        "tags": "webhook,http,trigger,endpoint",
        "usageCount": 48,
        "systemId": "stripe-pay",
    },
    {
        "nodeId": "database-query",
        "name": "Database Query",
        "type": "Customization",
        "description": "Execute SQL queries on connected databases",
        "tags": "sql,database,query,select",
        "usageCount": 39,
        "systemId": "stripe-pay",
    },
    {
        "nodeId": "csv-export",
        "name": "CSV Export",
        "type": "Customization",
        "description": "Export data to CSV file with delimiter and encoding options",
        "tags": "csv,export,file,save",
        "usageCount": 34,
        "systemId": "stripe-pay",
    },
    {
        "nodeId": "push-notification",
        "name": "Push Notification",
        "type": "Customization",
        "description": "Send push notifications to mobile and web clients",
        "tags": "push,notify,mobile,alert",
        "usageCount": 18,
        "systemId": "stripe-pay",
    },
    {
        "nodeId": "report-generator",
        "name": "Report Generator",
        "type": "Customization",
        "description": "Generate PDF and HTML reports from templates and data",
        "tags": "report,pdf,template,generate",
        "usageCount": 21,
        "recommended": True,
        "systemId": "stripe-pay",
    },
]


def get_system_by_id(sid: str) -> dict | None:
    """Look up a system by its systemId."""
    for s in SYSTEMS:
        if s["systemId"] == sid:
            return s
    return None


def get_system_color(name: str) -> str:
    """Get a system color by its display name."""
    for s in SYSTEMS:
        if s["name"] == name:
            return s["color"]
    return "#94A3B8"
