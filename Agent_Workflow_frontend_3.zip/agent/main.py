"""Workflow Agent Service — FastAPI HTTP server.

Endpoints:
    Agent:
        POST /api/agent/analyze  -> analyze requirement, return matched nodes
    Node Library (file-system backed):
        GET    /api/nodes           -> list all nodes from node_lib/
        GET    /api/nodes/{id}      -> get a single node
        POST   /api/nodes           -> create a new node (writes JSON file)
        PUT    /api/nodes/{id}      -> update a node (overwrites JSON file)
        DELETE /api/nodes/{id}      -> delete a node (removes JSON file)

Run:
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional

from engine import analyze_requirement
from node_store import (
    list_nodes, get_node, create_node, update_node, delete_node, seed_default_nodes,
)
from workflow_store import (
    list_workflows, get_workflow, create_workflow, update_workflow, delete_workflow, seed_default_workflows,
)

app = FastAPI(
    title="Workflow Agent",
    description="Intelligent workflow orchestration + Node Library file store.",
    version="2.0.0",
)

# ── CORS ───────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Startup: seed defaults if empty ────────────────────────────
@app.on_event("startup")
def on_startup():
    count_nodes = seed_default_nodes()
    if count_nodes:
        print(f"[startup] Seeded {count_nodes} default nodes into node_lib/")
    count_workflows = seed_default_workflows()
    if count_workflows:
        print(f"[startup] Seeded {count_workflows} default workflows into workflow_lib/")


# ════════════════════════════════════════════════════════════════
#  AGENT
# ════════════════════════════════════════════════════════════════

class AnalyzeRequest(BaseModel):
    requirement: str = Field(..., min_length=1)


class AnalyzeResponse(BaseModel):
    originalRequest: str
    interpretedGoal: str
    steps: list[dict]
    totalConfidence: int
    systemsUsed: list[str]
    unmetRequirements: list[str] = []
    fallbackMessage: Optional[str] = None


@app.post("/api/agent/analyze", response_model=AnalyzeResponse)
def analyze(req: AnalyzeRequest):
    result = analyze_requirement(req.requirement)
    return AnalyzeResponse(
        originalRequest=result.originalRequest,
        interpretedGoal=result.interpretedGoal,
        steps=[
            {
                "stepOrder": s.stepOrder,
                "nodeId": s.nodeId,
                "nodeName": s.nodeName,
                "systemId": s.systemId,
                "systemName": s.systemName,
                "systemColor": s.systemColor,
                "nodeType": s.nodeType,
                "confidence": s.confidence,
                "description": s.description,
                "reason": s.reason,
            }
            for s in result.steps
        ],
        totalConfidence=result.totalConfidence,
        systemsUsed=result.systemsUsed,
        unmetRequirements=result.unmetRequirements,
        fallbackMessage=result.fallbackMessage,
    )


# ════════════════════════════════════════════════════════════════
#  NODE LIBRARY (file-system CRUD)
# ════════════════════════════════════════════════════════════════

class NodeParam(BaseModel):
    name: str
    type: str = "string"
    required: bool = False
    default: Optional[str] = None


class NodeConnections(BaseModel):
    input: list[str] = []
    output: list[str] = []


class NodeCreate(BaseModel):
    id: Optional[str] = None
    name: str
    description: str = ""
    type: str  # Transformer | SWB | Customization
    source: str = "Custom"
    tags: list[str] = []
    usageCount: int = 0
    parameters: list[dict] = []
    connections: dict = {"input": ["data"], "output": ["data"]}
    workflows: list[str] = []
    recommended: bool = False


@app.get("/api/nodes")
def nodes_list():
    """Return all nodes from node_lib/ folder."""
    return list_nodes()


@app.get("/api/nodes/{node_id}")
def nodes_get(node_id: str):
    """Get a single node by id."""
    node = get_node(node_id)
    if not node:
        raise HTTPException(status_code=404, detail=f"Node '{node_id}' not found")
    return node


@app.post("/api/nodes")
def nodes_create(payload: NodeCreate):
    """Create a new node JSON file in node_lib/{category}/."""
    try:
        node = create_node(payload.model_dump())
        return {"success": True, "node": node}
    except FileExistsError as e:
        raise HTTPException(status_code=409, detail=str(e))


@app.put("/api/nodes/{node_id}")
def nodes_update(node_id: str, payload: NodeCreate):
    """Update an existing node JSON file."""
    try:
        node = update_node(node_id, payload.model_dump())
        return {"success": True, "node": node}
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.delete("/api/nodes/{node_id}")
def nodes_delete(node_id: str):
    """Delete a node JSON file."""
    try:
        delete_node(node_id)
        return {"success": True, "deleted": node_id}
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ── Health ─────────────────────────────────────────────────────

@app.get("/")
def root():
    return {"status": "ok", "service": "workflow-agent", "version": "2.0.0"}


# ════════════════════════════════════════════════════════════════
#  WORKFLOW MANAGER (file-system CRUD)
# ════════════════════════════════════════════════════════════════

class WorkflowCreate(BaseModel):
    id: Optional[str] = None
    name: str
    description: str = ""
    status: str = "Draft"  # Running | Idle | Error | Paused | Draft
    nodes: int = 0
    connections: int = 0
    tags: list[str] = []
    lastEdited: str = "Just now"
    folder: str = "Transformer"  # Transformer | SWB | Customization
    thumbnailColor: str = "#0F52BA"
    nodeRefs: list[str] = []


@app.get("/api/workflows")
def workflows_list():
    """Return all workflows from workflow_lib/ folder."""
    return list_workflows()


@app.get("/api/workflows/{wf_id}")
def workflows_get(wf_id: str):
    """Get a single workflow by id."""
    wf = get_workflow(wf_id)
    if not wf:
        raise HTTPException(status_code=404, detail=f"Workflow '{wf_id}' not found")
    return wf


@app.post("/api/workflows")
def workflows_create(payload: WorkflowCreate):
    """Create a new workflow JSON file in workflow_lib/{folder}/."""
    try:
        wf = create_workflow(payload.model_dump())
        return {"success": True, "workflow": wf}
    except FileExistsError as e:
        raise HTTPException(status_code=409, detail=str(e))


@app.put("/api/workflows/{wf_id}")
def workflows_update(wf_id: str, payload: WorkflowCreate):
    """Update an existing workflow JSON file."""
    try:
        wf = update_workflow(wf_id, payload.model_dump())
        return {"success": True, "workflow": wf}
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.delete("/api/workflows/{wf_id}")
def workflows_delete(wf_id: str):
    """Delete a workflow JSON file."""
    try:
        delete_workflow(wf_id)
        return {"success": True, "deleted": wf_id}
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ── Health ─────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "healthy", "nodes": len(list_nodes()), "workflows": len(list_workflows())}


# ── Run ────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
