"""Orchestration Engine — matches user requirements to Node Library nodes."""

from dataclasses import dataclass, field
from typing import List

from data import NODES, SYSTEMS, get_system_by_id, get_system_color


@dataclass
class OrchestrationStep:
    stepOrder: int
    nodeId: str
    nodeName: str
    systemId: str
    systemName: str
    systemColor: str
    nodeType: str
    confidence: float
    description: str
    reason: str


@dataclass
class OrchestrationResult:
    originalRequest: str
    interpretedGoal: str
    steps: List[OrchestrationStep] = field(default_factory=list)
    totalConfidence: int = 0
    systemsUsed: List[str] = field(default_factory=list)
    unmetRequirements: List[str] = field(default_factory=list)
    fallbackMessage: str | None = None


def _normalize(text: str) -> str:
    """Lowercase and strip punctuation for comparison."""
    return "".join(ch.lower() if ch.isalnum() else " " for ch in text).strip()


def _tokenize(text: str) -> set:
    """Split into meaningful words (length > 2)."""
    return {w for w in _normalize(text).split() if len(w) > 2}


def analyze_requirement(requirement: str) -> OrchestrationResult:
    """Analyze a user requirement and return matched nodes from the Node Library.

    Scoring rules:
      - Exact phrase match in searchable text  -> +20
      - Node name word appears in requirement   -> +5 / word
      - Tag word appears in requirement         -> +4 / word
      - Description word appears in requirement -> +2 / word (word len > 3)
      - Requirement word appears in searchable  -> +3 / word
      - Usage count > 40                        -> +1
      - Recommended node                        -> +2
    """
    req_lower = requirement.lower()
    req_words = _tokenize(requirement)

    scored = []
    for node in NODES:
        score = 0
        matched = []

        # Build searchable text from node fields
        searchable = (
            f"{node['name']} {node['description']} {node['tags']} {node['type']}"
        ).lower()

        # 1. Exact phrase match (highest weight)
        if req_lower in searchable or searchable in req_lower:
            score += 20
            matched.append("exact-match")

        # 2. Requirement word appears in searchable text
        for word in req_words:
            if word in searchable:
                score += 3
                matched.append(word)

        # 3. Node name word match (high weight)
        name_words = node["name"].lower().split()
        for nw in name_words:
            nw_clean = "".join(ch for ch in nw if ch.isalnum())
            if nw_clean in req_words:
                score += 5
                matched.append(nw_clean)

        # 4. Tag word match
        if node.get("tags"):
            for tw in node["tags"].lower().split(","):
                tw_clean = tw.strip()
                if tw_clean in req_words:
                    score += 4
                    matched.append(tw_clean)

        # 5. Description keyword match (words longer than 3 chars)
        desc_words = _tokenize(node.get("description", ""))
        for dw in desc_words:
            if dw in req_words:
                score += 2
                matched.append(dw)

        # 6. Usage count bonus
        if node.get("usageCount", 0) > 40:
            score += 1

        # 7. Recommended bonus
        if node.get("recommended"):
            score += 2

        scored.append({
            "node": node,
            "score": score,
            "matched": list(dict.fromkeys(matched)),  # dedupe, keep order
        })

    # Sort by score descending
    scored.sort(key=lambda x: x["score"], reverse=True)

    # Take top matches with score > 5
    top = [s for s in scored if s["score"] > 5][:8]

    used_system_names = set()
    steps: List[OrchestrationStep] = []

    for i, item in enumerate(top):
        node = item["node"]
        sys = get_system_by_id(node["systemId"])
        if not sys:
            continue

        used_system_names.add(sys["name"])
        confidence = min(98, max(50, 50 + item["score"] * 4))

        steps.append(
            OrchestrationStep(
                stepOrder=i + 1,
                nodeId=node["nodeId"],
                nodeName=node["name"],
                systemId=sys["systemId"],
                systemName=sys["name"],
                systemColor=sys["color"],
                nodeType=node["type"],
                confidence=confidence,
                description=node["description"],
                reason=f"Matched keywords: {', '.join(item['matched'][:5])}",
            )
        )

    # Fallback: no good matches
    fallback_message = None
    if not steps:
        fallback_message = (
            "No existing nodes strongly match your requirement. "
            "I'll create a custom workflow using placeholder nodes. "
            "Please review and modify as needed."
        )
        # Pick 3 Customization nodes as fallback
        fallback_nodes = [n for n in NODES if n["type"] == "Customization"][:3]
        for i, node in enumerate(fallback_nodes):
            sys = get_system_by_id(node["systemId"])
            if not sys:
                continue
            used_system_names.add(sys["name"])
            steps.append(
                OrchestrationStep(
                    stepOrder=i + 1,
                    nodeId=node["nodeId"],
                    nodeName=node["name"],
                    systemId=sys["systemId"],
                    systemName=sys["name"],
                    systemColor=sys["color"],
                    nodeType=node["type"],
                    confidence=45,
                    description=node["description"],
                    reason="Fallback: no direct match found",
                )
            )

    total_confidence = (
        round(sum(s.confidence for s in steps) / len(steps)) if steps else 0
    )

    interpreted = _interpret_goal(requirement, steps)

    return OrchestrationResult(
        originalRequest=requirement,
        interpretedGoal=interpreted,
        steps=steps,
        totalConfidence=total_confidence,
        systemsUsed=sorted(list(used_system_names)),
        fallbackMessage=fallback_message,
    )


def _interpret_goal(requirement: str, steps: List[OrchestrationStep]) -> str:
    """Generate a short human-readable goal description."""
    if not steps:
        return requirement

    # Extract action words from requirement
    action_words = [
        w
        for w in requirement.lower().split()
        if len(w) > 3
        and w not in {"need", "want", "like", "help", "with", "that", "this", "have", "from", "build", "make", "create"}
    ][:3]

    types = list(dict.fromkeys(s.nodeType for s in steps))
    type_label = "hybrid" if len(types) > 1 else types[0].lower()

    action = " ".join(action_words) or "Automated"
    return f"{action} {type_label} workflow ({len(steps)} steps)"
